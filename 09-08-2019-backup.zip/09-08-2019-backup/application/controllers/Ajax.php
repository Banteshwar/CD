<?php

defined('BASEPATH') OR exit('No direct script access allowed');

//  require_once APPPATH . 'third_party/jcryption/sqAES.php';
//require_once APPPATH . 'third_party/jcryption/JCryption.php';
class Ajax extends MY_Controller {

    private $user;

    public function __construct() {
        parent::__construct();

        $this->user = new Users();
        $this->load->model('hwc_model');
        //global $db;
    }

    function getSelectSDTH() {
       
        if (isset($_POST['action'])) {

            if ($_POST['action'] == 'getDistricts') {
               
                if (isset($_POST['State_ID'])) {
                    
                    //$state_id=$this->input->post('State_ID');

                    //$response['data']['state_name'] = $this->hwc_model->get_statename($state_id);
                    
                    $response['data']['district'] = getDistrictList(intval($_POST['State_ID']));
                   
                    json_encode($response);
                } else {
                    $response['error'] = 'Input state required!!';
                }
            }

            if ($_POST['action'] == 'getTalukas') {
                if (isset($_POST['State_ID']) && isset($_POST['District_ID'])) {
                    $response['data']['talukas'] = getTalukaList(intval($_POST['State_ID']), intval($_POST['District_ID']));
                    if (!isset($_POST['Taluka_ID'])) {
                        $Taluka_ID = '0';
                    } else {
                        $Taluka_ID = $_POST['Taluka_ID'];
                    }
                    $response['data']['healthBlocks'] = getHealthblockList(intval($_POST['State_ID']), intval($_POST['District_ID']), $Taluka_ID);
                    json_encode($response);
                } else {
                    $response['error'] = 'Input state and District required!!';
                }
            }

            if ($_POST['action'] == 'getHealthBlocks') {
                if (isset($_POST['State_ID']) && isset($_POST['District_ID'])) {
                    if (!isset($_POST['Taluka_ID'])) {
                        $Taluka_ID = '0';
                    } else {
                        $Taluka_ID = $_POST['Taluka_ID'];
                    }
                    $response['data']['healthBlocks'] = getHealthblockList(intval($_POST['State_ID']), intval($_POST['District_ID']), $Taluka_ID);
                    json_encode($response);
                } else {
                    $response['error'] = 'Input state and District required!!';
                }
            }
        }
       
        echo json_encode($response); 
    }

    function getModal() {

        extract($_POST);
        global $db;
        $user = $this->user;

        $data = json_decode($DATA, true);
        include 'page/get_modal.php';
    }

    function getHWCForm() {
        global $db;
        extract($_REQUEST);
//        showData($_REQUEST);
        $user = $this->user;
        $this->load->model('Hwc_model');
        if (isset($_POST['DATA'])) {
            $DATA = json_decode($_POST['DATA'], true);
            $NIN_2_HFI = $DATA['NIN_2_HFI'];
        }
        if (isset($NIN_2_HFI) && isValidNIN($NIN_2_HFI)) {
            $data['HWCInfo'] = $this->Hwc_model->getHWCInfo($NIN_2_HFI);
            if (isset($_REQUEST['submit']) && $_REQUEST['submit'] == 'HWC_FORM') {
                $this->load->helper('validation');
                $error = hwcFormValidation($_REQUEST);


                $responseArray = array('status' => 'error', 'status_msg' => error_format($error));
                //showData2($responseArray);
                JSONArrayResponse($responseArray);
            }
        }


        $data['ninID'] = $NIN_2_HFI;
        $data['facility'] = getFacilityInfo($NIN_2_HFI);

        loadLayout('admin/hwc/hwc_form', 'popup', $data);
    }

    function eventProcess() {

        extract($_REQUEST);
        global $db;
        $user = $this->user;

        include 'page/event_process.php';
    }

}
