<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Ambulance2 extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
     
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
       
        $this->load->model('Dashboard_model');
		$this->load->model('programmanager/Ambulance2_model');
		
		 $this->load->model('hwc_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index($year_id='',$q_id='') { 
	
	
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Ambulances', base_url('ambulance/index'));
		
		if($year_id)
		{
		$fin_year = $year_id;
		}
		else{
		$fin_year = getCurrFinYear();
		}	

        if($q_id)
		{
		$fin_querter = $q_id;
		}
		else{
		$fin_querter = getCurrQuarter(); 
		}			
		
		
        
        $data['page_type']='Ambulance';
       // $data['row'] = $this->Ambulance2_model->get_Ambulances();
		
		$data['state']=$this->Ambulance2_model->get_Ambulances_State($fin_year,$fin_querter);
		
		
				       
        loadLayout('programmanager/ambulance/form', 'program_manager', $data);
    }
	
	public function add_form() { 
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Ambulances', base_url('ambulance/index'));
		
		$data['state']=$this->hwc_model->get_state();
        
        $data['page_type']='Ambulance';
      
       
        loadLayout('programmanager/ambulance/form_add', 'program_manager', $data);
    }
	
	public function form_save()
	{ 
	
	
       if (isset($_POST['submit']))
		  {
			
			
        
		  $this->form_validation->set_rules('year_id', 'Year', 'required');
		  $this->form_validation->set_rules('q_id', 'Quarter', 'required');
		  
			 
          if ($this->form_validation->run() == FALSE)
                {
                	    $this->session->set_flashdata('required','Something went wrong. Please try again later.');
					   
                	 	redirect('ambulance2/index/');	
				}    
                else
                {
	             
						
                 $this->Ambulance2_model->saveAmbulances($_POST);
				

				$this->session->set_flashdata("success","Data has been submitted successfully.");
        
			    
				
				//$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('ambulance2/index/'.$this->input->post("year_id").'/'.$this->input->post("q_id"));     
		  
		  }

		  }
	}
	
	public function edit_form($id)
	{
	   $data['state']=$this->hwc_model->get_state();
       $data['value'] = $this->Ambulance_model->getAmbulance_byId($id);
	   
	  // echo print_r($data['value']); die;
	   
	     $data['page_type']='Ambulance';

	    loadLayout('programmanager/ambulance/form_edit', 'program_manager', $data);

	}
	
	public function form_update($id)
	{      
      if (isset($_POST['update']))
		  {
		  	 $data = array
				   (	
				   
				   'state_id'=> $this->input->post('state_name'),
					'e_year'=> $this->input->post('e_year'),
					'e_quarter'=> $this->input->post('e_quarter'),
					'ALS_ambulances_operational'=>$this->input->post('ALS_ambulances_operational'),
					'ALS_ambulances_required'=>$this->input->post('ALS_ambulances_required'),
					'BLS_ambulances_operational'=>$this->input->post('BLS_ambulances_operational'),
					'BLS_ambulances_required'=>$this->input->post('BLS_ambulances_required'),
					'ALS_average_response_time'=>$this->input->post('ALS_average_response_time'),
					'BLS_average_response_time'=>$this->input->post('BLS_average_response_time'),
					'updated_date'=> date("Y-m-d H:i:s"),
					
					'updated_by'=>  (isset($_SESSION['memberID']))

                    
													
			  	);
                
      

		$result = $this->Ambulance2_model->updateAmbulance_byId($id,$data);
	

        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
			
	     }
         redirect(base_url('ambulance/edit_form/'. $id));

		  }
	}
	

public function delete($id)
     {
       $this->db->delete('ambulance_master_table', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('ambulance/index'));
     }
	 
public function change_val_ajax($y_val,$q_val)
     {
		 
		 $data['state']=$this->Ambulance2_model->get_Ambulances_State_ajax($y_val,$q_val);
		 
		//echo print_r($data['state']); die;
		 
		 echo json_encode($data['state']);
		
		
		
		die;
	// $data['state']=$this->Ambulance2_model->get_Ambulances_State($fin_year,$fin_querter);
	 
	 }
  
}
