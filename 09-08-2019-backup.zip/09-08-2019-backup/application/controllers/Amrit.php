<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Amrit extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
     
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
       
        $this->load->model('Dashboard_model');
		$this->load->model('programmanager/Amt_model');
		
		$this->load->model('hwc_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index($year_id='',$month='') { 
	 
        $this->mybreadcrumb->add('Home', base_url('secretary/page/index'));
        $this->mybreadcrumb->add('Amrit', base_url('Amt/index'));
		
		if($year_id){
			$data['fin_year'] = $year_id;
		}else{
			$data['fin_year'] = getCurrYear('Monthly');
		}	

		

        if($month){
			$data['fin_month'] = $month;
		}else{
			$data['fin_month'] = getCurrMonth('Monthly'); 
		}		
			


        $data['page_type']='amrit';
       
		$data['state']  =  $this->Amt_model->get_Amt_State($data['fin_year'],$data['fin_month']);
		//echo "<pre>";print_r($data['state'] );die;
	
        loadLayout('programmanager/Amrit/form', 'program_manager', $data);

    }
	
	
	
	public function form_save(){ 
	
	
	
	$mon=getMonth_old();
	
       if (isset($_POST['submit'])){
		 
		  $this->form_validation->set_rules('year_id','Year', 'required');
		  $this->form_validation->set_rules('month', 'Month', 'required');
		
		  
			 
           if ($this->form_validation->run() == FALSE){
                $this->session->set_flashdata('required','Something went wrong. Please try again later.');	   
                redirect('Amrit/index/');	
		   } else {
	    		//echo "<pre>";print_r($_POST);die;
                $this->Amt_model->saveAmt($_POST);
				$this->session->set_flashdata("success","Data has been submitted successfully for  ".$mon[$_POST['month']]." ".$_POST['year_id'].".");				
                redirect('Amrit/index/'.$this->input->post("year_id").'/'.$this->input->post("month"));
           }

		  }
	}

	 public function deleteamt($id){

     $ss=$this->db->delete('amrit_master_tbl', array('id' => $id));
     
     if($ss){
       echo "1";
     }else{
       echo "0";
     }
    }

	
	 
public function change_val_ajax($y_val,$q_val){
		 
		 $data['state']=$this->Amt_model->get_Amt_State_ajax($y_val,$q_val);		 
		 echo json_encode($data['state']);
		 die;	 
	 }
  
}
