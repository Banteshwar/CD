<?php
// Report all errors except E_NOTICE
ini_set('display_errors',1); 

error_reporting(E_ALL & ~E_NOTICE);

defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends MY_Controller {
    private $user;
    
    public function __construct() {

        parent::__construct();        
       
         $this->load->model('programmanager/Api_model');       
        
        $this->load->library('mybreadcrumb');
        //$this->load->library('smslib');
        $this->load->driver('cache');

    }
  /**
     Save log data.. if API was success full or failed
     Status can be enum('oSucceed', 'Failed', 'Unexpected')
  */
    public function api_call_log($api_name, $call_status, $msg =''){

        $request   = array(
            "API_Name"      => $api_name,
            "call_status"   =>  $call_status,              
            "msg"           =>  $msg
        );
        $result  = $this->Api_model->insertdata("api_call_log",$request);

    }
   public function test() { 
      
       api_call_log('test','Succeed','I am live');
   }
   
   
    public function api_history() 
    { 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Api History', base_url('Api/api_history'));
        
        $data['page_type']='Api';
        $data['row'] = $this->Api_model->apihistory_list();
         
        loadLayout('programmanager/qa/api_history', 'program_manager', $data);
    }
	
	
	
	public function sms_history() 
    { 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Sms History', base_url('Api/api_history'));
        
        $data['page_type']='Api';
        $data['row'] = $this->Api_model->smshistory_list();
         
        loadLayout('programmanager/qa/sms_history', 'program_manager', $data);
    }


public function meraaspataal() { 
    $api_program_name = 'meraaspataal';
    $url = 'https://admin-meraaspataal.nhp.gov.in/api/dashboard-details';

    $ch  = curl_init($url);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
   
    $response = curl_exec($ch);
	
    if (curl_errno($ch)) {
		$error_msg = curl_error($ch);
		
	}
	curl_close($ch);
	
	if (isset($error_msg)) {
		$this->api_call_log($api_program_name,'Unexpected',$error_msg);
		return; // API call was unsuccessful
	} 
	 
		$output_object  =  json_decode($response,true);
		/*echo "<pre> "; 

		print_r($output_object);die;*/
		
		if($output_object){
			
			$this->db->trans_begin();
		
			foreach($output_object as $row){ 
				//print_r($row);
				
				$request   = array(				  
					"name"        =>  $row['name'],
					"score"       =>  $row['score'],
					"type"        =>  $row['type'],
					"color"       =>  $row['color'],
					"created_at"  =>  $row['created_at'],
					"updated_at"  =>  $row['updated_at'],
					"created_at"  =>  $row['created_at'],
					"state_id"    =>  $row['state_id'],					
				); 
				/*if( $row['id'] == 5) {
					echo "hi there";
					unset($request['name']);
					$request['name2'] = "hello";
				} */
						
			   //$result  = $this->Api_model->insertdata("merasptaal_master_table",$request);
			   $result  = $this->Api_model->updatedata("merasptaal_master_table",$request,array("id"=>$row['id']));
			   
			   // if any error occcured in the loop break loop rollback transaction.
			   $error_db = $this->db->error();
			   if($error_db['code'] != 0){
				   break;
			   }
			}  
			
			if($error_db['code'] == 0){
				     // commit if all transaction successfull 
				    $this->db->trans_commit();
					$msg =  "Successfully Updated";
					$this->api_call_log($api_program_name,'Succeed',$msg);
					
			 }else{			
				  // Rollback database transaction if any one failed				
					$this->db->trans_rollback();		 
					$msg = "Database Error. Code: ".$error_db['code']. " Msg: ".$error_db['message']; 
					$this->api_call_log($api_program_name,'Failed',$msg);
 
			 }

			
		   // $result  = $this->Cmha_model->updateapidata($output_object);
		}else{
			$msg =  "Something Went wrong! Data did Not Received.";
			$this->api_call_log($api_program_name,'Unexpected',$msg);
		}
		
}


public function elderly() { 
     $api_program_name = 'elderly';

    $url = 'http://nphce.nhp.gov.in/mis/Api/central_dashboard_kpi';

    $ch  = curl_init($url);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
   
    $response = curl_exec($ch);
	
    if (curl_errno($ch)) {
		$error_msg = curl_error($ch);
		
	}
	curl_close($ch);
	
	if (isset($error_msg)) {
		$this->api_call_log($api_program_name,'Unexpected',$error_msg);
		return; // API call was unsuccessful
	} 
    
    $row  =  json_decode($response,true);
    print_r($row);
	
    if($row){
        
        $request   = array(
            "fa_total"        =>  $row['fund_allocation']['fa_total'],
            "fu_total"        =>  $row['fund_utilization']['fu_total'],
            "no_of_district"  =>  $row['district_count']['no_of_district'],
            "no_of_rgc"       =>  $row['rgc_count']['no_of_rgc'],
            "nca_count"       =>  $row['nca_count'],
            "dh_operational"  =>  $row['dh_operational'],
            "rgc_operational"  =>  $row['rgc_operational']['no_of_rgc'],
            "nca_operational"  =>  $row['nca_operational'],
            "iec_activities_desc"  =>  $row['other_services'][0]['total'],
            "iec_activities"   =>  $row['other_services'][0]['service_desc'],                
            "trainings_desc"  =>  $row['other_services'][1]['service_desc'],
            "trainings_conducted"  =>  $row['other_services'][1]['total'],
            "persons_trained_desc"  =>  $row['other_services'][2]['service_desc'],
            "persons_trained"  =>  $row['other_services'][0]['total'],
            "provide_service_opd"  =>  $row['services'][0]['total'],
            "provide_sesrvice_ipd"  =>  $row['services'][1]['total'],
            "provide_lab_service"  =>  $row['services'][3]['total'],
            "financial_year"    => $row['financial_year'],
        );

     $data   = $this->Api_model->getElederlyData();

     if(!empty($data)){
        $result  = $this->Api_model->updatedata("elderly_master_table_new",$request,array("id"=>$data['id']));

     }else{
        $result  = $this->Api_model->insertdata("elderly_master_table_new",$request);
     }
     
	 $error_db = $this->db->error();
	 if($error_db['code'] == 0){
				$msg =  "Successfully Updated";
				$this->api_call_log($api_program_name,'Succeed',$msg);
	 }else{			
			$msg = "Database Error. Code: ".$error_db['code']. " Msg: ".$error_db['message']; 
			$this->api_call_log($api_program_name,'Failed',$msg);
	 }

       
        
       // $result  = $this->Cmha_model->updateapidata($output_object);
    }else{
        $msg =  "Something Went wrong";
        $this->api_call_log($api_program_name,'Unexpected',$msg);
    }
    curl_close($ch);
}


public function cghs() { 
    $api_program_name = 'cghs';

    $postData = array(
            'lgd_state_code'   => '00',
            'lgd_dist_code'   => '00',
            'nin_hosp_code'   =>'00',
            );

    $curlSecondHandler = curl_init();

    curl_setopt_array($curlSecondHandler, [
    CURLOPT_URL => 'https://cghs.nic.in/cghshfm/hfmdash',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POSTFIELDS => json_encode($postData,true),

    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: XMLCipher.@AESFEBEM@_256_ID_KeyWrap_RCRMRCPENDBILREC'
    ],
	]);

	$response = curl_exec($curlSecondHandler);
	//echo "<pre>";print_r($response);die;
	if (curl_errno($curlSecondHandler)) {
		$error_msg = curl_error($curlSecondHandler);
		
	}
	curl_close($curlSecondHandler);
	
	if (isset($error_msg)) {
		$this->api_call_log($api_program_name,'Unexpected',$error_msg);
		return; // API call was unsuccessful
	} 
	
	$output_object  =  json_decode($response,true);
	//print_r($output_object);die;
	$ss=$output_object['result'][0]['kpi'];
	
  	$kpi_date_time = date("Y-m-d H:i:s",strtotime($output_object['result'][0]['kpi_date_time']));

	//print_r($ss);

	//die;

    if($ss){
		
		$this->db->trans_begin();
		$count = 0;
        foreach($ss as $row){
            $request   = array(
                "kpi_code"        =>  $row['kpi_code'],
                "kpi_desc"       =>  $row['kpi_desc'],
                "kpi_value"       =>  $row['kpi_value'],
				"kpi_date_time"  =>  $kpi_date_time,
            );
            //print_r($request); die;			

            $this->load->model('programmanager/Api_model');
          
           //$result  = $this->Api_model->insertdata("cghs_master_table",$request);
           
            

            $result  = $this->Api_model->updatedata("cghs_master_table",$request,array("kpi_code"=>$row['kpi_code']));
            

           // if any error occcured in the loop break loop rollback transaction.
			$error_db = $this->db->error();
			if($error_db['code'] != 0){
				   break;
			}  
		}
		
		if($error_db['code'] == 0){
				 // commit if all transaction successfull 
				$this->db->trans_commit();
				$msg =  "Successfully Updated";
				$this->api_call_log($api_program_name,'Succeed',$msg);
				
		 }else{			
			  // Rollback database transaction if any one failed				
				$this->db->trans_rollback();		 
				$msg = "Database Error. Code: ".$error_db['code']. " Msg: ".$error_db['message']; 
				$this->api_call_log($api_program_name,'Failed',$msg);

		 }
        
       // $result  = $this->Cmha_model->updateapidata($output_object);
    }else{
        $msg =  "Something Went wrong";
        $this->api_call_log($api_program_name,'Unexpected',$msg);
    }

    //curl_close($ch);
}

public function ors() { 
	
	
	$api_program_name ='ors';

    $postData = array(
            'lgd_state_code'   => '0',
            'lgd_dist_code'   => '0',
            'nin_hosp_code'   =>'0',
            );


    $curlSecondHandler = curl_init();

	curl_setopt_array($curlSecondHandler, [
		CURLOPT_URL => 'http://dashboard.ehospital.gov.in/hfm-kpi/ors',
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_POSTFIELDS => json_encode($postData,true),

		CURLOPT_HTTPHEADER => [
			'Content-Type: application/json',
			
		],
	]);

	$response = curl_exec($curlSecondHandler);
	
	echo 'Response Recieved from ORS server<BR>';
	
	print_r($response); 
	if (curl_errno($curlSecondHandler)) {
			$error_msg = curl_error($curlSecondHandler);
			
		}
	curl_close($curlSecondHandler);
	
	if (isset($error_msg)) {
		$this->api_call_log($api_program_name,'Unexpected',$error_msg);
		return; // API call was unsuccessful
	} 

	$output_object  =  json_decode($response,true);



	$ss=$output_object['result'][0]['kpi'];


    if($output_object){
		
       $this->Api_model->truncate_ors();
        
		 foreach($output_object as $allvalue){
			 
			foreach($allvalue as $statevalue)
			{
				
				$request   = array(
				  "State_code"        =>  $statevalue['lgd_state_code'],
                  "No_of_Hospitals_On_boarded"        =>  $statevalue['kpi'][0]['kpi_value'],
                  "No_of_Total_Appointments"       =>  $statevalue['kpi'][1]['kpi_value'],
                   "No_of_Appointments_Taken_Today"       =>  $statevalue['kpi'][2]['kpi_value'],
				   "kpi_date_time"      =>  $statevalue['kpi_date_time'],
				   "updated_date"       =>  date("Y-m-d H:i:s")
                     );
			
             
			
			
          $result  = $this->Api_model->insertdata_ors($request);
		   
		   
		   // $result  = $this->Api_model->updatedata("ors_master_table",$request,array("kpi_code"=>$row['kpi_code']));

           }
			
		}
		if($result){
			$msg =  "Successfully Inserted";
			$this->api_call_log('ORS','Succeed',$msg);

		}else{
			$msg = "API could not update";
			$this->api_call_log('ORS','Failed',$msg);
		} 

    } else{
        $msg =  "Something Went wrong";
        $this->api_call_log('ORS','Unexpected',$msg);
    }

    //curl_close($ch);

}


public function ehospital() {

	 $api_program_name ='ehospital';
		
		

     $postData = array(
            'lgd_state_code'   => '0',
            'lgd_dist_code'   => '0',
            'nin_hosp_code'   =>'0',
            );



    $curlSecondHandler = curl_init();

	curl_setopt_array($curlSecondHandler, [
		CURLOPT_URL => 'http://dashboard.ehospital.gov.in/hfm-kpi/ehospital',
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_POSTFIELDS => json_encode($postData,true),

		CURLOPT_HTTPHEADER => [
			'Content-Type: application/json',
			
		],
	]);


	$response = curl_exec($curlSecondHandler);
	echo 'Response Recieved from ehospital server<BR>';
	print_r($response); 
	if (curl_errno($curlSecondHandler)) {
			$error_msg = curl_error($curlSecondHandler);
			
		}
	curl_close($curlSecondHandler);
	
	if (isset($error_msg)) {
		$this->api_call_log($api_program_name,'Unexpected',$error_msg);
		return; // API call was unsuccessful
	} 



	$output_object  =  json_decode($response,true);



	$ss=$output_object['result'][0]['kpi'];
	echo "<pre>"; print_r($ss); die;

    if($output_object){
		
       $this->Api_model->truncate_ehospital();
        
		 foreach($output_object as $allvalue){
			 
			foreach($allvalue as $statevalue)
			{
				
				$request   = array(
				  "State_code"        =>  $statevalue['lgd_state_code'],
                  "No_of_Hospitals_On_boarded"        =>  $statevalue['kpi'][0]['kpi_value'],
                  "No_of_Total_Registration"       =>  $statevalue['kpi'][1]['kpi_value'],
                   "No_of_Registration_done_Today"       =>  $statevalue['kpi'][2]['kpi_value'],
				   "kpi_date_time"      =>  $statevalue['kpi_date_time'],
				   "updated_date"       =>  date("Y-m-d H:i:s")
                     );
			
             
			
			
           $result  = $this->Api_model->insertdata_ehospital($request);
		   
		   
		   // $result  = $this->Api_model->updatedata("ors_master_table",$request,array("kpi_code"=>$row['kpi_code']));

            
           
		  

           }
			
		}		 

		if($result){
			$msg =  "Successfully Inserted";
			$this->api_call_log('ehospital','Succeed',$msg);

		}else{
			$msg = "API could not update";
			$this->api_call_log('ehospital','Failed',$msg);
		}  

    } else{
        $msg =  "Something Went wrong";
        $this->api_call_log('ehospital','Unexpected',$msg);
    }

    //curl_close($ch);
}

    /* ------------  twinkle code mental health -------------- */

public function mHealth() { 

	$api_program_name ='mHealth';
    $res  =  $this->Api_model->truncateMdiabetes();
    $url='http://117.239.178.202/newfunction.php?method=mhealthdash';
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($ch);

    if (curl_errno($ch)) {
		$error_msg = curl_error($ch);
	}
	curl_close($ch);
	
	if (isset($error_msg)) {
		$this->api_call_log($api_program_name,'Unexpected',$error_msg);
		return; // API call was unsuccessful
	} 
	
    $output_object  =  json_decode($response,true);
  /* echo "<pre>"; */
    print_r($output_object);
    if($output_object){
		
		$this->db->trans_begin();
         foreach($output_object as $row){
            $this->Api_model->truncateMdiabetes();
            $request   = array(
                "tabacco"        =>  $output_object[0]['num'],
                "diabeties"      =>  $output_object[1]['num']
            );
      //  var_dump($request);die;
       $result  = $this->Api_model->insertdata("tbl_mhealth",$request);
       
            // if any error occcured in the loop break loop rollback transaction.
			$error_db = $this->db->error();
			if($error_db['code'] != 0){
				   break;
			}
		}
		
		if($error_db['code'] == 0){
				 // commit if all transaction successfull 
				$this->db->trans_commit();
				$msg =  "Successfully Updated";
				$this->api_call_log($api_program_name,'Succeed',$msg);
				
		 }else{			
			  // Rollback database transaction if any one failed
				print_r($error_db);
				$this->db->trans_rollback();		 
				$msg = "Database Error. Code: ".$error_db['code']. " Msg: ".$error_db['message']; 
				$this->api_call_log($api_program_name,'Failed',$msg);

		 }
        
       // $result  = $this->Cmha_model->updateapidata($output_object);
     }else{
        $msg =  "Something Went wrong";
        $this->api_call_log($api_program_name,'Unexpected',$msg);
     }

    curl_close($ch);

}
/* ------------ end  ------------- */

   
/*-------------------Start DVDMS API--------------------------------------*/

private function dvdms_apicall($url){
    $api_program_name = 'dvdms';
    
    $username = 'hfm_dvdmscdbrank';
    $password = 'Cdb@87!(';
    
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL , $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    //curl_setopt($ch, CURLOPT_HEADER, 1);
    curl_setopt($ch, CURLOPT_USERPWD, $username . ":" . $password);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    //curl_setopt($ch, CURLOPT_POSTFIELDS, $payloadName);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); 
    $response = curl_exec($ch);
    
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    //print_r($response); 

    if (curl_errno($ch)) {
        echo $error_msg = curl_error($ch);
    }   
    curl_close($ch);
   
    if (isset($error_msg)  ) {
        $this->api_call_log($api_program_name,'Unexpected',$error_msg);
        return; // API call was unsuccessful
    } 
    else if($httpCode >= 400) {
        // if response is not OK
        $msg = 'Error Response code:'.$httpCode.' '.strip_tags($response);
        $this->api_call_log($api_program_name,'Unexpected',$msg);
        return; // API call was unsuccessful
    }
    
    return $response;

}

public function dvdms() { 
    $api_program_name = 'dvdms';
    
    
    $url1 = 'https://cdashboard.dcservices.in/HISUtilities/services/restful/DataService/getDataJSON/25';
    $response1 = $this->dvdms_apicall($url1);



  $output_object1  =  json_decode($response1,true);
   



$res=$output_object1['dataValue'];



    if($res){
        
       $this->Api_model->truncatedvdms();
        
         foreach($res as $allvalue){
          
                $request   = array(
                  "State_ID"       =>  $allvalue[0],
                  "Rank"           =>  $allvalue[1],
                  "State_name"     =>  $allvalue[2],
                  "avg_score"      =>  $allvalue[3]
                );
            
          $result  = $this->Api_model->insertdata("dvdms_master_table",$request);
         
         }
    }


    $url2    = 'https://cdashboard.dcservices.in/HISUtilities/services/restful/DataService/getDataJSON/26';
    $response2 = $this->dvdms_apicall($url2);
    if(!$response2) {
      // API failed
      return;
    }else{
      $request2   = array(
          "data2"        =>  $response2
    );       
       $this->Api_model->updatedata("dvdms_master_table",$request2,array("id"=>1));
    }
    
    $output_object2  =  json_decode($response2,true);
	echo "<pre>";
    print_r($output_object2);die;
}

/*-------------------End DVDMS API--------------------------------------*/  


/* --------------------- twinkle ncd api --------------------------- */


private function ncd_apicall($url){
    $api_program_name = 'ncd';
    
    $name  = 'txnuser';
    $value = 'ho_india';
    
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL , $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($ch, CURLOPT_HEADER,  $name . ":" . $value);
    //curl_setopt($ch, CURLOPT_USERPWD, $name . ":" . $value);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    //curl_setopt($ch, CURLOPT_POSTFIELDS, $payloadName);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); 
    $response = curl_exec($ch);
    
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    //print_r($response); 

    if (curl_errno($ch)) {
        
        echo $error_msg = curl_error($ch);
    }   
    curl_close($ch);
   
    if (isset($error_msg)  ) {
        
        $this->api_call_log($api_program_name,'Unexpected',$error_msg);
        return; // API call was unsuccessful
    } 
    else if($httpCode >= 400) {
        
        // if response is not OK
        $msg = 'Error Response code:'.$httpCode.' '.strip_tags($response);
        $this->api_call_log($api_program_name,'Unexpected',$msg);
        return; // API call was unsuccessful
    }
    
    return $response;

}

public function ncd() { 
    $api_program_name = 'ncd';
    
    
    $url1 = 'http://10.189.10.75:8067/custom-summary?locationType=COUNTRY&locationId=1&isSpecific=yes&summaryType=dashboardLandingPage&gender=All&dashboardtype=all';
    $response1 = $this->ncd_apicall($url1);
    $output_object1  =  json_decode($response1,true);

    
    if(!$response1) {
      // API failed 
      return;
    }else{
        $request1   = array(
           "data1"        =>  $response1
        );
          $this->Api_model->updatedata("ncd_master_table",$request1,array("id"=>1));
    }
    
  
    
    $output_object1  =  json_decode($response1,true);
    echo "<pre>";
    print_r($output_object1);die;

  
}


/* ------------------------- end ------------------------------ */





/*------------------Start PMssy Rocky-------------------------------------- */


public function pmssy() {



	$url="https://dashboard.nhp.gov.in/pmssy/pms/api/centraldashboard";
        $username="nhp";
        $password="Pq@mk82ky#Z";
        $ch = curl_init($url);
        $ch_post_data = array();
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, TRUE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        $rc = curl_exec($ch);
		echo "PMSSY API Response: ";
		print_r($rc);
        if ($rc) {
            $rc= json_decode($rc,true);
            echo "<pre>"; print_r($rc); die;
			
			foreach($rc as $row){
            $request   = array(
                "pid"        =>  $row['pid'],
                "project"       =>  $row['project'],
                "state"       =>  $row['state'],
				"location"       =>  $row['location'],
				//"dcid"       =>  $row['dcid'],
				//"scid"       =>  $row['scid'],
				"type"       =>  $row['type'],
				"phid"       =>  $row['phid'],
				"phase"       =>  $row['phase'],
				"typename"       =>  $row['typename'],
                "sanction_cost"       =>  $row['sanction_cost'],
                "sanction_startdt"       =>  $row['sanction_startdt'],
                "sanction_enddt"       =>  $row['sanction_enddt'],
				"approvedcost"       =>  $row['approvedcost'],
				//"emergencybeds"       =>  $row['emergencybeds'],
				//"privatebeds"       =>  $row['privatebeds'],
				//"sspcount"       =>  $row['sspcount'],
				//"icu"       =>  $row['icu'],
				//"ots"       =>  $row['ots'],
				//"cathlabs"       =>  $row['cathlabs'],
				//"normalbeds"       =>  $row['normalbeds'],
				//"ssp_details"       =>  $row['ssp_details'],
				//"other_details"       =>  $row['other_details'],
				//"pg_seats"       =>  $row['pg_seats'],
				//"dialysis_beds"       =>  $row['dialysis_beds'],
				//"ssp_beds"       =>  $row['ssp_beds'],
				//"totalbeds"       =>  $row['totalbeds'],
				"project_status"       =>  $row['project_status'],
				"opd_status"       =>  $row['opd_status'],
				"mc_status"       =>  $row['mc_status'],
				"phy_progress"       =>  $row['phy_progress'],
				//"fin_progress"       =>  $row['fin_progress'],
            );
			$this->load->model('programmanager/Api_model');
			
			$fetch  = $this->Api_model->fetchdata("pmssy_api_table",$row['pid']);
			if($fetch)
			{
				$result  = $this->Api_model->updatedata("pmssy_api_table",$request,array("pid"=>$row['pid']));
			}
            else{
				$result  = $this->Api_model->insertdata("pmssy_api_table",$request);
			}				
			//echo $fetch; die;
			
			//$result  = $this->Api_model->insertdata("pmssy_api_table",$request);
           
            

            //$result  = $this->Api_model->updatedata("pmssy_api_table",$request,array("pid"=>$row['pid']));

            
			
			
			}
			if($result){
                $msg =  "Successfully Inserted";
                $this->api_call_log('pmssy','Succeed',$msg);

            }else{
                $msg = "API could not update";
                $this->api_call_log('pmssy','Failed',$msg);
            }
			
			
        };
        curl_close($ch);


    

    //curl_close($ch);
    }
	
	
	/* function api() {
        $url="https://dashboard.nhp.gov.in/pmssy/pms/api/centraldashboard";
        $username="nhp";
        $password="Pq@mk82ky#Z";
        $ch = curl_init($url);
        $ch_post_data = array();
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, TRUE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        $rc = curl_exec($ch);
        if ($rc) {
            $rc= json_decode($rc,true);
            print_r($rc);
        };
        curl_close($ch);
    } */

/*----------------- End Pmssy Rocky-----------------------------------------*/  



 /*public function rch() { 
     
    $api_program_name ='RCH';
   
    
    $url = 'https://rchrpt.nhm.gov.in/DashBoard_RCHRPT_REL/DashBoard/DashBoardCountsDetails?Api_Token=QX9Aw8/T+tpdp/XkSXxTLg==&Date=2019-07-15&Statecode=-1';


    $ch  = curl_init($url);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
   

    $response = curl_exec($ch);
   

    if (curl_errno($ch)) {
        $error_msg = curl_error($ch);
    }
    curl_close($ch);
    
    if (isset($error_msg)) {
        $this->api_call_log($api_program_name,'Unexpected',$error_msg);
        return; 
    } 
        
    $output_object  =  json_decode($response,true);

    $kpidataarray   =  $output_object['result'];
   
    
    if($kpidataarray){
        $this->db->trans_begin();
        
        foreach($kpidataarray as $row){
            
            foreach($row['kpi'] as $val){
                $request   = array(
                    "lgd_state_code"     =>  $row['lgd_state_code'],
                    "kpi_date_time"      =>  date('Y-m-d',strtotime($row['kpi_date_time'])),
                    "kpi_code"           =>  $val['kpi_code'],
                    "kpi_desc"           =>  $val['kpi_desc'],
                    "kpi_value"          =>  $val['kpi_value']
                );
                $this->load->model('programmanager/Api_model');

                $result  = $this->Api_model->insertdata("rch_master_table",$request);
               
                $error_db = $this->db->error();
                if($error_db['code'] != 0){
                       break;
                }
            }
           
        }
        
        if($error_db['code'] == 0){
              
                $this->db->trans_commit();
                $msg =  "Successfully Updated";
                $this->api_call_log($api_program_name,'Succeed',$msg);
                
         }else{         
            
                print_r($error_db);
                $this->db->trans_rollback();         
                $msg = "Database Error. Code: ".$error_db['code']. " Msg: ".$error_db['message']; 
                $this->api_call_log($api_program_name,'Failed',$msg);

         }
        
     
     }else{
        $msg =  "Something Went wrong";
        $this->api_call_log($api_program_name,'Unexpected',$msg);
     }

    }  */



    public function rch() {
		
     $api_program_name ='RCH';
     $postData = array(
            'lgd_state_code'   => '00',
            'kpi_date_time'   => '7/17/2019 2:55:20 PM',
            );

    $url = 'https://rchrpt.nhm.gov.in/DashBoard_RCHRPT_REL/DashBoard/DashBoardCountsDetails?Api_Token=QX9Aw8/T+tpdp/XkSXxTLg==&Date=2019-07-15&Statecode=-1';

    $ch  = curl_init($url);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
   

    $response = curl_exec($ch);
   

    if (curl_errno($ch)) {
        $error_msg = curl_error($ch);
    }
    curl_close($ch);
    
    if (isset($error_msg)) {
        $this->api_call_log($api_program_name,'Unexpected',$error_msg);
        return; 
    } 

	$output_object  =  json_decode($response,true);

	//print_r($output_object  );

	$ss=$output_object['result'][0]['kpi'];
	echo "RCH";

    if($output_object){
        
       $this->Api_model->truncate_rch();
        
         foreach($output_object as $allvalue){
             
            foreach($allvalue as $statevalue)
            {
                
                $request   = array(
                  "State_code"         =>  $statevalue['lgd_state_code'],
                  "kpi_date"           =>  $statevalue['kpi_date_time'],
                  "No_of_Eligible_Couple_Registered"        =>  $statevalue['kpi'][0]['kpi_value'],
                  "No_of_Pregnant_Woman_Registered"       =>  $statevalue['kpi'][1]['kpi_value'],
                   "No_of_Children_Registered"       =>  $statevalue['kpi'][2]['kpi_value'],
                    "No_of_Health_Providers"       =>  $statevalue['kpi'][3]['kpi_value'],
                   "updated_date"       =>  date("Y-m-d H:i:s")
                     );
            
             
            
            
          $result  = $this->Api_model->insertdata("rch_master_table",$request);
           
           
           // $result  = $this->Api_model->updatedata("ors_master_table",$request,array("kpi_code"=>$row['kpi_code']));

            

           }
            
		}
		if($result){
			$msg =  "Successfully Inserted";
		   $this->api_call_log($api_program_name,'Succeed',$msg);

		}else{
			$msg = "API could not update";
			$this->api_call_log($api_program_name,'Failed',$msg);
		}

        }
        
       // $result  = $this->Cmha_model->updateapidata($output_object);
    else{
        $msg =  "Something Went wrong";
        $this->api_call_log($api_program_name,'Unexpected',$msg);
    }


}


/*------------------------PMJAY API-------------------------*/

public function pmJay() {

    $api_program_name = 'PMJAY';
    $postData = array(
            'stateCode' => '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36',
    );

    $curlSecondHandler = curl_init();

    curl_setopt_array($curlSecondHandler, [
        CURLOPT_URL => 'https://testapis.abnhpm.gov.in/nhpmapi/v0.2/apis/getchireport',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS => json_encode($postData,true),
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',           
        ],
    ]);

    $response = curl_exec($curlSecondHandler);
    echo "pmJay API response:"; 
	echo  $response;
    $test     = simplexml_load_string($response);

    $json     = json_encode($test);
    $arr      = json_decode($json,true);

    //echo "<pre>";print_r($arr['item']);die;

    if (curl_errno($curlSecondHandler)) {
        $error_msg = curl_error($curlSecondHandler);        
    }
    curl_close($curlSecondHandler);
    
    if (isset($error_msg)) {
        $this->api_call_log($api_program_name,'Unexpected',$error_msg);
        return; // API call was unsuccessful
    } 
        
    $ss     =   $arr['item'];

    $res  =  $this->Api_model->truncatePMJAY();
    if($ss){
        $this->db->trans_begin();
        
        foreach($ss as $row){
            if($row['response'] == 'Invalid stateCode') { 
                 $this->api_call_log($api_program_name,'Unexpected',print_r($row,true));
                continue;
            }
        
            $request   = array(
                "state_id"                      =>  $row['stateCode'],
                "no_ecards_generated"           =>  $row['countEcardsApproved'],
                "no_pre_authorizations"         =>  $row['countPreauthInitiated'],
                "hospitals_empanelled_scheme"   =>  $row['countHospApproved']
            );

            $result  = $this->Api_model->insertdata("pmjay_master_table",$request);

            // if any error occcured in the loop break loop rollback transaction.
            $error_db = $this->db->error();
            if($error_db['code'] != 0){
                   break;
            }
        }
        
        if($error_db['code'] == 0){
                 // commit if all transaction successfull 
                $this->db->trans_commit();
                $msg =  "Successfully Updated";
                $this->api_call_log($api_program_name,'Succeed',$msg);
                
         }else{         
              // Rollback database transaction if any one failed                
                $this->db->trans_rollback();         
                $msg = "Database Error. Code: ".$error_db['code']. " Msg: ".$error_db['message']; 
                $this->api_call_log($api_program_name,'Failed',$msg);

         }
        
       // $result  = $this->Cmha_model->updateapidata($output_object);
    }else{
        $msg =  "Something Went wrong";
        $this->api_call_log($api_program_name,'Unexpected',$msg);
    }

}

/*-------------------------END PMJAY API -----------------------------*/





     

}
