<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
        
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
       
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }


    public function index() { 
     
    $url = 'https://admin-meraaspataal.nhp.gov.in/api/dashboard-details';

    $ch  = curl_init($url);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
   
    $response = curl_exec($ch);
    curl_close($ch);
    
    $output_object  =  json_decode($response,true);
    /*echo "<pre>";
    print_r($output_object);die;*/
    if($output_object){
        foreach($output_object as $row){
            $request   = array(
                "name"        =>  $row['name'],
                "score"       =>  $row['score'],
                "type"        =>  $row['type'],
                "color"       =>  $row['color'],
                "created_at"  =>  $row['created_at'],
                "updated_at"  =>  $row['updated_at'],
                "state_id"    =>  $row['state_id'],
            );


            $this->load->model('programmanager/Api_model');
        
           // $result  = $this->Api_model->insertdata("merasptaal_master_table",$request);
           
            $result  = $this->Api_model->updatedata("merasptaal_master_table",$request,array("id"=>$row['id']));
            if($result){
                echo "Successfully Updated";

            }else{
                echo "Something Went Wrong";
            }
        }
        
       // $result  = $this->Cmha_model->updateapidata($output_object);
    }else{
        echo "Something Went wrong";
    }

    curl_close($ch);
    }



    /* ------------  twinkle code mental health -------------- */

public function mHealth() { 

    $url='http://117.239.178.202/newfunction.php?method=mhealthdash';
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
   
    $response = curl_exec($ch);
    curl_close($ch);
    
    $output_object  =  $response;
    //var_dump($output_object);die;
    if($output_object){

        $this->load->model('programmanager/Api_model');
        
        $result  = $this->Api_model->insertapidata($output_object);

        if($result){
            echo "Successfully Inserted";

        }else{
            echo "Something Went Wrong";
        }
       // $result  = $this->Cmha_model->updateapidata($output_object);
    }else{
        echo "Something Went wrong";
    }

    curl_close($ch);

}
/* ------------ end  ------------- */

   
  

    
     

}
