<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends MY_Controller {
   
    public function __construct() {

        parent::__construct();
        
              
        $this->load->library('mybreadcrumb');
        //$this->load->library('smslib');
        $this->load->driver('cache');
        $this->load->model('programmanager/Api_model');
    }
  /**
     Save log data.. if API was success full or failed
     Status can be enum('Succeed', 'Failed', 'Unexpected')
  */
    public function api_call_log($api_name, $call_status, $msg =''){

        $request   = array(
            "API_Name"      => $api_name,
            "call_status"   =>  $call_status,              
            "msg"           =>  $msg
        );
        $result  = $this->Api_model->insertdata("api_call_log",$request);

    }
   public function test() { 
      
       $this->api_call_log('test','Succeed','I am live');
	   echo "hi"; 
   }


    public function index() { 
     

    $url = 'https://admin-meraaspataal.nhp.gov.in/api/dashboard-details';

    $ch  = curl_init($url);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
   
    $response = curl_exec($ch);
    curl_close($ch);
    
    $output_object  =  json_decode($response,true);
    /*echo "<pre>";
    print_r($output_object);die;*/
    if($output_object){
        foreach($output_object as $row){
            $request   = array(
                "name"        =>  $row['name'],
                "score"       =>  $row['score'],
                "type"        =>  $row['type'],
                "color"       =>  $row['color'],
                "created_at"  =>  $row['created_at'],
                "updated_at"  =>  $row['updated_at'],
                "state_id"    =>  $row['state_id'],
            );


            $this->load->model('programmanager/Api_model');
        
           //$result  = $this->Api_model->insertdata("merasptaal_master_table",$request);
           
            

            $result  = $this->Api_model->updatedata("merasptaal_master_table",$request,array("id"=>$row['id']));

            if($result){
                $msg =  "Successfully Updated";
                api_call_log('meraaspataal','Succeed',$msg);

            }else{
                $msg = "API could not update";
                api_call_log('meraaspataal','Failed',$msg);
            }

        }
        
       // $result  = $this->Cmha_model->updateapidata($output_object);
    }else{
        $msg =  "Something Went wrong";
        api_call_log('meraaspataal','Unexpected',$msg);
    }

    curl_close($ch);
    }



    /* ------------  twinkle code mental health -------------- */

public function mHealth() { 

    $url='http://117.239.178.202/newfunction.php?method=mhealthdash';
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
   
    $response = curl_exec($ch);
    curl_close($ch);
    
    $output_object  =  json_decode($response,true);
   /* echo "<pre>";
    print_r($output_object);die;*/
    if($output_object){

         foreach($output_object as $row){
            $request   = array(
                "num"        =>  $row['num']
            );


        $this->load->model('programmanager/Api_model');
        
        $result  = $this->Api_model->insertdata("tbl_mhealth",$request);

        if($result){
            echo "Successfully Inserted";

        }else{
            echo "Something Went Wrong";
        }
     }   
       // $result  = $this->Cmha_model->updateapidata($output_object);
    }else{
        echo "Something Went wrong";
    }

    curl_close($ch);

}
/* ------------ end  ------------- */

   
  

    
     

}
