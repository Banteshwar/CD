<?php
// Report all errors except E_NOTICE
ini_set('display_errors',1); 

error_reporting(E_ALL & ~E_NOTICE);

defined('BASEPATH') OR exit('No direct script access allowed');

class Apicommon extends MY_Controller {
    private $user;
    
    public function __construct() {

        parent::__construct();
        
       
         $this->load->model('programmanager/Api_model');
       
        
        $this->load->library('mybreadcrumb');
        //$this->load->library('smslib');
        $this->load->driver('cache');
		

    }
  /**
     Save log data.. if API was success full or failed
     Status can be enum('Succeed', 'Failed', 'Unexpected')
  */
    public function api_call_log($api_name, $call_status, $msg =''){

        $request   = array(
            "API_Name"      => $api_name,
            "call_status"   =>  $call_status,              
            "msg"           =>  $msg
        );
        $result  = $this->Api_model->insertdata("api_call_log",$request);

    }
	
	
   public function test() { 
      
       $this->api_call_log('test','Succeed','I am live');
   }
   
   public function api_history() 
    { 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Api History', base_url('Api/api_history'));
        
        $data['page_type']='Api';
        $data['row'] = $this->Api_model->apihistory_list();
         
        loadLayout('programmanager/qa/api_history', 'program_manager', $data);
    }
   /**
   *
   */
   private function callAPI($program, $url, $method, $data = false, $headers = false, $auth = false ){
	   
	   $ch = curl_init();

	   switch ($method){
		  case "POST":
			 curl_setopt($ch, CURLOPT_POST, 1);
			 if ($data)
				curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
			 break;
		  case "PUT":
			 curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
			 if ($data)
				curl_setopt($ch, CURLOPT_POSTFIELDS, $data);			 					
			 break;
		  default:
			 if ($data)
				$url = sprintf("%s?%s", $url, http_build_query($data));
	   }
	   
	   // OPTIONS:
	   curl_setopt($ch, CURLOPT_URL, $url);
	   
	   if($headers){
			curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);
	   }
	   if($auth) {
			curl_setopt($ch, CURLOPT_USERPWD, $auth);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	   }
	   
	   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	   
	    // EXECUTE:
	    $response = curl_exec($ch);
	
		$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

		//print_r($response); 

		if (curl_errno($ch)) {
			echo $error_msg = curl_error($ch);
		}	
		curl_close($ch);
	   
		if (isset($error_msg)  ) {
			$this->api_call_log($program, 'Unexpected', $error_msg);
			return; // API call was unsuccessful
		} 
		else if($httpCode >= 400) {
			// if response is not OK
			$msg = 'Error Response code:'.$httpCode.' '.strip_tags($response);
			$this->api_call_log($program,'Unexpected',$msg);
			return; // API call was unsuccessful
		}
		
		return $response;
	   
	   
	   
	}
   
   private function apiJsonDecode($program, $response) {
	   
		$output_object  =  json_decode($response,true);
		/*echo "<pre> "; print_r($output_object);die;*/
			
		if(!$output_object){
			$msg =  "Something Went wrong! Data did Not Received.";
			$this->api_call_log($program,'Unexpected',$msg);
			return;
		}
		return $output_object;
   }
/** 
* 
*/
private function saveToDatabase($program, $dataTable, $insertOrUpdate = 'UPDATE', $dataArray = false, $data2DArray = false, 									$whereKey = false ){	
									
	$this->db->trans_begin();

	if($data2DArray == true) {
		
		foreach($data2DArray as $data){ 
		
			if($insertOrUpdate == 'UPDATE') {
				
				// find out where key and delete from $data array				  
				$where =  array($whereKey => $data[$whereKey]);				  
				unset($data[$whereKey]);
				 
				$result  = $this->Api_model->updatedata($dataTable,$data,$where);
			}
			else{
				$result  = $this->Api_model->insertdata($dataTable,$data);
			}
		   // if any error occcured in the loop break loop rollback transaction.
		   $error_db = $this->db->error();
		   if($error_db['code'] != 0){
			   break;
		   }
		}  
	}
	if($error_db['code'] == 0){
			 // commit if all transaction successfull 
			$this->db->trans_commit();
			$msg =  "Successfully Updated";
			$this->api_call_log($program,'Succeed',$msg);
			
	 }else{			
		  // Rollback database transaction if any one failed				
			$this->db->trans_rollback();		 
			$msg = "Database Error. Code: ".$error_db['code']. " Msg: ".$error_db['message']; 
			$this->api_call_log($program,'Failed',$msg);
	 }
		
}


public function meraaspataal() { 

    $program = 'meraaspataal';
    $url = 'https://admin-meraaspataal.nhp.gov.in/api/dashboard-details';

	$response = $this->callAPI($program,$url,'GET');
	if(!$response) {
	  // API failed 
	  return;
	}
	
	/* if Json_decode successfull*/
	if(!($output_object = $this->apiJsonDecode($program,$response))) {
		return;
	}
	
	foreach($output_object as $row){
		
		$data   = array(	
			"id"    =>  $row['id'],					
			"name"        =>  $row['name'],
			"score"       =>  $row['score'],
			"type"        =>  $row['type'],
			"color"       =>  $row['color'],
			"created_at"  =>  $row['created_at'],
			"updated_at"  =>  $row['updated_at'],
			"created_at"  =>  $row['created_at'],
			"state_id"    =>  $row['state_id'],	
		); 

	}  
	$this->saveToDatabase('merasptaal_master_table', 'UPDATE', false, $data , "id");
	
	//$result  = $this->Api_model->updatedata($program, "merasptaal_master_table",$request,array("id"=>$row['id']));
	
		
}


public function elderly() { 
     $api_program_name = 'elderly';

    $url = 'http://nphce.nhp.gov.in/mis/Api/central_dashboard_kpi';

    $ch  = curl_init($url);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
   
    $response = curl_exec($ch);
	
    if (curl_errno($ch)) {
		$error_msg = curl_error($ch);
		
	}
	curl_close($ch);
	
	if (isset($error_msg)) {
		$this->api_call_log($api_program_name,'Unexpected',$error_msg);
		return; // API call was unsuccessful
	} 
    
    $row  =  json_decode($response,true);
    print_r($row);
	
    if($row){
        
        $request   = array(
            "fa_total"        =>  $row['fund_allocation']['fa_total'],
            "fu_total"        =>  $row['fund_utilization']['fu_total'],
            "no_of_district"  =>  $row['district_count']['no_of_district'],
            "no_of_rgc"       =>  $row['rgc_count']['no_of_rgc'],
            "nca_count"       =>  $row['nca_count'],
            "dh_operational"  =>  $row['dh_operational'],
            "rgc_operational"  =>  $row['rgc_operational']['no_of_rgc'],
            "nca_operational"  =>  $row['nca_operational'],
            "iec_activities_desc"  =>  $row['other_services'][0]['total'],
            "iec_activities"   =>  $row['other_services'][0]['service_desc'],                
            "trainings_desc"  =>  $row['other_services'][1]['service_desc'],
            "trainings_conducted"  =>  $row['other_services'][1]['total'],
            "persons_trained_desc"  =>  $row['other_services'][2]['service_desc'],
            "persons_trained"  =>  $row['other_services'][0]['total'],
            "provide_service_opd"  =>  $row['services'][0]['total'],
            "provide_sesrvice_ipd"  =>  $row['services'][1]['total'],
            "provide_lab_service"  =>  $row['services'][3]['total'],
            "financial_year"    => $row['financial_year'],
        );

     $data   = $this->Api_model->getElederlyData();

     if(!empty($data)){
        $result  = $this->Api_model->updatedata("elderly_master_table_new",$request,array("id"=>$data['id']));

     }else{
        $result  = $this->Api_model->insertdata("elderly_master_table_new",$request);
     }
     
	 $error_db = $this->db->error();
	 if($error_db['code'] == 0){
				$msg =  "Successfully Updated";
				$this->api_call_log($api_program_name,'Succeed',$msg);
	 }else{			
			$msg = "Database Error. Code: ".$error_db['code']. " Msg: ".$error_db['message']; 
			$this->api_call_log($api_program_name,'Failed',$msg);
	 }

       
        
       // $result  = $this->Cmha_model->updateapidata($output_object);
    }else{
        $msg =  "Something Went wrong";
        $this->api_call_log($api_program_name,'Unexpected',$msg);
    }
    curl_close($ch);
}


public function cghs() { 
    $api_program_name = 'cghs';

    $postData = array(
            'lgd_state_code'   => '00',
            'lgd_dist_code'   => '00',
            'nin_hosp_code'   =>'00',
            );

    $curlSecondHandler = curl_init();

    curl_setopt_array($curlSecondHandler, [
    CURLOPT_URL => 'https://cghs.nic.in/cghshfm/hfmdash',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POSTFIELDS => json_encode($postData,true),

    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: XMLCipher.@AESFEBEM@_256_ID_KeyWrap_RCRMRCPENDBILREC'
    ],
	]);

	$response = curl_exec($curlSecondHandler);
	
	if (curl_errno($curlSecondHandler)) {
		$error_msg = curl_error($curlSecondHandler);
		
	}
	curl_close($curlSecondHandler);
	
	if (isset($error_msg)) {
		$this->api_call_log($api_program_name,'Unexpected',$error_msg);
		return; // API call was unsuccessful
	} 
	
	$output_object  =  json_decode($response,true);
	//print_r($output_object);
	$ss=$output_object['result'][0]['kpi'];
	
  	$kpi_date_time = date("Y-m-d H:i:s",strtotime($output_object['result'][0]['kpi_date_time']));

	//print_r($ss);

	//die;

    if($ss){
		
		$this->db->trans_begin();
		$count = 0;
        foreach($ss as $row){
            $request   = array(
                "kpi_code"        =>  $row['kpi_code'],
                "kpi_desc"       =>  $row['kpi_desc'],
                "kpi_value"       =>  $row['kpi_value'],
				"kpi_date_time"  =>  $kpi_date_time,
            );
            //print_r($request); die;			

            $this->load->model('programmanager/Api_model');
          
           //$result  = $this->Api_model->insertdata("cghs_master_table",$request);
           
            

            $result  = $this->Api_model->updatedata("cghs_master_table",$request,array("kpi_code"=>$row['kpi_code']));
            

           // if any error occcured in the loop break loop rollback transaction.
			$error_db = $this->db->error();
			if($error_db['code'] != 0){
				   break;
			}  
		}
		
		if($error_db['code'] == 0){
				 // commit if all transaction successfull 
				$this->db->trans_commit();
				$msg =  "Successfully Updated";
				$this->api_call_log($api_program_name,'Succeed',$msg);
				
		 }else{			
			  // Rollback database transaction if any one failed				
				$this->db->trans_rollback();		 
				$msg = "Database Error. Code: ".$error_db['code']. " Msg: ".$error_db['message']; 
				$this->api_call_log($api_program_name,'Failed',$msg);

		 }
        
       // $result  = $this->Cmha_model->updateapidata($output_object);
    }else{
        $msg =  "Something Went wrong";
        $this->api_call_log($api_program_name,'Unexpected',$msg);
    }

    //curl_close($ch);
}

public function ors() { 
	$api_program_name = 'ors';

    $postData = array(
            'stateCode'   => '0',
            'distCode'   => '0',
            'hospCode'   =>'0',
            );


    $curlSecondHandler = curl_init();

	curl_setopt_array($curlSecondHandler, [
		CURLOPT_URL => 'http://dashboard.ehospital.gov.in/hfm-kpi/ors',
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_POSTFIELDS => json_encode($postData,true),

		CURLOPT_HTTPHEADER => [
			'Content-Type: application/json',
			
		],
	]);

	$response = curl_exec($curlSecondHandler);
	
	if (curl_errno($curlSecondHandler)) {
		$error_msg = curl_error($curlSecondHandler);
		
	}
	curl_close($curlSecondHandler);
	
	if (isset($error_msg)) {
		$this->api_call_log($api_program_name,'Unexpected',$error_msg);
		return; // API call was unsuccessful
	} 
	
	$output_object  =  json_decode($response,true);

	$ss=$output_object['result'][0]['kpi'];


    if($ss){
		$this->db->trans_begin();
		
        foreach($ss as $row){
            $request   = array(
                "kpi_code"        =>  $row['kpi_code'],
                "kpi_desc"       =>  $row['kpi_desc'],
                "kpi_value"       =>  $row['kpi_value'],
            );
			
            $this->load->model('programmanager/Api_model');
        
           //$result  = $this->Api_model->insertdata("ors_master_table",$request);
           
            

            $result  = $this->Api_model->updatedata("ors_master_table",$request,array("kpi_code"=>$row['kpi_code']));

            // if any error occcured in the loop break loop rollback transaction.
			$error_db = $this->db->error();
			if($error_db['code'] != 0){
				   break;
			}
		}
		
		if($error_db['code'] == 0){
				 // commit if all transaction successfull 
				$this->db->trans_commit();
				$msg =  "Successfully Updated";
				$this->api_call_log($api_program_name,'Succeed',$msg);
				
		 }else{			
			  // Rollback database transaction if any one failed				
				$this->db->trans_rollback();		 
				$msg = "Database Error. Code: ".$error_db['code']. " Msg: ".$error_db['message']; 
				$this->api_call_log($api_program_name,'Failed',$msg);

		 }
        
       // $result  = $this->Cmha_model->updateapidata($output_object);
    }else{
        $msg =  "Something Went wrong";
        $this->api_call_log($api_program_name,'Unexpected',$msg);
    }

}


public function ehospital() {

    $api_program_name = 'ehospital';
	
    $postData = array(
            'stateCode'   => '0',
            'distCode'   => '0',
            'hospCode'   =>'0',
            );

    $curlSecondHandler = curl_init();

    curl_setopt_array($curlSecondHandler, [
		CURLOPT_URL => 'http://dashboard.ehospital.gov.in/hfm-kpi/ehospital',
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_POSTFIELDS => json_encode($postData,true),

		CURLOPT_HTTPHEADER => [
			'Content-Type: application/json',        
			],
	]);

	$response = curl_exec($curlSecondHandler);

	if (curl_errno($curlSecondHandler)) {
		$error_msg = curl_error($curlSecondHandler);
		
	}
	curl_close($curlSecondHandler);
	
	if (isset($error_msg)) {
		$this->api_call_log($api_program_name,'Unexpected',$error_msg);
		return; // API call was unsuccessful
	} 
	
	$output_object  =  json_decode($response,true);



	$ss= $output_object['result'][0]['kpi'];
	$kpi_date_time = date("Y-m-d H:i:s",strtotime($output_object['result'][0]['kpi_date_time']));

    if($ss){
		
		$this->db->trans_begin();
        foreach($ss as $row){
            $request   = array(
                "kpi_code"        =>  $row['kpi_code'],
                "kpi_desc"       =>  $row['kpi_desc'],
                "kpi_value"       =>  $row['kpi_value'],
				"kpi_date_time"   =>  $kpi_date_time,
            );
			
            $this->load->model('programmanager/Api_model');        

            $result  = $this->Api_model->updatedata("ehospital_master_table",$request,array("kpi_code"=>$row['kpi_code']));

            // if any error occcured in the loop break loop rollback transaction.
			$error_db = $this->db->error();
			if($error_db['code'] != 0){
				   break;
			}
		}
		
		if($error_db['code'] == 0){
				 // commit if all transaction successfull 
				$this->db->trans_commit();
				$msg =  "Successfully Updated";
				$this->api_call_log($api_program_name,'Succeed',$msg);
				
		 }else{			
			  // Rollback database transaction if any one failed				
				$this->db->trans_rollback();		 
				$msg = "Database Error. Code: ".$error_db['code']. " Msg: ".$error_db['message']; 
				$this->api_call_log($api_program_name,'Failed',$msg);

		 }
        
       // $result  = $this->Cmha_model->updateapidata($output_object);
     }else{
        $msg =  "Something Went wrong";
        $this->api_call_log($api_program_name,'Unexpected',$msg);
     }
}

    /* ------------  twinkle code mental health -------------- */

public function mHealth() { 

	$api_program_name ='mHealth';
    $res  =  $this->Api_model->emptyDatamHealth();
    $url='http://117.239.178.202/newfunction.php?method=mhealthdash';
	
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    echo $response = curl_exec($ch);

    if (curl_errno($ch)) {
		$error_msg = curl_error($ch);
	}
	curl_close($ch);
	
	if (isset($error_msg)) {
		$this->api_call_log($api_program_name,'Unexpected',$error_msg);
		return; // API call was unsuccessful
	} 
	
    $output_object  =  json_decode($response,true);
  /* echo "<pre>";
    print_r($output_object);die;*/
    if($output_object){
		
		$this->db->trans_begin();
         foreach($output_object as $row){
            $request   = array(
                "num"        =>  $row['num']
            );
			 
			$result  = $this->Api_model->insertdata("tbl_mhealth",$request);
       
            // if any error occcured in the loop break loop rollback transaction.
			$error_db = $this->db->error();
			if($error_db['code'] != 0){
				   break;
			}
		}
		
		if($error_db['code'] == 0){
				 // commit if all transaction successfull 
				$this->db->trans_commit();
				$msg =  "Successfully Updated";
				$this->api_call_log($api_program_name,'Succeed',$msg);
				
		 }else{			
			  // Rollback database transaction if any one failed
				print_r($error_db);
				$this->db->trans_rollback();		 
				$msg = "Database Error. Code: ".$error_db['code']. " Msg: ".$error_db['message']; 
				$this->api_call_log($api_program_name,'Failed',$msg);

		 }
        
       // $result  = $this->Cmha_model->updateapidata($output_object);
     }else{
        $msg =  "Something Went wrong";
        $this->api_call_log($api_program_name,'Unexpected',$msg);
     }

}
/* ------------ end  ------------- */

   
/*-------------------Start DVDMS API--------------------------------------*/

private function dvdms_apicall($url){
	$api_program_name = 'dvdms';
	
	$username = 'hfm_dvdmscdbrank';
	$password = 'Cdb@87!(';
	
    $ch = curl_init();
	curl_setopt($ch,CURLOPT_URL , $url);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
	//curl_setopt($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch, CURLOPT_USERPWD, $username . ":" . $password);
	curl_setopt($ch, CURLOPT_TIMEOUT, 30);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	//curl_setopt($ch, CURLOPT_POSTFIELDS, $payloadName);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); 
	$response = curl_exec($ch);
	
	$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

	//print_r($response); 

	if (curl_errno($ch)) {
		echo $error_msg = curl_error($ch);
	}	
	curl_close($ch);
   
	if (isset($error_msg)  ) {
		$this->api_call_log($api_program_name,'Unexpected',$error_msg);
		return; // API call was unsuccessful
	} 
	else if($httpCode >= 400) {
		// if response is not OK
		$msg = 'Error Response code:'.$httpCode.' '.strip_tags($response);
		$this->api_call_log($api_program_name,'Unexpected',$msg);
		return; // API call was unsuccessful
	}
	
	return $response;

}
public function dvdms() { 
	$api_program_name = 'dvdms';
	
	
    $url1 = 'https://cdashboard.dcservices.in/HISUtilities/services/restful/DataService/getDataJSON/25';
    $response1 = $this->dvdms_apicall($url1);
	if(!$response1) {
	  // API failed 
	  return;
	}
	
    $url2    = 'https://cdashboard.dcservices.in/HISUtilities/services/restful/DataService/getDataJSON/26';
	$response2 = $this->dvdms_apicall($url2);
	if(!$response2) {
	  // API failed
	  return;
	}
	
	$output_object1  =  json_decode($response1,true);
	var_dump($output_object1);

	$output_object2  =  json_decode($response2,true);
	var_dump($output_object2);
}

/*-------------------End DVDMS API--------------------------------------*/    
     

}
