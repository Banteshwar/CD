<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Atr extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
     
     
      
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('hwc_model');
        $this->load->model('Dashboard_model');
        $this->load->model('Report_model');
        $this->load->model('programmanager/Art_model');

     $this->load->model('Programmanager_model');
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index() { 
   
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Action Taken Report', base_url('Art/art_list'));
        
        $data['page_type']='art';

       $data['row']=$this->Art_model->art_list();
       
    loadLayout('programmanager/Art/art_list', 'program_manager',$data);
    }
  
  

  public function art_add() { 
     
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Action Taken Report', base_url('Art/art_add'));
          $data['program']=$this->Art_model->program_list();

        $data['page_type']='art';   
    loadLayout('programmanager/Art/art_add', 'program_manager', $data);
    }
   public function art_submit(){        
                     $insert=array(
'Name_Of_Section'=>$this->input->post('Name_Of_Section'),
'atrpending_pmoreference'=>$this->input->post('atrpending_pmoreference'),
'date1'=>$this->input->post('date1'),
);
    
                if($insert)
                {
                    
                   $this->Art_model->insertart($insert);

                $this->session->set_flashdata("success","Data has been submitted successfully."); 
                
                }
                else
                {
                
          $this->session->set_flashdata("error","Data has been submitted successfully."); 
                }
                
                //$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('Atr/index');     
          
    }
    
    public function art_edit($id){
       $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Action Taken Report', base_url('Ihd/son_update'));
        $data['page_type']='art';     
        $data['value'] = $this->Art_model->art_edit_show($id);
                  $data['program']=$this->Art_model->program_list();
       
        loadLayout('programmanager/Art/art_update', 'program_manager', $data);

    }
    public function art_update()
    {      

      if (isset($_POST['update']))
          {
                $id = $this->input->post('id');

             $data = array
                   (                    
                    
'Name_Of_Section'=>$this->input->post('Name_Of_Section'),
'atrpending_pmoreference'=>$this->input->post('atrpending_pmoreference'),
'date1'=>$this->input->post('date1'),


                    'updated_date'=> $this->input->post(date('updated_date')),

                    'updated_by'=>  (isset($_SESSION['memberID']))
                                                    
                );
     

                $result = $this->Art_model->art_update_data($id,$data);
               
        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
            
         }
           redirect('Atr/index',$id);

          }
    }
    public function delete($id)
     {
       $this->db->delete('art_master_tbl', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('Atr/index'));
     }




     /*Start Second */
      public function index2() { 
   
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Action Taken Report', base_url('Art/art_list2'));
        
        $data['page_type']='art';

       $data['row']=$this->Art_model->art2_list();
       
    loadLayout('programmanager/Art/art_list2', 'program_manager',$data);
    }
  
  

  public function art_add2() { 
     
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Action Taken Report', base_url('Art/art_add2'));
        $data['page_type']='art';   
                  $data['program']=$this->Art_model->program_list();

    loadLayout('programmanager/Art/art_add2', 'program_manager', $data);
    }
   public function art_submit2(){        
                     $insert=array(
  'name'=>$this->input->post('name'),

'devesion'=>$this->input->post('devesion'),
'date'=>$this->input->post('date'),
);
    
                if($insert)
                {
                    
                   $this->Art_model->insertart2($insert);

                $this->session->set_flashdata("success","Data has been submitted successfully."); 
                
                }
                else
                {
                
          $this->session->set_flashdata("error","Data has been submitted successfully."); 
                }
                
                //$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('Atr/index2');     
          
    }
    
    public function art_edit2($id){
       $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Action Taken Report', base_url('Art/art_update2'));
        $data['page_type']='art';     
        $data['value'] = $this->Art_model->art_edit_show2($id);
        
        $data['program']=$this->Art_model->program_list();

        loadLayout('programmanager/Art/art_update2', 'program_manager', $data);

    }
    public function art_update2()
    {      

      if (isset($_POST['update2']))
          {
                $id = $this->input->post('id');

             $data = array
                   (                    
                    
'devesion'=>$this->input->post('devesion'),
'name'=>$this->input->post('name'),


'date'=>$this->input->post('date'),


                    'updated_date'=> $this->input->post(date('updated_date')),

                    'updated_by'=>  (isset($_SESSION['memberID']))
                                                    
                );
     

                $result = $this->Art_model->art_update_data2($id,$data);
               
        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
            
         }
           redirect('Atr/index2',$id);

          }
    }
    public function delete2($id)
     {
       $this->db->delete('atr2_master_tbl', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('Atr/index2'));
     }
    



     /* End second */

     /* statrt third*/

public function index3() { 
   
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Action Taken Report', base_url('Art/art_list3'));
        
        $data['page_type']='art';

       $data['row']=$this->Art_model->art_list3();
       
    loadLayout('programmanager/Art/art_list3', 'program_manager',$data);
    }
  
  

  public function art_add3() { 
     
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Action Taken Report', base_url('Art/art_add3'));
        $data['page_type']='art';   
                  $data['program']=$this->Art_model->program_list();

    loadLayout('programmanager/Art/art_add3', 'program_manager', $data);
    }
   public function art_submit3(){        
                     $insert=array(
'Name_Section'=>$this->input->post('Name_Of_Section'),
'date1'=>$this->input->post('date1'),
'pacount'=>$this->input->post('pacount')
);
    
                if($insert)
                {
                    
                   $this->Art_model->insertart3($insert);

                $this->session->set_flashdata("success","Data has been submitted successfully."); 
                
                }
                else
                {
                
          $this->session->set_flashdata("error","Data has been submitted successfully."); 
                }
                
                //$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('Atr/index3');     
          
    }
    
    public function art_edit3($id){
       $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Action Taken Report', base_url('Ihd/son_update3'));
        $data['page_type']='art';     
        $data['value'] = $this->Art_model->art_edit_show3($id);
                  $data['program']=$this->Art_model->program_list();

       
        loadLayout('programmanager/Art/art_update3', 'program_manager', $data);

    }
    public function art_update3()
    {      

      if (isset($_POST['update']))
          {
                $id = $this->input->post('id');

             $data = array
                   (                    
                    
'Name_Section'=>$this->input->post('Name_Of_Section'),

'date1'=>$this->input->post('date1'),
'pacount'=>$this->input->post('pacount'),


                    'updated_date'=> $this->input->post(date('updated_date')),

                    'updated_by'=>  (isset($_SESSION['memberID']))
                                                    
                );
     

                $result = $this->Art_model->art_update_data3($id,$data);
               
        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
            
         }
           redirect('Atr/index3',$id);

          }
    }
    public function delete3($id)
     {
       $this->db->delete('atr3_master_tbl', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('Atr/index3'));
     }

     /*end third*/
     /*start fourth*/
     public function program() { 
   
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Action Taken Report', base_url('Art/program_list'));
        
        $data['page_type']='art';

       $data['row']=$this->Art_model->art_list4();
       
    loadLayout('programmanager/Art/program_list', 'program_manager',$data);
    }
  
  

  public function program_add() { 
     
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Action Taken Report', base_url('Art/program_add'));
        $data['page_type']='art';   
    loadLayout('programmanager/Art/program_add', 'program_manager', $data);
    }
   public function program_submit(){        
                     $insert=array(
'program_name'=>$this->input->post('program_name'),
);
    
                if($insert)
                {
                    
                   $this->Art_model->insertart4($insert);

                $this->session->set_flashdata("success","Data has been submitted successfully."); 
                
                }
                else
                {
                
          $this->session->set_flashdata("error","Data has been submitted successfully."); 
                }
                
                //$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('Atr/program');     
          
    }
    
    public function program_edit($id){
       $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Action Taken Report', base_url('Ihd/program_update'));
        $data['page_type']='art';     
        $data['value'] = $this->Art_model->art_edit_show4($id);
        
       
        loadLayout('programmanager/Art/program_update', 'program_manager', $data);

    }
    public function program_update()
    {      

      if (isset($_POST['update']))
          {
                $id = $this->input->post('id');

             $data = array
                   (                    
                            
'program_name'=>$this->input->post('program_name'),


                    'updated_date'=> $this->input->post(date('updated_date')),

                    'updated_by'=>  (isset($_SESSION['memberID']))
                                                    
                );
     

                $result = $this->Art_model->art_update_data4($id,$data);
               
        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
            
         }
           redirect('Atr/program',$id);

          }
    }
    public function programdelete($id)
     {
       $this->db->delete('atr4_master_tbl', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('Atr/program'));
     }


     /*end Forth */
   
}
/* ====================== end =============================== */