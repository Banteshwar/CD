<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Cdsco extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
     
     
      
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('hwc_model');
        $this->load->model('Dashboard_model');
        $this->load->model('Report_model');
     $this->load->model('programmanager/Cdsco_model');
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index() { 
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('CDSCO', base_url('Cdsco/hrcdsco_list'));
        
        $data['page_type']='cdsco';
      $data['row']=$this->Cdsco_model->cdsco_list();
       
    loadLayout('programmanager/Cdsco/hrcdsco_list', 'program_manager', $data);
  }
    
    

 public function hrreg_add() { 
     
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Human Resources', base_url('Cdsco/hrcdsco_add'));
        $data['state']=$this->hwc_model->get_state();
        $data['page_type']='cdsco';
        
       
    loadLayout('programmanager/Cdsco/hrcdsco_add', 'program_manager', $data);
    }
    
 public function HR_submit(){
         if (isset($_POST['submit']))
          {
          $this->form_validation->set_rules('post', 'post', 'required');
          if ($this->form_validation->run() == FALSE)
                {
                         redirect('Cdsco/hrreg_add');     
                }
                else
                {
                     $insert=array(
'post'=>$this->input->post('post'),
'sanctioned'=>$this->input->post('sanctioned'),
'filled'=>$this->input->post('filled')
);                
                if($insert)
                {
               $this->Cdsco_model->inserthrreg($insert);
                $this->session->set_flashdata("success","Data has been submitted successfully.");
                }
                else
                {
        $this->session->set_flashdata("error","Data has been submitted Failed.");
                }
               redirect('Cdsco/index');     
          }

        }
    }
     public function HRreg_edit($id){
        $data['state']=$this->hwc_model->get_state($id);
        $data['value'] = $this->Cdsco_model->hrreg_edit_show($id);
        
        $this->mybreadcrumb->add('Human Resources', base_url('Cdsco/hrcdsco_update'));

        $data['page_type']='cdsco';     
        loadLayout('programmanager/Cdsco/hrcdsco_update', 'program_manager', $data);

    }
    public function HRreg_update()
    {      
      if (isset($_POST['update']))
         $id = $this->input->post('id');
          {
             $data = array
                   (                    
                    
                    'post'=>$this->input->post('post'),
'sanctioned'=>$this->input->post('sanctioned'),
'filled'=>$this->input->post('filled'),
                    'updated_date'=> $this->input->post(date('updated_date')),

                    'updated_by'=>  (isset($_SESSION['memberID']))
                                                    
                );
     

                $result = $this->Cdsco_model->hrreg_update_data($id,$data);
               
        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
            
         }
           redirect('Cdsco/index',$id);

          }
    }
     public function delete($id)
     {
       $this->db->delete('hrcdsco_master_tbl', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('Cdsco/index'));
     }
    
    public function Ministerialhq() { 
   
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Human Resources', base_url('Cdsco/hq_list'));
        
        $data['page_type']='cdsco';
      $data['row']=$this->Cdsco_model->hrhq_list();
       
    loadLayout('programmanager/Cdsco/hq_list', 'program_manager', $data);
    }

    public function hrhq_add() { 
     
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Human Resources', base_url('Cdsco/hq_add'));
        $data['page_type']='cdsco';
    loadLayout('programmanager/Cdsco/hq_add', 'program_manager', $data);
    }
   public function HRhq_submit(){
         if (isset($_POST['submit']))
          {
             
          $this->form_validation->set_rules('post', 'post', 'required');
          
         
         
          if ($this->form_validation->run() == FALSE)
                {

                         redirect('Cdsco/hrhq_add');    
                      
                }
                else
                {
                     $insert=array(
'post'=>$this->input->post('post'),
'sanctioned'=>$this->input->post('sanctioned'),
'filled'=>$this->input->post('filled')
);             if($insert)
                {
                    
               $this->Cdsco_model->inserthrhq($insert);
                $this->session->set_flashdata("success","Data has been submitted successfully.");
                }
                else
                {
        $this->session->set_flashdata("error","Data has been submitted Failed.");
                }
               redirect('Cdsco/Ministerialhq');     
          
          }

        }
    }
   
   
    
   public function HRhq_edit($id){
        $data['state']=$this->hwc_model->get_state($id);
        $data['value'] = $this->Cdsco_model->hrrhq_edit_show($id);
         $this->mybreadcrumb->add('Human Resources', base_url('Cdsco/hq_update'));


        $data['page_type']='cdsco';     
        loadLayout('programmanager/Cdsco/hq_update', 'program_manager', $data);

    }
    public function HRhq_update()
    {      
      if (isset($_POST['update']))
         $id = $this->input->post('id');
          {
             $data = array
                   (                    
                    
                    'post'=>$this->input->post('post'),
'sanctioned'=>$this->input->post('sanctioned'),
'filled'=>$this->input->post('filled'),
                    'updated_date'=> $this->input->post(date('updated_date')),

                    'updated_by'=>  (isset($_SESSION['memberID']))
                                                    
                );
     

                $result = $this->Cdsco_model->hrrhq_update_data($id,$data);
               
        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
            
         }
           redirect('Cdsco/Ministerialhq',$id);

          }
    }
     public function deletehq($id)
     {
       $this->db->delete('hrhq_master_tbl', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('Cdsco/Ministerialhq'));
     }



       public function Claboratories() { 
   
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Human Resources', base_url('Cdsco/hrcl_list'));
        
        $data['page_type']='cdsco';
      $data['row']=$this->Cdsco_model->hrcl_list();
       
    loadLayout('programmanager/Cdsco/hrcl_list', 'program_manager', $data);
    }

    public function hrcl_add() { 
     
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Human Resources', base_url('Cdsco/hrcl_add'));
        $data['page_type']='cdsco';
    loadLayout('programmanager/Cdsco/hrcl_add', 'program_manager', $data);
    }
   public function HRcl_submit(){
         if (isset($_POST['submit']))
          {
             
          $this->form_validation->set_rules('name_of_lab', 'name_of_lab', 'required');
          
         
         
          if ($this->form_validation->run() == FALSE)
                {

                         redirect('Cdsco/hrcl_add');    
                      
                }
                else
                {
                     $insert=array(
'name_of_lab'=>$this->input->post('name_of_lab'),
'sanctioned_post'=>$this->input->post('sanctioned_post'),
'filled'=>$this->input->post('filled')
);             if($insert)
                {
                    
               $this->Cdsco_model->inserthrcl($insert);
                $this->session->set_flashdata("success","Data has been submitted successfully.");
                }
                else
                {
        $this->session->set_flashdata("error","Data has been submitted Failed.");
                }
               redirect('Cdsco/Claboratories');     
          
          }

        }
    }
   
   
    
   public function HRcl_edit($id){
        $data['state']=$this->hwc_model->get_state($id);
        $data['value'] = $this->Cdsco_model->hrrcl_edit_show($id);
         $this->mybreadcrumb->add('Human Resources', base_url('Cdsco/hrcl_update'));


        $data['page_type']='cdsco';     
        loadLayout('programmanager/Cdsco/hrcl_update', 'program_manager', $data);

    }
    public function HRcl_update()
    {      
      if (isset($_POST['update']))
         $id = $this->input->post('id');
          {
             $data = array
                   (                    
                    
                    'name_of_lab'=>$this->input->post('name_of_lab'),
'sanctioned_post'=>$this->input->post('sanctioned_post'),
'filled'=>$this->input->post('filled'),
                    'updated_date'=> $this->input->post(date('updated_date')),

                    'updated_by'=>  (isset($_SESSION['memberID']))
                                                    
                );
     

                $result = $this->Cdsco_model->hrrcl_update_data($id,$data);
               
        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
            
         }
           redirect('Cdsco/Claboratories',$id);

          }
    }
     public function cldelete($id)
     {
       $this->db->delete('hrcl_master_tbl', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('Cdsco/Claboratories'));
     }
    
     public function sugam_list() { 
   
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('SUGAM', base_url('Cdsco/suguam_list'));
        
        $data['page_type']='cdsco';
      $data['row']=$this->Cdsco_model->sugam_list();
       
    loadLayout('programmanager/Cdsco/suguam_list', 'program_manager', $data);
    }

    public function sugam_add() { 
     
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('SUGAM', base_url('Cdsco/suguam_add'));
        $data['page_type']='cdsco';
                $data['state']=$this->hwc_model->get_state();

    loadLayout('programmanager/Cdsco/sugum_add', 'program_manager', $data);
    }
   public function sugam_submit(){
         if (isset($_POST['submit']))
          {
             
          $this->form_validation->set_rules('no_of_manufacturing', 'name_of_lab', 'required');
          
         
         
          if ($this->form_validation->run() == FALSE)
                {

                         redirect('Cdsco/sugam_add');    
                      
                }
                else
                {
                     $insert=array(
'no_of_manufacturing'=>$this->input->post('no_of_manufacturing'),
' number_of_formulation '=>$this->input->post('number_of_formulation'),
'total_application'=>$this->input->post('total_application'),
'New'=>$this->input->post('New'),

'Approved'=>$this->input->post('Approved'),

'Rejected'=>$this->input->post('Rejected'),

'Inprocess'=>$this->input->post('Inprocess'),
'Query_Raised'=>$this->input->post('Query_Raised'),
'Division'=>$this->input->post('Division'),
'state_id'=>$this->input->post('state_id')

);             if($insert)
                {
                    
               $this->Cdsco_model->insertsugam($insert);
                $this->session->set_flashdata("success","Data has been submitted successfully.");
                }
                else
                {
        $this->session->set_flashdata("error","Data has been submitted Failed.");
                }
               redirect('Cdsco/sugam_list');     
          
          }

        }
    }
   
   
    
   public function sugam_edit($id){
               $this->mybreadcrumb->add('Home', base_url());

         $this->mybreadcrumb->add('SUGAM', base_url('Cdsco/suguam_update'));


        $data['page_type']='cdsco';    
         $data['state']=$this->hwc_model->get_state($id);
        $data['value'] = $this->Cdsco_model->sugam_edit_show($id); 
        loadLayout('programmanager/Cdsco/suguam_update', 'program_manager', $data);

    }
    public function sugam_update()
    {      
      if (isset($_POST['update']))
         $id = $this->input->post('id');
          {
             $data = array
                   (                    
                    'no_of_manufacturing'=>$this->input->post('no_of_manufacturing'),
' number_of_formulation '=>$this->input->post('number_of_formulation'),
'total_application'=>$this->input->post('total_application'),
'New'=>$this->input->post('New'),

'Approved'=>$this->input->post('Approved'),

'Rejected'=>$this->input->post('Rejected'),

'Inprocess'=>$this->input->post('Inprocess'),
'Query_Raised'=>$this->input->post('Query_Raised'),
'Division'=>$this->input->post('Division'),
'state_id'=>$this->input->post('state_id'),

                    'updated_date'=> $this->input->post(date('updated_date')),

                    'updated_by'=>  (isset($_SESSION['memberID']))
                                                    
                );
     

                $result = $this->Cdsco_model->sugam_update_data($id,$data);
               
        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
            
         }
           redirect('Cdsco/sugam_list',$id);

          }
    }
     public function sugamdelete($id)
     {
       $this->db->delete('sugam_master_tbl', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('Cdsco/sugam_list'));
     }




      public function cdscolab_list() { 
   
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('CDSCO Laboratories', base_url('Cdsco/cdscolab_list'));
        
        $data['page_type']='cdsco';
      $data['row']=$this->Cdsco_model->cdscolab_list();
       
    loadLayout('programmanager/Cdsco/cdscolab_list', 'program_manager', $data);
    }

    public function cdscolab_add() { 
     
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('CDSCO Laboratories', base_url('Cdsco/cdscolab_add'));
        $data['page_type']='cdsco';

    loadLayout('programmanager/Cdsco/cdscolab_add', 'program_manager', $data);
    }
   public function cdscolab_submit(){
         if (isset($_POST['submit']))
          {
             
          $this->form_validation->set_rules('name_of_the_lab', 'name_of_the_lab', 'required');
          
         
         
          if ($this->form_validation->run() == FALSE)
                {

                         redirect('Cdsco/cdscolab_add');    
                      
                }
                else
                {
                     $insert=array(
'name_of_the_lab'=>$this->input->post('name_of_the_lab'),
' total_no_of_sample_tested '=>$this->input->post('total_no_of_sample_tested'),
'sample_for_standard'=>$this->input->post('sample_for_standard'),
'sample_found'=>$this->input->post('sample_found'),

'spurious'=>$this->input->post('spurious'),



);             if($insert)
                {
                    
               $this->Cdsco_model->insertcdscolab($insert);
                $this->session->set_flashdata("success","Data has been submitted successfully.");
                }
                else
                {
        $this->session->set_flashdata("error","Data has been submitted Failed.");
                }
               redirect('Cdsco/cdscolab_list');     
          
          }

        }
    }
   
   
    
   public function cdscolab_edit($id){
               $this->mybreadcrumb->add('Home', base_url());

         $this->mybreadcrumb->add('CDSCO Laboratories', base_url('Cdsco/cdcolab_update'));


        $data['page_type']='cdsco';    
         $data['state']=$this->hwc_model->get_state($id);
        $data['value'] = $this->Cdsco_model->cdscolab_edit_show($id); 
        loadLayout('programmanager/Cdsco/cdcolab_update', 'program_manager', $data);

    }
    public function cdscolab_update()
    {      
      if (isset($_POST['update']))
         $id = $this->input->post('id');
          {
             $data = array
                   (                    
                    'name_of_the_lab'=>$this->input->post('name_of_the_lab'),
' total_no_of_sample_tested '=>$this->input->post('total_no_of_sample_tested'),
'sample_for_standard'=>$this->input->post('sample_for_standard'),
'sample_found'=>$this->input->post('sample_found'),

'spurious'=>$this->input->post('spurious'),
                    'updated_date'=> $this->input->post(date('updated_date')),

                    'updated_by'=>  (isset($_SESSION['memberID']))
                                                    
                );
     

                $result = $this->Cdsco_model->cdscolab_update_data($id,$data);
               
        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
            
         }
           redirect('Cdsco/cdscolab_list',$id);

          }
    }
     public function cdscolabdelete($id)
     {
       $this->db->delete('cdsco_lab_master_tbl', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('Cdsco/cdscolab_list'));
     }





  public function pvpi_list() { 
   
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('PVPI', base_url('Cdsco/pvpi_list'));
        
        $data['page_type']='cdsco';
      $data['row']=$this->Cdsco_model->pvpi_list();
       
    loadLayout('programmanager/Cdsco/pvpi_list', 'program_manager', $data);
    }

    public function pvpi_add() { 
     
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('PVPI', base_url('Cdsco/pvpi_add'));
        $data['page_type']='cdsco';

    loadLayout('programmanager/Cdsco/pvpi_add', 'program_manager', $data);
    }
   public function pvpi_submit(){
         if (isset($_POST['submit']))
          {
             
          $this->form_validation->set_rules('noof_individual', 'noof_individual', 'required');
          
         
         
          if ($this->form_validation->run() == FALSE)
                {

                         redirect('Cdsco/pvpi_add');    
                      
                }
                else
                {
                     $insert=array(
'noof_individual'=>$this->input->post('noof_individual'),
' noof_causality '=>$this->input->post('noof_causality'),
'noof_cases'=>$this->input->post('noof_cases'),
'outcome'=>$this->input->post('outcome'),
'month'=>$this->input->post('month'),





);             if($insert)
                {
                    
               $this->Cdsco_model->insertpvpi($insert);
                $this->session->set_flashdata("success","Data has been submitted successfully.");
                }
                else
                {
        $this->session->set_flashdata("error","Data has been submitted Failed.");
                }
               redirect('Cdsco/pvpi_list');     
          
          }

        }
    }
   
   
    
   public function pvpi_edit($id){
               $this->mybreadcrumb->add('Home', base_url());

         $this->mybreadcrumb->add('PVPI', base_url('Cdsco/pvpi_update'));


        $data['page_type']='cdsco';    
         $data['state']=$this->hwc_model->get_state($id);
        $data['value'] = $this->Cdsco_model->pvpi_edit_show($id); 
        loadLayout('programmanager/Cdsco/pvpi_update', 'program_manager', $data);

    }
    public function pvpi_update()
    {      
      if (isset($_POST['update']))
         $id = $this->input->post('id');
          {
             $data = array
                   (                    
                   'noof_individual'=>$this->input->post('noof_individual'),
' noof_causality '=>$this->input->post('noof_causality'),
'noof_cases'=>$this->input->post('noof_cases'),
'outcome'=>$this->input->post('outcome'),
'month'=>$this->input->post('month'),

                    'update_date'=> $this->input->post(date('update_date')),

                    'updated_by'=>  (isset($_SESSION['memberID']))
                                                    
                );
     

                $result = $this->Cdsco_model->pvpi_update_data($id,$data);
               
        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
            
         }
           redirect('Cdsco/pvpi_list',$id);

          }
    }
     public function pvpidelete($id)
     {
       $this->db->delete('pvpi_master_tbl', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('Cdsco/pvpi_list'));
     }



}
