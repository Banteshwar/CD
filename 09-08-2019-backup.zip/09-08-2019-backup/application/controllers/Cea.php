<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Childhealth extends MY_Controller 
{
    private $user;

    public function __construct() 
    {
        parent::__construct();
      
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        
        $this->load->model('programmanager/Childhealth_model');
        $this->load->model('hwc_model');
       
        $this->load->model('Report_model');
        $this->load->library('form_validation');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

  public function index()
  { 
    $this->mybreadcrumb->add('Home', base_url());
    $this->mybreadcrumb->add('Child Health', base_url('familyplanning/family_form_list'));    
    $data['page_type']='Familyplanning';
    $data['row'] = $this->Familyplanning_model->familyplanning_list();
         
    loadLayout('programmanager/familyplanning/family_form_list', 'program_manager', $data);
  }

    // Load Add Family Planning form page
    public function add_form() 
    {  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Family Planning', base_url('familyplanning/family_form_list'));   

        $data['page_type']='Familyplanning';
        loadLayout('programmanager/familyplanning/family_form_add', 'program_manager', 
            $data);
    }


    // Insert Family Planning form function
    public function insert_familyplanning()
    {
      if (isset($_POST['submitfpform']))
      {
        $table='familyplanning_master_table';

    
        $this->form_validation->set_rules('ppiucd_insertion_no', 'Number of PPIUCE insertions', 'required');
        $this->form_validation->set_rules('total_institution_delivery', 'Toital Institutional Deliveries', 
            'required');
        $this->form_validation->set_rules('acceptance_rate', 'PPIUCD Acceptance rate', 'required');
        $this->form_validation->set_rules('injectable_doses', 'Injectable Doses Given', 
            'required');
        $this->form_validation->set_rules('entry_date', 'Calendar input', 'required');
                
          if ($this->form_validation->run() == FALSE)
                {                                
                    redirect('Familyplanning/add_form');
                }
                else
                {
                    $data = array
                (  
                    'ppiucd_insertion_no'    =>  $this->input->post('ppiucd_insertion_no'),
                'total_institution_delivery' =>  $this->input->post('total_institution_delivery'),
                    'acceptance_rate'       =>  $this->input->post('acceptance_rate'),
                    'injectable_doses'  =>  $this->input->post('injectable_doses')
                    , 

                    
                    'entry_date' => $this->input->post('entry_date'),

                    'updated_by'        =>  (isset($_SESSION['memberID']))
                );

                $query =$this->Familyplanning_model->insert_familyplanning($data,$table);
                
                if($query)
                {                   
                    $this->session->set_flashdata("success","Family Planning form data has been saved successfully.");
                     redirect('Familyplanning/index');  
                }
                else
                {       
                    $this->session->set_flashdata("error","Failed to save Family Planning form data, Please Try again!!");               
                }

            redirect('Familyplanning/add_form');
          }
        }
    }

    // Edit Adolescent form
    public function edit_familyplanning($id)
    {
       $data['value'] = $this->Familyplanning_model->getFP_byId($id);
       /*echo "<pre>";
       print_r(date('Y-m-d',strtotime($data['value']))); die;*/
       $data['page_type']='Familyplanning';
       loadLayout('programmanager/familyplanning/family_form_edit', 'program_manager', $data);
    }

    // Update Family Planning form
    public function update_familyplanning($id)
    {      
              if (isset($_POST['updatefpform']))
              {
                $data = array
                (                
                'ppiucd_insertion_no'    =>  $this->input->post('ppiucd_insertion_no'),

                'total_institution_delivery' =>  $this->input->post('total_institution_delivery'),

                'acceptance_rate'       =>  $this->input->post('acceptance_rate'),
                'injectable_doses'  =>  $this->input->post('injectable_doses')
                    , 
                'entry_date' => $this->input->post('entry_date'),
           
                'updated_date'      =>  date("Y-m-d H:i:s"),            
                'updated_by'        =>  (isset($_SESSION['memberID']))                                                
                 );
                         
                $result = $this->Familyplanning_model->update_familyplanning($id,$data);

                if($result)
                {
                    $this->session->set_flashdata('success','Record Updated Successfully');
                     redirect('Familyplanning/index'); 
                }
                else
                {
                    $this->session->set_flashdata('error','Something went wrong. Please try again later.');        
                }
                    redirect(base_url('Familyplanning/edit_familyplanning/'. $id));
            }
    }


    // Delete Family Planning form
    public function delete($id)
    {
       $this->db->delete('familyplanning_master_table', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('Familyplanning/index'));
    }
       
}
