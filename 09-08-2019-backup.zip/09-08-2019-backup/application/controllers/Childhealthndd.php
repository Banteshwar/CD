<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Childhealthndd extends MY_Controller 
{
    private $user;

    public function __construct() 
    {
        parent::__construct();
      
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        
        $this->load->model('programmanager/Childhealthndd_model');
        $this->load->model('hwc_model');
       
        $this->load->model('Report_model');
        $this->load->library('form_validation');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

  public function index($year_id='',$month=''){ 
    $this->mybreadcrumb->add('Home', base_url("admin/home"));
    $this->mybreadcrumb->add('Child Health', base_url('Childhealthndd/index'));    
  
   if($year_id){
      $data['fin_year'] = $year_id;
    }else{
      $data['fin_year'] = date('Y');
    } 

   if($month){
      $data['fin_month'] = $month;
    }else{
      
      $current_month  = date('m');
      if($current_month >=1 && $current_month <=6 ) {
          $data['fin_month'] = 'Jan-Jun';
      }else {
         $data['fin_month'] = 'Jul-Dec';
      }
    }
    //var_dump($data);

    
    $data['page_type']='Childhealth';
    $data['state']=$this->Childhealthndd_model->get_ChNDD_State($data['fin_year'], $data['fin_month']);
                       
    loadLayout('programmanager/childhealth/formchildhealthndd', 'program_manager', $data);
  }

    // Load Add Child Health form page
    public function form_save()
    { 
       if (isset($_POST['submit']))
       {    
          $this->form_validation->set_rules('year_id', 'Year', 'required');
          $this->form_validation->set_rules('e_month', 'Month', 'required');

         
          if ($this->form_validation->run() == FALSE)
          {
              $this->session->set_flashdata('required','Something went wrong. Please try again later.');
              redirect('Childhealthndd/index/'); 
          }    
          else
          {                             
              $this->Childhealthndd_model->saveChNDD($_POST);
              $this->session->set_flashdata("success","Data has been submitted successfully.");
              redirect('Childhealthndd/index/'.$this->input->post("year_id").'/'.$this->input->post("e_month"));       
          }
        }
    }


    public function change_val_ajax($y_val, $month)
    { 
      $data['state']=$this->Childhealthndd_model->get_ChNDD_State_ajax($y_val,$month);        
      echo json_encode($data['state']);      
      die;
    }

   public function deleteNdd($id){

     $ss=$this->db->delete('childhealthndd_master_table', array('id' => $id));
     
     if($ss){
       echo "1";
     }else{
       echo "0";
     }
    }



       
}
