<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Cle_model extends CI_Model 
{
    public function __construct(){
        parent::__construct();
    } 

    //---------START Immunization CRUD FUNCTIONS-------->
  public function saveCle($post_val){		
		
	if(count($post_val['check'])>0){				
					 
		foreach($post_val['check'] as $check_value){
				
		$this->db->where('state_id',$post_val['state_id'][$check_value]);
		$this->db->where('year',$post_val['year_id']);		
        $this->db->from("cle_master_table");
        $count_val = $this->db->count_all_results(); 
		
          if($count_val>0){
				
			$data = array(			
			
			'allopathy'			=>		$post_val['allopathy'][$check_value],
			'ayurveda'			=>		$post_val['ayurveda'][$check_value],
			'unani'				=>		$post_val['unani'][$check_value],
			'siddha'			=>		$post_val['siddha'][$check_value],
			'homoeopathy '		=>		$post_val['homoeopathy'][$check_value],
			'yoga'				=>		$post_val['yoga'][$check_value],
			'naturapathy'		=>		$post_val['naturapathy'][$check_value],
			'sowa'				=>		$post_val['sowa'][$check_value],
			'total'				=>		$post_val['total'][$check_value],
			'updated_by'		=>  	(isset($_SESSION['memberID']))
											
	  	     );			 
			
              $this->db->where('state_id',$post_val['state_id'][$check_value]);
              $this->db->where('year',$post_val['year_id']);              
              $this->db->update('cle_master_table', $data);	


           ///////////// blank value should delete on update ////////
					  
					  if($post_val['allopathy'][$check_value]=='' && $post_val['ayurveda'][$check_value]=='' && $post_val['unani'][$check_value]=='' && $post_val['siddha'][$check_value]=='' && $post_val['homoeopathy'][$check_value]=='' && $post_val['yoga'][$check_value]=='' && $post_val['naturapathy'][$check_value]=='' && $post_val['sowa'][$check_value]=='' && $post_val['total'][$check_value]=='')
					  {
						  
					  $this->db->where('state_id',$post_val['state_id'][$check_value]);
                       $this->db->where('year',$post_val['year_id']);
                          $this->db->delete('cle_master_table');
						  
					  }
					  
					  
					  ///////////// end blank value should delete on update ////////			  
				
			}else{
				
				/// blank value should not insert in table //////	
						
                        if($post_val['allopathy'][$check_value]!='' || $post_val['ayurveda'][$check_value]!='' || $post_val['unani'][$check_value]!='' || $post_val['siddha'][$check_value]!='' || $post_val['homoeopathy'][$check_value]!='' || $post_val['yoga'][$check_value]!='' || $post_val['naturapathy'][$check_value]!='' || $post_val['sowa'][$check_value]!='' || $post_val['total'][$check_value]!='')
						{	

				$data = array(	 									
					'state_id'			=> $post_val['state_id'][$check_value],					
					'year'				=> $post_val['year_id'],
					'allopathy'			=>		$post_val['allopathy'][$check_value],
					'ayurveda'			=>		$post_val['ayurveda'][$check_value],
					'unani'				=>		$post_val['unani'][$check_value],
					'siddha'			=>		$post_val['siddha'][$check_value],
					'homoeopathy'		=>		$post_val['homoeopathy'][$check_value],
					'yoga'				=>		$post_val['yoga'][$check_value],
					'naturapathy'		=>		$post_val['naturapathy'][$check_value],
					'sowa'				=>		$post_val['sowa'][$check_value],
					'total'				=>		$post_val['total'][$check_value],
					'updated_by'		=>  	(isset($_SESSION['memberID']))													
			  	     );					 
					 $this->db->insert('cle_master_table', $data);
						
					 }
			}					 
					}					
				  }			
    		    }
	
	public function get_Cle_State($f_year){

		global $db; 
		$query = "Select m_state.*,cle_master_table.* from m_state LEFT JOIN cle_master_table on (m_state.State_ID=cle_master_table.state_id and cle_master_table.year='".$f_year."' ) order by m_state.State_Name" ;

		$stmt = $db->query($query);
		return $stmt->fetchAll(); 
	}

	public function get_Cle_State_ajax($f_year){
		global $db;
	    $query = "Select m_state.*,cle_master_table.* from m_state LEFT JOIN cle_master_table on (m_state.State_ID=cle_master_table.state_id and cle_master_table.year='".$f_year."')  order by m_state.State_Name" ; 
				$statement = $db->prepare($query);
			
			if($statement->execute()){
				 while($row = $statement->fetch(PDO::FETCH_ASSOC)){
				  $data[] = $row;
				 }
			}
				 
		return $data;
	}
   
}