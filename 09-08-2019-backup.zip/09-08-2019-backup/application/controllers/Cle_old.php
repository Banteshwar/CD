<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Cle extends MY_Controller {
    private $user;

    public function __construct() {
        parent::__construct();           
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('programmanager/cle_model');
        $this->load->model('Dashboard_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');
    }

    /*-------------------Start CLE Establishments ----------------------------------*/
    
    public function index() { 		
    	$this->establish_view();
    }
	
	public function establish_view(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('CLE', base_url('cle/index'));
        $this->mybreadcrumb->add('Clinical Establishments', base_url('registered/index'));
        
        $data['page_type'] = 'CLE';
		
        $data['row']       = $this->cle_model->get_cle_establish();
		
        loadLayout('programmanager/cle/establish/form_list', 'program_manager', $data);
    }
	
    public function establish_add_form(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('CLE', base_url('cle/index'));
        $data['page_type'] = 'CLE';
		$data['states']  = $this->cle_model->get_state();	
        loadLayout('programmanager/cle/establish/form_add', 'program_manager', $data);
    }
	
    private function establish_validate(){          
        $this->form_validation->set_rules('statename', 'State', 'trim|required');
        //$this->form_validation->set_rules('financial_year', 'Fiancial Year', 'trim|required');
               
		
        if($this->form_validation->run() == TRUE){
            $requestdata  =   array(
                "statename"         		=>  $this->input->post('statename')        
               
             ); 
            return $requestdata;
        }else{
            $this->form_validation->set_error_delimiters('', '');
            $message    = array("0",validation_errors());
            $this->session->set_flashdata('message', $message);
            return false;
        }
    }
	
    public function establish_InsertForm(){	
        $requestdata    =   $this->establish_validate();
		
        if(!empty($requestdata)){
            if($this->cle_model->insertdata("cle_clinical_establishment",$requestdata)){
                $message    = array("1","Successfully Submit");
            }else{
                $message    = array("0",$this->db->_error_message());
            }
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url("cle/establish_add_form"));
    }
	
   

    public function establish_edit(){
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('CLE', base_url('cle/index'));
        $data['page_type'] = 'CLE';      
		$data['states']  = $this->cle_model->get_state();
        $data['row']   		=   $this->cle_model->fetchwhere("cle_clinical_establishment",array("id"=>$this->input->get('id')),"","row_array");		
        
		loadLayout('programmanager/cle/establish/form_add', 'program_manager', $data);
    }
	
    public function establish_update(){
        $requestdata    =   $this->establish_validate();
        	if(!empty($requestdata)){
	
			 if($this->cle_model->updatedata("cle_clinical_establishment",$requestdata,array("id"=>$this->input->post('id')))){
			    $message    = array("1","Successfully Update");
		
            }else{
                $message    = array("0",$this->db->_error_message());
                $this->session->set_flashdata('message', $message);
            }		
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('cle/establish_edit').'?action=edit&id='.$this->input->post('id'));
    }
	
    public function establish_delete(){
        
		if($this->input->get('id')){
            $this->cle_model->deletedata("cle_clinical_establishment",array("id"=>$this->input->get('id')));
			 $message    = array("1","Successfully Deleted");
			  $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('cle/establish_view'),'location');
    }
    
    
    
    /*---------------------------Start Notadopted ---------------------------------------------*/
    
    public function notadopted_view(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('CLE', base_url('cle/index'));
        $this->mybreadcrumb->add('Clinical Establishments Not Adopted', base_url('registered/index'));
        
        $data['page_type'] = 'CLE';
		
        $data['row']       = $this->cle_model->get_cle_notadopted();
		
        loadLayout('programmanager/cle/notadopted/form_list', 'program_manager', $data);
    }
	
    public function notadopted_add_form(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('CLE', base_url('cle/index'));
        $data['page_type'] = 'CLE';
		$data['states']  = $this->cle_model->get_state();
			
        loadLayout('programmanager/cle/notadopted/form_add', 'program_manager', $data);
    }
	
    private function notadopted_validate(){          
        $this->form_validation->set_rules('statename', 'State', 'trim|required');
        $this->form_validation->set_rules('type', 'Type', 'trim|required');
               
		
        if($this->form_validation->run() == TRUE){
            $requestdata  =   array(
                "statename"         		=>  $this->input->post('statename'),        
                "type"    =>  $this->input->post('type')
             ); 
            return $requestdata;
        }else{
            $this->form_validation->set_error_delimiters('', '');
            $message    = array("0",validation_errors());
            $this->session->set_flashdata('message', $message);
            return false;
        }
    }
	
    public function notadopted_InsertForm(){	
        $requestdata    =   $this->notadopted_validate();
		
        if(!empty($requestdata)){
            if($this->cle_model->insertdata("cle_state_notadopted",$requestdata)){
                $message    = array("1","Successfully Submit");
            }else{
                $message    = array("0",$this->db->_error_message());
            }
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url("cle/notadopted_add_form"));
    }
	
   

    public function notadopted_edit(){
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('CLE', base_url('cle/index'));
        $data['page_type'] = 'CLE';      
		$data['states']  = $this->cle_model->get_state();
        $data['row']   		=   $this->cle_model->fetchwhere("cle_state_notadopted",array("id"=>$this->input->get('id')),"","row_array");		
        
		loadLayout('programmanager/cle/notadopted/form_add', 'program_manager', $data);
    }
	
    public function notadopted_update(){
        $requestdata    =   $this->notadopted_validate();
        	if(!empty($requestdata)){
	
			 if($this->cle_model->updatedata("cle_state_notadopted",$requestdata,array("id"=>$this->input->post('id')))){
			    $message    = array("1","Successfully Update");
		
            }else{
                $message    = array("0",$this->db->_error_message());
                $this->session->set_flashdata('message', $message);
            }		
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('cle/notadopted_edit').'?action=edit&id='.$this->input->post('id'));
    }
	
    public function notadopted_delete(){
        
		if($this->input->get('id')){
            $this->cle_model->deletedata("cle_state_notadopted",array("id"=>$this->input->get('id')));
			 $message    = array("1","Successfully Deleted");
			  $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('cle/notadopted_view'),'location');
    }
	/*-------------------Start Treatment----------------------*/
    
	
    public function treatment_view(){  
        
		$this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('CLE', base_url('cle/index'));
        $this->mybreadcrumb->add('Clinical Establishments Treatment Guideline', base_url('treatment/index'));
        
        $data['page_type'] = 'CLE';
		
        $data['row']       = $this->cle_model->get_treatment_guidelines();
		
        loadLayout('programmanager/cle/treatment/form_list', 'program_manager', $data);
    }
	
    public function treatment_add_form(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('CLE', base_url('cle/index'));
        $data['page_type'] = 'CLE';
		$data['states']  = $this->cle_model->get_state();	
        loadLayout('programmanager/cle/treatment/form_add', 'program_manager', $data);
    }
	
    private function treatment_validate(){          
        $this->form_validation->set_rules('allopathic', 'Allopathic', 'trim|required');
        $this->form_validation->set_rules('ayush', 'Ayush', 'trim|required');
        //$this->form_validation->set_rules('financial_year', 'Fiancial Year', 'trim|required');
               
		
        if($this->form_validation->run() == TRUE){
            $requestdata  =   array(
                "allopathic"         		=>  $this->input->post('allopathic'),        
                "ayush"         		=>  $this->input->post('ayush')        
                
             ); 
            return $requestdata;
        }else{
            $this->form_validation->set_error_delimiters('', '');
            $message    = array("0",validation_errors());
            $this->session->set_flashdata('message', $message);
            return false;
        }
    }
	
    public function treatment_InsertForm(){	
        $requestdata    =   $this->treatment_validate();
		
        if(!empty($requestdata)){
            if($this->cle_model->insertdata("cle_treatment_guidelines",$requestdata)){
                $message    = array("1","Successfully Submit");
            }else{
                $message    = array("0",$this->db->_error_message());
            }
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url("cle/treatment_add_form"));
    }
	
   

    public function treatment_edit(){
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('CLE', base_url('cle/index'));
        $data['page_type'] = 'CLE';      
	//	$data['states']  = $this->cle_model->get_state();
        $data['row']   		=   $this->cle_model->fetchwhere("cle_treatment_guidelines",array("id"=>$this->input->get('id')),"","row_array");		
        
		loadLayout('programmanager/cle/treatment/form_add', 'program_manager', $data);
    }
	
    public function treatment_update(){
        $requestdata    =   $this->treatment_validate();
        	if(!empty($requestdata)){
	
			 if($this->cle_model->updatedata("cle_treatment_guidelines",$requestdata,array("id"=>$this->input->post('id')))){
			    $message    = array("1","Successfully Update");
		
            }else{
                $message    = array("0",$this->db->_error_message());
                $this->session->set_flashdata('message', $message);
            }		
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('cle/treatment_edit').'?action=edit&id='.$this->input->post('id'));
    }
	
    public function treatment_delete(){
        
		if($this->input->get('id')){
            $this->cle_model->deletedata("cle_treatment_guidelines",array("id"=>$this->input->get('id')));
			 $message    = array("1","Successfully Deleted");
			  $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('cle/treatment_view'),'location');
    }
	
	
	
	/*-------------------Start Registered----------------------*/
    
	
    public function register_view(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('CLE', base_url('cle/index'));
        $this->mybreadcrumb->add('Clinical Establishments Registered', base_url('register/index'));
        
        $data['page_type'] = 'CLE';
		
        $data['row']       = $this->cle_model->get_cle_registered();
		
        loadLayout('programmanager/cle/register/form_list', 'program_manager', $data);
    }
	
    public function register_add_form(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('CLE', base_url('cle/index'));
        $data['page_type'] = 'CLE';
		$data['states']  = $this->cle_model->get_state();	
        loadLayout('programmanager/cle/register/form_add', 'program_manager', $data);
    }
	
    private function register_validate(){          
        $this->form_validation->set_rules('statename', 'State Name', 'trim|required');
        $this->form_validation->set_rules('allopathy', 'Allopathic', 'trim|required');
        $this->form_validation->set_rules('ayurveda', 'Ayurveda', 'trim|required');
        $this->form_validation->set_rules('unani', 'Unani', 'trim|required');
        $this->form_validation->set_rules('siddha', 'Siddha', 'trim|required');
        $this->form_validation->set_rules('homoeopathy', 'Homoeopathy', 'trim|required');
        $this->form_validation->set_rules('yoga', 'Yoga', 'trim|required');
        $this->form_validation->set_rules('naturapathy', 'Naturapathy', 'trim|required');
        $this->form_validation->set_rules('sowa', 'Sowa', 'trim|required');
               
		
        if($this->form_validation->run() == TRUE){
            $requestdata  =   array(
                "statename"         		=>  $this->input->post('statename'),        
                "allopathy"         		=>  $this->input->post('allopathy'),        
                "ayurveda"    =>  $this->input->post('ayurveda'),
				"unani"    =>  $this->input->post('unani'),
                "siddha"    =>  $this->input->post('siddha'),
                "homoeopathy"    =>  $this->input->post('homoeopathy'),
                "yoga"    =>  $this->input->post('yoga'),
                "naturapathy"    =>  $this->input->post('naturapathy'),
                "sowa"    =>  $this->input->post('sowa'),
				
             ); 
            return $requestdata;
        }else{
            $this->form_validation->set_error_delimiters('', '');
            $message    = array("0",validation_errors());
            $this->session->set_flashdata('message', $message);
            return false;
        }
    }
	
    public function register_InsertForm(){	
        $requestdata    =   $this->register_validate();
		//var_dump($requestdata);die;
        if(!empty($requestdata)){
            if($this->cle_model->insertdata("cle_registered",$requestdata)){
                $message    = array("1","Successfully Submit");
            }else{
                $message    = array("0",$this->db->_error_message());
            }
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url("cle/register_add_form"));
    }
	
   

    public function register_edit(){
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('CLE', base_url('cle/index'));
        $data['page_type'] = 'CLE';      
	 	$data['states']  = $this->cle_model->get_state();
        $data['row']   		=   $this->cle_model->fetchwhere("cle_registered",array("id"=>$this->input->get('id')),"","row_array");		
        
		loadLayout('programmanager/cle/register/form_add', 'program_manager', $data);
    }
	
    public function register_update(){
        $requestdata    =   $this->register_validate();
        	if(!empty($requestdata)){
	
			 if($this->cle_model->updatedata("cle_registered",$requestdata,array("id"=>$this->input->post('id')))){
			    $message    = array("1","Successfully Update");
		
            }else{
                $message    = array("0",$this->db->_error_message());
                $this->session->set_flashdata('message', $message);
            }		
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('cle/register_edit').'?action=edit&id='.$this->input->post('id'));
    }
	
    public function cle_register_delete(){
        
		if($this->input->get('id')){
            $this->cle_model->deletedata("cle_registered",array("id"=>$this->input->get('id')));
			 $message    = array("1","Successfully Deleted");
			  $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('cle/register_view'),'location');
    }
	
	
	
	
	
	
}