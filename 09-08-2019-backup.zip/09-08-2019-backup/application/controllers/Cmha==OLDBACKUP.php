<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Cmha extends MY_Controller {
    private $user;

    public function __construct() {
        parent::__construct();

        $this->load->helper('commondata_helper');

        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('programmanager/Cmha_model');
                
        $this->user = new Users();

        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');
    }
	

    public function index() { 
		
		$this->view();
    }
	
	 public function add_form(){  
        
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('CMHA', base_url('cmha/index'));

        $data['states']    = $this->Cmha_model->get_state();

		$data['districts'] = $this->Cmha_model->get_district();

        $data['page_type'] = 'Health Service Delivery';

        loadLayout('programmanager/cmha/cmha_form', 'program_manager', $data);
    }
	
	private function validate(){          
        $this->form_validation->set_rules('statename', 'State Name', 'trim|required');
        $this->form_validation->set_rules('districtname', 'District', 'trim|required');
         $this->form_validation->set_rules('hospital_name', 'Name of hospital', 'trim|required');
        $this->form_validation->set_rules('patient_treated_opd', 'Number of Patients treated in OPD', 'trim|required');
        $this->form_validation->set_rules('patient_treated_opd_lastentry', 'Patients OPD(name of month & year)', 'trim|required');
		$this->form_validation->set_rules('patient_treated_ipd', 'Number of Patients treated in IPD', 'trim|required');
        $this->form_validation->set_rules('patient_treated_ipd_lastentry', 'Patients IPD(name of month & year)', 'trim|required');
        $this->form_validation->set_rules('medical_officers', 'Medical Officers ', 'trim|required');
        $this->form_validation->set_rules('medical_officers_lastentry', 'Medical Officers(name of month & year)', 'trim|required');
        $this->form_validation->set_rules('psychologists', 'Psychologists', 'trim|required');
        $this->form_validation->set_rules('psychologists_lastentry', 'Psychologists(name of month & year)', 'trim|required');
		$this->form_validation->set_rules('social_workers', 'Social Workers', 'trim|required');
        $this->form_validation->set_rules('social_workers_lastentry', 'Social Workers(name of month & year)', 'trim|required');
        $this->form_validation->set_rules('nurses', 'Nurses', 'trim|required');
        $this->form_validation->set_rules('nurses_lastentry', 'Nurses(name of month & year)', 'trim|required');

        if($this->form_validation->run() == TRUE){
            $requestdata  =   array(
                "statename"                    =>  $this->input->post('statename'),
                "districtname"               =>  $this->input->post('districtname'), 
                "hospital_name"               =>  $this->input->post('hospital_name'),        
                "patient_treated_opd"                =>  $this->input->post('patient_treated_opd'),               
                "patient_treated_opd_lastentry"      =>  date('Y-m-d',strtotime($this->input->post('patient_treated_opd_lastentry'))),
				"patient_treated_ipd"                 =>  $this->input->post('patient_treated_ipd'),
                "patient_treated_ipd_lastentry"       =>  date('Y-m-d',strtotime($this->input->post('patient_treated_ipd_lastentry'))),
                "medical_officers"        =>  $this->input->post('medical_officers'),
                "medical_officers_lastentry"  => date('Y-m-d',strtotime($this->input->post('medical_officers_lastentry'))), 
                "psychologists"          =>  $this->input->post('psychologists'),
                "psychologists_lastentry"      =>  date('Y-m-d',strtotime($this->input->post('psychologists_lastentry'))),
                "social_workers"                      =>  $this->input->post('social_workers'),
                "social_workers_lastentry"      =>  date('Y-m-d',strtotime($this->input->post('social_workers_lastentry'))),
                 "nurses"                      =>  $this->input->post('nurses'),
                "nurses_lastentry"      =>  date('Y-m-d',strtotime($this->input->post('nurses_lastentry'))),
            ); 

            return $requestdata;
        }else{
            $this->form_validation->set_error_delimiters('', '');
            $message    = array("0",validation_errors());
            $this->session->set_flashdata('message', $message);
            return false;
        }
    }
	
	public function insertForm(){	
        $requestdata    =   $this->validate();
		//var_dump($requestdata);die;
        if(!empty($requestdata)){
            if($this->Cmha_model->insertdata("tbl_cmha",$requestdata)){
                $message    = array("1","Successfully Submit");
            }else{
                $message    = array("0",$this->db->_error_message());
            }
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url("cmha/add_form"));
    }
	
	public function view(){  

		$this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('CMHA', base_url('cmha/add_form'));        
        //$data['states']    = $this->Cmha_model->get_state();
       // $data['districts']    = $this->Cmha_model->get_district();
        $data['page_type'] = 'Health Service Delivery';
		$data['row']    = $this->Cmha_model->get_cmhaform();

//var_dump($data['row']); die;
        loadLayout('programmanager/cmha/cmha_list', 'program_manager', $data);
	}


	public function editForm(){
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('CMHA', base_url('cmha/index'));
        
        $data['states']     = $this->Cmha_model->get_state();
		$data['districts']  = $this->Cmha_model->get_district();
       // $data['row']   		=   $this->Cmha_model->fetchwhere("tbl_cmha",$this->input->get('id'));
		 $data['row']         =   $this->Cmha_model->fetchwhere("tbl_cmha",array("id"=>$this->input->get('id')),"","row_array");
        $data['page_type'] = 'Health Service Delivery';
		loadLayout('programmanager/cmha/cmha_form', 'program_manager', $data);
    }
	
    public function updateForm(){
        $requestdata    =   $this->validate();
        	if(!empty($requestdata)){
	
			 if($this->Cmha_model->updatedata("tbl_cmha",$requestdata,array("id"=>$this->input->post('id')))){
			    $message    = array("1","Successfully Update");
		
            }else{
                $message    = array("0",$this->db->_error_message());
                $this->session->set_flashdata('message', $message);
            }		
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('cmha/editForm').'?action=edit&id='.$this->input->post('id'));
    }
	
    public function deleteForm(){
        
		if($this->input->get('id')){
            $this->Cmha_model->deletedata("tbl_cmha",array("id"=>$this->input->get('id')));
			 $message    = array("1","Successfully Deleted");
			  $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('cmha/view'),'location');
    }	
	
	
	public function getDistrict($id) 
	{ 
		$result = $this->db->where("State_ID",$id)->get("m_district")->result();
        echo json_encode($result);
	}
	
	
	 
		
		
		
	}