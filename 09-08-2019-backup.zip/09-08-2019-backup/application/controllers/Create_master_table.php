<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Create_master_table extends CI_Controller {

    private $user;
    
    public function __construct() {
        parent::__construct();
        $this->load->model('Dashboard_model');
        $this->user = new Users();
    }

    public function index() {
        $f_year = "2018-19";
        $state_count = $this->Dashboard_model->get_state_count();
        
        $fetch_curr_date = $this->Dashboard_model->fetch_curr_date(); 
        $district_count = $this->Dashboard_model->get_district_count();
        $rgc_count = $this->Dashboard_model->get_rgc_count();
        $national_center_aging = 2;
        $state_color = $this->Dashboard_model->get_unsaved_state_data($f_year);
        $max_month  = max(array_column($state_color, 'month'));
        $month_name = $this->Dashboard_model->get_month_name_by_id($max_month);
        $fund_utilization = $this->Dashboard_model->get_all_fund_utilization($f_year); 
        $fund_allocation = $this->Dashboard_model->get_all_fund_allocation($f_year);
        $all_services_count = $this->Dashboard_model->all_service_total($f_year,NULL);

        $query = "insert into elderly_master_table (`financial_year`,`state_count`,`fetch_curr_date`,`district_count`,`rgc_count`,`national_center_ageing`,`state_color`,`max_month`,`month_name`,`fund_utilization`,`fund_allocation`,`all_services_count`) values ('".$f_year."','".serialize($state_count)."','".serialize($fetch_curr_date)."','".serialize($district_count)."','".serialize($rgc_count)."','".serialize($national_center_aging)."','".serialize($state_color)."','".serialize($max_month)."','".serialize($month_name)."','".serialize($fund_utilization)."','".serialize($fund_allocation)."','".serialize($all_services_count)."')" ;
           
        $rec = $this->db->query($query);
            
        if($rec){
            echo "row affected";
        }else{
            echo "not affected";
        }
           
           
    }
    
    
    


}