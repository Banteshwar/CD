<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard123 extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('hwc_model');
        $this->load->model('Dashboard_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() {  
	
         //$msgdata="hi kunal";
       

       //echo $this->smslib->sendSMS('9990624477',$msgdata);
       // die;
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('dashboard/ninportal'));
        
        $data['page_type']='Healthcare Infrastructure';
        $data['kiosk'] = $this->Dashboard_model->get_kiosk();
        /* ============ data fetch to master table code ============ */
        $ninmasterrec = fetchNINsyncdata();
            
        //$data['functionalFacilities']  = unserialize($ninmasterrec['total_functional_facilities']);
        $data['functionalFacilities'] = getNINFunctionalFacilities('','');
        
        $ID = 0;
        $State_ID = 0;
        
        $syncrec = fetchsyncdata($ID, $State_ID);
        $data['getApprovedState']  = unserialize($syncrec['getApprovedState']);
        $data['HWCGraphReport']  = unserialize($syncrec['hwcGraphReport']);
        /* ================ end ==================== */
       //$data['getApprovedState'] = getApprovedData(0, 0);
        loadLayout('admin/health_infra', 'admin', $data);
    }
	
	public function hwc() {
			
        /*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
		
		$this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('dashboard/index'));
        $this->mybreadcrumb->add('HWC', base_url('dashboard/hwc'));
		$data['page_type']='Healthcare Infrastructure';
        global $CURRENT_USER_STATE;
        
        $_REQUEST;
        $user = $this->user;
        
        //============= master database sync code here ===============//

       // $data['SYNC'] = syncHWCdatabase();
    
    //============= end master database sync code ===============//
    

        
        if ( ! $hwc_user_row = $this->cache->file->get('hwc_user_row'))
        {
            $hwc_user_row= $user->getUser();
            $this->cache->file->save('hwc_user_row', $hwc_user_row, 300);
        }
       
            $user_row = $hwc_user_row;
            $DASHBOARD = 0;
            $state = 0;
            $ID = 0;
            $TYPE = 0;
            $State_ID  =0;
            $State_Name  =0;
            
           
                    
        if (isset($_REQUEST['ID'])){

            $ID = 1;
            $State_ID   = $_REQUEST['ID'];
           
            $State_Name = $this->hwc_model->get_statename($State_ID); 
            $template   = array('page' => 'admin/dashboard/hwc', 'type' => 'popup');
        }else{
            $template   = array('page' => 'admin/dashboard/dashboard', 'type' => 'admin');
        }
   
     	//$data['HWCGraphCAReport'] = getHWCGraphCAReport($DASHBOARD, $ID); 
       
       // print_r($data['State_Name']); die;
       /* $data['HWCGraphReport'] = getHWCGraphReport($DASHBOARD, $ID);
        $data['HWCGraphCAReport'] = getHWCGraphCAReport($DASHBOARD, $ID);
        $data['getApprovedState'] = getApprovedData($DASHBOARD, $ID);
        $data['entry_status_graph_data'] = getGraphData($DASHBOARD, $ID);
        $data['HWC_CA_Report'] = getHWCCAReport($DASHBOARD, $ID);
       */
        
        $data['HWC_Report'] = getHWCReport($DASHBOARD, $ID);
        
        $syncrec 			= fetchsyncdata($ID, $State_ID);
		
        $HWCCAReport  		= unserialize($syncrec['hwcCAreport']);
        $getApprovedState   = unserialize($syncrec['getApprovedState']);
		/*echo "<pre>";
		print_r($getApprovedState);die;*/
        $HWCGraphReport  	= unserialize($syncrec['hwcGraphReport']);
        $HWCGraphCAReport   = unserialize($syncrec['hwcGraphCAReport']);
        $entry_status_graph_data  = unserialize($syncrec['entry_status_graph_data']);
        
        $data['DASHBOARD']  = $DASHBOARD;
        
        $data['getApprovedState']  = $getApprovedState;
        $data['HWCGraphReport']  = $HWCGraphReport;
        $data['HWCGraphCAReport']  = $HWCGraphCAReport;
        $data['entry_status_graph_data']  = $entry_status_graph_data;
        
        $data['HWC_CA_Report'] = $HWCCAReport;
        
        $data['data_temp'] = $_REQUEST;
        $data['_REQUEST'] = $_REQUEST;
        $data['user'] = $user;
        $data['State_ID'] = $State_ID;
        $data['State_Name'] = $State_Name;
        
        $data['updated_page'] = date('d M  Y');
        $data['remote_site_url'] = 'https://ab-hwc.nhp.gov.in/home/apilogintoken';

        loadLayout($template['page'], $template['type'], $data);

    }
	
	 public function dashboard_ajax() {
        
        $state_code = $this->input->post('state_code');
        
        $financial_year = $this->input->post('financial_year');
        if($financial_year!=""){
            $f_year = $financial_year;
        }else{
            $f_year = "2018-19";    
        }

if($state_code!='')
{			
			$elderly = $this->Dashboard_model->getelderlymasterrecord();


            /*$data['district_count'] = $this->Dashboard_model->get_district_count($state_code);
            $state_name=$this->Dashboard_model->get_state_by_code($state_code);
            $data['title']=$state_name['state_name'];
            $data['fund_allocation'] = $this->Dashboard_model->get_state_fund_allocation($state_code,$f_year);
            $data['fund_utilization'] = $this->Dashboard_model->get_state_fund_utilization($state_code,$f_year);
            $data['services'] = $this->Dashboard_model->state_all_service($f_year,$state_code);
            $data['ncd_enc'] = $this->Dashboard_model->get_ncd_cell($f_year,$state_code,5);
            $data['ncd_ros'] = $this->Dashboard_model->get_ncd_cell($f_year,$state_code,6);
            $data['ncd_ol'] = $this->Dashboard_model->get_ncd_cell($f_year,$state_code,7);
            $data['dh'] = $this->Dashboard_model->facility_wise_state_service($f_year,$state_code,'DH');
            $data['chc'] = $this->Dashboard_model->facility_wise_state_service($f_year,$state_code,'CHC');
            //$data['phc'] = $this->Dashboard_model->facility_wise_state_service($f_year,$state_code,'PHC');

            $data['phc'] =    unserialize($elderly['phc_services']);
           // var_dump($data['phc']);die;
            $data['sc'] = $this->Dashboard_model->facility_wise_state_service($f_year,$state_code,'SC');
            $state_name=$this->Dashboard_model->get_state_by_code($state_code);
            $data['title']=$state_name['state_name'];*/


        $data['state_count']      =  unserialize($elderly['state_count']);
        $data['fetch_curr_date']  =  unserialize($elderly['fetch_curr_date']);
        $data['district_count']   =  unserialize($elderly['district_count']);
        $data['rgc_count']        =  unserialize($elderly['rgc_count']);
        $data['national_center']  =  unserialize($elderly['national_center_ageing']);        
        $data['state_color']      =  unserialize($elderly['state_color']);
        $data['max_month']        =  unserialize($elderly['max_month']);
        $data['month_name']       =  unserialize($elderly['month_name']);       
        $fund_utilization         =  unserialize($elderly['fund_utilization']);
        $data['fund_utilization'] =  $fund_utilization[0];
		$fund_allocation          =  unserialize($elderly['fund_allocation']);
        $data['fund_allocation']  =  $fund_allocation[0];
        $data['all_services_count']  =  unserialize($elderly['all_services_count']);

        $data['phc_services']  =  unserialize($elderly['phc_services']);
        $data['dh_services']  =  unserialize($elderly['dh_services']);

        $data['chc_services']  =  unserialize($elderly['chc_services']);
        $data['sc_services']  =  unserialize($elderly['sc_services']);
        $data['all_state_funds']  =  unserialize($elderly['all_state_funds']);
        $data['ncd_enc']  =  unserialize($elderly['ENC']);
        $data['ncd_ol']   =  unserialize($elderly['OL']);        
        $data['financial_year']   =  $f_year;
    
    }

    else
    {
        $data['district_count']['no_of_district'] =  0;
    }
        $json_data = json_encode($data);

        echo $json_data;
        //print_r($json_data) ;
        exit();
    }
	
	public function pmsmaold() {
        $data['page_type']='Healthcare Infrastructure';
        loadLayout('admin/new_pmsma', 'admin',  $data);
    }
	 public function ninportal() { 
		$this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('dashboard/index'));
        $this->mybreadcrumb->add('NIN Portal', base_url('dashboard/ninportal'));
        /////////////////// master database sync code here ///////
        //$data['SYNC_NIN'] = syncNINdatabase();
        ////////////////// end master database sync code /////////
        ////////// show state ////////////
        //echo $this->input->get('state_name'); die;
        if ($this->input->get('state_name')) {
            $state_id=$this->input->get('state_name');
        }
        else
        {
            $state_id='';
        } 
        $data['searh_state_id']=$state_id;

        //echo $data['searh_state_id']; die;
            
        if ( ! $nin_state = $this->cache->file->get('nin_state'))
        {
            $nin_state=$this->hwc_model->get_state();
            $this->cache->file->save('nin_state', $nin_state, 300);
        }
            $data['state'] = $nin_state;
            $data['state'] = $nin_state; 
            $data['state_name'] = $this->hwc_model->get_statename($state_id);
        ////////// end show state ////////////
        
            $ninmasterrec = fetchNINsyncdata($state_id);
            
            $data['functionalFacilities']  = unserialize($ninmasterrec['total_functional_facilities']);
            $data['functionalStateWiseFacilities']  = unserialize($ninmasterrec['nin_functionalStateWiseFacilities']);
            $data['totalFacilitiesOperationalStatus']  = unserialize($ninmasterrec['nin_totalFacilitiesOperationalStatus']);
            $data['totalConfirmedVerified']  = unserialize($ninmasterrec['nin_totalConfirmedVerified']);
            $data['totalFacilitiesOperationalStatusStateWise']  = unserialize($ninmasterrec['nin_totalFacilitiesOperationalStatusStateWise']);
            
            $data['functionalFacilitiesStateWise']  = unserialize($ninmasterrec['nin_functionalFacilitiesStateWise']);

            $data['totalConfirmedVerifiedStateWise']  = unserialize($ninmasterrec['nin_totalConfirmedVerifiedStateWise']);
            $data['totalRuralUrbanVerifiedStateWise']  = unserialize($ninmasterrec['nin_totalRuralUrbanVerifiedStateWise']);
            $data['totalRuralUrbanVerified']  = unserialize($ninmasterrec['nin_totalRuralUrbanVerified']); 
          /*  echo "<pre>";
            print_r($ninmasterrec); die;
             */
            
           
       /* if( ! $nin_functionalStateWiseFacilities = $this->cache->file->get('nin_functionalStateWiseFacilities'))
        {
            $nin_functionalStateWiseFacilities=getNINFunctionalStateWiseFacilities();
            $this->cache->file->save('nin_functionalStateWiseFacilities', $nin_functionalStateWiseFacilities, 300);
        }
            $data['functionalStateWiseFacilities'] = $nin_functionalStateWiseFacilities;
            $data['functionalFacilities'] = getNINFunctionalFacilities('',$state_id);
        
        if ( ! $nin_functionalFacilitiesStateWise = $this->cache->file->get('nin_functionalFacilitiesStateWise'))
        {
            $nin_functionalFacilitiesStateWise=getNINFunctionalFacilities(TRUE);
            $this->cache->file->save('nin_functionalFacilitiesStateWise', $nin_functionalFacilitiesStateWise, 300);
        }
            $data['functionalFacilitiesStateWise'] = $nin_functionalFacilitiesStateWise;
		
        if( ! $nin_totalConfirmedVerified = $this->cache->file->get('nin_totalConfirmedVerified'))
        {
            $nin_totalConfirmedVerified=getNINTotalConfirmedVerified();
            $this->cache->file->save('nin_totalConfirmedVerified', $nin_totalConfirmedVerified, 300);
        }
            $data['totalConfirmedVerified'] = $nin_totalConfirmedVerified;

        if ( ! $nin_totalConfirmedVerifiedStateWise = $this->cache->file->get('nin_totalConfirmedVerifiedStateWise'))
        {
            $nin_totalConfirmedVerifiedStateWise=getNINTotalConfirmedVerified(TRUE);
            $this->cache->file->save('nin_totalConfirmedVerifiedStateWise', $nin_totalConfirmedVerifiedStateWise, 300);
        }
            $data['totalConfirmedVerifiedStateWise'] = $nin_totalConfirmedVerifiedStateWise;
		
		
        if ( ! $nin_totalRuralUrbanVerified = $this->cache->file->get('nin_totalRuralUrbanVerified'))
        {
            $nin_totalRuralUrbanVerified=getNINTotalRuralUrbanVerified(); 
            $this->cache->file->save('nin_totalRuralUrbanVerified', $nin_totalRuralUrbanVerified, 300);
        }
            $data['totalRuralUrbanVerified'] = $nin_totalRuralUrbanVerified;

        if ( ! $nin_totalRuralUrbanVerifiedStateWise = $this->cache->file->get('nin_totalRuralUrbanVerifiedStateWise'))
        {
            $nin_totalRuralUrbanVerifiedStateWise=getNINTotalRuralUrbanVerified(TRUE);
            $this->cache->file->save('nin_totalRuralUrbanVerifiedStateWise', $nin_totalRuralUrbanVerifiedStateWise, 300);
        }
            $data['totalRuralUrbanVerifiedStateWise'] =  $nin_totalRuralUrbanVerifiedStateWise;
        
        if ( ! $nin_totalFacilitiesOperationalStatus = $this->cache->file->get('nin_totalFacilitiesOperationalStatus'))
        {
            $nin_totalFacilitiesOperationalStatus=getFacilitiesOperationalStatus();
            $this->cache->file->save('nin_totalFacilitiesOperationalStatus', $nin_totalFacilitiesOperationalStatus, 300);
        }
		
            $data['totalFacilitiesOperationalStatus'] = $nin_totalFacilitiesOperationalStatus; 

        if ( ! $nin_totalFacilitiesOperationalStatusStateWise = $this->cache->file->get('nin_totalFacilitiesOperationalStatusStateWise'))
        {
            $nin_totalFacilitiesOperationalStatusStateWise= getFacilitiesOperationalStatus(TRUE);
            $this->cache->file->save('nin_totalFacilitiesOperationalStatusStateWise', $nin_totalFacilitiesOperationalStatusStateWise, 300);
        }
		
            $data['totalFacilitiesOperationalStatusStateWise'] =  $nin_totalFacilitiesOperationalStatusStateWise;*/
            $data['remote_site_url'] = 'https://nin.nhp.gov.in/cdapilogin.php';
            $data['page_type']='Healthcare Infrastructure';
	    	$data['updated_page'] = date('d M  Y');
            loadLayout('admin/nin_portal', 'admin', $data);
    }

}