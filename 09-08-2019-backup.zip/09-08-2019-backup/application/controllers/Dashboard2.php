<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard2 extends MY_Controller {

    private $user;

    public function __construct() {
        parent::__construct();

//        $this->load->helper('hwc_dashboard');
//        $this->load->model('hwc_model');

        global $db;
        $this->db = $db;
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
    }

    public function index() {
        loadLayout('admin/dashboard/dashboard2', 'admin', 0);
    }

    public function login_api() {


        $ch = curl_init();

$postData = array(
    'apikey' => 'HWC_CENTRAL_DASHBORD_LOGIN2018',
    'source' => 'central_dashboard'
     
);

curl_setopt_array($ch, array(
    CURLOPT_URL => 'http://172.16.1.165:8080/nin_ci/home/apilogintoken',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $postData,
    CURLOPT_FOLLOWLOCATION => true
));

$output = curl_exec($ch);


$output_object = json_decode($output);
//echo 'hhaa='.print_r($output_object); die;

$return["return_url"]=  $output_object->return_url; 

$return["status"]=  $output_object->status;

$return["message"] =$output_object->message;

$return["json"] = json_encode($return);
echo json_encode($return);

         die;
    }
}
