
<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   


    public function state_count() {
//        $obj =& get_instance();
        $this->db->select("COUNT(*) as no_of_state");
        $this->db->from('mst_state1');
        $this->db->where('state_code !=', 0);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row_array();
        } else {
            return false;
        }
        $query->free_result();
    }

    public function district_count($state_code = NULL) {

        if ($state_code != NULL) {
            //$wh = 'state_code=$state_code';

            $scode = "state_code=$state_code ";
        } else {
            $scode = ' 1=1';
        }

        $sql = "SELECT  COUNT(*)  as  no_of_district FROM `npcdc_state_district_mapping`  where $scode";
        //echo $sql;
        $result = $this->db->query($sql);
        $query = $result->fetch();
        if ($query) {
            return $query;
        } else {
            return false;
        }
    }

    public function rgc_count() {

        $sql = 'SELECT COUNT(*) as no_of_rgc FROM `state_rmi_relation` ';
        $result = $this->db->query($sql);
        $query = $result->fetch();
        if ($query) {
            return $query;
        } else {
            return false;
        }
    }
	
	
		public function insertdata($tbl_name,$value){
        if($this->db->insert($tbl_name, $value)){
            return true;
        }else{
            return false;
        }
    }

    //############### Dashboard start ##############
    public function get_state_count() {
//        $obj =& get_instance();
        $this->db->select("COUNT(*) as no_of_state");
        $this->db->from('mst_state1');
        $this->db->where('state_code !=', 0);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row_array();
        } else {
            return false;
        }
        $query->free_result();
    }

    public function get_district_count($state_code = NULL) {
        $this->db->select("COUNT(*) as no_of_district");
        $this->db->from('npcdc_state_district_mapping');
        if ($state_code != NULL) {
            $this->db->where('state_code', $state_code);
        }
        $query = $this->db->get();
        
        if ($query->num_rows() >= 1) {
            return $query->row_array();
        } else {
            return false;
        }
        $query->free_result();
    }

    public function get_state_fund_allocation($state_code = NULL, $f_year = NULL) {
        $this->db->select("fa_state_id,fa_total");
        $this->db->from('nphce_fund_allocation');
        $this->db->where('fa_state_id', $state_code);
        $this->db->where('fa_financial_year', $f_year);
        $this->db->where('fa_district_id is NULL');
        $this->db->where('fa_facility_id is NULL');
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row_array();
        } else {
            return 0;
        }
        $query->free_result();
    }

    public function get_state_fund_utilization($state_code = NULL, $f_year = NULL) {
        $this->db->select("fu_state_id,fu_total");
        $this->db->from('nphce_fund_utilisation as fu');
        $this->db->join("(select pr_financial_year, pr.pr_state_id, max(month_order) as month_order from mst_months
		inner join  nphce_progress_report as pr on mst_months.month_id = pr.pr_month 
		where pr.pr_district_id is null and pr_financial_year= '$f_year'
		group by pr_state_id) as max_month", " on max_month.pr_financial_year = fu.fu_financial_year
		and max_month.month_order = fu.fu_month and max_month.pr_state_id = fu.fu_state_id", "INNER");
        $this->db->where('fu.fu_financial_year', $f_year);
        $this->db->where('fu_state_id', $state_code);
        $this->db->where('fu.fu_district_id is NULL');
        $this->db->where('fu.fu_facility_id is NULL');
        $this->db->where('fu.fu_rgc_id is NULL');
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row_array();
        } else {
            return 0;
        }
        $query->free_result();
    }

    public function get_all_fund_allocation($f_year = NULL) {
        $this->db->select("sum(fa_total) as 'fa_total'");
        $this->db->from('nphce_fund_allocation');
        $this->db->where('fa_financial_year', $f_year);
        $this->db->where('fa_state_id is not NULL');
        $this->db->where('fa_district_id is NULL');
        $this->db->where('fa_facility_id is NULL');
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return 0;
        }
        $query->free_result();
    }

    public function get_all_fund_utilization($f_year = NULL) {
        $this->db->select("sum(fu_total) as 'fu_total'");
        $this->db->from('nphce_fund_utilisation as fu');
        $this->db->join("(select pr_financial_year, pr.pr_state_id, max(month_order) as month_order from mst_months
		inner join  nphce_progress_report as pr on mst_months.month_id = pr.pr_month 
		where pr.pr_district_id is null and pr_financial_year= '$f_year'
		group by pr_state_id) as max_month", " on max_month.pr_financial_year = fu.fu_financial_year
		and max_month.month_order = fu.fu_month and max_month.pr_state_id = fu.fu_state_id", "INNER");
        $this->db->where('fu.fu_financial_year', $f_year);
        $this->db->where('fu.fu_state_id is not NULL');
        $this->db->where('fu.fu_district_id is NULL');
        $this->db->where('fu.fu_facility_id is NULL');
        $this->db->where('fu.fu_rgc_id is NULL');
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return 0;
        }
        $query->free_result();
    }

    public function get_ncd_cell($f_year = NULL, $state_code = NULL, $service_id = NULL) {
        $this->db->select("n.pr_state_id,nd.dpr_service_id,nd.dpr_achieved");
        $this->db->from('nphce_progress_report n');
        $this->db->join('nphce_dpr as nd', ' nd.dpr_progress_report_id = n.pr_id');
        $this->db->join("(select pr_financial_year, pr.pr_state_id, max(month_order) as month_order from mst_months
inner join  nphce_progress_report as pr on mst_months.month_id = pr.pr_month where pr.pr_district_id is null and pr_financial_year= '$f_year'
group by pr_state_id) as max_month", " on max_month.pr_financial_year = n.pr_financial_year
and max_month.month_order = n.pr_month and max_month.pr_state_id = n.pr_state_id", "INNER");
        $this->db->where('n.pr_state_id', $state_code);
        $this->db->where('n.pr_financial_year', $f_year);
        $this->db->where('nd.dpr_service_id', $service_id);
        $this->db->where('n.pr_district_id is NULL');
        $this->db->where('n.pr_facility_id is NULL');
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row_array();
        } else {
            return 0;
        }
        $query->free_result();
    }

    public function get_all_ncd_cell($f_year = NULL, $service_id = NULL, $state_code = NULL) {
        $this->db->select("sum(nd.dpr_achieved) as 'total'");
        $this->db->from('nphce_progress_report n');
        $this->db->join('nphce_dpr as nd', ' nd.dpr_progress_report_id = n.pr_id');
        $this->db->join("(select pr_financial_year, pr.pr_state_id, max(month_order) as month_order from mst_months
inner join  nphce_progress_report as pr on mst_months.month_id = pr.pr_month where pr.pr_district_id is null and pr_financial_year= '$f_year'
group by pr_state_id) as max_month", " on max_month.pr_financial_year = n.pr_financial_year
and max_month.month_order = n.pr_month and max_month.pr_state_id = n.pr_state_id", "INNER");
        $this->db->where('n.pr_financial_year', $f_year);
        $this->db->where('nd.dpr_service_id', $service_id);
        $this->db->where('n.pr_district_id is NULL');
        $this->db->where('n.pr_facility_id is NULL');
        if ($state_code != NULL) {
            $this->db->where('n.pr_state_id', $state_code);
        }
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row_array();
        } else {
            return 0;
        }
        $query->free_result();
    }

    public function facility_wise_state_service($FinancialYear, $StateId, $facility_type) {
        $financialyear = check_input($FinancialYear);
        $state_id = check_input($StateId);
        $this->db->select("dft_service_id, sum(dft_achieved) as 'total'");
        $this->db->from('nphce_progress_report as progress ');
        $this->db->join('nphce_dpr_facility_type  as dpr', 'progress.pr_id = dpr.dft_progress_report_id');
        $this->db->join('mst_months', ' month_id = progress.pr_month');
        $this->db->join('nphce_services_new as services', 'services.service_id = dpr.dft_service_id');
        $this->db->join("(select pr_financial_year, pr.pr_state_id, max(month_order) as month_order from mst_months
inner join  nphce_progress_report as pr on mst_months.month_id = pr.pr_month where pr.pr_district_id is null and pr_financial_year= '$financialyear'
group by pr_state_id) as max_month", " on max_month.pr_financial_year = progress.pr_financial_year
and max_month.month_order = progress.pr_month and max_month.pr_state_id = progress.pr_state_id", "INNER");
        $this->db->where('services.service_group_id  ', 5);
        $this->db->where('services.service_state ', 1);
        if ($financialyear) {
            $this->db->where('progress.pr_financial_year = ', $financialyear);
        }
        if ($state_id) {
            $this->db->where('progress.pr_state_id = ', $state_id);
        }
        $this->db->where('dft_facility_type = ', $facility_type);
        $this->db->group_by('dft_service_id');
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return false;
        }
        $query->free_result();
    }

    public function all_service_total($FinancialYear = NULL, $state_code = NULL) {

        $this->load->database();
        $this->load->helper('commondata_helper');

        $group_ids = array();
        $group_ids[] = 5;
        $group_ids[] = 4;

        $financialyear = check_input($FinancialYear);

        $this->db->select("dft_service_id, sum(dft_achieved) as 'total'");
        $this->db->from('nphce_progress_report as progress ');
        $this->db->join('nphce_dpr_facility_type  as dpr', 'progress.pr_id = dpr.dft_progress_report_id');
        $this->db->join('mst_months', ' month_id = progress.pr_month');
        $this->db->join('nphce_services_new as services', 'services.service_id = dpr.dft_service_id');
        $this->db->join("(select pr_financial_year, pr.pr_state_id, max(month_order) as month_order from mst_months
inner join  nphce_progress_report as pr on mst_months.month_id = pr.pr_month where pr.pr_district_id is null and pr_financial_year= '$financialyear'
group by pr_state_id) as max_month", " on max_month.pr_financial_year = progress.pr_financial_year
and max_month.month_order = progress.pr_month and max_month.pr_state_id = progress.pr_state_id", "INNER");
        //$this->db->where('services.service_group_id  ',5);
        $this->db->where_in('services.service_group_id', $group_ids);
        $this->db->where('services.service_state ', 1);
        if ($financialyear) {
            $this->db->where('progress.pr_financial_year = ', $financialyear);
        }
        if ($state_code != NULL) {
            $this->db->where('progress.pr_state_id = ', $state_code);
        }
        $this->db->group_by('dft_service_id');
        $this->db->order_by('dft_service_id');
        $query = $this->db->get();
        //echo $this->db->last_query();die;
        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return false;
        }
        $query->free_result();
    }

    public function all_service_facility_wise($FinancialYear = NULL, $facility_type = NULL, $state_code = NULL) {
        $financialyear = check_input($FinancialYear);
        $this->db->select("dft_service_id, service_desc, sum(dft_achieved) as 'total'");
        $this->db->from('nphce_progress_report as progress ');
        $this->db->join('nphce_dpr_facility_type  as dpr', 'progress.pr_id = dpr.dft_progress_report_id');
        $this->db->join('mst_months', ' month_id = progress.pr_month');
        $this->db->join('nphce_services_new as services', 'services.service_id = dpr.dft_service_id');
        $this->db->join("(select pr_financial_year, pr.pr_state_id, max(month_order) as month_order from mst_months
inner join  nphce_progress_report as pr on mst_months.month_id = pr.pr_month where pr_financial_year= '$financialyear'
group by pr_state_id) as max_month", " on max_month.pr_financial_year = progress.pr_financial_year
and max_month.month_order = progress.pr_month and max_month.pr_state_id = progress.pr_state_id", "INNER");
        $this->db->where('services.service_group_id  ', 5);

        $this->db->where('services.service_state ', 1);
        if ($financialyear) {
            $this->db->where('progress.pr_financial_year = ', $financialyear);
        }
        $this->db->where('dpr.dft_facility_type = ', $facility_type);
        if ($state_code != NULL) {
            $this->db->where('progress.pr_state_id = ', $state_code);
        }
        $this->db->group_by('dft_service_id,progress.pr_financial_year');
        $this->db->order_by('progress.pr_financial_year');
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return false;
        }
        $query->free_result();
    }

    public function get_all_state_funds($f_year = NULL) {
        $query = $this->db->query("select master.*, sum(fa_total) as total_allocation ,
sum(fu_total)as total_utilisation   from
(SELECT  financial_year_id,financial_year_name,state_cnt.state_code, state_cnt.state_name  FROM  mst_financial_years
cross join mst_state1 as state_cnt where financial_year_name='$f_year' and state_code !=0) as master
left JOIN nphce_fund_allocation as allocation on master.state_code=allocation.fa_state_id
and fa_district_id is null and fa_facility_id is null
and master.financial_year_name = allocation.fa_financial_year
left join nphce_fund_utilisation as utilisation on master.state_code=utilisation.fu_state_id
and utilisation.fu_district_id is null and utilisation.fu_facility_id is null
and master.financial_year_name = utilisation.fu_financial_year and utilisation.fu_month = (select max(fu_month) from nphce_fund_utilisation where fu_financial_year='$f_year' and fu_district_id is null and fu_facility_id is null and fu_state_id = master.state_code)
group by  master.financial_year_id,master.financial_year_name,master.state_code, master.state_name
order by master.state_name");
        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return 0;
        }
        $query->free_result();
    }

    public function get_state_by_code($state_code = NULL) {


        $this->db->select("s.state_code, s.state_name");
        $this->db->from('mst_state1 s');
        $this->db->where('s.state_code', $state_code);

        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row_array();
        } else {
            return 0;
        }
    }//############### Dashboard End ##############
    //############### Dashboard General Start#########
    public function get_service_group_facility($FinancialYear = NULL, $facility_type = NULL, $group_id = NULL, $state_code = NULL) {
        $financialyear = check_input($FinancialYear);

        if ($state_code != NULL) {
            $state_query = "and max_month_state.pr_state_id=" . $state_code;
        } else {
            $state_query = '';
        }
        if ($facility_type == "DH") {
            $show_query = " and show_dh=0";
        } elseif ($facility_type == "CHC") {
            $show_query = " and show_chc=0";
        } elseif ($facility_type == "PHC") {
            $show_query = " and show_phc=0";
        } elseif ($facility_type == "SC") {
            $show_query = " and show_shc=0";
        } else {
            $show_query = '';
        }

        $query = $this->db->query("select service_id,service_desc,sum(dft_achieved) as total from
		(select pr_financial_year, pr.pr_state_id, max(month_order) as month_order from mst_months
		inner join nphce_progress_report as pr on mst_months.month_id = pr.pr_month
		where pr.pr_district_id is null and pr_financial_year= '$financialyear'
		group by pr_state_id) as max_month_state
		Inner join nphce_progress_report as progress on progress.pr_state_id= max_month_state.pr_state_id
		inner join nphce_dpr_facility_type as dpr on progress.pr_id = dpr.dft_progress_report_id
		inner join nphce_services_new as services on services.service_id = dpr.dft_service_id
		where progress.pr_financial_year = '$financialyear' and dpr.dft_facility_type='$facility_type' and services.service_group_id in(3) 
		and services.service_state =1 and progress.pr_month = max_month_state.month_order " . $state_query . "
		group by dpr.dft_service_id");

        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return false;
        }
        $query->free_result();
    }

    public function all_service_facility_wise_general($FinancialYear = NULL, $facility_type = NULL, $state_code = NULL) {
        $financialyear = check_input($FinancialYear);
        $this->db->select("dft_service_id, service_desc, sum(dft_achieved) as 'total'");
        $this->db->from('nphce_progress_report as progress ');
        $this->db->join('nphce_dpr_facility_type  as dpr', 'progress.pr_id = dpr.dft_progress_report_id');
        $this->db->join('mst_months', ' month_id = progress.pr_month');
        if ($facility_type == "DH") {
            $this->db->join('nphce_services_new as services', 'services.service_id = dpr.dft_service_id and services.show_dh=0');
        } elseif ($facility_type == "CHC") {
            $this->db->join('nphce_services_new as services', 'services.service_id = dpr.dft_service_id and services.show_chc=0');
        } elseif ($facility_type == "PHC") {
            $this->db->join('nphce_services_new as services', 'services.service_id = dpr.dft_service_id and services.show_phc=0');
        } elseif ($facility_type == "SC") {
            $this->db->join('nphce_services_new as services', 'services.service_id = dpr.dft_service_id and services.show_shc=0');
        } else {
            $this->db->join('nphce_services_new as services', 'services.service_id = dpr.dft_service_id');
        }
        $this->db->join("(select pr_financial_year, pr.pr_state_id, max(month_order) as month_order from mst_months
inner join  nphce_progress_report as pr on mst_months.month_id = pr.pr_month where pr.pr_district_id is null and pr_financial_year= '$financialyear'
group by pr_state_id) as max_month", " on max_month.pr_financial_year = progress.pr_financial_year
and max_month.month_order = progress.pr_month and max_month.pr_state_id = progress.pr_state_id", "INNER");
        $this->db->where('services.service_group_id  ', 5);
        $this->db->where('services.service_state ', 1);
        if ($financialyear) {
            $this->db->where('progress.pr_financial_year = ', $financialyear);
        }
        $this->db->where('dpr.dft_facility_type = ', $facility_type);
        if ($state_code != NULL) {
            $this->db->where('progress.pr_state_id = ', $state_code);
        }
        $this->db->group_by('dft_service_id,progress.pr_financial_year');
        $this->db->order_by('progress.pr_financial_year');
        $query = $this->db->get();
        //echo $this->db->last_query();die;
        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return false;
        }
        $query->free_result();
    }

    public function get_other_service_general($FinancialYear = NULL, $facility_type = NULL, $state_code = NULL) {
        $financialyear = check_input($FinancialYear);
        $this->db->select("dft_service_id, service_desc, sum(dft_achieved) as 'total'");
        $this->db->from('nphce_progress_report as progress ');
        $this->db->join('nphce_dpr_facility_type  as dpr', 'progress.pr_id = dpr.dft_progress_report_id');
        $this->db->join('mst_months', ' month_id = progress.pr_month');
        if ($facility_type == "DH") {
            $this->db->join('nphce_services_new as services', 'services.service_id = dpr.dft_service_id and services.show_dh=0');
        } elseif ($facility_type == "CHC") {
            $this->db->join('nphce_services_new as services', 'services.service_id = dpr.dft_service_id and services.show_chc=0');
        } elseif ($facility_type == "PHC") {
            $this->db->join('nphce_services_new as services', 'services.service_id = dpr.dft_service_id and services.show_phc=0');
        } elseif ($facility_type == "SC") {
            $this->db->join('nphce_services_new as services', 'services.service_id = dpr.dft_service_id and services.show_shc=0');
        } else {
            $this->db->join('nphce_services_new as services', 'services.service_id = dpr.dft_service_id');
        }
        $this->db->join("(select pr_financial_year, pr.pr_state_id, max(month_order) as month_order from mst_months
inner join  nphce_progress_report as pr on mst_months.month_id = pr.pr_month where pr_financial_year= '$financialyear'
group by pr_state_id) as max_month", " on max_month.pr_financial_year = progress.pr_financial_year
and max_month.month_order = progress.pr_month and max_month.pr_state_id = progress.pr_state_id", "INNER");
        $this->db->where('services.service_group_id  ', 4);
        $this->db->where('services.service_state ', 1);
        if ($financialyear) {
            $this->db->where('progress.pr_financial_year = ', $financialyear);
        }
        $this->db->where('dpr.dft_facility_type = ', $facility_type);
        if ($state_code != NULL) {
            $this->db->where('progress.pr_state_id = ', $state_code);
        }
        $this->db->group_by('dft_service_id,progress.pr_financial_year');
        $this->db->order_by('progress.pr_financial_year');
        $query = $this->db->get();

        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return false;
        }
        $query->free_result();
    }

    //############### Dashboard General End#########


    public function get_year_wise_services($state_code = NULL) {

        if ($state_code != "") {
            $state_query = ' AND progress.pr_state_id=' . $state_code;
        } else {
            $state_query = '';
        }
        $query = $this->db->query("SELECT `dft_service_id`,services.service_desc,progress.pr_financial_year, sum(dft_achieved) as 'total'
		FROM `nphce_progress_report` as `progress`
		JOIN `nphce_dpr_facility_type` as `dpr` ON `progress`.`pr_id` = `dpr`.`dft_progress_report_id`
		JOIN `mst_months` ON `month_id` = `progress`.`pr_month`
		JOIN `nphce_services_new` as `services` ON `services`.`service_id` = `dpr`.`dft_service_id`
		INNER JOIN (select pr_financial_year, pr.pr_state_id, max(month_order) as month_order from mst_months
inner join  nphce_progress_report as pr on mst_months.month_id = pr.pr_month where pr.pr_district_id is null and pr.pr_facility_id is null
group by pr_financial_year,pr_state_id) as max_month on max_month.month_order = progress.pr_month
and max_month.pr_state_id = progress.pr_state_id and max_month.pr_financial_year = progress.pr_financial_year
		WHERE services.service_group_id in (4,5) AND `services`.`service_state` = 1" . $state_query . "
		GROUP BY `dft_service_id`,pr_financial_year ORDER BY `pr_financial_year`;");
        //echo $this->db->last_query();die;
        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return 0;
        }
        $query->free_result();
    }

    public function get_all_services() {
        $this->db->select("service_id, service_desc");
        $this->db->from('nphce_services_new');
        $this->db->where('service_group_id', 5);
        $this->db->where('service_state', 1);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return 0;
        }
        $query->free_result();
    }

    public function get_all_services_forywds() { //ywds=Year wise Services
        $group_ids = array();
        $group_ids[] = 5;
        $group_ids[] = 4;
        $this->db->select("service_id, service_desc");
        $this->db->from('nphce_services_new');
        $this->db->where_in('service_group_id', $group_ids);
        //$this->db->where('service_group_id', 5);
        $this->db->where('service_state', 1);
        $this->db->order_by('service_group_id', 'DESC');
        $this->db->order_by('service_id', 'ASC');
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return 0;
        }
        $query->free_result();
    }

    public function get_all_financial_year() {

        $this->load->database();

        $this->db->select("*");
        $this->db->from('mst_financial_years');
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return 0;
        }
        $query->free_result();
    }

    public function get_unsaved_state_data($f_year = NULL) {

        $fy_year_1 = date("Y");
        $month = date("m");
        if ($month <= 3) {
            $fy_year_1 = $fy_year_1 - 1;
        }
        $fy_year1 = substr($fy_year_1, -2);
        $fy_year2 = $fy_year1 + 1;
        $current_year = $fy_year_1 . '-' . $fy_year2;

        if ($f_year == $current_year) {
            $previous_month = date("m") - 1;
        } else {
            $previous_month = 12;
        }

        $query = $this->db->query("SELECT s.state_code, s.state_name, npr.pr_financial_year, max(npr.pr_month) as 'month' FROM mst_state1 s
		LEFT JOIN nphce_progress_report as npr on npr.pr_state_id = s.state_code and npr.pr_financial_year='$f_year'
		and npr.pr_district_id is null and npr.pr_facility_id is null
		where s.state_code !=0
		group by s.state_code, npr.pr_financial_year;");

        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return 0;
        }
        $query->free_result();
    }

    public function get_all_states() {
        $this->db->select('state_code,state_name');
        $this->db->from('mst_state1');
        $this->db->where('state_code !=', 0);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return false;
        }
        $query->free_result();
    }

    public function get_month_name_by_id($id = NULL) {
        $this->db->select('month_name');
        $this->db->from('mst_months');
        $this->db->where('month_id', $id);
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row_array();
        } else {
            return false;
        }
        $query->free_result();
    }

    public function get_all_establish_purchase_undertaken($FinancialYear = NULL, $state_code = NULL) {
        $financialyear = check_input($FinancialYear);
        if ($state_code != NULL) {
            $state_query = "and max_month_state.pr_state_id=" . $state_code;
        } else {
            $state_query = '';
        }
        $query = $this->db->query(" select service_id,service_desc,sum(dft_achieved) as total from
		(select pr_financial_year, pr.pr_state_id, max(month_order) as month_order from mst_months
		inner join nphce_progress_report as pr on mst_months.month_id = pr.pr_month
		where pr.pr_district_id is null and pr_financial_year= '$financialyear'
		group by pr_state_id) as max_month_state
		Inner join nphce_progress_report as progress on progress.pr_state_id= max_month_state.pr_state_id
		inner join nphce_dpr_facility_type as dpr on progress.pr_id = dpr.dft_progress_report_id
		inner join nphce_services_new as services on services.service_id = dpr.dft_service_id
		where progress.pr_financial_year = '$financialyear' and services.service_group_id in(3) 
		and services.service_state =1 and progress.pr_month = max_month_state.month_order " . $state_query . "
		group by dpr.dft_service_id");
        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return false;
        }
        $query->free_result();
    }

    public function all_other_service_total($FinancialYear = NULL, $state_code = NULL) {
        $financialyear = check_input($FinancialYear);
        $this->db->select("dft_service_id,services.service_desc, sum(dft_achieved) as 'total'");
        $this->db->from('nphce_progress_report as progress ');
        $this->db->join('nphce_dpr_facility_type  as dpr', 'progress.pr_id = dpr.dft_progress_report_id');
        $this->db->join('mst_months', ' month_id = progress.pr_month');
        $this->db->join('nphce_services_new as services', 'services.service_id = dpr.dft_service_id');
        $this->db->join("(select pr_financial_year, pr.pr_state_id, max(month_order) as month_order from mst_months
inner join  nphce_progress_report as pr on mst_months.month_id = pr.pr_month where pr_financial_year= '$financialyear'
group by pr_state_id) as max_month", " on max_month.pr_financial_year = progress.pr_financial_year
and max_month.month_order = progress.pr_month and max_month.pr_state_id = progress.pr_state_id", "INNER");
        $this->db->where('services.service_group_id  ', 4);
        $this->db->where('services.service_state ', 1);
        if ($financialyear) {
            $this->db->where('progress.pr_financial_year = ', $financialyear);
        }
        if ($state_code != NULL) {
            $this->db->where('progress.pr_state_id = ', $state_code);
        }
        $this->db->group_by('dft_service_id');
        $this->db->order_by('dft_service_id');
        $query = $this->db->get();

        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return false;
        }
        $query->free_result();
    }

    public function state_all_service($FinancialYear, $StateId) {
        $group_ids = array();
        $group_ids[] = 5;
        $group_ids[] = 4;
        $financialyear = check_input($FinancialYear);
        $state_code = check_input($StateId);

        $this->db->select("dft_service_id, sum(dft_achieved) as 'total'");
        $this->db->from('nphce_progress_report as progress ');
        $this->db->join('nphce_dpr_facility_type  as dpr', 'progress.pr_id = dpr.dft_progress_report_id');
        $this->db->join('mst_months', ' month_id = progress.pr_month');
        $this->db->join('nphce_services_new as services', 'services.service_id = dpr.dft_service_id');
        $this->db->join("(select pr_financial_year, pr.pr_state_id, max(month_order) as month_order from mst_months
inner join  nphce_progress_report as pr on mst_months.month_id = pr.pr_month where pr.pr_district_id is null and pr_financial_year= '$financialyear'
group by pr_state_id) as max_month", " on max_month.pr_financial_year = progress.pr_financial_year
and max_month.month_order = progress.pr_month and max_month.pr_state_id = progress.pr_state_id", "INNER");
        $this->db->where_in('services.service_group_id', $group_ids);

        $this->db->where('services.service_state ', 1);
        if ($financialyear) {
            $this->db->where('progress.pr_financial_year = ', $financialyear);
        }
        if ($state_code != NULL) {
            $this->db->where('progress.pr_state_id = ', $state_code);
        }
        $this->db->group_by('dft_service_id');
        $this->db->order_by('dft_service_id');
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return false;
        }
    }

    public function get_rgc_count() {
        $this->db->select("COUNT(*) as no_of_rgc");
        $this->db->from('state_rmi_relation');
        $query = $this->db->get();
        
        if ($query->num_rows() >= 1) {
            return $query->row_array();
        } else {
            return false;
        }
        $query->free_result();
    }

    public function all_service_total_general($FinancialYear = NULL, $state_code = NULL) {

        $group_ids = array();
        $group_ids[] = 5;
        $group_ids[] = 4;

        $financialyear = check_input($FinancialYear);
        $this->db->select("dft_service_id, sum(dft_achieved) as 'total'");
        $this->db->from('nphce_progress_report as progress ');
        $this->db->join('nphce_dpr_facility_type  as dpr', 'progress.pr_id = dpr.dft_progress_report_id');
        $this->db->join('mst_months', ' month_id = progress.pr_month');
        $this->db->join('nphce_services_new as services', 'services.service_id = dpr.dft_service_id');
        $this->db->join("(select pr_financial_year, pr.pr_state_id, max(month_order) as month_order from mst_months
inner join  nphce_progress_report as pr on mst_months.month_id = pr.pr_month where pr.pr_district_id is null and pr_financial_year= '$financialyear'
group by pr_state_id) as max_month", " on max_month.pr_financial_year = progress.pr_financial_year
and max_month.month_order = progress.pr_month and max_month.pr_state_id = progress.pr_state_id", "INNER");

        $this->db->where_in('services.service_group_id', $group_ids);
        $this->db->where('services.service_state ', 1);
        if ($financialyear) {
            $this->db->where('progress.pr_financial_year = ', $financialyear);
        }
        if ($state_code != NULL) {
            $this->db->where('progress.pr_state_id = ', $state_code);
        }
        $this->db->group_by('dft_service_id');
        $this->db->order_by('`services`.`service_group_id` DESC,`service_id`');
        $query = $this->db->get();

        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return false;
        }
        $query->free_result();
    }

    public function get_staff_total($FinancialYear = NULL, $staff_type = NULL, $state_code = NULL) {
        $group_ids = array();
        if ($staff_type == "contractual") {
            $group_ids[] = 100;
            $group_ids[] = 107;
        } else if ($staff_type == "regular") {
            $group_ids[] = 110;
            $group_ids[] = 117;
        }
        $financialyear = check_input($FinancialYear);
        $this->db->select("sum(dft_achieved) as 'achieved'");
        $this->db->from('nphce_progress_report as progress ');
        $this->db->join('nphce_dpr_facility_type  as dpr', 'progress.pr_id = dpr.dft_progress_report_id');
        $this->db->join('mst_months', ' month_id = progress.pr_month');
        $this->db->join('nphce_services_new as services', 'services.service_id = dpr.dft_service_id');
        $this->db->join("(select pr_financial_year, pr.pr_state_id, max(month_order) as month_order from mst_months
inner join  nphce_progress_report as pr on mst_months.month_id = pr.pr_month where pr.pr_district_id is null and pr_financial_year= '$financialyear'
group by pr_state_id) as max_month", " on max_month.pr_financial_year = progress.pr_financial_year
and max_month.month_order = progress.pr_month and max_month.pr_state_id = progress.pr_state_id", "INNER");
        $this->db->where_in('services.service_group_id', $group_ids);
        $this->db->where('services.service_state ', 1);
        if ($financialyear) {
            $this->db->where('progress.pr_financial_year = ', $financialyear);
        }
        if ($state_code != NULL) {
            $this->db->where('progress.pr_state_id = ', $state_code);
        }
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row_array();
        } else {
            return false;
        }
        $query->free_result();
    }


    /* public function all_elderly_total() {

        $sql = 'SELECT COUNT(*) as total FROM `nphce_progress_report` ';
        $result = $this->db->query($sql);
        $query = $result->fetch();
        if ($query) {
            return $query;
        } else {
            return false;
        }
    } */


    public function all_elderly_total() {
//        $obj =& get_instance();
        $this->db->select("COUNT(*) as total");
        $this->db->from('nphce_progress_report');
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row_array();
        } else {
            return false;
        }
        $query->free_result();
    }


    public function fetch_curr_date() {
        $this->db->select('date_update');
        $this->db->from('tbl_date');
        $this->db->where('name =', 'Elderly');
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return false;
        }
        $query->free_result();
    }

    public function fetch_notto_currdate() {
        $this->db->select("date_added,date_update");
        $this->db->from('tbl_date');
        $this->db->where('name =', 'NOTTO');
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return false;
        }
        $query->free_result();
    }

    public function rch_curr_date() {
        $this->db->select("date_added,date_update");
        $this->db->from('tbl_date');
        $this->db->where('name =', 'RCH Portal');
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return false;
        }
        $query->free_result();
    }

    public function amrit_curr_date() {
        $this->db->select("date_added,date_update");
        $this->db->from('tbl_date');
        $this->db->where('name =', 'AMRIT');
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return false;
        }
        $query->free_result();
    }

    public function ors_curr_date() {
        $this->db->select("date_update");
        $this->db->from('tbl_date');
        $this->db->where('name =', 'ORS');
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row_array();
        } else {
            return false;
        }
        $query->free_result();
    }

    public function hmis_curr_date() {
        $this->db->select("date_added,date_update");
        $this->db->from('tbl_date');
        $this->db->where('name =', 'HMIS');
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return false;
        }
        $query->free_result();
    }

    /*  --------  end code -------- */

    public function get_laqshya_data() {

        $sql = 'SELECT baseline_facilities as total FROM `dashboard_data_laqshya` ';
        $qry = $this->db->query($sql);
        $query = $qry->fetch();
        if ($query) {
            return $query;
        } else {
            return false;
        }
    }

    public function get_healthserviceopd() {

        $sql = 'SELECT baseline_facilities as total FROM `dashboard_data_laqshya` ';
        $qry = $this->db->query($sql);
        $query = $qry->fetch();
        if ($query) {
            return $query;
        } else {
            return false;
        }
    }


     function get_alert_details(){
        $this->db->select('*');
        $this->db->from('mohfw_flash_alert');
        $this->db->where('fa_status',1);
        $query = $this->db->get();
        if($query -> num_rows() >= 1){
            return $query->result_array();
        }
        else{
            return false;
        }
        $query->free_result();
    } 



    function get_dashboard_notification(){
        $this->db->select('id, title, link, description, document, notification_type');
        $this->db->from('mohfw_mst_notification');
        $this->db->where('status', 1);
        $query = $this->db->get();
        if($query -> num_rows() >= 1){
            return $query->result_array();
        }
        else{ 
            return false;
        }
        $query->free_result();
    }
    
    //Convert The Code Core Php To CI Date 04/02/2019
     public function newerinitamrit() {
        $this->db->select('*'); 
        $this->db->from('tbl_amrit');
        $query=$this->db->get();
        if($query){
            return $query->row_array();
        }else{
            return false;
        }
    }
    
    public function get_kiosk(){		
        $this->db->select('*');
        $this->db->from('tbl_kiosk');
        $query=$this->db->get();
        if($query){
            return $query->row_array();
        } else {
            return false;
        }
    }
    
    public function get_swachhta_dash(){
        $this->db->select('facilities_participated_kayakalp as kayaklp,vhsnc_participated as vhs, swachhta_pakhwara as pakh ,district_hospital_participated as dhospital , villages_participated as vill , chc_sdh_participated as chc , people_vhsnc_event as event, phc_participated as phc ,district_participated as dpart');
        $this->db->from('swachhata_top_dashboard');
        $query=$this->db->get();
        if($query ->num_rows()>=1){
            return $query->result_array();
        }else {
            return false;
        }
    }
    
    public function get_swachhta_sarvatra() {
        $this->db->select('*');
        $this->db->from('swachhata_sarvatra');
        $query=$this->db->get();
       // echo $this->db->last_query(); die;
        $result =  $query->row_array();
        return $result;
    }    
     
    
// show elderly master table record   
    public function getelderlymasterrecord() {
        $this->db->select("*");
        $this->db->from('elderly_master_table');
        $query = $this->db->get();
        return $query->row_array();
    }
	
	 public function total_foreign_tour() {
        $this->db->select("field_1");
        $this->db->from('fvms_dashboard');
        $this->db->where('chart_type=', 'total');
        $query = $this->db->get();
        return $query->row_array();
    }
	
	public function total_active_mou() {
        $this->db->select("field_1");
        $this->db->from('mou_graph');
        $this->db->where('chart_type=', 'total');
        $query = $this->db->get();
        return $query->row_array();
    }
	
	public function get_requiring_renewal() {
        $this->db->select("field_1,field_2,field_3,field_4,field_5");
        $this->db->from('mou_graph');
        $this->db->where('chart_type=', 'chart_5');
        $query = $this->db->get();
        if($query ->num_rows()>=1){
            return $query->result_array();
        }else {
            return $query->row_array();
        }
    }
	
	public function get_mou_expired() {
        $this->db->select("field_1,field_2,field_3,field_4,field_5");
        $this->db->from('mou_graph');
        $this->db->where('chart_type=', 'chart_6');
        $query = $this->db->get();
        if($query ->num_rows()>=1){
            return $query->result_array();
        }else {
            return $query->row_array();
        }
    }
	
	public function get_all_record() {
        $this->db->select("*");
        $this->db->from('merasptaal_master_table');
        $query = $this->db->get();
        return $query->result_array();
    }
	
	public function get_record() {
        $this->db->select("*");
        $this->db->from('merasptaal_master_table');
        $query = $this->db->get();
        return $query->row_array();
    }

    //Mera aspataal update record by API

     public function updateRecord($row) {
       $data   =  array(
                    "name"          =>$row['name'],
                    "score"         =>$row['score'],
                    "type"          =>$row['type'], 
                    "color"         =>$row['color'],
                    "created_at"  =>date('Y-m-d h:i:s',strtotime($row['created_at'])),
                  );

        $this->db->where('id', $row['id']);
        $this->db->update('merasptaal_master_table', $data);
        return true;

    }



   

    
/*   ----------  twinkle code start  --------------  */

  public function get_totalRecordNVHCPs(){ 
    $this->db->select('SUM( Model_Treatment_Center_Target ) as mt , SUM(Model_Treatment_Center_Achieved) as ma , SUM(Number_of_Districts) as nd , SUM( Districts_with_TC ) as dtc , SUM(Total_No_of_TC) as tc , SUM( Patient_on_treatment ) as pt , SUM(Patient_Successfully_Treated) as pst , SUM( Institutional_Deliveries ) as id , SUM( Newborns_Received ) as nr , state_id, updated_date  ');
    $this->db->from('nvhcp_master_table');
    
    $this->db->order_by("nvhcp_master_table.id", "desc");

    $query = $this->db->get();

    return $query->row_array();  
}


public function searchnvhcprecord($filter){ 
    $sql   =  "select SUM( Model_Treatment_Center_Target ) as mt , SUM(Model_Treatment_Center_Achieved) as ma , SUM(Number_of_Districts) as nd , SUM( Districts_with_TC ) as dtc , SUM(Total_No_of_TC) as tc , SUM( Patient_on_treatment ) as pt , SUM(Patient_Successfully_Treated) as pst , SUM( Institutional_Deliveries ) as id , SUM( Newborns_Received ) as nr,  state_id ,updated_date from nvhcp_master_table where 1  ";

        if($filter['stateid']!=''){
           $sql  .= " and state_id = '".$filter['stateid']."'";
        }if($filter['eyear']!=''){
           $sql  .= " and e_year = '".$filter['eyear']."'";
        }if($filter['emonth']!=''){
            $sql  .= " and e_month='".$filter['emonth']."'";
        }

        $query  =  $this->db->query($sql);
        //echo $this->db->last_query(); die;
        if($query->num_rows()>1){
             return $query->result_array();
        }else{
            return $query->row_array(); 
        } 
}
  

  public function get_totalRecordfdsi(){ 
    $this->db->select('SUM( Number_of_States ) as st ,  updated_by   ');
    $this->db->from('free_diagnosticssi_master_tbl');
    
    $this->db->order_by("free_diagnosticssi_master_tbl.id", "desc");

    $query = $this->db->get();

    return $query->row_array();  
}


public function searchfdsirecord($filter){ 
    $sql   =  "select SUM( Number_of_States ) as st  ,updated_by from free_diagnosticssi_master_tbl where 1  ";

        if($filter['quarterly']!=''){
           $sql  .= " and  Quarterly = '".$filter['quarterly']."'";
        }if($filter['eyear']!=''){
           $sql  .= " and year = '".$filter['eyear']."'";
        }if($filter['emonth']!=''){
            $sql  .= " and month='".$filter['emonth']."'";
        }

        $query  =  $this->db->query($sql);
        //echo $this->db->last_query(); die;
        if($query->num_rows()>1){
             return $query->result_array();
        }else{
            return $query->row_array(); 
        } 
}


 public function get_totalRecordhr(){ 
    $this->db->select('SUM( Vacancies_of_medical_officers ) as vmo  , SUM( vacancies_of_nurses_against_sanctioned_posts ) as vnas , updated_date ');
    $this->db->from('hr_master_tbl');
    
    $this->db->order_by("hr_master_tbl.id", "desc");

    $query = $this->db->get();

    return $query->row_array();  
}


public function searchhrrecord($filter){ 
    $sql   =  "select SUM( Vacancies_of_medical_officers ) as vmo  , SUM( vacancies_of_nurses_against_sanctioned_posts ) as vnas , updated_date from hr_master_tbl where 1  ";

        if($filter['state_id']!=''){
           $sql  .= " and   state_id  = '".$filter['state_id']."'";
        }if($filter['eyear']!=''){
           $sql  .= " and year = '".$filter['eyear']."'";
        }if($filter['quarterly']!=''){
            $sql  .= " and Quarterly='".$filter['quarterly']."'";
        }

        $query  =  $this->db->query($sql);
        //echo $this->db->last_query(); die;
        if($query->num_rows()>1){
             return $query->result_array();
        }else{
            return $query->row_array(); 
        } 
}


public function get_totalRecordnqas(){ 
    $this->db->select('SUM( nqas_facilities_count ) as nfc , updated_date ');
    $this->db->from('qa_master_table');
    
    $this->db->order_by("qa_master_table.id", "desc");

    $query = $this->db->get();

    return $query->row_array();  
}


public function searchnqasrecord($filter){ 
    $sql   =  "select SUM( nqas_facilities_count ) as nfc , updated_date from qa_master_table where 1  ";

        if($filter['state_id']!=''){
           $sql  .= " and   state_id  = '".$filter['state_id']."'";
        }if($filter['eyear']!=''){
           $sql  .= " and financial_year = '".$filter['eyear']."'";
        }if($filter['quarterly']!=''){
            $sql  .= " and quarter='".$filter['quarterly']."'";
        }

        $query  =  $this->db->query($sql);
        //echo $this->db->last_query(); die;
        if($query->num_rows()>1){
             return $query->result_array();
        }else{
            return $query->row_array(); 
        } 
}


 public function get_totalRecordntcp(){ 
    $this->db->select('SUM( district_no ) as dn , SUM( fine_imposed ) as fi , SUM( tccs_no ) as tn, SUM( cotpa_cases_no ) as ccn , SUM(  persons_service_no  ) as psn , SUM(  districts_tccs_no  ) as dtn, SUM(  quitline_centre_name  ) as qcn , SUM( quitlinecalls_no ) as qn , SUM( reg_quitters_no ) as rqn  , SUM( persons_quit_no ) as pqn  , SUM( seats_quitline ) as sq , SUM( states_quitline ) as stq , updated_by ');
    
    $this->db->from('ntcp_master_table');
    
    $this->db->order_by("ntcp_master_table.id", "desc");

    $query = $this->db->get();

    return $query->row_array();  
}


public function searchntcprecord($filter){ 
    $sql   =  "select SUM( district_no ) as dn , SUM( fine_imposed ) as fi , SUM( tccs_no ) as tn, SUM( cotpa_cases_no ) as ccn , SUM(  persons_service_no  ) as psn , SUM(  districts_tccs_no  ) as dtn, SUM(  quitline_centre_name  ) as qcn , SUM( quitlinecalls_no ) as qn , SUM( reg_quitters_no ) as rqn  , SUM( persons_quit_no ) as pqn  , SUM( seats_quitline ) as sq , SUM( states_quitline ) as stq , updated_by from ntcp_master_table where 1  ";

        if($filter['state_id']!=''){
           $sql  .= " and   state_id  = '".$filter['state_id']."'";
        }if($filter['eyear']!=''){
           $sql  .= " and  financial_year  = '".$filter['eyear']."'";
        }if($filter['emonth']!=''){
            $sql  .= " and financial_month='".$filter['emonth']."'";
        }

        $query  =  $this->db->query($sql);
        //echo $this->db->last_query(); die;
        if($query->num_rows()>1){
             return $query->result_array();
        }else{
            return $query->row_array(); 
        } 
}


public function get_totalRecordntcpcentre(){ 
    $this->db->select('COUNT( institution_name ) as insn , updated_by ');
    
    $this->db->from('ntcpcentre_master_table');
    
    $this->db->order_by("ntcpcentre_master_table.id", "desc");

    $query = $this->db->get();
//echo $this->db->last_query(); die;
    return $query->row_array();  
}


public function searchntcpcentrerecord($filter){ 
    $sql   =  "select COUNT( institution_name ) as insn , updated_by from ntcpcentre_master_table where 1  ";

        if($filter['state_id']!=''){
           $sql  .= " and   state_id  = '".$filter['state_id']."'";
        }if($filter['district_id']!=''){
           $sql  .= " and  district_id  = '".$filter['district_id']."'";
        }

        $query  =  $this->db->query($sql);
//echo $this->db->last_query(); die;
        if($query->num_rows()>1){
            return $query->result_array();
        }else{
            return $query->row_array(); 
        } 
}


public function get_district(){ 
           
            $query = "Select * from m_district order by District_Name" ;
            $stmt = $this->db->query($query); 
            return $stmt->result_array();
    }


    public function get_dashboard_central(){
      $this->db->select("*");
      $this->db->from('elderly_master_table');
      $query = $this->db->get();
      if($query -> num_rows ()>=1){
        return $query->row_array();
      }else{
        return false;
      }
      $query->free_result();
  }
  
/* -------------  twinkle code end -------------- */


public function total_get_nppcd(){ 
    $this->db->select('SUM( Total_Number_of_districts ) as total_dist ,  SUM( Total_Number_of_district_made_operational ) as total_dist_opr   ');
    $this->db->from('nppcd_master_tbl');
    
    $this->db->order_by("nppcd_master_tbl.id", "desc");

    $query = $this->db->get();

    return $query->row_array();  
}

}

