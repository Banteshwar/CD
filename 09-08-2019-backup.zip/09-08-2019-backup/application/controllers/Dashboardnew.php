<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_Controller {
    private $user;

    public function __construct() {
		die('test');
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('hwc_model');
        $this->load->model('Dashboard_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() {  
	
         //$msgdata="hi kunal";
       

       //echo $this->smslib->sendSMS('9990624477',$msgdata);
       // die;
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('dashboard/ninportal'));
        
        $data['page_type']='Healthcare Infrastructure';
        $data['kiosk'] = $this->Dashboard_model->get_kiosk();
        /* ============ data fetch to master table code ============ */
        $ninmasterrec = fetchNINsyncdata();
            
        //$data['functionalFacilities']  = unserialize($ninmasterrec['total_functional_facilities']);
        $data['functionalFacilities'] = getNINFunctionalFacilities('','');
        
        $ID = 0;
        $State_ID = 0;
        
        $syncrec = fetchsyncdata($ID, $State_ID);
        $data['getApprovedState']  = unserialize($syncrec['getApprovedState']);
        $data['HWCGraphReport']  = unserialize($syncrec['hwcGraphReport']);
        /* ================ end ==================== */
       //$data['getApprovedState'] = getApprovedData(0, 0);
        loadLayout('admin/health_infra', 'admin', $data);
    }


    public function hwc() {
			
        /*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
		
		$this->mybreadcrumb->add('Home', base_url());
      //  $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('dashboard/index'));
        $this->mybreadcrumb->add('HWC', base_url('dashboard/hwc'));
		$data['page_type']='Healthcare Infrastructure';
        global $CURRENT_USER_STATE;
        
        $_REQUEST;
        $user = $this->user;
        
        //============= master database sync code here ===============//

       // $data['SYNC'] = syncHWCdatabase();
    
    //============= end master database sync code ===============//
    

        
        if ( ! $hwc_user_row = $this->cache->file->get('hwc_user_row'))
        {
            $hwc_user_row= $user->getUser();
            $this->cache->file->save('hwc_user_row', $hwc_user_row, 300);
        }
       
            $user_row = $hwc_user_row;
            $DASHBOARD = 0;
            $state = 0;
            $ID = 0;
            $TYPE = 0;
            $State_ID  =0;
            $State_Name  =0;
            
           
                    
        if (isset($_REQUEST['ID'])){

            $ID = 1;
            $State_ID   = $_REQUEST['ID'];
           
            $State_Name = $this->hwc_model->get_statename($State_ID); 
            $template   = array('page' => 'admin/dashboard/hwc', 'type' => 'popup');
        }else{
            $template   = array('page' => 'admin/dashboard/dashboard', 'type' => 'admin');
        }
   
     	//$data['HWCGraphCAReport'] = getHWCGraphCAReport($DASHBOARD, $ID); 
       
       // print_r($data['State_Name']); die;
       /* $data['HWCGraphReport'] = getHWCGraphReport($DASHBOARD, $ID);
        $data['HWCGraphCAReport'] = getHWCGraphCAReport($DASHBOARD, $ID);
        $data['getApprovedState'] = getApprovedData($DASHBOARD, $ID);
        $data['entry_status_graph_data'] = getGraphData($DASHBOARD, $ID);
        $data['HWC_CA_Report'] = getHWCCAReport($DASHBOARD, $ID);
       */
        
        $data['HWC_Report'] = getHWCReport($DASHBOARD, $ID);
        
        $syncrec 			= fetchsyncdata($ID, $State_ID);
		
        $HWCCAReport  		= unserialize($syncrec['hwcCAreport']);
        $getApprovedState   = unserialize($syncrec['getApprovedState']);
		/*echo "<pre>";
		print_r($getApprovedState);die;*/
        $HWCGraphReport  	= unserialize($syncrec['hwcGraphReport']);
        $HWCGraphCAReport   = unserialize($syncrec['hwcGraphCAReport']);
        $entry_status_graph_data  = unserialize($syncrec['entry_status_graph_data']);
        
        $data['DASHBOARD']  = $DASHBOARD;
        
        $data['getApprovedState']  = $getApprovedState;
        $data['HWCGraphReport']  = $HWCGraphReport;
        $data['HWCGraphCAReport']  = $HWCGraphCAReport;
        $data['entry_status_graph_data']  = $entry_status_graph_data;
        
        $data['HWC_CA_Report'] = $HWCCAReport;
        
        $data['data_temp'] = $_REQUEST;
        $data['_REQUEST'] = $_REQUEST;
        $data['user'] = $user;
        $data['State_ID'] = $State_ID;
        $data['State_Name'] = $State_Name;
        
        $data['updated_page'] = date('d M  Y');
        $data['remote_site_url'] = 'https://ab-hwc.nhp.gov.in/home/apilogintoken';

        loadLayout($template['page'], $template['type'], $data);

    }
    
  
    
    /* public function dashboard_ajax() {
        
        $state_code = $this->input->post('state_code');
        $financial_year = $this->input->post('financial_year');
        if($financial_year!=""){
            $f_year = $financial_year;
        }else{
            $f_year = "2018-19";    
        }

        if($state_code!='')
        {

            $data['district_count'] = $this->Dashboard_model->district_count($state_code);
            $state_name=$this->Dashboard_model->get_state_by_code($state_code);
            $data['title']=$state_name['state_name'];
           
    }

    else
    {
    $data['district_count']['no_of_district'] =  0;
    }

    $json_data = json_encode($data);
    print_r($json_data) ;
    exit();
    } */

        public function dashboard_ajax() {
        
        $state_code = $this->input->post('state_code');
        
        $financial_year = $this->input->post('financial_year');
        if($financial_year!=""){
            $f_year = $financial_year;
        }else{
            $f_year = "2018-19";    
        }

if($state_code!='')
{			
			$elderly = $this->Dashboard_model->getelderlymasterrecord();


            /*$data['district_count'] = $this->Dashboard_model->get_district_count($state_code);
            $state_name=$this->Dashboard_model->get_state_by_code($state_code);
            $data['title']=$state_name['state_name'];
            $data['fund_allocation'] = $this->Dashboard_model->get_state_fund_allocation($state_code,$f_year);
            $data['fund_utilization'] = $this->Dashboard_model->get_state_fund_utilization($state_code,$f_year);
            $data['services'] = $this->Dashboard_model->state_all_service($f_year,$state_code);
            $data['ncd_enc'] = $this->Dashboard_model->get_ncd_cell($f_year,$state_code,5);
            $data['ncd_ros'] = $this->Dashboard_model->get_ncd_cell($f_year,$state_code,6);
            $data['ncd_ol'] = $this->Dashboard_model->get_ncd_cell($f_year,$state_code,7);
            $data['dh'] = $this->Dashboard_model->facility_wise_state_service($f_year,$state_code,'DH');
            $data['chc'] = $this->Dashboard_model->facility_wise_state_service($f_year,$state_code,'CHC');
            //$data['phc'] = $this->Dashboard_model->facility_wise_state_service($f_year,$state_code,'PHC');

            $data['phc'] =    unserialize($elderly['phc_services']);
           // var_dump($data['phc']);die;
            $data['sc'] = $this->Dashboard_model->facility_wise_state_service($f_year,$state_code,'SC');
            $state_name=$this->Dashboard_model->get_state_by_code($state_code);
            $data['title']=$state_name['state_name'];*/


        $data['state_count']      =  unserialize($elderly['state_count']);
        $data['fetch_curr_date']  =  unserialize($elderly['fetch_curr_date']);
        $data['district_count']   =  unserialize($elderly['district_count']);
        $data['rgc_count']        =  unserialize($elderly['rgc_count']);
        $data['national_center']  =  unserialize($elderly['national_center_ageing']);        
        $data['state_color']      =  unserialize($elderly['state_color']);
        $data['max_month']        =  unserialize($elderly['max_month']);
        $data['month_name']       =  unserialize($elderly['month_name']);       
        $fund_utilization         =  unserialize($elderly['fund_utilization']);
        $data['fund_utilization'] =  $fund_utilization[0];
		$fund_allocation          =  unserialize($elderly['fund_allocation']);
        $data['fund_allocation']  =  $fund_allocation[0];
        $data['all_services_count']  =  unserialize($elderly['all_services_count']);

        $data['phc_services']  =  unserialize($elderly['phc_services']);
        $data['dh_services']  =  unserialize($elderly['dh_services']);

        $data['chc_services']  =  unserialize($elderly['chc_services']);
        $data['sc_services']  =  unserialize($elderly['sc_services']);
        $data['all_state_funds']  =  unserialize($elderly['all_state_funds']);
        $data['ncd_enc']  =  unserialize($elderly['ENC']);
        $data['ncd_ol']   =  unserialize($elderly['OL']);        
        $data['financial_year']   =  $f_year;
    
    }

    else
    {
        $data['district_count']['no_of_district'] =  0;
    }
        $json_data = json_encode($data);

        echo $json_data;
        //print_r($json_data) ;
        exit();
    }

    public function pmsmaold() {
        $data['page_type']='Healthcare Infrastructure';
        loadLayout('admin/new_pmsma', 'admin',  $data);
    }
    
    
    public function ninportal() { 
		$this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('dashboard/index'));
        $this->mybreadcrumb->add('NIN Portal', base_url('dashboard/ninportal'));
        /////////////////// master database sync code here ///////
        //$data['SYNC_NIN'] = syncNINdatabase();
        ////////////////// end master database sync code /////////
        ////////// show state ////////////
        //echo $this->input->get('state_name'); die;
        if ($this->input->get('state_name')) {
            $state_id=$this->input->get('state_name');
        }
        else
        {
            $state_id='';
        } 
        $data['searh_state_id']=$state_id;

        //echo $data['searh_state_id']; die;
            
        if ( ! $nin_state = $this->cache->file->get('nin_state'))
        {
            $nin_state=$this->hwc_model->get_state();
            $this->cache->file->save('nin_state', $nin_state, 300);
        }
            $data['state'] = $nin_state;
            $data['state'] = $nin_state; 
            $data['state_name'] = $this->hwc_model->get_statename($state_id);
        ////////// end show state ////////////
        
            $ninmasterrec = fetchNINsyncdata($state_id);
            
            $data['functionalFacilities']  = unserialize($ninmasterrec['total_functional_facilities']);
            $data['functionalStateWiseFacilities']  = unserialize($ninmasterrec['nin_functionalStateWiseFacilities']);
            $data['totalFacilitiesOperationalStatus']  = unserialize($ninmasterrec['nin_totalFacilitiesOperationalStatus']);
            $data['totalConfirmedVerified']  = unserialize($ninmasterrec['nin_totalConfirmedVerified']);
            $data['totalFacilitiesOperationalStatusStateWise']  = unserialize($ninmasterrec['nin_totalFacilitiesOperationalStatusStateWise']);
            
            $data['functionalFacilitiesStateWise']  = unserialize($ninmasterrec['nin_functionalFacilitiesStateWise']);

            $data['totalConfirmedVerifiedStateWise']  = unserialize($ninmasterrec['nin_totalConfirmedVerifiedStateWise']);
            $data['totalRuralUrbanVerifiedStateWise']  = unserialize($ninmasterrec['nin_totalRuralUrbanVerifiedStateWise']);
            $data['totalRuralUrbanVerified']  = unserialize($ninmasterrec['nin_totalRuralUrbanVerified']); 
          /*  echo "<pre>";
            print_r($ninmasterrec); die;
             */
            
           
       /* if( ! $nin_functionalStateWiseFacilities = $this->cache->file->get('nin_functionalStateWiseFacilities'))
        {
            $nin_functionalStateWiseFacilities=getNINFunctionalStateWiseFacilities();
            $this->cache->file->save('nin_functionalStateWiseFacilities', $nin_functionalStateWiseFacilities, 300);
        }
            $data['functionalStateWiseFacilities'] = $nin_functionalStateWiseFacilities;
            $data['functionalFacilities'] = getNINFunctionalFacilities('',$state_id);
        
        if ( ! $nin_functionalFacilitiesStateWise = $this->cache->file->get('nin_functionalFacilitiesStateWise'))
        {
            $nin_functionalFacilitiesStateWise=getNINFunctionalFacilities(TRUE);
            $this->cache->file->save('nin_functionalFacilitiesStateWise', $nin_functionalFacilitiesStateWise, 300);
        }
            $data['functionalFacilitiesStateWise'] = $nin_functionalFacilitiesStateWise;
		
        if( ! $nin_totalConfirmedVerified = $this->cache->file->get('nin_totalConfirmedVerified'))
        {
            $nin_totalConfirmedVerified=getNINTotalConfirmedVerified();
            $this->cache->file->save('nin_totalConfirmedVerified', $nin_totalConfirmedVerified, 300);
        }
            $data['totalConfirmedVerified'] = $nin_totalConfirmedVerified;

        if ( ! $nin_totalConfirmedVerifiedStateWise = $this->cache->file->get('nin_totalConfirmedVerifiedStateWise'))
        {
            $nin_totalConfirmedVerifiedStateWise=getNINTotalConfirmedVerified(TRUE);
            $this->cache->file->save('nin_totalConfirmedVerifiedStateWise', $nin_totalConfirmedVerifiedStateWise, 300);
        }
            $data['totalConfirmedVerifiedStateWise'] = $nin_totalConfirmedVerifiedStateWise;
		
		
        if ( ! $nin_totalRuralUrbanVerified = $this->cache->file->get('nin_totalRuralUrbanVerified'))
        {
            $nin_totalRuralUrbanVerified=getNINTotalRuralUrbanVerified(); 
            $this->cache->file->save('nin_totalRuralUrbanVerified', $nin_totalRuralUrbanVerified, 300);
        }
            $data['totalRuralUrbanVerified'] = $nin_totalRuralUrbanVerified;

        if ( ! $nin_totalRuralUrbanVerifiedStateWise = $this->cache->file->get('nin_totalRuralUrbanVerifiedStateWise'))
        {
            $nin_totalRuralUrbanVerifiedStateWise=getNINTotalRuralUrbanVerified(TRUE);
            $this->cache->file->save('nin_totalRuralUrbanVerifiedStateWise', $nin_totalRuralUrbanVerifiedStateWise, 300);
        }
            $data['totalRuralUrbanVerifiedStateWise'] =  $nin_totalRuralUrbanVerifiedStateWise;
        
        if ( ! $nin_totalFacilitiesOperationalStatus = $this->cache->file->get('nin_totalFacilitiesOperationalStatus'))
        {
            $nin_totalFacilitiesOperationalStatus=getFacilitiesOperationalStatus();
            $this->cache->file->save('nin_totalFacilitiesOperationalStatus', $nin_totalFacilitiesOperationalStatus, 300);
        }
		
            $data['totalFacilitiesOperationalStatus'] = $nin_totalFacilitiesOperationalStatus; 

        if ( ! $nin_totalFacilitiesOperationalStatusStateWise = $this->cache->file->get('nin_totalFacilitiesOperationalStatusStateWise'))
        {
            $nin_totalFacilitiesOperationalStatusStateWise= getFacilitiesOperationalStatus(TRUE);
            $this->cache->file->save('nin_totalFacilitiesOperationalStatusStateWise', $nin_totalFacilitiesOperationalStatusStateWise, 300);
        }
		
            $data['totalFacilitiesOperationalStatusStateWise'] =  $nin_totalFacilitiesOperationalStatusStateWise;*/
            $data['remote_site_url'] = 'https://nin.nhp.gov.in/cdapilogin.php';
            $data['page_type']='Healthcare Infrastructure';
	    	$data['updated_page'] = date('d M  Y');
            loadLayout('admin/nin_portal', 'admin', $data);
    }

    public function ajaxTableview() {

        $data['stdID']= $this->input->post('stID');
        $this->load->view('admin/facility_type_ajax',$data);
    }


    public function ajaxFacilityOperation() {

        $data['stateID']= $this->input->post('stateID');
        $this->load->view('admin/facility_operation_ajax',$data);
    }


    public function ajaxStatus() {

        $data['stateID']= $this->input->post('stateID');
        $this->load->view('admin/status_ajax',$data);
    }

    public function regionIndicator() {

        $data['stateID']= $this->input->post('stateID');
        $this->load->view('admin/region_ajax',$data);
    }

/* Table Reset Code Start */
    public function ajaxResetFacOper() {
        $data['stIDFac']= $this->input->post('stIDFac');
        $this->load->view('admin/facility_reset_ajax',$data);
    }


    public function ajaxResetFacTy() {
        $data['stIDFacTy']= $this->input->post('stIDFacTy');
        $this->load->view('admin/facilityTy_reset_ajax',$data);
    }


    public function ajaxResetsta() {
        $data['stIDstatus']= $this->input->post('stIDstatus');
        $this->load->view('admin/status_reset_ajax',$data);
    }

    public function ajaxResetregion() {
        $data['stIDregion']= $this->input->post('stIDregion');
        $this->load->view('admin/region_reset_ajax',$data);
    }

    

    public function kiosk() {  
	
		/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
	
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('dashboard/index'));
        $this->mybreadcrumb->add('Kiosk', base_url('dashboard/kiosk'));
        $data['page_type']='Healthcare Infrastructure';
        $data['kiosk'] = $this->Dashboard_model->get_kiosk();
        $data['updated_page'] = date('d M  Y');
        loadLayout('admin/kiosk', 'admin', $data);
    }
    
    public function clinicalestablishment() { 
	
		/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
		
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));
        $this->mybreadcrumb->add('Clinical Establishment', base_url('dashboard/clinicalestablishment'));
        $data['page_type']='Health Service Delivery';
        loadLayout('admin/clinicalestablishment', 'admin', $data);
    }
    
    /* public function budget() { 
    
$this->mybreadcrumb->add('Home', base_url());
$this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));
$this->mybreadcrumb->add('Clinical Establishment', base_url('dashboard/healthinfrafacilities'));
        
    $data['page_type']='Health Service Delivery';
        loadLayout('admin/budget', 'admin', $data);
        
        
    } */

    /* Rocky Budget Start */

    public function budget() {
	/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
		
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));
        $this->mybreadcrumb->add('Budget', base_url('dashboard/budget'));
        /* Merge Budget Code */

        $data['alert_details'] = $this->Report_model->get_alert_details();
        $data['notifications'] = $this->Report_model->get_dashboard_notification();
        
        $fy_year_1 = date("Y");
        $month = date("m");
        if($month <= 3){ $fy_year_1 = $fy_year_1 -1; }
        $fy_year1=substr($fy_year_1,-2);
        $fy_year2=$fy_year1+1;
        $current_year=$fy_year_1.'-'.$fy_year2;
        
        $grant_no = '042';
        
        // Year override for now
        $current_year = "2018-19";
        
        $data['f_year'] = $current_year;
        if($this->input->server('REQUEST_METHOD') == "POST"){
            $data['f_year'] = $this->input->post('f_year');
        }
        $data['budget_type_list'] = $this->Report_model->get_mohfw_budget_table_mapping($data['f_year'],'get_budget_type');
        
        $data['year_list'] = $this->Report_model->get_mohfw_budget_table_mapping($data['f_year']);
        

        $data['re_case_hide'] = '';
        $data['budget_type_val'] = 'BE';
        if ($this->input->server('REQUEST_METHOD') == "POST" && $this->input->post('budget_type')=='RE'){
            $data['re_case_hide'] = "show";
            $data['budget_type_val'] = 'RE';
            
            $data['budget_total'] = $this->Report_model->get_budget($data['f_year'],'RE',NULL,'total',$grant_no); 
            $data['budget_total'] = $data['budget_total'][0];
            
            $data['main_scheme_be'] = $this->Report_model->get_budget($data['f_year'], 'RE',NULL,NULL,$grant_no);
            
            $data['css_be'] = $this->Report_model->get_budget($data['f_year'], 'RE',nhm_id, NULL,$grant_no);
            
            $data['css_main_be'] = $this->Report_model->get_budget($data['f_year'], 'RE',css_id, NULL, $grant_no);
            
            $data['cs_be'] = $this->Report_model->get_budget($data['f_year'], 'RE',cs_id, NULL,$grant_no);
            
            $data['gross_be'] = $this->Report_model->get_gross_budget($data['f_year'], 'RE',$grant_no);
            
            $data['ner_be'] = $this->Report_model->get_NER_budget($data['f_year'],'RE',$grant_no);
            
            $data['eac_be'] = $this->Report_model->get_EAC_budget($data['f_year'],'RE',$grant_no);
            
            $data['budget_total_dhr'] = $this->Report_model->get_budget($data['f_year'], 'RE',NULL,'total','043');
            $data['budget_total_dhr'] = $data['budget_total_dhr'][0];
            
            $data['budget_total_ayush'] = $this->Report_model->get_budget($data['f_year'], 'RE',NULL,'total','005');
            $data['budget_total_ayush'] = $data['budget_total_ayush'][0];
            
            //get total recoveries (function used in recoveries report)
            $data['total_rec'] = $this->Report_model->get_total_recoveries(NULL,$data['f_year'],'RE', $grant_no);
            
        }else{
        	
            $data['re_case_hide'] = "show";
            $data['budget_total'] = $this->Report_model->get_budget($data['f_year'], 'BE',NULL,'total',$grant_no);
            $data['budget_total'] = $data['budget_total'][0];
            
            $data['css_be'] = $this->Report_model->get_budget($data['f_year'], 'BE','nhm_id',NULL,$grant_no);
            
            $data['main_scheme_be'] = $this->Report_model->get_budget($data['f_year'], 'BE',NULL,NULL,$grant_no);
            
            $data['css_main_be'] = $this->Report_model->get_budget($data['f_year'], 'BE','css_id',NULL,$grant_no);
            
            $data['cs_be'] = $this->Report_model->get_budget($data['f_year'], 'BE','cs_id',NULL,$grant_no);
            
            $data['gross_be'] = $this->Report_model->get_gross_budget($data['f_year'], 'BE',$grant_no);
            
            $data['ner_be'] = $this->Report_model->get_NER_budget($data['f_year'],'BE',$grant_no);
            
            $data['eac_be'] = $this->Report_model->get_EAC_budget($data['f_year'],'BE',$grant_no);
            
            $data['budget_total_dhr'] = $this->Report_model->get_budget($data['f_year'], 'BE',NULL,'total','043');
            $data['budget_total_dhr'] = $data['budget_total_dhr'][0];
            
            $data['budget_total_ayush'] = $this->Report_model->get_budget($data['f_year'], 'BE',NULL,'total','005');
            $data['budget_total_ayush'] = $data['budget_total_ayush'][0];   

            //get total recoveries (function used in recoveries report)
            $data['total_rec'] = $this->Report_model->get_total_recoveries(NULL,$data['f_year'],'RE', $grant_no);
        }
        
        //get recoveries (function used in recoveries report)
        $data['received_rec'] = $this->Report_model->get_received_recoveries(NULL, $data['f_year'], $grant_no);
        
        //for net categories
        $data['exp_total'] = $this->Report_model->get_opr_exp_total(NULL,$data['f_year'],$grant_no);

        //for gross categories
        $data['gross_exp'] = $this->Report_model->get_gross_exp($data['f_year'],$grant_no);
        
        //added net figures(calculated from gross and recoveries) for net speedometer
        $data['gross_exp_for_net'] = isset($data['gross_exp']['gross_exp_total'])?$data['gross_exp']['gross_exp_total']:'0.00';
        $data['received_rec_for_net'] = isset($data['received_rec']['exp_total'])?$data['received_rec']['exp_total']:'0.00';
          $data['exp_total_for_net'] = bcsub($data['gross_exp_for_net'], $data['received_rec_for_net'], 2); 
        $data['net_pop_up_percent'] = getPercentage2(isset($data['exp_total_for_net'])?$data['exp_total_for_net']:'0.00', isset($data['budget_total']['budget_total'])?$data['budget_total']['budget_total']:'0.00');
        
        //for all 4 main categories

        $data['main_scheme_exp'] = $this->Report_model->get_opr_expenditure(NULL,$data['f_year'],$grant_no);
        
        $data['css_exp'] = $this->Report_model->get_opr_expenditure('nhm_id',$data['f_year'],$grant_no);
        $data['css_main_exp'] = $this->Report_model->get_opr_expenditure('css_id',$data['f_year'],$grant_no);
        
        //central sector schemes children (especially for PMSSY)
        $data['cs_exp'] = $this->Report_model->get_opr_expenditure('cs_id',$data['f_year'],$grant_no);
        
        //for NER
        $data['ner_exp'] = $this->Report_model->get_opr_exp_NER($data['f_year'],$grant_no);
        //for EAC
        $data['eac_exp'] = $this->Report_model->get_opr_exp_EAC($data['f_year'],$grant_no);
        
        $data['qep'] = $this->Report_model->get_qep($data['f_year'],'BE',$grant_no);
        
        $data['mep'] = $this->Report_model->get_mep($data['f_year'],'BE',$grant_no);
        
        if(isset($data['exp_total']['expenditure_upto']) && $data['exp_total']['expenditure_upto']!=''){
            $data['exp_date'] = date("d.m.Y", strtotime($data['exp_total']['expenditure_upto']));
        }else{
            $data['exp_date'] = FALSE;
        }
        
        $data['exp_total_dhr'] = $this->Report_model->get_opr_exp_total(NULL,$data['f_year'],'043');
        if(isset($data['exp_total_dhr']['expenditure_upto']) && $data['exp_total_dhr']['expenditure_upto']!=''){
            $data['exp_date_dhr'] = date("d.m.Y", strtotime($data['exp_total_dhr']['expenditure_upto']));
        }else{
            $data['exp_date_dhr'] = FALSE;
        }
        
        $data['exp_total_ayush'] = $this->Report_model->get_opr_exp_total(NULL,$data['f_year'],'005');
        if(isset($data['exp_total_ayush']['expenditure_upto']) && $data['exp_total_ayush']['expenditure_upto']!=''){
            $data['exp_date_ayush'] = date("d.m.Y", strtotime($data['exp_total_ayush']['expenditure_upto']));
        }else{
            $data['exp_date_ayush'] = FALSE;
        }
        
        $data['qep_dhr']    = 	$this->Report_model->get_qep($data['f_year'],$data['budget_type_val'],'043');

        $data['page_type']	=	'Health Service Delivery';
        loadLayout('admin/budget_report', 'admin', $data);
             
    }

    /* Rocky Budget Ended */
	
	 public function ddap() {
	
		/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/	
			
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));
        $this->mybreadcrumb->add('DDAP', base_url('dashboard/ddap'));
		$data['page_type']	=	'Health Service Delivery';
        loadLayout('admin/ddap', 'admin', $data);
             
    }
		
    
    public function pmssy() {
	
		/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/	
			
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('dashboard/index'));
        $this->mybreadcrumb->add('PMSSY', base_url('dashboard/pmssy'));
        $data['page_type']='Healthcare Infrastructure';
        loadLayout('admin/pmssy', 'admin', $data);
    }
    
    public function hmis() {

		/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/	
			
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('dashboard/index'));
        $this->mybreadcrumb->add('HMIS', base_url('dashboard/hmis'));
        $data['page_type']='Healthcare Infrastructure';;
        loadLayout('admin/hmis1', 'admin', $data);
    }
    
    public function hmis2(){
		
		/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
		
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Human Resources', base_url('dashboard/healthhumanresources'));
        $this->mybreadcrumb->add('HMIS', base_url('dashboard/healthhumanresources'));
        $data['page_type']='Health Human Resources';
        loadLayout('admin/hmis', 'admin', $data);
    }
    
    public function hmis3() {

		/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
		
        $data['hmis_curr_date'] = $this->Dashboard_model->hmis_curr_date();
        $data['h_s_opd'] = $this->Dashboard_model->all_elderly_total(); 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));
        $this->mybreadcrumb->add('HWC', base_url('dashboard/hmis3'));
        $data['page_type']='Health Service Delivery';
        loadLayout('admin/hmis3', 'admin', $data);
    }
    
    public function hmis4(){ 
	
		/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
	
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Quality of Health Services', base_url('dashboard/qualityhealthservices'));
        $this->mybreadcrumb->add('HMIS', base_url('dashboard/hmis4'));
        $data['page_type']='Quality of Health Services';
        loadLayout('admin/hmis4', 'admin', $data);
    }
    
    public function healthhumanresources(){ 
	
		/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
	
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Human Resources', base_url('dashboard/healthhumanresources'));
        $data['row'] = $this->Dashboard_model->get_totalRecordhr();
        $data['page_type']='Health Human Resources';
        loadLayout('admin/health_infra_healthhuman', 'admin', $data);
    }



    public function healthservice() {
	/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
		
        /* =============== fetch elderly data from master table ============= */
        
       /* $elderly = $this->Dashboard_model->getelderlymasterrecord();
        $data['state_count']  =  unserialize($elderly['state_count']);
        $data['district_count']  =  unserialize($elderly['district_count']);
        $data['rgc_count']  =  unserialize($elderly['rgc_count']);
        $data['national_center']  =  unserialize($elderly['national_center_ageing']);*/






        $data['fetch_date'] = $this->Dashboard_model->fetch_curr_date(); 
       
        
        $data['hmis_curr_date'] = $this->Dashboard_model->hmis_curr_date(); 
        $data['amrit_curr_date'] = $this->Dashboard_model->amrit_curr_date(); 
        $data['rch_curr_date'] = $this->Dashboard_model->rch_curr_date(); 
        $data['ors_curr_date'] = $this->Dashboard_model->ors_curr_date(); 
        $data['fetch_curr_date'] = $this->Dashboard_model->fetch_notto_currdate(); 
        $data['amrit'] = $this->Dashboard_model->newerinitamrit();
       
        $data['result'] = getPMSMAReport();
        $data['result1'] = getLAQSHAYReport();
        
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));


        $data['page_type']='Health Service Delivery';
        loadLayout('admin/health_service', 'admin', $data);
    }
    
    
    public function amrit() {

		/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
		
        $data['amrit_curr_date'] = $this->Dashboard_model->amrit_curr_date(); 

        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));
        $this->mybreadcrumb->add('AMRIT', base_url('dashboard/amrit'));
        $data['amrit'] = $this->Dashboard_model->newerinitamrit();
                
        $data['page_type']='Health Service Delivery';
        loadLayout('admin/amrit', 'admin', $data);
    }

    public function pmsma() { 
			/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
	
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));
        $this->mybreadcrumb->add('PMSMA', base_url('dashboard/pmsma'));
        
         //============= master database sync code here ===============//

        //$data['SYNC'] = syncPMSMAdatabase();
    
    //============= end master database sync code ===============//
        
        $data['result'] = getPMSMAReport();
        /*echo "<pre>";
        print_r($data['result']); die;*/
        $data['remote_site_url'] = 'https://pmsma.nhp.gov.in/pmsma-app/login/apilogintoken';

        $data['page_type']='Health Service Delivery';       
        loadLayout('admin/new_pmsma', 'admin', $data);
    }
    
    public function rch() {
/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/		
        $data['rch_curr_date'] = $this->Dashboard_model->rch_curr_date(); 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));
        $this->mybreadcrumb->add('RCH Portal', base_url('dashboard/rch'));
        $data['page_type']='Health Service Delivery';
        loadLayout('admin/rch', 'admin', $data);
    }
    
    public function rchrkskannex() {
		/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));
        $this->mybreadcrumb->add('RCH RKSK Portal', base_url('dashboard/rch_rksk_annex'));
        $data['page_type']='Health Service Delivery';
        loadLayout('admin/rch_rksk_annex', 'admin', $data);
    }
    
    public function healthservicetotalchcrating() { 
	/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $data['page_type']='';
        loadLayout('admin/health_service_totalchcrating', 'admin', $data);
    }
    
    public function healthserviceessentialdrugs() {
/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/		
        $data['page_type']='Health Service Delivery';
        loadLayout('admin/health_service_essentialdrugs', 'admin', $data);
    }
    
    
    
    public function cghs() { 
	/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));
        $this->mybreadcrumb->add('CGHS', base_url('dashboard/cghs'));
        $data['page_type']='Health Service Delivery';
        loadLayout('admin/cghs', 'admin', $data);
    }

    public function diseasescontrol() { 
	/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Diseases Control', base_url('dashboard/diseasescontrol'));
        $data['page_type']='Diseases Control';
        loadLayout('admin/diseases_control', 'admin', $data);
    }
    
    public function idsp() {
		/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Diseases Control', base_url('dashboard/diseasescontrol'));
        $this->mybreadcrumb->add('Outbreaks (IDSP)', base_url('dashboard/idsp'));
        $data['page_type']='Diseases Control';
        loadLayout('admin/idsp', 'admin', $data);
    }
    
    public function nikshay() {
		/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Diseases Control', base_url('dashboard/diseasescontrol'));
        $this->mybreadcrumb->add('Nikshay', base_url('dashboard/nikshay'));
        $data['page_type']='Diseases Control';
        loadLayout('admin/nikshay', 'admin', $data);
    }
    
    public function swachhta() { 
	/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Diseases Control', base_url('dashboard/diseasescontrol'));
        $this->mybreadcrumb->add('Swachhta', base_url('dashboard/swachhta'));
        $data['swachhta'] = $this->Dashboard_model->get_swachhta_dash(); 
        $data['swachhta_sar'] = $this->Dashboard_model->get_swachhta_sarvatra();
        //$data['swachhta_expend'] = $this->Dashboard_model->get_swachhta_expenditure();

        $data['page_type']='Diseases Control';
        loadLayout('admin/swachhta', 'admin',  $data);
    }
	
	 public function nlep() {
		 /*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Diseases Control', base_url('dashboard/diseasescontrol'));
        $this->mybreadcrumb->add('NLEP', base_url('dashboard/nlep'));
        $data['page_type']='Diseases Control';
        loadLayout('admin/nlep', 'admin', $data);
    }
	
	 public function nvbdcp() {
		 /*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Diseases Control', base_url('dashboard/diseasescontrol'));
        $this->mybreadcrumb->add('NVBDCP', base_url('dashboard/nvbdcp'));
        $data['page_type']='Diseases Control';
        loadLayout('admin/nvbdcp', 'admin', $data);
    }
/* ----------  twinkle code -------------- */	
	 public function nvchp() {
		 /*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Diseases Control', base_url('dashboard/diseasescontrol'));
        $this->mybreadcrumb->add('NVHCP', base_url('dashboard/nvchp'));
        $data['state'] = $this->hwc_model->get_state();
       


        if (isset($_REQUEST['submit'])) {
            $filter = array(
                "stateid"  => $this->input->get('state_name'),
                "eyear"    => $this->input->get('e_year'),
                "emonth"   => $this->input->get('e_month'), 
            );

            $data['row'] = $this->Dashboard_model->searchnvhcprecord($filter);
        }else{
            $data['row'] = $this->Dashboard_model->get_totalRecordNVHCPs();
        }
     /**   echo "<pre>";
        print_r($data['row']); die;*/
        $data['page_type']='Diseases Control';
        loadLayout('admin/nvchp', 'admin', $data);
    }

 public function hr() { 
 /*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
     
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Human Resources', base_url('dashboard/healthhumanresources'));
        $this->mybreadcrumb->add('Human Resources', base_url('dashboard/hr'));
        
        
        $data['state'] = $this->hwc_model->get_state();
       


        if (isset($_REQUEST['submit'])) {
            $filter = array(
                "state_id"  => $this->input->get('state_name'),
                "eyear"    => $this->input->get('e_year'),
                "quarterly"   => $this->input->get('quarterly'), 
            );

            $data['row'] = $this->Dashboard_model->searchhrrecord($filter);
        }else{
            $data['row'] = $this->Dashboard_model->get_totalRecordhr();
        }
      $data['page_type']='hr'; 
      loadLayout('admin/HR/hr', 'admin', $data);
    }


     public function nqas() { 
	 /*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
     
        $this->mybreadcrumb->add('Home', base_url());
        
         $this->mybreadcrumb->add('Quality of Health Services', base_url('dashboard/qualityhealthservices'));
        $this->mybreadcrumb->add('National Quality Assurance Standards', base_url('dashboard/nqas'));
        $data['state'] = $this->hwc_model->get_state();
       


        if (isset($_REQUEST['submit'])) {
            $filter = array(
                "state_id"  => $this->input->get('state_name'),
                "eyear"    => $this->input->get('e_year'),
                "quarterly"   => $this->input->get('quarterly'), 
            );

            $data['row'] = $this->Dashboard_model->searchnqasrecord($filter);
        }else{
            $data['row'] = $this->Dashboard_model->get_totalRecordnqas();
        }
      $data['page_type']='nqas'; 
      loadLayout('admin/nqas/nqas', 'admin', $data);
    }
	
	public function ntcp() {
		/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Diseases Control', base_url('dashboard/diseasescontrol'));
        $this->mybreadcrumb->add('NTCP', base_url('dashboard/ntcp'));
		
		$state=$this->hwc_model->get_state();
		
		$data['state']=$state;
        $data['districts'] = $this->Dashboard_model->get_district();
        if (isset($_REQUEST['submit'])) {
            $filter = array(
                "state_id"  => $this->input->get('state_name'),
                "emonth"    => $this->input->get('e_month'),
                "eyear"     => $this->input->get('e_year'), 
            );

            $data['row'] = $this->Dashboard_model->searchntcprecord($filter);
        }else{
            $data['row'] = $this->Dashboard_model->get_totalRecordntcp();
        }

        if (isset($_REQUEST['submit'])=='Submit') {
            
            $filter = array(
                "state_id"  => $this->input->get('statename'),
                "district_id"    => $this->input->get('districtname'),
            );

            $data['row1'] = $this->Dashboard_model->searchntcpcentrerecord($filter);
        }else{
            $data['row1'] = $this->Dashboard_model->get_totalRecordntcpcentre();
        }
		
        $data['page_type']='Diseases Control';
        loadLayout('admin/ntcp', 'admin', $data);
    }

   /* public function ntcpcentre() {
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Diseases Control', base_url('dashboard/diseasescontrol'));
        $this->mybreadcrumb->add('NTCP', base_url('dashboard/ntcp'));
        
        $state=$this->hwc_model->get_state();
        
        $data['state']=$state;

        if (isset($_REQUEST['submit'])) {
            $filter = array(
                "state_id"  => $this->input->get('statename'),
                "district_id"    => $this->input->get('districtname'),
            );

            $data['row'] = $this->Dashboard_model->searchntcpcentrerecord($filter);
        }else{
            $data['row'] = $this->Dashboard_model->get_totalRecordntcpcentre();
        }
        var_dump($data['row']); die;
        $data['page_type']='Diseases Control';
        loadLayout('admin/ntcp', 'admin', $data);
    }
*/
    public function getDistrict($id) 
    { 
        $result = $this->db->where("State_ID",$id)->get("m_district")->result();
        echo json_encode($result);
    }

    public function fdsi() { 
     /*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Drugs & Diagnostics', base_url('dashboard/drugsdiagnostics'));
        $this->mybreadcrumb->add('Drugs & Diagnostics', base_url('dashboard/fdsi'));
        $data['state'] = $this->hwc_model->get_state();
       
        if (isset($_REQUEST['submit'])) {
            $filter = array(
                "quarterly"  => $this->input->get('quarterly'),
                "eyear"      => $this->input->get('e_year'),
                "emonth"     => $this->input->get('e_month'), 
            );

            $data['row'] = $this->Dashboard_model->searchfdsirecord($filter);
        }else{
            $data['row'] = $this->Dashboard_model->get_totalRecordfdsi();
        }
        $data['page_type']='fdsi';
     
       
        loadLayout('admin/freeDiagnosticsSI/freeDiagnosticsSI', 'admin', $data);
    }


    /* -------------- end ---------------  */ 
    
    public function ors() { 
    /*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $data['ors_curr_date'] = $this->Dashboard_model->ors_curr_date(); 

        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));
        $this->mybreadcrumb->add('ORS', base_url('dashboard/ors'));

        if($this->input->get('s_issue_date'))
         {
            $data['year_val']=$this->input->get('s_issue_date');
         }
         else
         {
         $data['year_val']=date('Y-m-d');
         }

        ///////////// call data from api ////////

        $client = new SoapClient("https://ors.gov.in/orsapi/services?wsdl",array('soap_version' => SOAP_1_1,'trace' => 1 ));
        $params = array('inToken'=>'dS6yFX4DqTTT32WmFkEhg','appointmentRequestDate'=>$data['year_val']);
        $return = $client->__soapCall("getDateWiseAppointmentCount",array($params));
        $array_data = json_decode($return->return, True);

        $data['array_data']=$array_data;

         /*
        if($array_data['details']['status_code']==1)
        {
            echo print_r($array_data);  
        }
        else
        {
            echo $array_data['details']['status'];  
        }

        */

        /////// end call data from api /////////

        $data['page_type']='Health Service Delivery';
        loadLayout('admin/ors', 'admin', $data);
    }
    
    public function notto() { 
	/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $data['fetch_curr_date'] = $this->Dashboard_model->fetch_notto_currdate(); 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));
        $this->mybreadcrumb->add('NOTTO', base_url('dashboard/notto'));
        $data['page_type']='Health Service Delivery';
        loadLayout('admin/notto', 'admin', $data);
    }
    
    public function laqshya() {
		/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));
        $this->mybreadcrumb->add('LAQSHYA Portal', base_url('dashboard/laqshya'));

        $data['result'] = getLAQSHAYReport();
       // $data['remote_site_url'] = 'http://demosl56.rvsolutions.in/nhp-laqshya/laqshya-portal-local/login/apilogintoken';
        $data['remote_site_url'] = 'http://laqshya.nhp.gov.in/portal/login/apilogintoken';

        $data['page_type']='Health Service Delivery';
        loadLayout('admin/laqshya', 'admin', $data);
    }

    /* public function elderly() { 


        if($this->input->server('REQUEST_METHOD')=="POST"){
            $post=$this->input->post();
            $this->form_validation->set_rules('financial_year','Financial Year','trim|required|xss_clean');
            if($this->form_validation->run()==FALSE){   
                $data['errors'] = validation_errors();
                $this->session->set_flashdata('msg', $data['errors']);
                redirect('Dashboard');
            }else{
                $f_year = $post['financial_year'];
            }
        }else{
            $f_year = "2018-19";    
        }

        //$data['fy_list']=$this->Dashboard_model->get_all_financial_year();
        $data['all_elderly_count'] = $this->Dashboard_model->all_elderly_total(); 
        $data['fetch_curr_date'] = $this->Dashboard_model->fetch_curr_date(); 
        $data['state_count'] = $this->Dashboard_model->state_count();
        $data['district_count'] = $this->Dashboard_model->district_count();
        $data['rgc_count'] = $this->Dashboard_model->rgc_count();
        $data['all_services_count'] = $this->Dashboard_model->all_service_total($f_year,NULL);
        $data['financial_year'] = $f_year;
        $fund_allocation = $this->Dashboard_model->get_all_fund_allocation($f_year);
        $data['fund_allocation'] = $fund_allocation[0];
        $data['state_color']=$this->Dashboard_model->get_unsaved_state_data($f_year);
        $data['max_month']= max(array_column($data['state_color'], 'month'));
        $data['month_name'] = $this->Dashboard_model->get_month_name_by_id($data['max_month']);
        $data['ENC'] = $this->Dashboard_model->get_all_ncd_cell($f_year,5,NULL);    
        $data['ROS'] = $this->Dashboard_model->get_all_ncd_cell($f_year,6,NULL);    
        $data['OL'] = $this->Dashboard_model->get_all_ncd_cell($f_year,7,NULL); 
        $data['dh_services'] = $this->Dashboard_model->all_service_facility_wise($f_year,'DH',NULL);    
        $data['chc_services'] = $this->Dashboard_model->all_service_facility_wise($f_year,'CHC',NULL);  

        $data['sc_services'] = $this->Dashboard_model->all_service_facility_wise($f_year,'SC',NULL); 
        $data['all_state_funds'] = $this->Dashboard_model->get_all_state_funds($f_year);

        //print $data['state_count']['no_of_state']; die;

        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));
        $this->mybreadcrumb->add('Elderly', base_url('dashboard/elderly'));

        //$data['remote_site_url'] = 'http://117.239.178.42/nphce/mis/Rest_login/apilogintoken';

        $data['remote_site_url'] = 'http://117.239.178.42/nphce/mis/Rest_login/apilogintoken?apikey=HWC_CENTRAL_DASHBORD_LOGIN2018&source=central_dashboard';

        $data['page_type'] = 'Health Service Delivery';
        loadLayout('admin/elderly2', 'admin', $data);
    } */


    public function elderly() { 
	/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        
        if($this->input->server('REQUEST_METHOD')=="POST"){
            $post=$this->input->post();
            $this->form_validation->set_rules('financial_year','Financial Year','trim|required|xss_clean');
            if($this->form_validation->run()==FALSE){   
                $data['errors'] = validation_errors();
                $this->session->set_flashdata('msg', $data['errors']);
                redirect('Dashboard');
            }else{
                $f_year = $post['financial_year'];
            }
        }else{
            $f_year = "2018-19";    
        }
        
         //============= master database sync code here ===============//

        $data['SYNC'] = syncELDERLYdatabase();
    
        //============= end master database sync code ===============//
    
        
        /* =============== fetch elderly data from master table ============= */

     /*   $india_map[0] = array(

                     "state_name"       => "Jammu And Kashmir",
                     "state_sortname"       => "JK",
                     "state_code"       => "1",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );

        $india_map[1] = array(

                     "state_name"       => "Himachal Pradesh",
                     "state_sortname"       => "HP",
                     "state_code"       => "2",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
        $india_map[2] = array(

                     "state_name"       => "Punjab",
                    "state_sortname"       => "PB",
                     "state_code"       => "3",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
        $india_map[3] = array(

                     "state_name"       => "Chandigarh",
                     "state_sortname"       => "CH",
                     "state_code"       => "4",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
        $india_map[4] = array(

                     "state_name"       => "Uttarakhand",
                     "state_sortname"       => "UT",
                     "state_code"       => "5",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
        $india_map[5] = array(

                     "state_name"       => "Haryana",
                     "state_sortname"       => "HR",
                     "state_code"       => "6",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
        $india_map[6] = array(

                     "state_name"       => "Delhi",
                     "state_sortname"       => "DL",
                     "state_code"       => "7",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
        $india_map[7] = array(

                     "state_name"       => "Rajasthan",
                     "state_sortname"       => "RJ",
                     "state_code"       => "8",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
        $india_map[8] = array(

                     "state_name"       => "Uttar Pradesh",
                     "state_sortname"       => "UP",
                     "state_code"       => "9",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
        $india_map[9] = array(

                     "state_name"       => "Bihar",
                      "state_sortname"       => "BR",
                     "state_code"       => "10",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );

        $india_map[10] = array(

                     "state_name"       => "Sikkim",
                     "state_sortname"       => "SK",
                     "state_code"       => "11",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );

        $india_map[11] = array(

                     "state_name"       => "Arunachal Pradesh",
                     "state_sortname"       => "AP",
                     "state_code"       => "12",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );

        $india_map[12] = array(

                     "state_name"       => "Nagaland",
                     "state_sortname"       => "NG",
                     "state_code"       => "13",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
        $india_map[13] = array(

                     "state_name"       => "Manipur",
                     "state_sortname"       => "MN",
                     "state_code"       => "14",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
        $india_map[14] = array(

                     "state_name"       => "Mizoram",
                     "state_sortname"       => "MZ",
                     "state_code"       => "15",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
        $india_map[15] = array(

                     "state_name"       => "Tripura",
                      "state_sortname"       => "TR",
                     "state_code"       => "16",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
        $india_map[16] = array(

                     "state_name"       => "Meghalaya",
                     "state_sortname"       => "MG",
                     "state_code"       => "17",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
        $india_map[17] = array(

                     "state_name"       => "Assam",
                     "state_sortname"       => "AS",
                     "state_code"       => "18",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
         $india_map[18] = array(

                     "state_name"       => "West Bengal",
                      "state_sortname"       => "WB",
                     "state_code"       => "19",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );

         $india_map[19] = array(

                     "state_name"       => "Jharkhand",
                      "state_sortname"       => "JH",
                     "state_code"       => "20",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
         $india_map[20] = array(

                     "state_name"       => "Odisha",
                     "state_sortname"       => "OD",
                     "state_code"       => "21",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
         $india_map[21] = array(

                     "state_name"       => "Chhattisgarh",
                      "state_sortname"       => "CH",
                     "state_code"       => "22",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );

          $india_map[22] = array(

                     "state_name"       => "Madhya Pradesh",
                     "state_sortname"       => "MP",
                     "state_code"       => "23",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
          $india_map[23] = array(

                     "state_name"       => "Gujarat",
                     "state_sortname"       => "GJ",
                     "state_code"       => "24",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
          $india_map[24] = array(

                     "state_name"       => "Daman And Diu",
                     "state_sortname"       => "DD",
                     "state_code"       => "25",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
          $india_map[25] = array(

                     "state_name"       => "Dadra And Nagar Haveli",
                      "state_sortname"       => "DN",
                     "state_code"       => "26",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
          $india_map[26] = array(

                     "state_name"       => "Maharashtra",
                     "state_sortname"       => "MH",
                     "state_code"       => "27",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
          $india_map[27] = array(

                     "state_name"       => "Andhra Pradesh",
                     "state_sortname"       => "AP",
                     "state_code"       => "28",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
          $india_map[28] = array(

                     "state_name"       => "Karnataka",
                     "state_sortname"       => "KR",
                     "state_code"       => "29",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
          $india_map[29] = array(

                     "state_name"       => "Goa",
                     "state_sortname"       => "GO",
                     "state_code"       => "30",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
$india_map[30] = array(

                     "state_name"       => "Lakshadweep",
                     "state_sortname"       => "LK",
                     "state_code"       => "31",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );

$india_map[31] = array(

                     "state_name"       => "Kerala",
                     "state_sortname"       => "KL",
                     "state_code"       => "32",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
$india_map[32] = array(

                     "state_name"       => "Tamil Nadu",
                     "state_sortname"       => "TN",
                     "state_code"       => "33",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );

$india_map[33] = array(

                     "state_name"       => "Puducherry",
                     "state_sortname"       => "PD",
                     "state_code"       => "34",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );
$india_map[34] = array(

                     "state_name"       => "Andaman And Nicobar Islands",
                     "state_sortname"       => "AN",
                     "state_code"       => "35",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );

$india_map[35] = array(

                     "state_name"       => "Telangana",
                     "state_sortname"       => "TL",
                     "state_code"       => "36",
                     "color_code"       => "#17a900",
                     "data_availabile"  => "1",
                     "data_not_availabile"=> "0",
                     "previous_month_data_not_availabile"=>"0",
                     "fund_utilizaion"  => "500",
                     "fund_allocation"  => "400",
                     "ncd_cell_ol"      => "50",
                     "ncd_cell_enc"     => "50",
                     "service_provider" => array("attended_OPD"           => "1",
                                                "admitted_in_wards"      => "2",
                                                "rehabilitation_Services"=> "3",
                                                "lab_test_undertaken"    => "4",
                                                "screened_provided_health_card"=>"5",
                                                "persons_provided_home"  => "6",
                                                "assistive_devices"      => "7",
                                                "patients_referred"      => "8",
                                                "died_in_hospitals"      => "9",
                                                "rehabilitation_given_Patients"=>"10",
                                               "advised_lab_test"        => "11",
                                               "iec_activities_conducted"=> "12", 
                                               "trainings_conducted"     => "13",
                                               "persons_trained"         => "14",
                                        )                     
                );



*/

        //echo "<pre>";
        //print_r($india_map);die;
                
       // $data['india_map']=$india_map;

        
       /* $elderly = $this->Dashboard_model->getelderlymasterrecord();
       
        $data['state_count']      =  unserialize($elderly['state_count']);	

        $data['fetch_curr_date']  =  unserialize($elderly['fetch_curr_date']);
        $data['district_count']   =  unserialize($elderly['district_count']);
        $data['rgc_count']        =  unserialize($elderly['rgc_count']);
        $data['national_center']  =  unserialize($elderly['national_center_ageing']);
        
        $data['state_color']      =  unserialize($elderly['state_color']);

      
		
        $data['max_month']        =  unserialize($elderly['max_month']);
        $data['month_name']       =  unserialize($elderly['month_name']);
       
        $fund_utilization         =  unserialize($elderly['fund_utilization']);
        $data['fund_utilization'] =  $fund_utilization[0];
		$fund_allocation          =  unserialize($elderly['fund_allocation']);
        $data['fund_allocation']  =  $fund_allocation[0];
        $data['all_services_count']  =  unserialize($elderly['all_services_count']);

        $data['phc_services']  =  unserialize($elderly['phc_services']);
        $data['dh_services']  =  unserialize($elderly['dh_services']);
        
        $data['chc_services']  =  unserialize($elderly['chc_services']);
        $data['sc_services']  =  unserialize($elderly['sc_services']);
        $data['all_state_funds']  =  unserialize($elderly['all_state_funds']);
        $data['ncd_enc']  =  unserialize($elderly['ENC']);
        $data['ncd_ol']   =  unserialize($elderly['OL']);        
        $data['financial_year']   =  $f_year;*/
        
		/*echo "<pre>";
		print_r($data['fund_utilization']);die;*/
        

        /* =========================== end ============================== */
      
     /* $data['all_elderly_count'] = $this->Dashboard_model->all_elderly_total(); 
        $data['fetch_curr_date'] = $this->Dashboard_model->fetch_curr_date(); 
        $data['state_count'] = $this->Dashboard_model->get_state_count();
        $data['district_count'] = $this->Dashboard_model->get_district_count();
        $data['rgc_count'] = $this->Dashboard_model->get_rgc_count();
        $data['all_services_count'] = $this->Dashboard_model->all_service_total($f_year,NULL);
        $fund_allocation = $this->Dashboard_model->get_all_fund_allocation($f_year);
        $fund_utilization = $this->Dashboard_model->get_all_fund_utilization($f_year); 
        $data['fund_allocation'] = $fund_allocation[0];
        $data['fund_utilization'] = $fund_utilization[0];
        $data['state_color']=$this->Dashboard_model->get_unsaved_state_data($f_year);
        $data['max_month']= max(array_column($data['state_color'], 'month'));
        $data['month_name'] = $this->Dashboard_model->get_month_name_by_id($data['max_month']);*/
        /*
        $data['fy_list']=$this->Dashboard_model->get_all_financial_year();
        $data['ENC'] = $this->Dashboard_model->get_all_ncd_cell($f_year,5,NULL);    
        $data['ROS'] = $this->Dashboard_model->get_all_ncd_cell($f_year,6,NULL);    
        $data['OL'] = $this->Dashboard_model->get_all_ncd_cell($f_year,7,NULL); 
        $data['dh_services'] = $this->Dashboard_model->all_service_facility_wise($f_year,'DH',NULL);    
        $data['chc_services'] = $this->Dashboard_model->all_service_facility_wise($f_year,'CHC',NULL); 

        //echo print_r($data['chc_services']); die;
        $data['phc_services'] = $this->Dashboard_model->all_service_facility_wise($f_year,'PHC',NULL);  
        $data['sc_services'] = $this->Dashboard_model->all_service_facility_wise($f_year,'SC',NULL); 
        $data['all_state_funds'] = $this->Dashboard_model->get_all_state_funds($f_year);
        $data['title'] = "National";
*/
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));
        $this->mybreadcrumb->add('Elderly', base_url('dashboard/elderly'));

        //$data['remote_site_url'] = 'http://117.239.178.42/nphce/mis/Rest_login/apilogintoken';

        $data['remote_site_url'] = 'http://117.239.178.42/nphce/mis/Rest_login/apilogintoken?apikey=HWC_CENTRAL_DASHBORD_LOGIN2018&source=central_dashboard';

        $data['page_type'] = 'Health Service Delivery';
        loadLayout('admin/elderly', 'admin', $data);
    }
    
    
    
    
    public function qualityhealthservices(){ 
	/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Quality of Health Services', base_url('dashboard/qualityhealthservices'));
        $data['row'] = $this->Dashboard_model->get_totalRecordnqas();
        $data['page_type']='Quality of Health Services';
        loadLayout('admin/quality_health_services', 'admin', $data);
    }
	
	
	 public function sdg(){ 
	 /*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Quality of Health Services', base_url('dashboard/qualityhealthservices'));
        $data['page_type']='Quality of Health Services';
        loadLayout('admin/sdg', 'admin', $data);
    }
    
    public function qualityhealthpatient() { 
	/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Quality of Health Services', base_url('dashboard/qualityhealthservices'));
        $this->mybreadcrumb->add('Mera Aspatal', base_url('dashboard/qualityhealthpatient'));
        $data['page_type']='Quality of Health Services';
        loadLayout('admin/quality_health_patient', 'admin', $data);
    }
    
    

    public function drugsdiagnostics(){ 
	/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Drugs & Diagnostics', base_url('dashboard/drugsdiagnostics'));
         $data['row'] = $this->Dashboard_model->get_totalRecordfdsi();
        $data['page_type']='Drugs-Diagnostics';
        loadLayout('admin/drugs_diagnostics', 'admin', $data);
    }
    
    public function dvdms() { 
	/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Drugs & Diagnostics', base_url('dashboard/drugsdiagnostics'));
        $this->mybreadcrumb->add('eAushadhi (DVDMS)', base_url('dashboard/dvdms'));
        $data['page_type']='Drugs-Diagnostics';
        loadLayout('admin/dvdms', 'admin', $data);
    }
    
    public function sugam() { 
	/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Drugs & Diagnostics', base_url('dashboard/drugsdiagnostics'));
        $this->mybreadcrumb->add('Sugam', base_url('dashboard/sugam'));
        $data['page_type']='Drugs-Diagnostics';
        loadLayout('admin/sugam', 'admin', $data);
    }
    /*----------Start Code Veer---*/
	public function freedrugservices() {
/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/		
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Drugs & Diagnostics', base_url('dashboard/drugsdiagnostics'));
        $this->mybreadcrumb->add('eAushadhi (DVDMS)', base_url('dashboard/dvdms'));
        $data['page_type']='Drugs-Diagnostics';
        loadLayout('admin/free_drugs_services', 'admin', $data);
    }
	
	public function nhmfinance() { 
	/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Drugs & Diagnostics', base_url('dashboard/drugsdiagnostics'));
        $this->mybreadcrumb->add('eAushadhi (DVDMS)', base_url('dashboard/dvdms'));
        $data['page_type']='Drugs-Diagnostics';
        loadLayout('admin/nhm_finance', 'admin', $data);
    }
	
	
	public function bloodbank() { 
/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/    
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('dashboard/index'));
        $this->mybreadcrumb->add('Blood Bank', base_url('dashboard/bloodbank'));
        $data['page_type']='Healthcare Infrastructure';
        loadLayout('admin/bloodbank', 'admin', $data);
    }
	
	/*----------End Code Veer---*/	
		
    public function ivrbasedapp() {
/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/		
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('IVR Based App', base_url('dashboard/ivrbasedapp'));
        $data['page_type']='IVR Based App';
        loadLayout('admin/newer_init_userregisteredmissedcalls', 'admin', $data);
    }



    public function meraaspataal() {
/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/		
	
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('IVR Based App', base_url('dashboard/ivrbasedapp'));
        $this->mybreadcrumb->add('Mera Aspataal', base_url('dashboard/meraaspataal'));
        //$data['remote_site_url'] = 'http://pssadmin.mahiti.org/api/chiLogin';
        $data['remote_site_url']   = 'http://admin.meraaspataal.nhp.gov.in/api/chiLogin';									  
		
		/////////////////// master database sync code here ///////
       $result = syncMeraAspataaldatabase();
        ////////////////// end master database sync code /////////
	   
       foreach($result as $row){
            $result   =  $this->Dashboard_model->updateRecord($row);            
       }
        
		$data['record'] =  $this->Dashboard_model->get_all_record();
        /*echo "<pre>";
        print_r($data['record']);die;*/
		$data['record1']=  $this->Dashboard_model->get_record();
        /*echo "<pre>";
        print_r($data['record1']);die;*/
        $data['page_type'] = 'IVR Based App';
        loadLayout('admin/meraaspataal', 'admin', $data);
    }

    public function tobacco() { 
	/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
	
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('IVR Based App', base_url('dashboard/ivrbasedapp'));
        $this->mybreadcrumb->add('Tobacco & Diabetes', base_url('dashboard/tobacco'));
        $data['page_type']='IVR Based App';
        loadLayout('admin/tobacco', 'admin', $data);
    }
        
    public function newerinittotaldownloads() { 
	/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $data['page_type']='Mobile Apps';
        loadLayout('admin/newer_init_totaldownloads', 'admin', $data);
    }
    

    public function ihic() { 
	/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('IHIC', base_url('dashboard/ihic'));
		$data['total_tour']=$this->Dashboard_model->total_foreign_tour();
		$data['active_mou']=$this->Dashboard_model->total_active_mou();
		$data['total_visit']=$this->Dashboard_model->total_fvms_visit();
		
		// find date last update master table ////////
		
		 $this->db->select('*');
         $this->db->from('last_update_sync_master');
         $query=$this->db->get();
		 $last_update[]='';
		 if($query->num_rows()>0){
			 $data_arr = $query->result_array(); 
					foreach($data_arr as $result){
						$last_update[$result['program']]=$result['updated_date'];
					}
					
					 $data['last_update_sync_master']= $last_update;
					
		 }
		 else{
			 $data['last_update_sync_master']= $last_update;
		 }
		
		  		
		// end find date last update master table ////////
		
        $data['page_type']='IHIC';
        loadLayout('admin/ihic', 'admin', $data);
    }

    public function fvms() {
		/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('IHIC', base_url('dashboard/ihic'));
        $this->mybreadcrumb->add('FVMS (IHIC)', base_url('dashboard/fvms'));
		
		$data['fvms_master_data']=$this->Dashboard_model->get_fvms_masterData

        //============= master database sync code here ===============//

        //$data['SYNC'] = syncFVMSdatabase();
    
        //============= end master database sync code ===============//
		
		// find date last update master table ////////
		
		 $this->db->select('*');
         $this->db->from('last_update_sync_master');
         $query=$this->db->get();
		 $last_update[]='';
		 if($query->num_rows()>0){
			 $data_arr = $query->result_array(); 
					foreach($data_arr as $result){
						$last_update[$result['program']]=$result['updated_date'];
					}
					
					 $data['last_update_sync_master']= $last_update;
					
		 }
		 else{
			 $data['last_update_sync_master']= $last_update;
		 }
		  		
		// end find date last update master table ////////

        $data['remote_site_url'] = 'http://ih.nhp.gov.in/admin/apilogin/apilogintoken';
        $data['page_type']='IHIC';
		
		
		
        loadLayout('admin/fvms', 'admin', $data);
    }
    
    public function mou() { 
	/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('IHIC', base_url('dashboard/ihic'));
        $this->mybreadcrumb->add('MOU (IHIC)', base_url('dashboard/mou'));
        //============= master database sync code here ===============//

       // $data['SYNC'] = syncMOUdatabase();
    
        //============= end master database sync code ===============//
		
		$data['requiring_renewal']=$this->Dashboard_model->get_requiring_renewal();
		
		$data['mou_expired']=$this->Dashboard_model->get_mou_expired();
		
        $data['remote_site_url'] = 'http://ih.nhp.gov.in/admin/apilogin/apilogintoken';
        $data['page_type']='IHIC';
        loadLayout('admin/mou', 'admin', $data);
    }
    
    public function son(){
		/*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('IHIC', base_url('dashboard/ihic'));
        $this->mybreadcrumb->add('SON (IHIC)', base_url('dashboard/son'));
        $data['remote_site_url'] = 'http://ih.nhp.gov.in/admin/apilogin/apilogintoken';
        $data['page_type']		 = 'IHIC';
        loadLayout('admin/son', 'admin', $data);
    }

     public function login_api(){
        $ch = curl_init();
        //isset($_POST['remote_site_url']
        //
        // $url='https://ab-hwc.nhp.gov.in/home/apilogintoken';

        //$url='http://172.16.1.165:8080/nin_ci/home/apilogintoken';

        $url = $_POST['remote_site_url'];

        $postData = array(
            'apikey'   => 'HWC_CENTRAL_DASHBORD_LOGIN2018',
            'source'   => 'Central_Dashboard',
            );

        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postData,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYHOST => 0,   		// don't verify ssl  
            CURLOPT_SSL_VERIFYPEER => false

        ));

        $output = curl_exec($ch);
    /*
    $ch = curl_init() or die("Error");
        curl_setopt($ch, CURLOPT_USERAGENT, USERAGENT);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);     
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
         curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);  
        if(curl_exec($ch) === FALSE) 
        {
            die("Curl failed: " . curl_error($ch));  // Never goes here
        }

        curl_close($ch);
    echo curl_getinfo($ch); die;
    */
    //echo $url.'<br/>';
    //echo 'hello.....'.($output); die;

        if($output){

        $output_object = json_decode($output);
        //echo 'hhaa='.print_r($output_object); die;


        $return["return_url"]=  $output_object->return_url; 

        $return["status"]=  $output_object->status;

        $return["message"] =$output_object->message;

        $return["json"] = json_encode($return);
        echo json_encode($return);
        }
        else
        {
        $return["return_url"]=  ''; 

        $return["status"]=  0;

        $return["message"] ='';

        $return["json"] = json_encode($return);
        echo json_encode($return);
        }
    }


public function refreshSyncData()
{

$ch = curl_init();
$optArray = array(
    CURLOPT_URL => 'https://ab-hwc.nhp.gov.in/Sync_master_code',
    CURLOPT_RETURNTRANSFER => true
);
curl_setopt_array($ch, $optArray);
$result = curl_exec($ch);

echo $result;

}
/* ------------  Send sms code by kunal -------------- */
public function sendsms(){
	
	   $mobileno=$this->input->post('contact_no1');
	   $message=$this->input->post('message1');
       
		
       echo $this->smslib->sendSMS($mobileno,$message);
        die;
}
/* ------------ end code Send sms code by kunal -------------- */

     

}
