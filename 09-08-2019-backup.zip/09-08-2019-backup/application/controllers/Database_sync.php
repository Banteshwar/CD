<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Database_sync extends CI_Controller {

   

    public function __construct() {
       
        parent::__construct();
        
        $this->load->helper('hwc_dashboard');
        //$this->load->model('hwc_model');
        /*global $db;
        $this->db = $db;
        $this->user = new Users();

        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }*/
    }

    public function index() {
        $list  =  parse_ini_file("config.ini",true);
        
        $arr  = json_encode($list,true);
        
        $post_data  = array("File1"=>$arr,"Header"=>"","Footer"=>"","Options"=>array(2,2),"Export"=>"return");
        
        $baseurl  = base_url('mysqldumpdiff/ProcessFiles');
        $ch = curl_init($baseurl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
        $result = curl_exec($ch);
        curl_close($ch);
      
        echo "<pre>";
        print_r($result);
    }
    
    public function mysqldump() {
       
        redirect(base_url('mysqldumpdiff'));
        //loadLayout('db_sync/mysqldumpdiff', 'db_sync');
        
    }

    

}
