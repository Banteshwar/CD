<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dmhp extends MY_Controller {
    private $user;

    public function __construct() {
        parent::__construct();           
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('programmanager/dmhp_model');
        $this->load->model('Dashboard_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');
    }

        
    public function index() { 		
    	$this->dmhp_view();
    }
	
	public function dmhp_view(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('NMHP', base_url('dmhp/index'));
    //     $this->mybreadcrumb->add('District Mental Health Programme', base_url('dmhp/index'));       
        $data['page_type'] = 'Health Service Delivery';
		$data['row'] = $this->dmhp_model->get_dmhp();
		//var_dump($data['row']);die;
		loadLayout('programmanager/cmha/dmhp/form_list', 'program_manager', $data);
    }
	
    public function dmhp_add_form(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('NMHP', base_url('dmhp/index'));
		
        $data['page_type'] = 'Health Service Delivery';	
		$data['states']    = $this->dmhp_model->get_state();
        loadLayout('programmanager/cmha/dmhp/form_add', 'program_manager', $data);
    }
	
    private function dmhp_validate(){          
        
        $this->form_validation->set_rules('e_year', 'Year', 'trim|required');
        $this->form_validation->set_rules('e_quarter', 'Quater', 'trim|required');
        $this->form_validation->set_rules('statename', 'State', 'trim|required');
        $this->form_validation->set_rules('num_district', 'Number of Districts Covered under DMHP', 'trim|required');
        $this->form_validation->set_rules('num_district_cover', 'Number of Districts Covered under DMHP', 'trim|required');
        $this->form_validation->set_rules('fund', 'Funds sanctioned under ROP', 'trim|required');
        $this->form_validation->set_rules('expenditure', 'Expenditure', 'trim|required');            
        
		
        if($this->form_validation->run() == TRUE){
            $requestdata  =   array(
                "e_year"           =>  $this->input->post('e_year'),
                "e_quarter"        =>  $this->input->post('e_quarter'),
                "statename"        =>  $this->input->post('statename'),        
                "num_district"     =>  $this->input->post('num_district'),        
                "num_district_cover"    =>  $this->input->post('num_district_cover'),               
                "fund"    			=>  $this->input->post('fund'),
                "expenditure"       =>  $this->input->post('expenditure')				
				
             ); 
            return $requestdata;
        }else{
            $this->form_validation->set_error_delimiters('', '');
            $message    = array("0",validation_errors());
            $this->session->set_flashdata('message', $message);
            return false;
        }
    }
	
    public function dmhp_InsertForm(){	
        $requestdata    =   $this->dmhp_validate();
		
        if(!empty($requestdata)){
            if($this->dmhp_model->insertdata("tbl_dmhp",$requestdata)){
                $message    = array("1","Successfully Submit");
            }else{
                $message    = array("0",$this->db->_error_message());
            }
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url("dmhp/dmhp_add_form"));
    }
	
   

    public function dmhp_edit(){
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('NMHP', base_url('dmhp/index'));
        $data['page_type'] = 'Health Service Delivery'; 
		$data['states']    = $this->dmhp_model->get_state();		
        $data['row']   		=   $this->dmhp_model->fetchwhere("tbl_dmhp",array("id"=>$this->input->get('id')),"","row_array");		        
		loadLayout('programmanager/cmha/dmhp/form_add', 'program_manager', $data);
    }
	
    public function dmhp_update(){
        $requestdata    =   $this->dmhp_validate();
        	if(!empty($requestdata)){
	
			 if($this->dmhp_model->updatedata("tbl_dmhp",$requestdata,array("id"=>$this->input->post('id')))){
			    $message    = array("1","Successfully Update");
		
            }else{
                $message    = array("0",$this->db->_error_message());
                $this->session->set_flashdata('message', $message);
            }		
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('dmhp/dmhp_edit').'?action=edit&id='.$this->input->post('id'));
    }
	
    public function dmhp_delete(){
        
		if($this->input->get('id')){
            $this->dmhp_model->deletedata("tbl_dmhp",array("id"=>$this->input->get('id')));
			 $message    = array("1","Successfully Deleted");
			  $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('dmhp/dmhp_view'),'location');
    }
    
  
    
    
    
	
	
}