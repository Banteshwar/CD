<?php

defined('BASEPATH') OR exit('No direct script access allowed');

//  require_once APPPATH . 'third_party/jcryption/sqAES.php';
//require_once APPPATH . 'third_party/jcryption/JCryption.php';


class EntryReport extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Hwc_model');
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
    }

     public function index() {
        global $db;
        global $OPERATION_STATUS_LIST_COLOR_CLASS;
        global $OPERATION_STATUS_LIST_ABBR;
        global $OPERATION_STATUS_LIST;
        global $CURRENT_USER_DISTRICT;
        global $CURRENT_USER_STATE;
        global $CURRENT_USER_ROLE;
        $user = $this->user;
        $state = 0;
        $district = 0;
        $healthBlock = 0;
        $taluka = 0;
        $proposed = 2;
        $queryWhere = array();
        $html_paging = '';
        if (isset($_POST['submit']) && $_POST['submit'] == 'PROPOSED') {
            $memberID = $_SESSION['memberID'];
            $checkeds = $this->input->post('facility_proposed');
            $population_coverage = $this->input->post('population_coverage');
            if ($checkeds != null OR $checkeds != '') {
                foreach ($checkeds as $key => $value) {
                    $data_insert = array(
                        'NIN_2_HFI' => $key,
                        'proposed_status' => $value,
                        'memberID' => $memberID,
                    );
                    $GetInsertedResponse = $this->Hwc_model->InsertUpdateProposed($data_insert);
                }
            }
            if (isset($population_coverage) && count($population_coverage) > 0) {

                $this->_updatePopulationCoverage($population_coverage);
            }
            status_message('Record Updated successfully');
        }


        if (isset($_REQUEST['submit'])) {
            extract($_REQUEST);
        }
        if (isHavingState($user)) {
            $state = $CURRENT_USER_STATE;
        }
        if (isHavingDistrict($user)) {
            $district = $CURRENT_USER_DISTRICT;
        }
        if (intval(trim($state)) != 0) {

            $queryWhere[] = "hf.State_ID= $state ";
        }
        if (intval(trim($district)) != 0) {

            $queryWhere[] = "hf.District_ID= $district ";
        }
        if (intval(trim($taluka)) != 0) {

            $queryWhere[] = " hf.Taluka_ID=$taluka ";
        }
        if (intval(trim($healthBlock)) != 0) {
            $queryWhere[] = " hf.HealthBlock_ID=$healthBlock ";
        }

        if (isset($proposed_status)) {

            if (count(array_intersect(array(0, 1, 2), $proposed_status)) == count($proposed_status)) {
                $queryWhere[] = "hwcp.proposed_status IN (" . implode(',', $proposed_status) . ")";
            } else {
                die("<h2>Attached Found!</h2>");
            }
        }

        $HWC_entry_status[] = 1;
        if (isset($HWC_entry_status)) {

            if (count(array_intersect(array(0, 1), $HWC_entry_status)) == count($HWC_entry_status)) {

                if (in_array('0', $HWC_entry_status)) {
                    $queryWhere[] = " ( hwc.status IN (" . implode(',', $HWC_entry_status) . ") OR hwc.status is NULL ) ";
                } else {
                    $queryWhere[] = "hwc.status IN (" . implode(',', $HWC_entry_status) . ") ";
                }
            } else {
                die("<h2>Attached Found!</h2>");
            }
        }

        if (isset($verify_status) && sizeof($verify_status) > 0) {
            if (count(array_intersect(array(1, 2), $verify_status)) == count($verify_status)) {
                $queryWhere[] = "hwc.verify_status IN (" . implode(',', $verify_status) . ")";
            }
        }/* else{
          // $queryWhere[] = "hwc.verify_status IN (0,1,2) ";
          } */
        // print_r($queryWhere);
        if (isset($HFI_Type) && sizeof($HFI_Type) > 0) {
            // showData($HFI_Type);
            if (count(array_intersect(array(1, 3, 99), $HFI_Type)) == count($HFI_Type)) {
                $queryWhere[] = "  hf.HFI_Type IN ( " . implode(',', $HFI_Type) . " )";
            }
        } else {
            $HFI_Type = array(1, 3, 99);
            $queryWhere[] = "  hf.HFI_Type IN ( " . implode(',', $HFI_Type) . " )";
        }

        if (!count($queryWhere) > 0) {
            $queryWhere[] = 1;
        }
        $filterArray['WHERE'] = $queryWhere;
        $result = $this->Hwc_model->getHWCFacilityList($filterArray);
        $result_list = $result['result'];
        $foundRows = $result['total'];
        $data['_REQUEST'] = $_REQUEST;
        $data['facility_list'] = $result_list;
        $data['user'] = $user;
        $data['html_paging'] = pagination($foundRows);
        // $data['Table_Views'] = $this->load->view('admin/HwcViews/Table_Views', NULL, TRUE);
        loadLayout('admin/Entry_Report', 'admin', $data);
    }

    /**
     * [hwc_verify hwc form]
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function hwc_verify($value = '') {
        $ninID = $this->uri->segment(3);
        $verifyStatus = $this->uri->segment(4);
        if (!empty($ninID) && !empty($verifyStatus)) {
            if ($verifyStatus == 1) {
                $verifyProposed = [
                    'verify_status' => $verifyStatus
                ];
                $verifyProposedResponse = $this->Hwc_model->verifyProposed($verifyProposed, $ninID);
                status_message('HWC Verified successfully.');
                redirect('hwc/hwc_view/' . $ninID);
            } else {
                error_message('Something wrong in verify Proposed');
                redirect('hwc/hwc_view/' . $ninID);
            }
        } else {
            error_message('Something wrong Please contact to admin.');
            redirect('hwc');
        }
    }

}
