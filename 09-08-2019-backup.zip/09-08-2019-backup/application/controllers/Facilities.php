

<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Facilities extends MY_Controller {
    private $user;
 
    public function __construct() {
        parent::__construct();
        global $db;
        $this->db = $db;
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
    }

    public function facilitylist() {
        $resultList = null;
        $html_paging = '';
        global $db;
        global $OPERATION_STATUS_LIST_COLOR_CLASS;
        global $OPERATION_STATUS_LIST_ABBR;
        global $OPERATION_STATUS_LIST;
        global $CURRENT_USER_DISTRICT;
        global $CURRENT_USER_STATE;
        $user = $this->user;

        // check permission
     //   if (isset($_REQUEST) && count($_REQUEST) > 0) {
        if (1) {
            //collect form data
            //extract($_REQUEST);
     
            if (isset($_REQUEST['submit'])) {
                $submit = $_REQUEST['submit'];
            }
            if (isset($_REQUEST['state'])) {
                $state = $_REQUEST['state'];
            }
            if (isHavingState($user)) {
                $state = $CURRENT_USER_STATE;
            }
            $district = 0;
            if (isset($_REQUEST['district'])) {
                $district = $_REQUEST['district'];
            }
            if (isHavingDistrict($user)) {
                $district = $CURRENT_USER_DISTRICT;
            }
            $taluka = 0;
            if (isset($_REQUEST['taluka'])) {
                $taluka = $_REQUEST['taluka'];
            }
            $healthBlock = 0;
            if (isset($_REQUEST['healthBlock'])) {
                $healthBlock = $_REQUEST['healthBlock'];
            }
            $operational_Status = array();
            if (isset($_REQUEST['operational_Status']) && is_array($_REQUEST['operational_Status'])) {
                foreach ($_REQUEST['operational_Status'] as $key) {
                    if (isValidOperationStatus($key)) {
                        $operational_Status[] = $key;
                    }
                }
            }

            if (isset($_REQUEST['date_range'])) {
                $date_range_array = explode("-", $_REQUEST['date_range']);
                if (count($date_range_array) > 1) {
                    $_REQUEST['date_from'] = date("Y-m-d", strtotime($date_range_array[0]));
                    $_REQUEST['date_to'] = date("Y-m-d", strtotime($date_range_array[1]));
                }
            }


            if (isset($_REQUEST['date_from'])) {
                if (preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/", $_REQUEST['date_from'])) {
                    $date_from = $_REQUEST['date_from'];
                }
            }

            if (isset($_REQUEST['date_to'])) {
                if (preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/", $_REQUEST['date_to'])) {
                    $date_to = $_REQUEST['date_to'];
                }
            }

            if (isset($_REQUEST['confirmed_flag'])) {
                if ($_REQUEST['confirmed_flag'] == 1) {
                    $confirmed_flag = 1;
                }
                if ($_REQUEST['confirmed_flag'] == 0) {
                    $confirmed_flag = 0;
                }
            }

            if (isset($_REQUEST['verified_flag'])) {
                if ($_REQUEST['verified_flag'] == 1) {
                    $verified_flag = 1;
                }
                if ($_REQUEST['verified_flag'] == 0) {
                    $verified_flag = 0;
                }
            }

            if (isset($_REQUEST['it_infrastructure'])) {
                if ($_REQUEST['it_infrastructure'] == 1) {
                    $it_infrastructure = 1;
                }
                if ($_REQUEST['it_infrastructure'] == 0) {
                    $it_infrastructure = 0;
                }
            }

            if (isset($_REQUEST['ninCodeSearch'])) {
                $ninCodeSearch = $_REQUEST['ninCodeSearch'];
            }
            if (isset($_REQUEST['check_nin_validity'])) {
                $check_nin_validity = $_REQUEST['check_nin_validity'];
            }

            if (isset($state) && isset($district)) {

                $errorList = array();
                $queryParameters = array();
                $queryWhere = array();

                //searching facility by Location

           
                if (isset($submit)) {
                    // check state
         
                    if (trim($state) == '0') {
                        $errorList[] = 'Please select state';
                    } else {
                        //only for special case
                        if (isset($_REQUEST['all_state']) && $_REQUEST['all_state'] == 'ALL') {
                            // $queryParameters[':State_ID'] = intVal($state);
                            // $queryWhere[] = ' hf.State_ID=:State_ID ';
                            $queryWhere[] = 1;
                        } else {
                            $queryParameters[':State_ID'] = intVal($state);
                            $queryWhere[] = ' hf.State_ID=:State_ID ';
                        }
                    }

                    // check district

                    if (trim($district) != '0') {
                        $queryParameters[':District_ID'] = intVal($district);
                        $queryWhere[] = ' hf.District_ID=:District_ID ';
                    }

                    // check Taluka
                    if (trim($taluka) != '0') {
                        $queryParameters[':Taluka_ID'] = $taluka;
                        $queryWhere[] = " hf.Taluka_ID=:Taluka_ID ";
                    }

                    // check Healthblock
                    if (trim($healthBlock) != '0') {
                        $queryParameters[':HealthBlock_ID'] = $healthBlock;
                        $queryWhere[] = " hf.HealthBlock_ID=:HealthBlock_ID ";
                    }
                    if (sizeof($operational_Status) > 0) {
                        $queryWhere[] = "  hf.operational_Status IN ( " . implode(',', $operational_Status) . " )";
                    }

                    if (isset($date_from)) {
                        $queryWhere[] = "  hf.Created_On > '" . $date_from . "' ";
                    }

                    if (isset($date_to)) {
                        $queryWhere[] = "  hf.Created_On < '" . $date_to . "' ";
                    }


                    if (isset($confirmed_flag)) {
                        if ($confirmed_flag == 1) {
                            $queryWhere[] = " hf.confirmed_flag = 1 ";
                        } else {
                            $queryWhere[] = " (hf.confirmed_flag != 1 OR hf.confirmed_flag is NULL) ";
                        }
                    }

                    if (isset($verified_flag)) {
                        if ($verified_flag == 1) {
                            $queryWhere[] = " hf.verified_flag = 1 ";
                        } else {
                            $queryWhere[] = " (hf.verified_flag != 1 OR hf.verified_flag is NULL)  ";
                        }
                    }

                    if (isset($it_infrastructure)) {
                        if ($it_infrastructure == 1) {
                            $queryWhere[] = " it.it_infrastructure is not NULL  ";
                        } else {
                            $queryWhere[] = "  it.it_infrastructure is NULL  ";
                        }
                    }
                } else if (isset($ninCodeSearch)) {


                    if (trim($ninCodeSearch) != '') {
                        $queryWhere[] = ' hf.NIN_2_HFI=:NINCode ';
                        $queryParameters[':NINCode'] = $ninCodeSearch;
                        $query = 'select * from ' . TB_HMIS_HEALTH_FACILITIES . ' where NIN_2_HFI=:NINCode limit 1';

                        $stmt = $db->prepare($query);
                        $stmt->execute($queryParameters);
                        while ($row = $stmt->fetch()) {
                            $foundbyNIN = true;
                        }
                        if (!isset($foundbyNIN)) {
                            $errorList[] = 'NIN code does not match to any Facility.';
                        }
                    } else {
                        $errorList[] = 'Please enter NIN Code.';
                    }
                } else {
                    if (trim($state) != '0') {
                        $queryParameters[':State_ID'] = intVal($state);
                        $queryWhere[] = ' hf.State_ID=:State_ID ';
                    }
                    // check district

                    if (trim($district) != '0') {
                        $queryParameters[':District_ID'] = intVal($district);
                        $queryWhere[] = ' hf.District_ID=:District_ID ';
                    }
                    //  $errorList[] = 'Unexpected Error.';
                }
                if (count($errorList) > 0) {
                    error_message(error_format($errorList));
                }
                if (count($errorList) == 0) {

                    $query = " select
                          SQL_CALC_FOUND_ROWS
                          hf.NIN_2_HFI,
                          hf.HFI_Name,
                          hf.State_ID,
                          hf.District_ID,
                          hf.HFI_Type,
                          hf.confirmed_flag,
                          hf.verified_flag,
                          hf.house_number,
                          hf.street,
                          hf.landmark,
                          hf.locality,
                          hf.pincode,
                          hf.landline_number,
                          hf.in_charge_mobile,
                          hf.email,
                          hf.latitude,
                          hf.longitude,
                          hf.altitude,
                          hf.region_indicator,
                          hf.operational_Status,
                          hf.ownership_authority,
                          hf.Created_On,
                          pcm.PHC_CHC_Type,
                          s.State_Name,
                          d.District_Name,
                          t.Taluka_Name,
                          b.Block_Name,
                          m.memberID,
                          m.username,
                          it.it_infrastructure,
                          it.desktop_nos,
                          it.laptop_nos,
                          it.tablets_nos,
                          it.smartphone_nos,
                          it.internet_connection,
                          it.LAN,
                          it.Leased_line,
                          it.NKN,
                          it.Broad_Band,
                          it.VPN,
                          it.Dial_Up,
                          it.wifi_modem,
                          it.wiMax_usb_modem,
                          it.wiMax_enabled_mobile,
                          it.availability_smartphone_ASHA
                          from " . TB_HMIS_HEALTH_FACILITIES . " hf
                          Left join " . TB_PHC_CSC_MSTER . " pcm on hf.HFI_Type=pcm.PHC_CHC_ID
                          Left join " . TB_M_STATES . " s on hf.State_ID=s.State_ID
                          Left join " . TB_M_DISTRICTS . " d on hf.District_ID=d.District_ID
                          Left join " . TB_M_TALUKA . " t on hf.Taluka_ID=t.Taluka_ID
                          Left join " . TB_M_HEALTHBLOCKS . " b on hf.HealthBlock_ID=b.Block_ID
                          Left join " . TB_T_MEMBERS . " m on hf.added_by_user=m.memberID
                          left join " . TB_T_IT_INFRASTRUCTURE . " it on hf.NIN_2_HFI = it.NIN_2_HFI
                          where " . implode(' AND ', $queryWhere) . '  Order by s.State_Name, d.District_Name, b.Block_Name, hf.HFI_Name  ';
                   
                    // where ". implode(' AND ',$queryWhere). '  Order by hf.verified_flag DESC, hf.confirmed_flag DESC  ';
                    if (isset($_REQUEST['csv'])) {
                        $stmt = $db->prepare($query);
                        $stmt->execute($queryParameters);
                        header("Content-type: text/x-csv");
                        header("Content-Disposition: attachment; filename=facilities_" . date('Y-m-d-h-i-s') . ".csv");
                        echo ob_get_clean();
                        flush();
                        echo '"Facility Name","NIN to HFI","State","District","Taluka","Block","Facility Type","Confirmed","Verified",';
                        echo '"Latitude","longitude","Altitude",';
                        echo '"House Number","Street","Landmark","Locality","Pincode","Landline","In-charge Mobile","Email",';
                        echo '"Region Indicator","Operational Status","Ownership Authority",';
                        echo '"Added By User","Added Time",';
                        echo '"it_infrastructure","desktop_nos","laptop_nos","tablets_nos","smartphone_nos","internet_connection",';
                        echo '"LAN","Leased_line","NKN","Broad_Band","VPN","Dial_Up","wifi_modem","wiMax_usb_modem",';
                        echo '"wiMax_enabled_mobile","availability_smartphone_ASHA"' . PHP_EOL;

                        while ($row = $stmt->fetch()) {
                           ob_start();
                            flush();
                            $latitude = $row['latitude'] == 0 ? '' : $row['latitude'];
                            $longitude = $row['longitude'] == 0 ? '' : $row['longitude'];
                            $altitude = $row['altitude'] == 0 ? '' : $row['altitude'];
                            echo '"' . addslashes($row['HFI_Name']) . '",';
                            echo '"' . addslashes($row['NIN_2_HFI']) . '",';
                            echo '"' . addslashes($row['State_Name']) . '",';
                            echo '"' . addslashes($row['District_Name']) . '",';
                            echo '"' . addslashes($row['Taluka_Name']) . '",';
                            echo '"' . addslashes($row['Block_Name']) . '",';
                            echo '"' . addslashes($row['PHC_CHC_Type']) . '",';
                            echo '"' . addslashes($row['confirmed_flag']) . '",';
                            echo '"' . addslashes($row['verified_flag']) . '",';
                            echo '"' . addslashes($latitude) . '",';
                            echo '"' . addslashes($longitude) . '",';
                            echo '"' . addslashes($altitude) . '",';
                            echo '"' . addslashes($row['house_number']) . '",';
                            echo '"' . addslashes($row['street']) . '",';
                            echo '"' . addslashes($row['landmark']) . '",';
                            echo '"' . addslashes($row['locality']) . '",';
                            echo '"' . addslashes($row['pincode']) . '",';
                            echo '"' . addslashes($row['landline_number']) . '",';
                            echo '"' . addslashes($row['in_charge_mobile']) . '",';
                            echo '"' . addslashes($row['email']) . '",';
                            echo '"' . getRegionIndicatorName($row['region_indicator']) . '",';
                            echo '"' . getOperationStatusName($row['operational_Status']) . '",';
                            echo '"' . getOwnershipAuthorityName($row['ownership_authority']) . '",';
                            if ($row['memberID'] != '') {
                                echo '"' . addslashes($row['username']) . '",';
                                echo '"' . $row['Created_On'] . '",';
                            } else {
                                echo '"","",';
                            }

                            $it_infrastructure_text = '';
                            if ($row['it_infrastructure'] == 1) {
                                $it_infrastructure_text = 'YES';
                            } else if ($row['it_infrastructure'] != '') {
                                $it_infrastructure_text = 'NO';
                            }


                            echo '"' . $it_infrastructure_text . '",';
                            echo '"' . addslashes($row['desktop_nos']) . '",';
                            echo '"' . addslashes($row['laptop_nos']) . '",';
                            echo '"' . addslashes($row['tablets_nos']) . '",';
                            echo '"' . addslashes($row['smartphone_nos']) . '",';
                            $internet_connection_text = '';
                            if ($row['internet_connection'] == 1) {
                                $internet_connection_text = 'YES';
                            } else if ($row['internet_connection'] != '') {
                                $internet_connection_text = 'NO';
                            }
                            echo '"' . $internet_connection_text . '",';
                            echo '"' . addslashes($row['LAN']) . '",';
                            echo '"' . addslashes($row['Leased_line']) . '",';
                            echo '"' . addslashes($row['NKN']) . '",';
                            echo '"' . addslashes($row['Broad_Band']) . '",';
                            echo '"' . addslashes($row['VPN']) . '",';
                            echo '"' . addslashes($row['Dial_Up']) . '",';
                            echo '"' . addslashes($row['wifi_modem']) . '",';
                            echo '"' . addslashes($row['wiMax_usb_modem']) . '",';
                            echo '"' . addslashes($row['wiMax_enabled_mobile']) . '",';
                            $availability_smartphone_ASHA_text = '';
                            if ($row['availability_smartphone_ASHA'] == 1) {
                                $availability_smartphone_ASHA_text = 'YES';
                            } else if ($row['availability_smartphone_ASHA'] != '') {
                                $availability_smartphone_ASHA_text = 'NO';
                            }
                            echo '"' . $availability_smartphone_ASHA_text . '"';
                            echo PHP_EOL;
                        }
                        exit;
                    }
                    $query .= limit();
                    
                    $stmt = $db->prepare($query);
                    $stmt->execute($queryParameters);

                    $resultList = '<table id="facilities-data" class="table table-striped table-bordered nowrap dt-responsive"><thead>'
                            . '<tr>'
                            . '<th>SrNo.</th>'
                            . '<th>Facility Name</th>'
                            . '<th>NIN to HFI</th>'
                            . '<th>State</th>'
                            . '<th>District</th>'
                            . '<th>Taluka</th>'
                            . '<th>Block</th>'
                            . '<th>Facility Type</th>'
                            . '<th>Status</th>'
                            . '<th><abbr title="Operational Status">OP Status</abbr></th>'
                            . '<th>Created On</th>'
                            . '<th>View</th>';
                    if ($user->hasPermission('EDIT_HEALTH_FACILITY')) {
                        $resultList .= '<th>Edit</th>';
                    }
                    if ($user->hasPermission('VIEW_IT_INFRASTRUCTURE')) {
                        $resultList .= '<th>IT Status</th>';
                        $resultList .= '<th>IT View</th>';
                    }
                    $resultList .= '</tr></thead><tbody>';

                    $foundRows = $db->query('SELECT FOUND_ROWS()')->fetchColumn();
                    
                    $html_paging = pagination($foundRows);
                    $i = serial_number_start();
                    $row_data = $stmt->fetchAll();

                    foreach ($row_data as $row) {
                        $i++;
                        $resultList .= '<tr>';
                        $resultList .= '<td>' . $i . '</td>';
                        $resultList .= '<td>' . $row['HFI_Name'] . '</td>';
                        $resultList .= '<td>' . $row['NIN_2_HFI'] . '</td>';
                        $resultList .= '<td>' . $row['State_Name'] . '</td>';
                        $resultList .= '<td>' . $row['District_Name'] . '</td>';
                        $resultList .= '<td>' . $row['Taluka_Name'] . '</td>';
                        $resultList .= '<td>' . $row['Block_Name'] . '</td>';
                        $resultList .= '<td>' . $row['PHC_CHC_Type'] . '</td>';
                        $status_value = '';
                        if ($row['confirmed_flag'] == 1) {
                            $status_value .= '<span class="label1 bg-blue btn-block">Confirmed</span>';
                        } else {
                            $status_value .= '<span class="label1 bg-navy btn-block">Not Confirmed</span>';
                        }
                        $status_value .= '  ';
                        if ($row['verified_flag'] == 1) {
                            $status_value .= '<span class="label1 bg-green btn-block">Verified</span>';
                        } else {
                            $status_value .= '<span class="label1 bg-red btn-block">Not Verified</span>';
                        }

                        $resultList .= '<td>' . $status_value . '</td>';
                        $resultList .= '<td class="' . $OPERATION_STATUS_LIST_COLOR_CLASS[$row['operational_Status']] . '">';
                        if ($OPERATION_STATUS_LIST_ABBR[$row['operational_Status']] != '') {
                            $resultList .= '<abbr title="' . $OPERATION_STATUS_LIST[$row['operational_Status']] . '">' .
                                    $OPERATION_STATUS_LIST_ABBR[$row['operational_Status']] . '</abbr>';
                        } else {
                            $resultList .= $OPERATION_STATUS_LIST[$row['operational_Status']];
                        }
                        $resultList .= '</td>';


                        $resultList .= '<td>' . $row['Created_On'] . '</td>';
                        $resultList .= '<td><a class="label1 label-mr bg-blue get_modal_data_click" data-toggle="tooltip" data-TITLE=" Health Facility Details"  data-URL=' . base_url('facilities/getfacilityview') . '?nin=' . $row['NIN_2_HFI'] . '&' . currentPageURLAdd() . '"  data-target="#getModal"  data-original-title="Full Detail"><i class="fa  fa-eye"></i> View</a></td>';
                        //   $resultList .= '<td><a href="facility_view.php?nin=' . $row['NIN_2_HFI'] . '&' . currentPageURLAdd() . '">Full Detail</a></td>';

                        if ($user->hasPermission('EDIT_HEALTH_FACILITY')) {
                            $resultList .= '<td><a class="label1 label-mr bg-blue get_modal_data_click" data-toggle="tooltip" data-TITLE="Edit Health Facility" data-URL="' . base_url('facilities/getFacilityEdit') . '?nin=' . $row['NIN_2_HFI'] . '&' . currentPageURLAdd() . '"  data-DATA="" data-target="#getModal"  data-original-title="Edit Health Facility"><i class="fa fa-edit"></i>Edit </a></td>';

                            //$resultList .= '<td><a href="facility_edit.php?nin=' . $row['NIN_2_HFI'] . '&' . currentPageURLAdd() . '">Edit</a></td>';
                        }
                        if ($user->hasPermission('VIEW_IT_INFRASTRUCTURE')) {

                            if ($row['it_infrastructure'] != '') {
                                $resultList .= '<td><span class="label1 bg-green btn-block">Filled</span></td>';
                            } else {
                                $resultList .= '<td><span class="label1 bg-red btn-block">Not Filled</span></td>';
                            }

                            //<a class="label label-mr bg-blue get_modal_data_click" data-toggle="tooltip" data-TITLE="View Health Facility" data-URL="page/m_facility_view.php?nin=' . $row['NIN_2_HFI'] . '&' . currentPageURLAdd() . '"  data-DATA="" data-target="#getModal"  data-original-title="Full Detail">


                            $resultList .= '<td><a class="label1 label-mr bg-blue get_modal_data_click" data-toggle="tooltip" data-TITLE=" IT Infrastructure" data-URL="' . base_url('facilities/getInfrastructureView') . '?nin=' . $row['NIN_2_HFI'] . '&' . currentPageURLAdd() . '"  data-DATA="" data-target="#getModal"  data-original-title="IT Infrastructure"><i class="fa fa-plus-square"></i>&nbsp;IT Infrastructure</a></td>';


                            // $resultList .= '<td><a href="it_infrastructure_view.php?nin=' . $row['NIN_2_HFI'] . '&' . currentPageURLAdd() . '">IT Infrastructure</a></td>';
                        }
                        $resultList .= '</tr>';
                    }
                    if ($i == 0) {
                        $resultList .= '<tr><td colspan="8" style="text-align:left;padding:20px;color:#990000">No Record Found!</td></tr>';
                    }
                    $resultList .= '</table>';
                }
            }
        }



//Send data For view 
        $data['facility_table'] = $resultList;
        $data['user'] = $user;
        $data['html_paging'] = $html_paging;
        $data['REQUEST'] = $_REQUEST;
        loadLayout('admin/facilitylist', 'admin', $data);
    }

    public function facilityView() {

        global $db;
        global $OPERATION_STATUS_LIST_COLOR_CLASS;
        global $OPERATION_STATUS_LIST_ABBR;
        global $OPERATION_STATUS_LIST;
        global $CURRENT_USER_DISTRICT;
        global $CURRENT_USER_STATE;
        $user = $this->user;
        $data = null;
        $errorNINMsg = "<H1>Invalid NIN Number";

// check permission
        if (!$user->hasPermission('VIEW_HEALTH_FACILITY')) {
            echo '<h1>Sorry, you are not allowed to access permission this page.</h1>';
            exit;
        }

        if (isset($_REQUEST['nin'])) {
            $nin = $_REQUEST['nin'];
            $rowFacility = getRowByNIN($nin);


            if (!$rowFacility) {
                echo $errorNINMsg;
                exit;
            }
        } else {
            echo $errorNINMsg;
            exit;
        }

        $data['rowFacility'] = $rowFacility;
        $data['user'] = $user;
        loadLayout('admin/facility_view', 'admin', $data);
    }

    function getFacilityView() {

		global $db;
        global $OPERATION_STATUS_LIST_COLOR_CLASS;
        global $OPERATION_STATUS_LIST_ABBR;
        global $OPERATION_STATUS_LIST;
        global $CURRENT_USER_DISTRICT;
        global $CURRENT_USER_STATE;
        $user = $this->user;
        $data = null;
//if not logged in redirect to login page
        if (!$user->is_logged_in()) {
        echo 'Please login again';
            exit;
        }
// check permission
        if (!$user->hasPermission('VIEW_HEALTH_FACILITY')) {
            echo '<h1>Sorry, you are not allowed to access permission this page.</h1>';
            exit;
        }
        if (!isset($_POST)) {
            echo '<h1>Sorry, you are not allowed to access this page.</h1>';
            exit;
        }

        $errorNINMsg = "<H1>Invalid NIN Number";


        if (isset($_REQUEST['nin'])) {
            $nin = $_REQUEST['nin'];
            $rowFacility = getRowByNIN($nin);

           
            if (!$rowFacility) {
                echo $errorNINMsg;
                exit;
            }
        } else {
            echo $errorNINMsg;
            exit;
        }



        $error = array();


        if (isHavingState($user)) {
            if ($rowFacility['State_ID'] != $CURRENT_USER_STATE) {
                echo '<h2>You do not have permission to View/update facility of State '
                . getStatesName($rowFacility['State_ID']) . '</h1>';
                exit;
            }
        }


        if (isHavingDistrict($user)) {
            if ($rowFacility['District_ID'] != $CURRENT_USER_DISTRICT) {
                echo '<h2>You do not have permission to View/update facility of District '
                . getDistrictName($rowFacility['State_ID'], $rowFacility['District_ID']) . '</h1>';
                exit;
            }
        }
  
        /*



          if (isset($_REQUEST['action'])) {
          switch ($_REQUEST['action']) {
          case 'confirmNin':
          if ($user->hasPermission('NIN_MAKE_CONFIRM') && $rowFacility['confirmed_flag'] != 1 && $rowFacility['verified_flag'] != 1) {
          $updateField = ' confirmed_flag = 1 , confirmed_by_user = ' . $_SESSION['memberID'] . ', confirmed_on = NOW() ';
          }
          break;
          case 'unConfirmNin':
          if ($user->hasPermission('NIN_MAKE_NOT_CONFIRM') && $rowFacility['confirmed_flag'] == 1 && $rowFacility['verified_flag'] != 1) {
          $updateField = ' confirmed_flag = 0, confirmed_by_user = ' . $_SESSION['memberID'] . ', confirmed_on = NOW() ';
          }
          break;
          case 'verifyNin':
          if ($user->hasPermission('NIN_MAKE_VERIFY') && $rowFacility['verified_flag'] != 1 && $rowFacility['confirmed_flag'] == 1) {
          $updateField = ' verified_flag = 1 , verified_by_user = ' . $_SESSION['memberID'] . ', verified_on = NOW()';
          }
          break;
          }
          }

          if (isset($updateField)) {
          $query = " update " . TB_HMIS_HEALTH_FACILITIES . "
          set " . $updateField . "
          where  NIN_2_HFI  =  " . $nin . "
          limit 1";
          $stmt = $db->prepare($query);
          $stmt->execute();
          status_message('Record Updated Successfully!');
          echo 'location:facility_view.php?nin=' . $nin . '&' . previousParam();

          header('location:facility_view.php?nin=' . $nin . '&' . previousParam());
          }

         */

        $data['rowFacility'] = $rowFacility;
        $data['user'] = $user;
        $data['nin'] = $nin;

        loadLayout('admin/facility/facility_view', 'popup', $data);
    }
    function getFacilityEdit() {
        global $db;
        global $OPERATION_STATUS_LIST_COLOR_CLASS;
        global $OPERATION_STATUS_LIST_ABBR;
        global $OPERATION_STATUS_LIST;
        global $CURRENT_USER_DISTRICT;
        global $CURRENT_USER_STATE;
        $user = $this->user;
        $data = null;


        if (!$user->hasPermission('EDIT_HEALTH_FACILITY')) {
            include_once('../includes/json_permission_denied.php');
            exit;
        }
        $errorNINMsg = "<H1>Invalid NIN Number";
        if (isset($_REQUEST['nin'])) {
            $nin = $_REQUEST['nin'];
            $rowFacility = getRowByNIN($nin);
            if (!$rowFacility) {
                echo $errorNINMsg;
                exit;
            }
        } else {
            echo $errorNINMsg;
            exit;
        }


        $error = array();
        if (isHavingState($user)) {
            if ($rowFacility['State_ID'] != $CURRENT_USER_STATE) {
                echo '<h2>You do not have permission to View/update facility of State '
                . getStatesName($rowFacility['State_ID']) . '</h1>';
                exit;
            }
        }
        if (isHavingDistrict($user)) {
            if ($rowFacility['District_ID'] != $CURRENT_USER_DISTRICT) {
                echo '<h2>You do not have permission to View/update facility of District '
                . getDistrictName($rowFacility['State_ID'], $rowFacility['District_ID']) . '</h1>';
                exit;
            }
        }
//if form has been submitted process it
        if (isset($_POST['EncToken'])) {



            if (!checkCSRF()) {
                $error[] = CSRF_ERROR;
            }

            //collect form data
            //extract($_POST);
            //very basic validation
            if (isset($_POST['facility_name'])) {
                $facility_name = trim(filter_var($_POST['facility_name'], FILTER_SANITIZE_STRING));
                if ($facility_name == '') {
                    $error['facility_name'] = 'Please enter the Facility Name.';
                }
                if (strlen($facility_name) > 200) {
                    $error['facility_name'] = 'Facility Name exceeds max characters limit 200.';
                }
            } else {
                // filter_var($city, FILTER_SANITIZE_STRING)
                $error['facility_name'] = 'Please enter the Facility Name.';
            }

            if (isset($_POST['facility_type']) && $_POST['facility_type'] != '0') {
                $facility_type = intval($_POST['facility_type']);
                if (!isValidFacilityType($facility_type)) {
                    $error['facility_type'] = 'Invalid selected Facility Type.';
                }
            } else {
                $error['facility_type'] = 'Please select Facility Type.';
            }

            // State and District User can not update State
            if (isHavingState($user)) {
                $_POST['state'] = $CURRENT_USER_STATE;
            }
            // check if State and District of User
            if (isset($_POST['state']) && $_POST['state'] != '0') {
                $state = intVal($_POST['state']);
                if (!isValidStateId($state)) {
                    $error['state'] = 'Invalid selected State.';
                }
            } else {
                $error['state'] = 'Please select State.';
            }

            if (isHavingDistrict($user)) {
                $_POST['district'] = $CURRENT_USER_DISTRICT;
            }

            if (isset($state) && isset($_POST['district']) && $_POST['district'] != '0') {
                $district = intval($_POST['district']);
                if (!isValidDistrictId($state, $district)) {
                    $error['district'] = 'Invalid selected District.';
                }
            }
            /* else {
              $error['district'] = 'Please select District.';
              } */

            //verify if Taluka is selected
            $taluka = 0;
            if (isset($state) && isset($district) && isset($_POST['taluka']) && $_POST['taluka'] != '0') {
                $taluka = intval($_POST['taluka']);
                if (!isValidTalukaId($state, $district, $taluka)) {
                    $error['taluka'] = 'Invalid selected District.';
                }
            }

            //verify if Health Block is selected
            $healthBlock = 0;
            if (isset($state) && isset($district) && isset($_POST['healthBlock']) && $_POST['healthBlock'] != '0') {
                if (!isset($taluka)) {
                    $taluka = 0;
                }
                $healthBlock = intval($_POST['healthBlock']);
                if (!isValidHealthBlockId($state, $district, $taluka, $healthBlock)) {
                    $error['healthBlock'] = 'Invalid selected Health Block.';
                }
            }

            $pincode = '';
            if (isset($_POST['pincode']) && trim($_POST['pincode']) != '') {
                $pincode = trim($_POST['pincode']);
                if (!preg_match('/^[1-9]{1}[0-9]{5}$/', $pincode)) {
                    $error['pincode'] = 'Pincode seems invalid.';
                }
            }


            $house_number = '';
            if (isset($_POST['house_number']) && trim($_POST['house_number']) != '') {
                $house_number = trim(filter_var($_POST['house_number'], FILTER_SANITIZE_STRING));
                if ($house_number == '') {
                    $error['house_number'] = 'Please enter the House Number.';
                }
                if (strlen($house_number) > 100) {
                    $error['house_number'] = 'House Number exceeds max characters limit 100.';
                }
            }
            /* else {
              $error['house_number'] = 'Please enter the House Number.';
              } */
            $street = '';
            if (isset($_POST['street']) && trim($_POST['street']) != '') {
                $street = trim(filter_var($_POST['street'], FILTER_SANITIZE_STRING));
                if ($street == '') {
                    $error['street'] = 'Please enter street.';
                }
                if (strlen($street) > 100) {
                    $error['street'] = 'Street exceeds max characters limit 100.';
                }
            } /* else {
              $error['street'] = 'Please enter street.';
              } */

            $landmark = '';
            if (isset($_POST['landmark']) && trim($_POST['landmark']) != '') {
                $landmark = trim(filter_var($_POST['landmark'], FILTER_SANITIZE_STRING));
                if (strlen($landmark) > 100) {
                    $error['landmark'] = 'Landmark max characters limit 100.';
                }
            }

            $locality = '';
            if (isset($_POST['locality']) && trim($_POST['locality']) != '') {
                $locality = trim(filter_var($_POST['locality'], FILTER_SANITIZE_STRING));
                if (strlen($locality) > 100) {
                    $error['locality'] = 'Locality max characters limit 100.';
                }
            }

            $landline_number = '';
            if (isset($_POST['landline_number']) && trim($_POST['landline_number']) != '') {
                $landline_number = trim(filter_var($_POST['landline_number'], FILTER_SANITIZE_STRING));
                if (strlen($landline_number) > 50) {
                    $error['landline_number'] = 'Locality max characters limit 50.';
                }
            }


            $in_charge_mobile = '';
            if (isset($_POST['in_charge_mobile']) && trim($_POST['in_charge_mobile']) != '') {
                $in_charge_mobile = trim($_POST['in_charge_mobile']);
                if (!preg_match('/^[1-9][0-9]{9}$/', $in_charge_mobile)) {
                    $error['in_charge_mobile'] = 'In Charge Mobile seems invalid. It should be 10 digit number';
                }
            }

            $email = '';
            if (isset($_POST['email']) && trim($_POST['email']) != '') {
                $email = trim($_POST['email']);
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $error['email'] = 'Email seems invalid.';
                }
                if (strlen($email) > 60) {
                    $error['email'] = 'Email max characters limit 60.';
                }
            }/* else {
              $error['email'] = 'Please enter email.';
              } */

            $latitude = 0;
            if (isset($_POST['latitude']) && trim($_POST['latitude']) != '' && trim($_POST['latitude']) != 0) {
                $latitude = trim($_POST['latitude']);
                if (!isValidLatitude($latitude)) {
                    $error['latitude'] = 'Latitude seems incorrect value.';
                }
            }

            $longitude = 0;
            if (isset($_POST['longitude']) && trim($_POST['longitude']) != '' && trim($_POST['longitude']) != 0) {
                $longitude = trim($_POST['longitude']);
                if (!isValidLongitude($longitude)) {
                    $error['longitude'] = 'Longitude seems incorrect value.';
                }
            }

            if ($latitude != 0 && $longitude == 0) {
                if (!isset($error['longitude'])) {
                    $error['longitude'] = 'Longitude should have a value.';
                }
            }

            if ($latitude == 0 && $longitude != 0) {
                if (!isset($error['latitude'])) {
                    $error['latitude'] = 'Latitude should have a value.';
                }
            }

            $altitude = 0;
            if (isset($_POST['altitude']) && trim($_POST['altitude'] != '')) {
                $altitude = trim($_POST['altitude']);
                if (!isValidAltitude($altitude)) {
                    $error['altitude'] = 'Altitude seems incorrect value. Should be in meters and not more than 4 dicimal places';
                }
            }



            // check region_indicator
            $region_indicator = 0;
            if (isset($_POST['region_indicator']) && trim($_POST['region_indicator']) != '0') {
                $region_indicator = intVal($_POST['region_indicator']);
                if (!isValidRegionIndicator($region_indicator)) {
                    $error['region_indicator'] = 'Invalid selected Region Indicator.';
                }
            }
            /* else {
              $error['region_indicator'] = 'Please select Region Indicator.';
              } */

            // check if State and District of User
            $operational_Status = 0;
            if (isset($_POST['operational_Status']) && trim($_POST['operational_Status']) != '0') {
                $operational_Status = intVal($_POST['operational_Status']);
                if (!isValidOperationStatus($operational_Status)) {
                    $error['operational_Status'] = 'Invalid selected Operational Status.';
                }
            }
            /* else {
              $error['operational_Status'] = 'Please select Operational Status.';
              } */

            // check if State and District of User
            $ownership_authority = 0;
            if (isset($_POST['ownership_authority']) && trim($_POST['ownership_authority']) != '0') {
                $ownership_authority = intVal($_POST['ownership_authority']);
                if (!isValidOwnershipAuthority($ownership_authority)) {
                    $error['ownership_authority'] = 'Invalid selected Ownership Authority.';
                }
            }
            /* else {
              $error['ownership_authority'] = 'Please select Ownership Authority.';
              } */

            if (isset($error) && count($error) == 0) {

                try {
                    $NIN_Code = $nin;
                    $query = 'UPDATE ' . TB_HMIS_HEALTH_FACILITIES . '  set
                                      HFI_Name = :HFI_Name,
                                      HFI_Type = :HFI_Type,
                                      State_ID = :State_ID,
                                      District_ID = :District_ID,
                                      Taluka_ID = :Taluka_ID,
                                      HealthBlock_ID = :HealthBlock_ID,
                                      pincode = :pincode,
                                      house_number = :house_number,
                                      street = :street,
                                      landmark = :landmark,
                                      locality = :locality,
                                      landline_number = :landline_number,
                                      in_charge_mobile = :in_charge_mobile,
                                      email = :email,
                                      latitude = :latitude,
                                      longitude = :longitude,
                                      altitude = :altitude,
                                      region_indicator = :region_indicator,
                                      operational_Status = :operational_Status,
                                      ownership_authority = :ownership_authority,
                                      updated_by_user = :updated_by_user,
                                      updated_on =  NOW()
                                      WHERE  NIN_2_HFI  = ' . $NIN_Code;
                    $stmt2 = $db->prepare($query);
                    $parameters = array(
                        ':HFI_Name' => $facility_name,
                        ':HFI_Type' => $facility_type,
                        ':State_ID' => $state,
                        ':District_ID' => $district,
                        ':Taluka_ID' => $taluka,
                        ':HealthBlock_ID' => $healthBlock,
                        ':pincode' => $pincode,
                        ':house_number' => $house_number,
                        ':street' => $street,
                        ':landmark' => $landmark,
                        ':locality' => $locality,
                        ':landline_number' => $landline_number,
                        ':in_charge_mobile' => $in_charge_mobile,
                        ':email' => $email,
                        ':latitude' => $latitude,
                        ':longitude' => $longitude,
                        ':altitude' => $altitude,
                        ':region_indicator' => $region_indicator,
                        ':operational_Status' => $operational_Status,
                        ':ownership_authority' => $ownership_authority,
                        ':updated_by_user' => $_SESSION['memberID']
                    );
                    // print_r($parameters);

                    $success = $stmt2->execute($parameters);
                    status_message('Facility Updated Successfully');
                    $responseArray = array('status' => 'success', 'status_msg' => 'Facility Updated Successfully', 'return_url' => base_url('facilities/facilityview') . '?nin=' . $NIN_Code);

                    // $responseArray = array('status' => 'success', 'status_msg' => 'Facility Updated Successfully', 'return_url' => getUrl());
                    // header('location:facility_view.php?nin=' . $NIN_Code);
                } catch (PDOException $e) {
                    echo $e->getMessage();
                    exit;
                }
            } else {
                //display_message();
//$responseArray = array('status' => 'success', 'status_msg' => 'Form save Successfully ' . $array);
                $errors = error_format($error);
                $responseArray = array('status' => 'error', 'status_msg' => $errors, 'token' => generatetoken());
            }


            if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
                $encoded = json_encode($responseArray);
                header('Content-Type: application/json');
                echo $encoded;
                exit();
            } else {
                echo $responseArray['status'];
                exit();
            }
        }


//check for any errors
        if (isset($error) && count($error) > 0) {
            $rowFacility['HFI_Name'] = $_POST['facility_name'];
            $rowFacility['HFI_Type'] = $_POST['facility_type'];
            $rowFacility['house_number'] = $_POST['house_number'];
            $rowFacility['street'] = $_POST['street'];
            $rowFacility['landmark'] = $_POST['landmark'];
            $rowFacility['locality'] = $_POST['locality'];
            $rowFacility['State_ID'] = $_POST['state'];
            $rowFacility['District_ID'] = $_POST['district'];
            $rowFacility['Taluka_ID'] = $_POST['taluka'];
            $rowFacility['HealthBlock_ID'] = $_POST['healthBlock'];
            $rowFacility['pincode'] = $_POST['pincode'];
            $rowFacility['landline_number'] = $_POST['landline_number'];
            $rowFacility['in_charge_mobile'] = $_POST['in_charge_mobile'];
            $rowFacility['email'] = $_POST['email'];
            $rowFacility['latitude'] = $_POST['latitude'];
            $rowFacility['longitude'] = $_POST['longitude'];
            $rowFacility['altitude'] = $_POST['altitude'];
            $rowFacility['region_indicator'] = $_POST['region_indicator'];
            $rowFacility['operational_Status'] = $_POST['operational_Status'];
            $rowFacility['ownership_authority'] = $_POST['ownership_authority'];
            $rowFacility['ownership_authority'] = $_POST['ownership_authority'];
            echo '<div class=" error">Please review the following error.</div>';
        }

        $data['user'] = $user;
        $data['error'] = $error;
        $data['nin'] = $nin;
        $data['rowFacility'] = $rowFacility;
        loadLayout('admin/facility/facility_edit', 'popup', $data);
    }

    function getInfrastructureView() {
        global $CURRENT_USER_STATE;
        global $CURRENT_USER_DISTRICT;
        //if not logged in redirect to login page
            global $db;
//        global $OPERATION_STATUS_LIST_COLOR_CLASS;
//        global $OPERATION_STATUS_LIST_ABBR;
//        global $OPERATION_STATUS_LIST;
//        global $CURRENT_USER_DISTRICT;
//        global $CURRENT_USER_STATE;
        $user = $this->user;
        $data = null;
// check permission
        if (!$user->hasPermission('UPDATE_IT_INFRASTRUCTURE')) {
            exit;
        }

        $errorNINMsg = "<H1>Invalid NIN Number";
        if (isset($_REQUEST['nin'])) {
            $nin = $_REQUEST['nin'];
            $rowFacility = getRowByNIN($nin);
            if (!$rowFacility) {
                echo $errorNINMsg;
                exit;
            }
        } else {
            echo $errorNINMsg;
            exit;
        }

        if (isHavingState($user)) {
            if ($rowFacility['State_ID'] != $CURRENT_USER_STATE) {
                echo '<h2>You do not have permission to View/update facility of State '
                . getStatesName($rowFacility['State_ID']) . '</h1>';
                exit;
            }
        }
        if (isHavingDistrict($user)) {
            if ($rowFacility['District_ID'] != $CURRENT_USER_DISTRICT) {
                echo '<h2>You do not have permission to View/update facility of District '
                . getDistrictName($rowFacility['State_ID'], $rowFacility['District_ID']) . '</h1>';
                exit;
            }
        }

//$objBlock = new Block($db);
//if form has been submitted process it
        if (isset($_POST['EncToken'])) {
            //    check CRRF
            if (!checkCSRF()) {
                $error[] = CSRF_ERROR;
            }
            //collect form data
            extract($_POST);
            if (!isset($it_infrastructure)) {
                $it_infrastructure = -1;
            }
            if ($it_infrastructure != 1 && $it_infrastructure != 0) {
                $error[] = 'Please select available IT infrastucture.';
            }

            //verify basic validation
            if ($it_infrastructure == 1) {

                if ($desktop_nos == '') {
                    $desktop_nos = 0;
                }
                if (filter_var($desktop_nos, FILTER_VALIDATE_INT) === false || ($desktop_nos < 0 && $desktop_nos > 100000)) {
                    $error[] = 'Invalid no of Desktops.';
                }

                if ($laptop_nos == '') {
                    $laptop_nos = 0;
                }
                if (filter_var($laptop_nos, FILTER_VALIDATE_INT) === false || ($laptop_nos < 0 && $laptop_nos > 100000)) {
                    $error[] = 'Invalid no of Laptops.';
                }

                if ($tablets_nos == '') {
                    $tablets_nos = 0;
                }
                if (filter_var($tablets_nos, FILTER_VALIDATE_INT) === false || ($tablets_nos < 0 && $tablets_nos > 100000)) {
                    $error[] = 'Invalid no of Tablets.';
                }

                if ($smartphone_nos == '') {
                    $smartphone_nos = 0;
                }
                if (filter_var($smartphone_nos, FILTER_VALIDATE_INT) === false || ($smartphone_nos < 0 && $smartphone_nos > 100000)) {
                    $error[] = 'Invalid no of Smart phones.';
                }

                if ($desktop_nos == 0 && $laptop_nos == 0 && $tablets_nos == 0 && $smartphone_nos == 0) {
                    $error[] = 'Please enter no of Desktops/Laptops/Tablets/Smartphones.';
                }
            } else {
                $desktop_nos = 0;
                $laptop_nos = 0;
                $tablets_nos = 0;
                $smartphone_nos = 0;
            }

            if (!isset($internet_connection)) {
                $internet_connection = -1;
            }
            if ($internet_connection != 1 && $internet_connection != 0) {
                $error[] = 'Please select Availability of Internet Connectivity.';
            }

            if ($internet_connection == 1) {

                if ($LAN == '') {
                    $LAN = 0;
                }
                if (filter_var($LAN, FILTER_VALIDATE_INT) === false || ($LAN < 0 && $LAN > 100000)) {
                    $error[] = 'Invalid no of Local Area Network (LAN) .';
                }

                if ($Leased_line == '') {
                    $Leased_line = 0;
                }
                if (filter_var($Leased_line, FILTER_VALIDATE_INT) === false || ($Leased_line < 0 && $Leased_line > 100000)) {
                    $error[] = 'Invalid no of Leased line.';
                }

                if ($NKN == '') {
                    $NKN = 0;
                }
                if (filter_var($NKN, FILTER_VALIDATE_INT) === false || ($NKN < 0 && $NKN > 100000)) {
                    $error[] = 'Invalid no of National Knowledge Network (NKN).';
                }

                if ($Broad_Band == '') {
                    $Broad_Band = 0;
                }
                if (filter_var($Broad_Band, FILTER_VALIDATE_INT) === false || ($Broad_Band < 0 && $Broad_Band > 100000)) {
                    $error[] = 'Invalid no of Broad Band.';
                }

                if ($VPN == '') {
                    $VPN = 0;
                }
                if (filter_var($VPN, FILTER_VALIDATE_INT) === false || ($VPN < 0 && $VPN > 100000)) {
                    $error[] = 'Invalid no of Virtual Private Network (VPN)  .';
                }

                if ($Dial_Up == '') {
                    $Dial_Up = 0;
                }
                if (filter_var($Dial_Up, FILTER_VALIDATE_INT) === false || ($Dial_Up < 0 && $Dial_Up > 100000)) {
                    $error[] = 'Invalid no of Dial Up .';
                }

                if ($wifi_modem == '') {
                    $wifi_modem = 0;
                }
                if (filter_var($wifi_modem, FILTER_VALIDATE_INT) === false || ($wifi_modem < 0 && $wifi_modem > 100000)) {
                    $error[] = 'Invalid no of Wifi Modem .';
                }

                if ($wiMax_usb_modem == '') {
                    $wiMax_usb_modem = 0;
                }
                if (filter_var($wiMax_usb_modem, FILTER_VALIDATE_INT) === false || ($wiMax_usb_modem < 0 && $wiMax_usb_modem > 100000)) {
                    $error[] = 'Invalid no of WiMax USB Modem (2G/3G/4G) .';
                }

                if ($wiMax_enabled_mobile == '') {
                    $wiMax_enabled_mobile = 0;
                }
                if (filter_var($wiMax_enabled_mobile, FILTER_VALIDATE_INT) === false || ($wiMax_enabled_mobile < 0 && $wiMax_enabled_mobile > 100000)) {
                    $error[] = 'Invalid no of WiMax enabled mobiles (2G/3G/4G).';
                }
            } else {
                $LAN = 0;
                $Leased_line = 0;
                $NKN = 0;
                $Broad_Band = 0;
                $VPN = 0;
                $Dial_Up = 0;

                $wifi_modem = 0;
                $wiMax_usb_modem = 0;
                $wiMax_enabled_mobile = 0;
            }

            if (!isset($availability_smartphone_ASHA)) {
                $availability_smartphone_ASHA = -1;
            }
            if ($availability_smartphone_ASHA != 1 && $availability_smartphone_ASHA != 0) {
                $error[] = 'Please select Availability of Smart phone / Tablets with the ANM/ASHA for providing health services.';
            }

            /*
              if (filter_var($id, FILTER_VALIDATE_INT) === false) {
              $error[] = 'Please enter the valid block Id.';
              }else {
              $id = intval(trim($id));
              if($id <= 0  && $id >= 100000 ) {
              $error[] = 'Invalid Block Id.';
              }
              else if($objBlock->isBlockIdExist($id)){
              $error[] = 'Block Id already exits.';
              }
              }
             */

            //update

            if (!isset($error)) {
                try {

                    $query = 'INSERT INTO ' . TB_T_IT_INFRASTRUCTURE . '
                            SET
                            NIN_2_HFI = :NIN_2_HFI,
                            it_infrastructure = :it_infrastructure,
                            desktop_nos = :desktop_nos,
                            laptop_nos = :laptop_nos,
                            tablets_nos = :tablets_nos,
                            smartphone_nos = :smartphone_nos,
                            internet_connection = :internet_connection,
                            LAN = :LAN,
                            Leased_line = :Leased_line,
                            NKN = :NKN,
                            Broad_Band = :Broad_Band,
                            VPN = :VPN,
                            Dial_Up = :Dial_Up,
                            wifi_modem = :wifi_modem,
                            wiMax_usb_modem = :wiMax_usb_modem,
                            wiMax_enabled_mobile = :wiMax_enabled_mobile,
                            availability_smartphone_ASHA = :availability_smartphone_ASHA,
                            updated_by_user = :updated_by_user,
                            updated_on = NOW()

                            ON DUPLICATE KEY UPDATE
                            it_infrastructure     = VALUES(it_infrastructure),
                            desktop_nos = VALUES(desktop_nos),
                            laptop_nos     = VALUES(laptop_nos),
                            tablets_nos = VALUES(tablets_nos),
                            smartphone_nos = VALUES(smartphone_nos),
                            internet_connection = VALUES(internet_connection),
                            LAN = VALUES(LAN),
                            Leased_line = VALUES(Leased_line),
                            NKN = VALUES(NKN),
                            Broad_Band = VALUES(Broad_Band),
                            VPN = VALUES(VPN),
                            Dial_Up = VALUES(Dial_Up),
                            wifi_modem = VALUES(wifi_modem),
                            wiMax_usb_modem = VALUES(wiMax_usb_modem),
                            wiMax_enabled_mobile = VALUES(wiMax_enabled_mobile),
                            availability_smartphone_ASHA = VALUES(availability_smartphone_ASHA),
                            updated_by_user = VALUES(updated_by_user),
                            updated_on = VALUES(updated_on)
                            ';
                    $data = array(
                        ':NIN_2_HFI' => $nin,
                        ':it_infrastructure' => $it_infrastructure,
                        ':desktop_nos' => intVal($desktop_nos),
                        ':laptop_nos' => intVal($laptop_nos),
                        ':tablets_nos' => intVal($tablets_nos),
                        ':smartphone_nos' => intVal($smartphone_nos),
                        ':internet_connection' => intVal($internet_connection),
                        ':LAN' => intVal($LAN),
                        ':Leased_line' => intVal($Leased_line),
                        ':NKN' => intVal($NKN),
                        ':Broad_Band' => intVal($Broad_Band),
                        ':VPN' => intVal($VPN),
                        ':Dial_Up' => intVal($Dial_Up),
                        ':wifi_modem' => intVal($wifi_modem),
                        ':wiMax_usb_modem' => intVal($wiMax_usb_modem),
                        ':wiMax_enabled_mobile' => intVal($wiMax_enabled_mobile),
                        ':availability_smartphone_ASHA' => intVal($availability_smartphone_ASHA),
                        ':updated_by_user' => $_SESSION['memberID']
                    );

                    $stmt = $db->prepare($query);
                    $stmt->execute($data);
                    //status_message("IT infrastructure updated successfully!");
                    //redirect to index page
                    // header('Location: it_infrastructure_view.php?nin=' . $nin);
                    $responseArray = array('status' => 'success', 'status_msg' => 'IT infrastructure updated successfully!');
                } catch (PDOException $e) {
                    echo $e->getMessage();
                }
            } else {
                $errors = error_format($error);
                $responseArray = array('status' => 'error', 'status_msg' => $errors, 'token' => generatetoken());
            }
            if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
                $encoded = json_encode($responseArray);
                header('Content-Type: application/json');
                echo $encoded;
                exit();
            } else {
                echo $responseArray['status'];
                exit();
            }
        } else {
            $stmt = $db->prepare('SELECT * FROM ' . TB_T_IT_INFRASTRUCTURE . ' WHERE NIN_2_HFI = :NIN_2_HFI');
            $stmt->execute(array(':NIN_2_HFI' => $nin));
            $rowIT_Infrastructure = $stmt->fetch();
        }

        $data['nin'] = $nin;
        $data['user'] = $user;
        $data['rowFacility'] = $rowFacility;

        $data['rowIT_Infrastructure'] = $rowIT_Infrastructure;
        loadLayout('admin/facility/it_infrastructure_view', 'popup', $data);
    }
  function getInfrastructureUpdate() {
          global $db;
        global $CURRENT_USER_STATE;
        global $CURRENT_USER_DISTRICT;

        $user = $this->user;
        $data = null;
        if (!$user->hasPermission('UPDATE_IT_INFRASTRUCTURE')) {
            exit;
        }

        $errorNINMsg = "<H1>Invalid NIN Number";
        if (isset($_REQUEST['nin'])) {
            $nin = $_REQUEST['nin'];
            $rowFacility = getRowByNIN($nin);
            if (!$rowFacility) {
                echo $errorNINMsg;
                exit;
            }
        } else {
            echo $errorNINMsg;
            exit;
        }

        if (isHavingState($user)) {
            if ($rowFacility['State_ID'] != $CURRENT_USER_STATE) {
                echo '<h2>You do not have permission to View/update facility of State '
                . getStatesName($rowFacility['State_ID']) . '</h1>';
                exit;
            }
        }
        if (isHavingDistrict($user)) {
            if ($rowFacility['District_ID'] != $CURRENT_USER_DISTRICT) {
                echo '<h2>You do not have permission to View/update facility of District '
                . getDistrictName($rowFacility['State_ID'], $rowFacility['District_ID']) . '</h1>';
                exit;
            }
        }

//$objBlock = new Block($db);
//if form has been submitted process it
        if (isset($_POST['EncToken'])) {
            //    check CRRF
            if (!checkCSRF()) {
                $error[] = CSRF_ERROR;
            }
            //collect form data
            extract($_POST);
            if (!isset($it_infrastructure)) {
                $it_infrastructure = -1;
            }
            if ($it_infrastructure != 1 && $it_infrastructure != 0) {
                $error[] = 'Please select available IT infrastucture.';
            }

            //verify basic validation
            if ($it_infrastructure == 1) {

                if ($desktop_nos == '') {
                    $desktop_nos = 0;
                }
                if (filter_var($desktop_nos, FILTER_VALIDATE_INT) === false || ($desktop_nos < 0 && $desktop_nos > 100000)) {
                    $error[] = 'Invalid no of Desktops.';
                }

                if ($laptop_nos == '') {
                    $laptop_nos = 0;
                }
                if (filter_var($laptop_nos, FILTER_VALIDATE_INT) === false || ($laptop_nos < 0 && $laptop_nos > 100000)) {
                    $error[] = 'Invalid no of Laptops.';
                }

                if ($tablets_nos == '') {
                    $tablets_nos = 0;
                }
                if (filter_var($tablets_nos, FILTER_VALIDATE_INT) === false || ($tablets_nos < 0 && $tablets_nos > 100000)) {
                    $error[] = 'Invalid no of Tablets.';
                }

                if ($smartphone_nos == '') {
                    $smartphone_nos = 0;
                }
                if (filter_var($smartphone_nos, FILTER_VALIDATE_INT) === false || ($smartphone_nos < 0 && $smartphone_nos > 100000)) {
                    $error[] = 'Invalid no of Smart phones.';
                }

                if ($desktop_nos == 0 && $laptop_nos == 0 && $tablets_nos == 0 && $smartphone_nos == 0) {
                    $error[] = 'Please enter no of Desktops/Laptops/Tablets/Smartphones.';
                }
            } else {
                $desktop_nos = 0;
                $laptop_nos = 0;
                $tablets_nos = 0;
                $smartphone_nos = 0;
            }

            if (!isset($internet_connection)) {
                $internet_connection = -1;
            }
            if ($internet_connection != 1 && $internet_connection != 0) {
                $error[] = 'Please select Availability of Internet Connectivity.';
            }

            if ($internet_connection == 1) {

                if ($LAN == '') {
                    $LAN = 0;
                }
                if (filter_var($LAN, FILTER_VALIDATE_INT) === false || ($LAN < 0 && $LAN > 100000)) {
                    $error[] = 'Invalid no of Local Area Network (LAN) .';
                }

                if ($Leased_line == '') {
                    $Leased_line = 0;
                }
                if (filter_var($Leased_line, FILTER_VALIDATE_INT) === false || ($Leased_line < 0 && $Leased_line > 100000)) {
                    $error[] = 'Invalid no of Leased line.';
                }

                if ($NKN == '') {
                    $NKN = 0;
                }
                if (filter_var($NKN, FILTER_VALIDATE_INT) === false || ($NKN < 0 && $NKN > 100000)) {
                    $error[] = 'Invalid no of National Knowledge Network (NKN).';
                }

                if ($Broad_Band == '') {
                    $Broad_Band = 0;
                }
                if (filter_var($Broad_Band, FILTER_VALIDATE_INT) === false || ($Broad_Band < 0 && $Broad_Band > 100000)) {
                    $error[] = 'Invalid no of Broad Band.';
                }

                if ($VPN == '') {
                    $VPN = 0;
                }
                if (filter_var($VPN, FILTER_VALIDATE_INT) === false || ($VPN < 0 && $VPN > 100000)) {
                    $error[] = 'Invalid no of Virtual Private Network (VPN)  .';
                }

                if ($Dial_Up == '') {
                    $Dial_Up = 0;
                }
                if (filter_var($Dial_Up, FILTER_VALIDATE_INT) === false || ($Dial_Up < 0 && $Dial_Up > 100000)) {
                    $error[] = 'Invalid no of Dial Up .';
                }

                if ($wifi_modem == '') {
                    $wifi_modem = 0;
                }
                if (filter_var($wifi_modem, FILTER_VALIDATE_INT) === false || ($wifi_modem < 0 && $wifi_modem > 100000)) {
                    $error[] = 'Invalid no of Wifi Modem .';
                }

                if ($wiMax_usb_modem == '') {
                    $wiMax_usb_modem = 0;
                }
                if (filter_var($wiMax_usb_modem, FILTER_VALIDATE_INT) === false || ($wiMax_usb_modem < 0 && $wiMax_usb_modem > 100000)) {
                    $error[] = 'Invalid no of WiMax USB Modem (2G/3G/4G) .';
                }

                if ($wiMax_enabled_mobile == '') {
                    $wiMax_enabled_mobile = 0;
                }
                if (filter_var($wiMax_enabled_mobile, FILTER_VALIDATE_INT) === false || ($wiMax_enabled_mobile < 0 && $wiMax_enabled_mobile > 100000)) {
                    $error[] = 'Invalid no of WiMax enabled mobiles (2G/3G/4G).';
                }
            } else {
                $LAN = 0;
                $Leased_line = 0;
                $NKN = 0;
                $Broad_Band = 0;
                $VPN = 0;
                $Dial_Up = 0;

                $wifi_modem = 0;
                $wiMax_usb_modem = 0;
                $wiMax_enabled_mobile = 0;
            }

            if (!isset($availability_smartphone_ASHA)) {
                $availability_smartphone_ASHA = -1;
            }
            if ($availability_smartphone_ASHA != 1 && $availability_smartphone_ASHA != 0) {
                $error[] = 'Please select Availability of Smart phone / Tablets with the ANM/ASHA for providing health services.';
            }

            /*
              if (filter_var($id, FILTER_VALIDATE_INT) === false) {
              $error[] = 'Please enter the valid block Id.';
              }else {
              $id = intval(trim($id));
              if($id <= 0  && $id >= 100000 ) {
              $error[] = 'Invalid Block Id.';
              }
              else if($objBlock->isBlockIdExist($id)){
              $error[] = 'Block Id already exits.';
              }
              }
             */

            //update

            if (!isset($error)) {
                try {

                    $query = 'INSERT INTO ' . TB_T_IT_INFRASTRUCTURE . '
                            SET
                            NIN_2_HFI = :NIN_2_HFI,
                            it_infrastructure = :it_infrastructure,
                            desktop_nos = :desktop_nos,
                            laptop_nos = :laptop_nos,
                            tablets_nos = :tablets_nos,
                            smartphone_nos = :smartphone_nos,
                            internet_connection = :internet_connection,
                            LAN = :LAN,
                            Leased_line = :Leased_line,
                            NKN = :NKN,
                            Broad_Band = :Broad_Band,
                            VPN = :VPN,
                            Dial_Up = :Dial_Up,
                            wifi_modem = :wifi_modem,
                            wiMax_usb_modem = :wiMax_usb_modem,
                            wiMax_enabled_mobile = :wiMax_enabled_mobile,
                            availability_smartphone_ASHA = :availability_smartphone_ASHA,
                            updated_by_user = :updated_by_user,
                            updated_on = NOW()

                            ON DUPLICATE KEY UPDATE
                            it_infrastructure     = VALUES(it_infrastructure),
                            desktop_nos = VALUES(desktop_nos),
                            laptop_nos     = VALUES(laptop_nos),
                            tablets_nos = VALUES(tablets_nos),
                            smartphone_nos = VALUES(smartphone_nos),
                            internet_connection = VALUES(internet_connection),
                            LAN = VALUES(LAN),
                            Leased_line = VALUES(Leased_line),
                            NKN = VALUES(NKN),
                            Broad_Band = VALUES(Broad_Band),
                            VPN = VALUES(VPN),
                            Dial_Up = VALUES(Dial_Up),
                            wifi_modem = VALUES(wifi_modem),
                            wiMax_usb_modem = VALUES(wiMax_usb_modem),
                            wiMax_enabled_mobile = VALUES(wiMax_enabled_mobile),
                            availability_smartphone_ASHA = VALUES(availability_smartphone_ASHA),
                            updated_by_user = VALUES(updated_by_user),
                            updated_on = VALUES(updated_on)
                            ';
                    $data = array(
                        ':NIN_2_HFI' => $nin,
                        ':it_infrastructure' => $it_infrastructure,
                        ':desktop_nos' => intVal($desktop_nos),
                        ':laptop_nos' => intVal($laptop_nos),
                        ':tablets_nos' => intVal($tablets_nos),
                        ':smartphone_nos' => intVal($smartphone_nos),
                        ':internet_connection' => intVal($internet_connection),
                        ':LAN' => intVal($LAN),
                        ':Leased_line' => intVal($Leased_line),
                        ':NKN' => intVal($NKN),
                        ':Broad_Band' => intVal($Broad_Band),
                        ':VPN' => intVal($VPN),
                        ':Dial_Up' => intVal($Dial_Up),
                        ':wifi_modem' => intVal($wifi_modem),
                        ':wiMax_usb_modem' => intVal($wiMax_usb_modem),
                        ':wiMax_enabled_mobile' => intVal($wiMax_enabled_mobile),
                        ':availability_smartphone_ASHA' => intVal($availability_smartphone_ASHA),
                        ':updated_by_user' => $_SESSION['memberID']
                    );

                    $stmt = $db->prepare($query);
                    $stmt->execute($data);
                    //status_message("IT infrastructure updated successfully!");
                    //redirect to index page
                    // header('Location: it_infrastructure_view.php?nin=' . $nin);
                    $responseArray = array('status' => 'success', 'status_msg' => 'IT infrastructure updated successfully!');
                } catch (PDOException $e) {
                    echo $e->getMessage();
                }
            } else {
                $errors = error_format($error);
                $responseArray = array('status' => 'error', 'status_msg' => $errors, 'token' => generatetoken());
            }
            if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
                $encoded = json_encode($responseArray);
                header('Content-Type: application/json');
                echo $encoded;
                exit();
            } else {
                echo $responseArray['status'];
                exit();
            }
        } else {
            $stmt = $db->prepare('SELECT * FROM ' . TB_T_IT_INFRASTRUCTURE . ' WHERE NIN_2_HFI = :NIN_2_HFI');
            $stmt->execute(array(':NIN_2_HFI' => $nin));
            $rowIT_Infrastructure = $stmt->fetch();
        }
        $data['nin'] = $nin;
        $data['user'] = $user;
        $data['rowFacility'] = $rowFacility;

        $data['rowIT_Infrastructure'] = $rowIT_Infrastructure;
        loadLayout('admin/facility/it_infrastructure_update', 'popup', $data);
    }

    function addFacility() {
            global $db;
        global $OPERATION_STATUS_LIST_COLOR_CLASS;
        global $OPERATION_STATUS_LIST_ABBR;
        global $OPERATION_STATUS_LIST;
        global $CURRENT_USER_DISTRICT;
        $user = $this->user;

//$pageLayout = new layout();
//$pageLayout->setTitle('Dashboard');
//if not logged in redirect to login page
//check permission


        $error = array();
//if form has been submitted process it
        if (isset($_POST['submit'])) {

            //    check CRRF
            if (!checkCSRF()) {
                $error[] = CSRF_ERROR;
            }

            //collect form data
            //extract($_POST);
            //very basic validation
            if (isset($_POST['facility_name'])) {
                $facility_name = trim(filter_var($_POST['facility_name'], FILTER_SANITIZE_STRING));
                if ($facility_name == '') {
                    $error['facility_name'] = 'Please enter the Facility Name.';
                }
                if (strlen($facility_name) > 200) {
                    $error['facility_name'] = 'Facility Name exceeds max characters limit 200.';
                }
            } else {
                // filter_var($city, FILTER_SANITIZE_STRING)
                $error['facility_name'] = 'Please enter the Facility Name.';
            }

            if (isset($_POST['facility_type']) && $_POST['facility_type'] != '0') {
                $facility_type = intval($_POST['facility_type']);
                if (!isValidFacilityType($facility_type)) {
                    $error['facility_type'] = 'Invalid selected Facility Type.';
                }
            } else {
                $error['facility_type'] = 'Please select Facility Type.';
            }

            if (isHavingState($user)) {
                $_POST['state'] = $CURRENT_USER_STATE;
            }
            // check if State and District of User
            if (isset($_POST['state']) && $_POST['state'] != '0') {
                $state = intVal($_POST['state']);
                if (!isValidStateId($state)) {
                    $error['state'] = 'Invalid selected State.';
                }
            } else {
                $error['state'] = 'Please select State.';
            }

            if (isHavingDistrict($user)) {
                $_POST['district'] = $CURRENT_USER_DISTRICT;
            }

            if (isset($state) && isset($_POST['district']) && $_POST['district'] != '0') {
                $district = intval($_POST['district']);
                if (!isValidDistrictId($state, $district)) {
                    $error['district'] = 'Invalid selected District.';
                }
            } else {
                $error['district'] = 'Please select District.';
            }

            //verify if Taluka is selected
            $taluka = 0;
            if (isset($state) && isset($district) && isset($_POST['taluka']) && $_POST['taluka'] != '0') {
                $taluka = intval($_POST['taluka']);
                if (!isValidTalukaId($state, $district, $taluka)) {
                    $error['taluka'] = 'Invalid selected District.';
                }
            }

            //verify if Health Block is selected
            $healthBlock = 0;
            if (isset($state) && isset($district) && isset($_POST['healthBlock']) && $_POST['healthBlock'] != '0') {
                if (!isset($taluka)) {
                    $taluka = 0;
                }
                $healthBlock = intval($_POST['healthBlock']);
                if (!isValidHealthBlockId($state, $district, $taluka, $healthBlock)) {
                    $error['healthBlock'] = 'Invalid selected Health Block.';
                }
            }

            $pincode = '';
            if (isset($_POST['pincode'])) {
                $pincode = trim($_POST['pincode']);
                if (!preg_match('/^[1-9]{1}[0-9]{5}$/', $pincode)) {
                    $error['pincode'] = 'Pincode seems invalid.';
                }
            }


            if (isset($_POST['house_number'])) {
                $house_number = trim(filter_var($_POST['house_number'], FILTER_SANITIZE_STRING));
                if ($house_number == '') {
                    $error['house_number'] = 'Please enter the House Number.';
                }
                if (strlen($house_number) > 100) {
                    $error['house_number'] = 'House Number exceeds max characters limit 100.';
                }
            } else {
                $error['house_number'] = 'Please enter the House Number.';
            }

            if (isset($_POST['street'])) {
                $street = trim(filter_var($_POST['street'], FILTER_SANITIZE_STRING));
                if ($street == '') {
                    $error['street'] = 'Please enter street.';
                }
                if (strlen($street) > 100) {
                    $error['street'] = 'Street exceeds max characters limit 100.';
                }
            } else {
                $error['street'] = 'Please enter street.';
            }

            $landmark = '';
            if (isset($_POST['landmark'])) {
                $landmark = trim(filter_var($_POST['landmark'], FILTER_SANITIZE_STRING));
                if (strlen($landmark) > 100) {
                    $error['landmark'] = 'Landmark max characters limit 100.';
                }
            }

            $locality = '';
            if (isset($_POST['locality'])) {
                $locality = trim(filter_var($_POST['locality'], FILTER_SANITIZE_STRING));
                if (strlen($locality) > 100) {
                    $error['locality'] = 'Locality max characters limit 100.';
                }
            }

            $landline_number = '';
            if (isset($_POST['landline_number'])) {
                $landline_number = trim(filter_var($_POST['landline_number'], FILTER_SANITIZE_STRING));
                if (strlen($landline_number) > 60) {
                    $error['landline_number'] = 'Locality max characters limit 50.';
                }
            }


            $in_charge_mobile = '';
            if (isset($_POST['in_charge_mobile'])) {
                $in_charge_mobile = trim($_POST['in_charge_mobile']);
                if (!preg_match('/^[1-9][0-9]{9}$/', $in_charge_mobile)) {
                    $error['in_charge_mobile'] = 'In Charge Mobile seems invalid. It should be 10 digit number';
                }
            }


            if (isset($_POST['email']) && trim($_POST['email']) != '') {
                $email = trim($_POST['email']);
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $error['email'] = 'Email seems invalid.';
                }
                if (strlen($email) > 120) {
                    $error['email'] = 'Email max characters limit 60.';
                }
            } else {
                $error['email'] = 'Please enter email.';
            }

            $latitude = 0;
            if (isset($_POST['latitude']) && trim($_POST['latitude']) != '' && trim($_POST['latitude']) != 0) {
                $latitude = trim($_POST['latitude']);
                if (!isValidLatitude($latitude)) {
                    $error['latitude'] = 'Latitude seems incorrect value.';
                }
            }

            $longitude = 0;
            if (isset($_POST['longitude']) && trim($_POST['longitude']) != '' && trim($_POST['longitude']) != 0) {
                $longitude = trim($_POST['longitude']);
                if (!isValidLongitude($longitude)) {
                    $error['longitude'] = 'Longitude seems incorrect value.';
                }
            }

            if ($latitude != 0 && $longitude == 0) {
                if (!isset($error['longitude'])) {
                    $error['longitude'] = 'Longitude should have a value.';
                }
            }

            if ($latitude == 0 && $longitude != 0) {
                if (!isset($error['latitude'])) {
                    $error['latitude'] = 'Latitude should have a value.';
                }
            }

            $altitude = 0;
            if (isset($_POST['altitude']) && trim($_POST['altitude'] != '')) {
                $altitude = trim($_POST['altitude']);
                if (!isValidAltitude($altitude)) {
                    $error['altitude'] = 'Altitude seems incorrect value. Should be in meters and not more than 4 dicimal places';
                }
            }

            if (isset($_POST['region_indicator']) && trim($_POST['region_indicator']) != '0') {
                $region_indicator = intVal($_POST['region_indicator']);
                if (!isValidRegionIndicator($region_indicator)) {
                    $error['region_indicator'] = 'Invalid selected Region Indicator.';
                }
            } else {
                $error['region_indicator'] = 'Please select Region Indicator.';
            }

            // check if State and District of User
            if (isset($_POST['operational_status']) && trim($_POST['operational_status']) != '0') {
                $operational_status = intVal($_POST['operational_status']);
                if (!isValidOperationStatus($operational_status)) {
                    $error['operational_status'] = 'Invalid selected Operational Status.';
                }
            } else {
                $error['operational_status'] = 'Please select Operational Status.';
            }

            // check if State and District of User
            if (isset($_POST['ownership_authority']) && trim($_POST['ownership_authority']) != '0') {
                $ownership_authority = intVal($_POST['ownership_authority']);
                if (!isValidOwnershipAuthority($ownership_authority)) {
                    $error['ownership_authority'] = 'Invalid selected Ownership Authority.';
                }
            } else {
                $error['ownership_authority'] = 'Please select Ownership Authority.';
            }

            if (isset($error) && count($error) == 0) {

                try {

                    $stmt = $db->prepare('SELECT * FROM ' . TB_M_NINCODE . ' WHERE IsAssigned = 0 limit 1');
                    $stmt->execute();
                    $row = $stmt->fetch();
                    if ($row) {
                        $NIN_Code = $row['NIN'];
                        $db->beginTransaction();
                        $query = 'INSERT INTO ' . TB_HMIS_HEALTH_FACILITIES . '
                                            (NIN_2_HFI, HFI_Name, HFI_Type, State_ID, District_ID, Taluka_ID, HealthBlock_ID,
                                             pincode, house_number, street, landmark, locality, landline_number, in_charge_mobile,
                                             email, latitude, longitude, altitude, region_indicator, operational_Status,
                                             ownership_authority, added_by_user, source_entry, Created_On)
                                             VALUES
                                            (' . $NIN_Code . ', :HFI_Name, :HFI_Type, :State_ID, :District_ID, :Taluka_ID, :HealthBlock_ID,
                                             :pincode, :house_number, :street, :landmark, :locality, :landline_number, :in_charge_mobile,
                                             :email, :latitude, :longitude, :altitude, :region_indicator, :operational_Status,
                                             :ownership_authority, :added_by_user, :source_entry, NOW())';
                        $stmt2 = $db->prepare($query);
                        $parameters = array(
                            ':HFI_Name' => $facility_name,
                            ':HFI_Type' => $facility_type,
                            ':State_ID' => $state,
                            ':District_ID' => $district,
                            ':Taluka_ID' => $taluka,
                            ':HealthBlock_ID' => $healthBlock,
                            ':pincode' => $pincode,
                            ':house_number' => $house_number,
                            ':street' => $street,
                            ':landmark' => $landmark,
                            ':locality' => $locality,
                            ':landline_number' => $landline_number,
                            ':in_charge_mobile' => $in_charge_mobile,
                            ':email' => $email,
                            ':latitude' => $latitude,
                            ':longitude' => $longitude,
                            ':altitude' => $altitude,
                            ':region_indicator' => $region_indicator,
                            ':operational_Status' => $operational_status,
                            ':ownership_authority' => $ownership_authority,
                            ':source_entry' => 'By Website Loged-In User',
                            ':added_by_user' => $_SESSION['memberID']
                        );
                        // print_r($parameters);
                        $success = $stmt2->execute($parameters);
                        if ($success) {
                            $query = "UPDATE " . TB_M_NINCODE . " set IsAssigned = 1 where NIN = '" . $NIN_Code . "' ";
                            $stmt3 = $db->prepare($query);
                            $stmt3->execute();

                            $db->commit();
                            status_message('Facility Added Successfully');
                            redirect('facilities/facilityview?nin=' . $NIN_Code, 'refresh');
                        }
                        status_message('Technical Error: Cannot assign NIN to Health facility');
                    } else {
                        status_message('Technical Error: Cannot assign NIN to Health facility');
                    }
                } catch (PDOException $e) {
                    // echo '<pre>'.print_r($e->getTrace()).'</pre>';
                    echo $e->getMessage();
                    try {
                        $db->rollBack();
                    } catch (Exception $e2) {
                        echo $e2->getMessage();
                    }
                    exit;
                }
            }
        }

       $data['user'] = $user;
        $data['error'] = $error;
        $data['_POST'] = $_POST;
        loadLayout('admin/facility_add', 'admin', $data);
    }

}