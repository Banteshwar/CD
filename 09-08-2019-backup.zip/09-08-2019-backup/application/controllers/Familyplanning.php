<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Familyplanning extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
     
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
       
        $this->load->model('Dashboard_model');
		$this->load->model('programmanager/Familyplanning_model');
		
		$this->load->model('hwc_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index($year_id='',$q_id='') { 
	
        $this->mybreadcrumb->add('Home', base_url('secretary/page/index'));
        $this->mybreadcrumb->add('Family Planning', base_url('familyplanning/index'));
		
		if($year_id)
		{
		$data['fin_year'] = $year_id;
		}
		else{
		$data['fin_year'] = getCurrFinYear('Quarterly');
		}	

        if($q_id)
		{
		$data['fin_querter'] = $q_id;
		}
		else{
		$data['fin_querter'] = getCurrQuarter('Quarterly'); 
		}			
		
        $data['page_type']='Familyplanning';
       // $data['row'] = $this->Familyplanning_model->get_Ambulances();
		
		$data['state']=$this->Familyplanning_model->get_Family_State($data['fin_year'],$data['fin_querter']);
				       
        loadLayout('programmanager/familyplanning/form', 'program_manager', $data);
    }
	
	
	
	/* public function form_save()
	{ 
	
	
       if (isset($_POST['submit']))
		  {
			
			
        
		  $this->form_validation->set_rules('year_id', 'Year', 'required');
		  $this->form_validation->set_rules('q_id', 'Quarter', 'required');
		  
			 
          if ($this->form_validation->run() == FALSE)
                {
                	    $this->session->set_flashdata('required','Something went wrong. Please try again later.');
					   
                	 	redirect('Familyplanning/index/');	
				}    
                else
                {
	             
						
                 $this->Familyplanning_model->saveFamily($_POST);
				

				$this->session->set_flashdata("success","Data has been submitted successfully.");
        
			    
				
				//$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('Familyplanning/index/'.$this->input->post("year_id").'/'.$this->input->post("q_id"));     
		  
		  }

		  }
	} */
	
	
	public function form_save()
	{ 
       if (isset($_POST['submit']))
		  {
		 
		  $this->form_validation->set_rules('year_id', 'Year', 'required');
		  $this->form_validation->set_rules('q_id', 'Quarter', 'required');
		  			 
          if ($this->form_validation->run() == FALSE)
                {
                	    $this->session->set_flashdata('required','Something went wrong. Please try again later.');
					   
                	 	redirect('Familyplanning/index/');	
				}    
                else
                {
	             
						
                 $this->Familyplanning_model->saveFamily($_POST);
				

				$this->session->set_flashdata("success","Data has been submitted successfully.");
        
			    
				
				//$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('Familyplanning/index/'.$this->input->post("year_id").'/'.$this->input->post("q_id"));     
		  
		  }

		  }
	}
	
	
	
	

  public function deleteFp($id){

     $ss=$this->db->delete('familyplanning_master_table', array('id' => $id));
     
     if($ss){
       echo "1";
     }else{
       echo "0";
     }
    }

	 
public function change_val_ajax($y_val,$q_val)
     {
		 
		 $data['state']=$this->Familyplanning_model->get_family_State_ajax($y_val,$q_val);
		 
		//echo print_r($data['state']); die;
		 
		 echo json_encode($data['state']);
		
		
		
		die;
	// $data['state']=$this->Familyplanning_model->get_Ambulances_State($fin_year,$fin_querter);
	 
	 }
  
}
