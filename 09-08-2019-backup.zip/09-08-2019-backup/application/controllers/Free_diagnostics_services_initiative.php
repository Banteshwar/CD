<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Free_diagnostics_services_initiative extends MY_Controller 
{
    private $user;

    public function __construct() 
    {
        parent::__construct();
      
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('hwc_model');
        $this->load->model('Programmanager_model');

        $this->load->model('Dashboard_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }


    public function index() 
    { 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Free Diagnostic Services Initiative', base_url('freeDiagnosticsSI/FreeDiagnosticsSI'));
        
        $data['page_type']='fdsi';     
       $data['row']=$this->Programmanager_model->FDSI_list();
        loadLayout('programmanager/freeDiagnosticsSI/FreeDiagnosticsSI', 'program_manager', $data);
    }


    public function fdsi_form(){
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Free Diagnostic Services Initiative', base_url('freeDiagnosticsSI/fdsi_form'));
        
        $data['page_type']='fdsi'; 
        $data['state']=$this->hwc_model->get_state();    
        loadLayout('programmanager/freeDiagnosticsSI/fdsi_form', 'program_manager', $data);
    }


    public function fdsi_submit(){
 if (isset($_POST['submit']))
          {
             
          $this->form_validation->set_rules('Number_of_States', 'Number_of_States', 'required');
          
         
         
          if ($this->form_validation->run() == FALSE)
                {
                        //$data['state']=$this->hwc_model->get_state();
                         redirect('Free_diagnostics_services_initiative/fdsi_form');    
                       // $this->load->view('admin/nvhcp/nvhcp_form_add',$data);
                }
                else
                {

        $insert=array(
'State_ID'=>$this->input->post('State_ID'),
'Number_of_States'=>$this->input->post('Number_of_States'),
'Free_Laboratory_services'=>$this->input->post('Free_Laboratory_services'),

'Radiology_services'=>$this->input->post('Radiology_services'),

'services_in_DHs'=>$this->input->post('services_in_DHs'),

'Quarterly'=>$this->input->post('Quarterly'),

'year'=>$this->input->post('year')
);


        $result = $this->Programmanager_model->chkFDSI($this->input->post('year'),$this->input->post('Quarterly'));
                  
                  

                ///////////// end check availability ///////////
                
                if($result>0)
                {
                    
                    
                 $this->session->set_flashdata("already_added","Record already added.");
                 
                    
                     redirect('Free_diagnostics_services_initiative/fdsi_form');                    
                        
                }
                else
                {
                $this->Programmanager_model->insertFDSI($insert);

                $this->session->set_flashdata("success","Data has been submitted successfully.");
        
                }
                
                //$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('Free_diagnostics_services_initiative/index');     
          
          }

        }
    }

    public function fdsi_edit($id){
        $data['state']=$this->hwc_model->get_state($id);
        $data['state']=$this->hwc_model->get_state();
        $data['value'] = $this->Programmanager_model->fdsi_edit_show($id);
         

        $data['page_type']='fdsi';     
        loadLayout('programmanager/freeDiagnosticsSI/fdsi_update', 'program_manager', $data);

    }


    public function form_update($id)
    {      
      if (isset($_POST['update']))
          {
             $data = array
                   (                    
                    
                    'State_ID'=> $this->input->post('State_ID'),
                    'Quarterly'=> $this->input->post('Quarterly'),
                    'Free_Laboratory_services'=>$this->input->post('Free_Laboratory_services'),

'Radiology_services'=>$this->input->post('Radiology_services'),

'services_in_DHs'=>$this->input->post('services_in_DHs'),
                    'year'=> $this->input->post('year'),
                    'Number_of_States'=> $this->input->post('Number_of_States'),
                    'updated_date'=>  $this->input->post(date('updated_date')),
                    'updated_by'=>  (isset($_SESSION['memberID']))
                                                    
                );
                
      

                $result = $this->Programmanager_model->update_fdsi($id,$data);

        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
            
         }
          redirect('Free_diagnostics_services_initiative/index',$id);

          }
    }
    public function delete($id)
     {
       $this->db->delete('free_diagnosticssi_master_tbl', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('Free_diagnostics_services_initiative/index'));
     }
  
} 
