<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Freedrugservice extends MY_Controller {
    private $user;

    public function __construct() {
        parent::__construct();           
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('programmanager/freedrugservice_model');
        $this->load->model('Dashboard_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');
    }

        
    public function index() { 		
    	$this->freedrugservice_view();
    }
	
	public function freedrugservice_view(){  
        $this->mybreadcrumb->add('Home', base_url());
    //    $this->mybreadcrumb->add('FDSI', base_url('freedrugservice/index'));
		$this->mybreadcrumb->add('Free Drugs Services Initiative', base_url('freedrugservice/index'));			
        $data['page_type'] = 'FDSI';
		$data['row'] = $this->freedrugservice_model->get_freedrugservice();
		
		loadLayout('programmanager/freedrugservice/form_list', 'program_manager', $data);
    }
	
    public function freedrugservice_add_form(){  
        $this->mybreadcrumb->add('Home', base_url());
       // $this->mybreadcrumb->add('FDSI', base_url('freedrugservice/index'));
        $this->mybreadcrumb->add('Free Drugs Services Initiative', base_url('freedrugservice/index'));
        $data['page_type'] = 'FDSI';	
		$data['states']    = $this->freedrugservice_model->get_state();
        loadLayout('programmanager/freedrugservice/form_add', 'program_manager', $data);
    }
	
    private function freedrugservice_validate(){          
        $this->form_validation->set_rules('entrydate', 'Date', 'trim|required');
        $this->form_validation->set_rules('statename', 'Number of States with active users till PHC level', 'trim|required');
        $this->form_validation->set_rules('rank', 'State Ranking as per Central DVDMS Dashboard', 'trim|required');
        $this->form_validation->set_rules('active_user', 'Active User', 'trim|required');
              
        
		
        if($this->form_validation->run() == TRUE){
            $requestdata  =   array(
                "entrydate"        =>  $this->input->post('entrydate'),        
                "statename"        =>  $this->input->post('statename'),        
                "rank"    =>  $this->input->post('rank'),               
                "active_user"    =>  $this->input->post('active_user')				
				
             ); 
            return $requestdata;
        }else{
            $this->form_validation->set_error_delimiters('', '');
            $message    = array("0",validation_errors());
            $this->session->set_flashdata('message', $message);
            return false;
        }
    }
	
    public function freedrugservice_InsertForm(){	
        $requestdata    =   $this->freedrugservice_validate();
		
        if(!empty($requestdata)){
            if($this->freedrugservice_model->insertdata("freedrugservice_master_table",$requestdata)){
                $message    = array("1","Successfully Submit");
            }else{
                $message    = array("0",$this->db->_error_message());
            }
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url("freedrugservice/freedrugservice_add_form"));
    }
	
   

    public function freedrugservice_edit(){
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Free Drugs Services Initiative', base_url('freedrugservice/index'));
        $data['page_type'] = 'FDSI'; 
		$data['states']    = $this->freedrugservice_model->get_state();		
        $data['row']   		=   $this->freedrugservice_model->fetchwhere("freedrugservice_master_table",array("id"=>$this->input->get('id')),"","row_array");		        
		loadLayout('programmanager/freedrugservice/form_add', 'program_manager', $data);
    }
	
    public function freedrugservice_update(){
        $requestdata    =   $this->freedrugservice_validate();
        	if(!empty($requestdata)){
	
			 if($this->freedrugservice_model->updatedata("freedrugservice_master_table",$requestdata,array("id"=>$this->input->post('id')))){
			    $message    = array("1","Successfully Update");
		
            }else{
                $message    = array("0",$this->db->_error_message());
                $this->session->set_flashdata('message', $message);
            }		
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('freedrugservice/freedrugservice_edit').'?action=edit&id='.$this->input->post('id'));
    }
	
    public function freedrugservice_delete(){
        
		if($this->input->get('id')){
            $this->freedrugservice_model->deletedata("freedrugservice_master_table",array("id"=>$this->input->get('id')));
			 $message    = array("1","Successfully Deleted");
			  $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('freedrugservice/freedrugservice_view'),'location');
    }
    
  
    
    
    
	
	
}