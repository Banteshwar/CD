<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Fssai extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
     
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
       
        $this->load->model('Dashboard_model');
		$this->load->model('programmanager/Fssainew_model');
		
		$this->load->model('hwc_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index($year_id='',$q_id='') { 
	
	
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('FSSAI', base_url('Fssai/index'));
		
		if($year_id)
		{
		$data['fin_year'] = $year_id;
		}
		else{
		$data['fin_year'] = getCurrFinYear('Quarterly');
		}	

    if($q_id)
		{
		$data['fin_querter'] = $q_id;
		}
		else{
		$data['fin_querter'] = getCurrQuarter('Quarterly'); 
		}			
		
		
		
        
        $data['page_type']='fssai';
       // $data['row'] = $this->Fssainew_model->get_Ambulances();
		
		$data['state']=$this->Fssainew_model->get_nrcp_State($data['fin_year'],$data['fin_querter']);
				       
        loadLayout('programmanager/Fssai/fssainew1', 'program_manager', $data);
    }
	
	
	
	public function form_save()
	{ 
	
	
       if (isset($_POST['submit']))
		  {
			
			
        
		  $this->form_validation->set_rules('year_id', 'Year', 'required');
		  $this->form_validation->set_rules('q_id', 'Quarter', 'required');
		  
			 
          if ($this->form_validation->run() == FALSE)
                {
                	    $this->session->set_flashdata('required','Something went wrong. Please try again later.');
					   
                	 	redirect('Fssai/index/');	
				}    
                else
                {
	             
						
                 $this->Fssainew_model->saveNrcp($_POST);
				

				$this->session->set_flashdata("success","Data has been submitted successfully.");
        
			    
				
				//$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('Fssai/index/'.$this->input->post("year_id").'/'.$this->input->post("q_id"));     
		  
		  }

		  }
	}

  /* For First Page */

  public function form_save1()
  { 
  
  
       if (isset($_POST['submit']))
      {
      
      
        
      $this->form_validation->set_rules('year_id', 'Year', 'required');
      $this->form_validation->set_rules('q_id', 'Quarter', 'required');
      
       
          if ($this->form_validation->run() == FALSE)
                {
                      $this->session->set_flashdata('required','Something went wrong. Please try again later.');
             
                    redirect('Fssai/index/'); 
        }    
                else
                {
               
            
                 $this->Fssainew_model->saveNrcp1($_POST);
        

        $this->session->set_flashdata("success","Data has been submitted successfully.");
        
          
        
        //$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('Fssai/index/'.$this->input->post("year_id").'/'.$this->input->post("q_id"));     
      
      }

      }
  }

  /* End */
	
	
	
	


	 
public function change_val_ajax($y_val,$q_val)
     {
		 
		 $data['state']=$this->Fssainew_model->get_nrcp_State_ajax($y_val,$q_val);
		 
		//echo print_r($data['state']); die;
		 
		 echo json_encode($data['state']);
		
		
		
	 
	 }
	 
	 
	 public function change_val_ajax2($y_val)
     {
		 
		 $data['state']=$this->Fssainew_model->get_nrcp_State_ajax2($y_val);
		 
		//echo print_r($data['state']); die;
		 
		 echo json_encode($data['state']);
		
		
		
	 
	 }
	 
	 public function change_val_ajax6($y_val)
     {
		 
		 $data['state']=$this->Fssainew_model->get_nrcp_State_ajax6($y_val);
		 
		//echo print_r($data['state']); die;
		 
		 echo json_encode($data['state']);
		
		
		
	 
	 }
	 
	 
	 public function change_val_ajax4($y_val,$y_month)
     {
		 
		 $data['state']=$this->Fssainew_model->get_nrcp_State_ajax4($y_val,$y_month);
		 
		//echo print_r($data['state']); die;
		 
		 echo json_encode($data['state']);
		
		
		
	 
	 }
	 
	 public function index2($year_id='') { 
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('FSSAI', base_url('Fssai/index2'));
		
		if($year_id)
		{
		$data['fin_year'] = $year_id;
		}
		else{
		$data['fin_year'] = getCurrYear('Yearly');
		}	

        $data['page_type']='fssai';
        $data['state']=$this->Fssainew_model->get_nrcp_State2($data['fin_year']);
				       
        loadLayout('programmanager/Fssai/fssainew_yearly', 'program_manager', $data);
				       
      
    }
	
	public function index6($year_id='') { 
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('FSSAI', base_url('Fssai/index6'));
		
		if($year_id)
		{
		$data['fin_year'] = $year_id;
		}
		else{
		$data['fin_year'] = getCurrYear('Yearly');
		}	

        $data['page_type']='fssai';
        $data['state']=$this->Fssainew_model->get_nrcp_State6($data['fin_year']);
				       
        loadLayout('programmanager/Fssai/fssainew_yearly2', 'program_manager', $data);
				       
      
    }
	
	
	
	
	
	public function index4($year_id='',$month='') { 
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('FSSAI', base_url('Fssai/index4'));
		
		if($year_id){
			$data['fin_year'] = $year_id;
		}else{
			$data['fin_year'] = getCurrYear('Monthly');
		}	


        if($month){
			$data['fin_month'] = $month;
		}else{
			$data['fin_month'] = getCurrMonth('Monthly'); 
		}		
				
        $data['page_type']='fssai';
       
		$data['state']  =  $this->Fssainew_model->get_nrcp_State4($data['fin_year'],$data['fin_month']);
		
		//$data['months'] =  $this->Fssainew_model->getmonth();

        loadLayout('programmanager/Fssai/fssainew_monthly', 'program_manager', $data);

    }
	
	 public function index5($year_id='',$q_id='') { 
	
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('FSSAI', base_url('Fssai/index5'));
		
		if($year_id)
		{
			$data['fin_year'] = $year_id;
		}
		else{
			$data['fin_year'] = getCurrFinYear('Quarterly');
		}	

        if($q_id)
		{
			$data['fin_querter'] = $q_id;
		}
		else{
			$data['fin_querter'] = getCurrQuarter('Quarterly'); 
		}
		
        $data['page_type']='fssai';
      
		$data['state']=$this->Fssainew_model->get_nrcp_State5($data['fin_year'],$data['fin_querter']);
				       
        loadLayout('programmanager/Fssai/fssainew2', 'program_manager', $data);
    }
	
	
	public function form_save2()
	{ 
       if (isset($_POST['submit']))
		  {
		  $this->form_validation->set_rules('year_id', 'Year', 'required');
		 	  
		  
			 
          if ($this->form_validation->run() == FALSE)
                {
                	    $this->session->set_flashdata('required','Something went wrong. Please try again later.');
					   
                	 	redirect('fssai/index2/');	
				}    
                else
                {
	             
						
                 $this->Fssainew_model->saveNrcp2($_POST);
				

				$this->session->set_flashdata("success","Data has been submitted successfully.");
        
			    
				
				//$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('fssai/index2/'.$this->input->post("year_id").'/'.$this->input->post("q_id"));     
		  
		  }

		  }
	}
	
	
	
	public function form_save6()
	{ 
	
	
       if (isset($_POST['submit']))
		  {
			
			
        
		  $this->form_validation->set_rules('year_id', 'Year', 'required');
		 	  
		  
			 
          if ($this->form_validation->run() == FALSE)
                {
                	    $this->session->set_flashdata('required','Something went wrong. Please try again later.');
					   
                	 	redirect('fssai/index6/');	
				}    
                else
                {
	             
						
                 $this->Fssainew_model->saveNrcp6($_POST);
				

				$this->session->set_flashdata("success","Data has been submitted successfully.");
        
			    
				
				//$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('fssai/index6/'.$this->input->post("year_id").'/'.$this->input->post("q_id"));     
		  
		  }

		  }
	}
	
	
		public function form_save4()
	{ 
	
	if (isset($_POST['submit'])){
        
		  $this->form_validation->set_rules('year_id','Year', 'required');
		  $this->form_validation->set_rules('month', 'Month', 'required');
		  
			 
           if ($this->form_validation->run() == FALSE){
                $this->session->set_flashdata('required','Something went wrong. Please try again later.');	   
                redirect('Fssai/index4/');	
		   } else {
	    					
                $this->Fssainew_model->saveNrcp4($_POST);
				$this->session->set_flashdata("success","Data has been submitted successfully.");				
                redirect('Fssai/index4/'.$this->input->post("year_id").'/'.$this->input->post("month"));
           }

		  }
		  
	
	
	}
	
	
	
	public function form_save5()
	{ 
	
	
       if (isset($_POST['submit']))
		  {
			
			
        
		  $this->form_validation->set_rules('year_id', 'Year', 'required');
		  $this->form_validation->set_rules('q_id', 'Quarter', 'required');
		  
			 
          if ($this->form_validation->run() == FALSE)
                {
                	    $this->session->set_flashdata('required','Something went wrong. Please try again later.');
					   
                	 	redirect('Fssai/index5/');	
				}    
                else
                {
	             
						
                 $this->Fssainew_model->saveNrcp5($_POST);
				
				$this->session->set_flashdata("success","Data has been submitted successfully.");
        
			    
				
				//$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('Fssai/index5/'.$this->input->post("year_id").'/'.$this->input->post("q_id"));     
		  
		  }

		  }
	}
	
	
	
	


	 
public function change_val_ajax5($y_val,$q_val)
     {
		 
		 $data['state']=$this->Fssainew_model->get_nrcp_State_ajax5($y_val,$q_val);
		 
		//echo print_r($data['state']); die;
		 
		 echo json_encode($data['state']);
		
		
		
		
	 
	 }

	  public function index3($year_id='',$q_id='') { 
	
	
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('FSSAI', base_url('Fssai/index3'));
		
		if($year_id)
		{
		$data['fin_year'] = $year_id;
		}
		else{
		$data['fin_year'] = getCurrFinYear('Quarterly');
		}	

        if($q_id)
		{
		$data['fin_querter'] = $q_id;
		}
		else{
		$data['fin_querter'] = getCurrQuarter('Quarterly'); 
		}			
		
		
		
        
        $data['page_type']='fssai';
       // $data['row'] = $this->Fssainew_model->get_Ambulances();
		
		$data['state']=$this->Fssainew_model->get_nrcp_State3($data['fin_year'],$data['fin_querter']);
				       
        loadLayout('programmanager/Fssai/fssainew3', 'program_manager', $data);
    }
	
	
	
	public function form_save3()
	{ 
	
	
        if (isset($_POST['submit']))
		{
        
		  $this->form_validation->set_rules('year_id', 'Year', 'required');
		  $this->form_validation->set_rules('q_id', 'Quarter', 'required');
		  
			 
          if ($this->form_validation->run() == FALSE)
                {
                	    $this->session->set_flashdata('required','Something went wrong. Please try again later.');
					   
                	 	redirect('Fssai/index3/');	
				}    
                else
                {
	             
						
                 $this->Fssainew_model->saveNrcp3($_POST);
				
				$this->session->set_flashdata("success","Data has been submitted successfully.");
        
			    
				
				//$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('Fssai/index3/'.$this->input->post("year_id").'/'.$this->input->post("q_id"));     
		  
		  }

		  }
	}
	
	
	
	


	 
public function change_val_ajax3($y_val,$q_val)
     {
		 
		 $data['state']=$this->Fssainew_model->get_nrcp_State_ajax3($y_val,$q_val);
		 
		//echo print_r($data['state']); die;
		 
		 echo json_encode($data['state']);
		
		
		
		die;
	// $data['state']=$this->Fssainew_model->get_Ambulances_State($fin_year,$fin_querter);
	 
	 }
	 
	  public function deletefs($id){

     $ss=$this->db->delete('fssais_master_tbl', array('id' => $id));
	   
	   if($ss){
		   echo "1";
	   }else{
		   echo "0";
	   }
    }
	
	public function deletefs1($id){

     $ss=$this->db->delete('fssai_master_tbl5', array('id' => $id));
	   
	   if($ss){
		   echo "1";
	   }else{
		   echo "0";
	   }
    }
	
	public function deletefs2($id){

     $ss=$this->db->delete('fssai_master_tbl2', array('id' => $id));
	   
	   if($ss){
		   echo "1";
	   }else{
		   echo "0";
	   }
    }
	
	public function deletefs3($id){

     $ss=$this->db->delete('fssai_master_tbl3', array('id' => $id));
	   
	   if($ss){
		   echo "1";
	   }else{
		   echo "0";
	   }
    }
	
		public function deletefs4($id){

     $ss=$this->db->delete('fssai_master_tbl4', array('id' => $id));
	   
	   if($ss){
		   echo "1";
	   }else{
		   echo "0";
	   }
    }
	
		public function deletefs5($id){

     $ss=$this->db->delete('fssai_master_tbl6', array('id' => $id));
	   
	   if($ss){
		   echo "1";
	   }else{
		   echo "0";
	   }
    }
  
}
