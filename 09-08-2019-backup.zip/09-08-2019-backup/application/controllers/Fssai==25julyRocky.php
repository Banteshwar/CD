<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Fssai extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
     
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('hwc_model');
        $this->load->model('Dashboard_model');
        $this->load->model('Report_model');
        $this->load->model('programmanager/Fssai_model');

     $this->load->model('Programmanager_model');
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index() { 
   
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('FSSAI', base_url('Fssai/fssai_list'));
        
        $data['page_type']='fssai';

       $data['fssai']=$this->Fssai_model->fssai_list();
       
    loadLayout('programmanager/Fssai/fssai_list', 'program_manager', $data);
    }
     public function index2() { 
   
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('FSSAI', base_url('Fssai/fssai_list2'));
        
        $data['page_type']='fssai';

       $data['fssai2']=$this->Fssai_model->fssai_list2();
       
    loadLayout('programmanager/Fssai/fssai_list2', 'program_manager', $data);
    }
  
  public function index3() { 
   
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('FSSAI', base_url('Fssai/fssai_list3'));
        
        $data['page_type']='fssai';

       $data['fssai3']=$this->Fssai_model->fssai_list3();
       
    loadLayout('programmanager/Fssai/fssai_list3', 'program_manager', $data);
    }
    public function index4() { 
   
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('FSSAI', base_url('Fssai/fssai_list4'));
        
        $data['page_type']='fssai';

       $data['fssai4']=$this->Fssai_model->fssai_list4();
       
    loadLayout('programmanager/Fssai/fssai_list4', 'program_manager', $data);
    }

  public function fssai_add() { 
     
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('FSSAI', base_url('Fssai/fssai_add'));
        $data['page_type']='fssai';
        
       
    loadLayout('programmanager/Fssai/fssai_add', 'program_manager', $data);
    }
    
public function fssai_add2() { 
     
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('FSSAI', base_url('Fssai/fssai_add2'));
        $data['page_type']='fssai';
        
       
    loadLayout('programmanager/Fssai/fssai_add2', 'program_manager', $data);
    }


    public function fssai_add3() { 
     
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('FSSAI', base_url('Fssai/fssai_add3'));
        $data['page_type']='fssai';
        
       
    loadLayout('programmanager/Fssai/fssai_add3', 'program_manager', $data);
    }

    public function fssai_add4() { 
     
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('FSSAI', base_url('Fssai/fssai_add4'));
        $data['page_type']='fssai';
        
       
    loadLayout('programmanager/Fssai/fssai_add4', 'program_manager', $data);
    }
   public function fssai_submit(){
         if (isset($_POST['submit']))
          {
             
          $this->form_validation->set_rules('Total_number_of_State_Food', 'RTI_Applications_Received', 'required');
          
         
         
          if ($this->form_validation->run() == FALSE)
                {

                         redirect('Fssai/fssai_add');    
                      
                }
                else
                {
                     $insert=array(
                       

'Total_number_of_State_Food'=>$this->input->post('Total_number_of_State_Food'),
'Total_number_of_Food'=>$this->input->post('Total_number_of_Food'),
'year'=>$this->input->post('year'),
'Quarterly'=>$this->input->post('Quarterly')





);
   $result = $this->Fssai_model->chkfssai($this->input->post('year'),$this->input->post('Quarterly'));
                  
                  

                ///////////// end check availability ///////////
                
                if($result>0)
                {
                    
                    
                 $this->session->set_flashdata("already_added","Record already added.");
                 
                    
                     redirect('Fssai/fssai_add');                    
                        
                }
                else
                {
                $this->Fssai_model->insertfssai($insert);

                $this->session->set_flashdata("success","Data has been submitted successfully.");
        
                }
                
                //$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('Fssai/index');     
          
          }

        }
    }
    

 public function fssai_submit2(){
         if (isset($_POST['submit2']))
          {
             
          $this->form_validation->set_rules('Central_Government_institutes', 'Central_Government_institutes', 'required');
          
         
         
          if ($this->form_validation->run() == FALSE)
                {

                         redirect('Fssai/fssai_add2');    
                      
                }
                else
                {
                     $insert=array(
                       


    'Central_Government_institutes'=>$this->input->post('Central_Government_institutes'),
'State_Food_Laboratories'=>$this->input->post('State_Food_Laboratories'),
'year'=>$this->input->post('year'),
'State_Government_laboratories'=>$this->input->post('State_Government_laboratories'),

'Central_Government_institutes2'=>$this->input->post('Central_Government_institutes2'),

'FSSAIs_Own_Laboratories'=>$this->input->post('FSSAIs_Own_Laboratories'),

'Private_Laboratories'=>$this->input->post('Private_Laboratories'),


'Private_Laboratories'=>$this->input->post('Private_Laboratories')






);
   $result = $this->Fssai_model->chkfssai2($this->input->post('year'));
                  
                  

                ///////////// end check availability ///////////
                
                if($result>0)
                {
                    
                    
                 $this->session->set_flashdata("already_added","Record already added.");
                 
                    
                     redirect('Fssai/fssai_add2');                    
                        
                }
                else
                {
                $this->Fssai_model->insertfssai2($insert);

                $this->session->set_flashdata("success","Data has been submitted successfully.");
        
                }
                
                //$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('Fssai/index2');     
          
          }

        }
    }
    

    public function fssai_submit3(){
         if (isset($_POST['submit3']))
          {
             
          $this->form_validation->set_rules('Number_of_Central_Food_Safety_Officers', 'Number_of_Central_Food_Safety_Officers', 'required');
          
         
         
          if ($this->form_validation->run() == FALSE)
                {

                         redirect('Fssai/fssai_add3');    
                      
                }
                else
                {
                     $insert=array(
                       

'Number_of_Central_Food_Safety_Officers'=>$this->input->post('Number_of_Central_Food_Safety_Officers'),
'Number_of_posts_filled_up_in_fssai'=>$this->input->post('Number_of_posts_filled_up_in_fssai'),
'year'=>$this->input->post('year'),
'Quarterly'=>$this->input->post('Quarterly')





);
   $result = $this->Fssai_model->chkfssai3($this->input->post('year'),$this->input->post('Quarterly'));
                  
                  

                ///////////// end check availability ///////////
                
                if($result>0)
                {
                    
                    
                 $this->session->set_flashdata("already_added","Record already added.");
                 
                    
                     redirect('Fssai/fssai_add3');                    
                        
                }
                else
                {
                $this->Fssai_model->insertfssai3($insert);

                $this->session->set_flashdata("success","Data has been submitted successfully.");
        
                }
                
                //$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('Fssai/index3');     
          
          }

        }
    }

public function fssai_submit4(){
         if (isset($_POST['submit4']))
          {
             
          $this->form_validation->set_rules('Center_Licenses', 'Center_Licenses', 'required');
          
         
         
          if ($this->form_validation->run() == FALSE)
                {

                         redirect('Fssai/fssai_add4');    
                      
                }
                else
                {
                     $insert=array(
                       

'Center_Licenses'=>$this->input->post('Center_Licenses'),
'State_Licenses'=>$this->input->post('State_Licenses'),
'No_of_FBOs_registered'=>$this->input->post('No_of_FBOs_registered'),

'year'=>$this->input->post('year'),
'Weekly'=>$this->input->post('Weekly')





);
   $result = $this->Fssai_model->chkfssai4($this->input->post('year'),$this->input->post('Weekly'));
                  
                  

                ///////////// end check availability ///////////
                
                if($result>0)
                {
                    
                    
                 $this->session->set_flashdata("already_added","Record already added.");
                 
                    
                     redirect('Fssai/fssai_add4');                    
                        
                }
                else
                {
                $this->Fssai_model->insertfssai4($insert);

                $this->session->set_flashdata("success","Data has been submitted successfully.");
        
                }
                
                //$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('Fssai/index4');     
          
          }

        }
    }

    public function fssai_edit($id){
       $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('FSSAI', base_url('Fssai/fssai_update'));
        $data['page_type']='fssai';     
        $data['value'] = $this->Fssai_model->fssai_edit_show($id);
        
       
        loadLayout('programmanager/Fssai/fssai_update', 'program_manager', $data);

    }
    public function fssai_edit2($id){
       $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('FSSAI', base_url('Fssai/fssai_update2'));
        $data['page_type']='fssai';     
        $data['value'] = $this->Fssai_model->fssai_edit_show2($id);
        
       
        loadLayout('programmanager/Fssai/fssai_update2', 'program_manager', $data);

    }
     public function fssai_edit3($id){
       $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('FSSAI', base_url('Fssai/fssai_update3'));
        $data['page_type']='fssai';     
        $data['value'] = $this->Fssai_model->fssai_edit_show3($id);
        
       
        loadLayout('programmanager/Fssai/fssai_update3', 'program_manager', $data);

    }

    public function fssai_edit4($id){
       $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('FSSAI', base_url('Fssai/fssai_update4'));
        $data['page_type']='fssai';     
        $data['value'] = $this->Fssai_model->fssai_edit_show4($id);
        
       
        loadLayout('programmanager/Fssai/fssai_update4', 'program_manager', $data);

    }


    public function fssai_update()
    {      

      if (isset($_POST['update']))
          {
                $id = $this->input->post('id');

             $data = array
                   (                    
                    
 'Total_number_of_State_Food'=>$this->input->post('Total_number_of_State_Food'),
'Total_number_of_Food'=>$this->input->post('Total_number_of_Food'),
'year'=>$this->input->post('year'),
'Quarterly'=>$this->input->post('Quarterly'),


                    'updated_date'=> $this->input->post(date('updated_date')),

                    'updated_by'=>  (isset($_SESSION['memberID']))
                                                    
                );
     

                $result = $this->Fssai_model->fssai_update_data($id,$data);
               
        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
            
         }
           redirect('fssai/index',$id);

          }
    }
     public function fssai_update2()
    {      

      if (isset($_POST['update2']))
          {
                $id = $this->input->post('id');

             $data = array
                   (                    
                    
 'Central_Government_institutes'=>$this->input->post('Central_Government_institutes'),
'State_Food_Laboratories'=>$this->input->post('State_Food_Laboratories'),
'year'=>$this->input->post('year'),
'State_Government_laboratories'=>$this->input->post('State_Government_laboratories'),

'Central_Government_institutes2'=>$this->input->post('Central_Government_institutes2'),

'FSSAIs_Own_Laboratories'=>$this->input->post('FSSAIs_Own_Laboratories'),

'Private_Laboratories'=>$this->input->post('Private_Laboratories'),


'Private_Laboratories'=>$this->input->post('Private_Laboratories'),


                    'updated_date'=> $this->input->post(date('updated_date')),

                    'updated_by'=>  (isset($_SESSION['memberID']))
                                                    
                );
     

                $result = $this->Fssai_model->fssai_update_data2($id,$data);
               
        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
            
         }
           redirect('fssai/index',$id);

          }
    }

    public function fssai_update3()
    {      

      if (isset($_POST['update3']))
          {
                $id = $this->input->post('id');

             $data = array
                   (                    
                    
 'Number_of_Central_Food_Safety_Officers'=>$this->input->post('Number_of_Central_Food_Safety_Officers'),
'Number_of_posts_filled_up_in_fssai'=>$this->input->post('Number_of_posts_filled_up_in_fssai'),
'year'=>$this->input->post('year'),
'Quarterly'=>$this->input->post('Quarterly'),


                    'update_date'=> $this->input->post(date('update_date')),

                    'updated_by'=>  (isset($_SESSION['memberID']))
                                                    
                );
     

                $result = $this->Fssai_model->fssai_update_data3($id,$data);
               
        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
            
         }
           redirect('fssai/index3',$id);

          }
    }


    public function fssai_update4()
    {      

      if (isset($_POST['update4']))
          {
                $id = $this->input->post('id');

             $data = array
                   (                    
                    
 'Center_Licenses'=>$this->input->post('Center_Licenses'),
'State_Licenses'=>$this->input->post('State_Licenses'),
'No_of_FBOs_registered'=>$this->input->post('No_of_FBOs_registered'),

'year'=>$this->input->post('year'),
'Weekly'=>$this->input->post('Weekly'),


                    'updated_date'=> $this->input->post(date('updated_date')),

                    'updated_by'=>  (isset($_SESSION['memberID']))
                                                    
                );
     

                $result = $this->Fssai_model->fssai_update_data4($id,$data);
               
        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
            
         }
           redirect('fssai/index4',$id);

          }
    }
     
   
    public function delete($id)
     {
       $this->db->delete('fssais_master_tbl', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('Fssai/index'));
     }
public function deletesecond($id)
     {
       $this->db->delete('fssai_master_tbl2', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('Fssai/index'));
     }
     
     public function deletethird($id)
     {
       $this->db->delete('fssai_master_tbl3', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('Fssai/index3'));
     }
     public function deletefourth($id)
     {
       $this->db->delete('fssai_master_tbl4', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('Fssai/index4'));
     }
}

