<?php

defined('BASEPATH') OR exit('No direct script access allowed');

//  require_once APPPATH . 'third_party/jcryption/sqAES.php';
//require_once APPPATH . 'third_party/jcryption/JCryption.php';


class G extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
    }

    public function index($value='')
    {

        // query echo 'SELECT 
        echo 'SELECT hwc.NIN_2_HFI,hhf.HFI_Type,SUM(IF(hhf.HFI_Type = 1,1,0)) AS phc_operation
             from t_hwc as hwc INNER JOIN hmis_healthfacilities as hhf ON(hwc.NIN_2_HFI=hhf.NIN_2_HFI) where hwc.criteria=8';
         
         
        // $this->hwc_model->getFocusWiseStateDetails();

        // end query
    	loadLayout('admin/graphic', 'admin', '0');
    }
    

}
