<?php

defined('BASEPATH') OR exit('No direct script access allowed');

//  require_once APPPATH . 'third_party/jcryption/sqAES.php';
//require_once APPPATH . 'third_party/jcryption/JCryption.php';
class HWCPlanningSheet extends MY_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('HwcPlanning_model');
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
    }
    public function index() {
        global $CURRENT_USER_STATE, $CURRENT_USER_ROLE;
        $user = $this->user;
        if (isHavingState($user)) {
            $State_ID = $CURRENT_USER_STATE;
        } elseif ($CURRENT_USER_ROLE == 3) {
            $State_ID = 0;
        }


        $Planning_Year_Data = $this->HwcPlanning_model->getPlanningData($State_ID);
        $data['Planning_Year_Data'] = $Planning_Year_Data;
        loadLayout('admin/HWC_Planning_Sheet', 'admin', $data);
    }

    public function addFinancialYear() {
        $data = array();
        $user = $this->user;
        $data['user'] = $user;
        loadLayout('admin/hwc_planning/addFinancialYear', 'popup', $data);
    }

    public function saveFinancialYear($value='')
    {
        $user = $this->user;
        $error = array();
        $state = 0;
        global $CURRENT_USER_STATE, $CURRENT_USER_ROLE, $FINANCIAL_YEAR;

        if (isset($_POST)) {
             extract($_POST);
            if (isHavingState($user)) {
                $State_ID = $CURRENT_USER_STATE;
                } elseif ($CURRENT_USER_ROLE == 3) {
                    $State_ID = $state;
                } else {
                $error[] = "Permission Error..! <br>You are not allowed to perform this action. ";
            }

            if ($State_ID == 0) {
                $error[] = "State ID not found. ";
            }

            if (trim($financial_year) == 0 || trim($financial_year) == '') {
                $error[] = "Please select a financial year ";
            }

            if (count($error) == 0) {
                $checkExistFinancialYear = $this->HwcPlanning_model->checkExistFinancialYear($State_ID, $financial_year);
                if ($checkExistFinancialYear) {
                    $error[] = 'Entry all ready exist for Financial Year ' . $FINANCIAL_YEAR[$financial_year] . '.';
                }
            }

            if (count($error) == 0) {
                  $planningFormYear = [
                    'financial_year' => intval($financial_year),
                    'State_ID' => intval($State_ID),
                    'y_uphc' => intval($y_uphc),
                    'y_phc' => intval($y_phc),
                    'y_shc' => intval($y_shc),
                ];
                try {
                   $getResponse = $this->HwcPlanning_model->planningYearDataSave($planningFormYear);
                } catch (Exception $e) {
                    $error[] = $e;
                }
                if (!$getResponse) {
                    $error[] = 'Somthing error';
                }
                        }
        } else {
            $error[] = 'Invalid Request';
        }


        if (count($error) == 0) {
            $responseArray = array('status' => 'success', 'status_msg' => 'Record Updated Successfully!', 'return_url' => base_url('HWCPlanningSheet'));
            status_message('Record Updated Successfully');
        } else {
            $errors = error_format($error);
            $responseArray = array('status' => 'error', 'status_msg' => $errors, 'token' => generatetoken());
        }
          JSONArrayResponse($responseArray);
           exit;
    }

    public function updateFinancialYear($value='')
    {
        if (isset($_POST)) {
            extract($_POST);
        if (!empty($year_State_ID) && !empty($year_financial_year)) {
                     $planningFormYear = [
                    'y_uphc' => intval($y_uphc),
                    'y_phc' => intval($y_phc),
                    'y_shc' => intval($y_shc),
                ];
                try {
                   $getResponse = $this->HwcPlanning_model->planningYearDataUpdate($planningFormYear,$year_State_ID,$year_financial_year);
                   // showData($getResponse);die();
                   if($getResponse == true) {
                    status_message('Financial Year Info Updated successfully.');
                   }else{
                    status_message('Financial Year Info Updated Successfully.');
                   }
                   redirect('HWCPlanningSheet/updateQuarterPlan/' . $year_State_ID.'/'.$year_financial_year);
                } catch (Exception $e) {
                    $error[] = $e;
                }
                if (!$getResponse) {
                    $error[] = 'Somthing error';
            }
          }else{
            error_message('Somthing Error in financial year AND State User.');
          }
        }
    }

    /**
     * @return [type]
     */
    public function updateQuarterPlan() {
        $data = array();
        $State_ID = $this->uri->segment(3);
        $financial_year = $this->uri->segment(4);

        // print_r($financial_year);

        if($State_ID & $financial_year){
            $data['getEditInfoYear'] = $this->HwcPlanning_model->getEditInfoYear($State_ID,$financial_year);
            $data['getEditInfoQuarters'] = $this->HwcPlanning_model->getEditInfoQuarter($State_ID,$financial_year);
        }


//        if (isset($_POST) && count($_POST) > 0) {
//            $y_uphc = $checkExistFinancialyear ? $checkExistFinancialyear[0]->y_uphc : '';
//            $y_phc = $checkExistFinancialyear ? $checkExistFinancialyear[0]->y_phc : '';
//            $y_shc = $checkExistFinancialyear ? $checkExistFinancialyear[0]->y_shc : '';
//            $financial_year = $checkExistFinancialyear ? $checkExistFinancialyear[0]->financial_year : '';
//// start quarter 1
//            $q_uphc1 = $checkExistFinancialyear[0]->q_uphc ? $checkExistFinancialyear[0]->q_uphc : '';
//            $q_phc1 = $checkExistFinancialyear[0]->q_phc ? $checkExistFinancialyear[0]->q_phc : '';
//            $q_shc1 = $checkExistFinancialyear[0]->q_shc ? $checkExistFinancialyear[0]->q_shc : '';
//            $quarter1 = $checkExistFinancialyear[0]->quarter ? $checkExistFinancialyear[0]->quarter : '';
//// end quarter 1
//// start quarter 2
//            $q_uphc2 = $checkExistFinancialyear[1]->q_uphc ? $checkExistFinancialyear[1]->q_uphc : '';
//            $q_phc2 = $checkExistFinancialyear[1]->q_phc ? $checkExistFinancialyear[1]->q_phc : '';
//            $q_shc2 = $checkExistFinancialyear[1]->q_shc ? $checkExistFinancialyear[1]->q_shc : '';
//            $quarter2 = $checkExistFinancialyear[1]->quarter ? $checkExistFinancialyear[1]->quarter : '';
//// end quarter 2
//// start quarter 3
//            $q_uphc3 = $checkExistFinancialyear[2]->q_uphc ? $checkExistFinancialyear[2]->q_uphc : '';
//            $q_phc3 = $checkExistFinancialyear[2]->q_phc ? $checkExistFinancialyear[2]->q_phc : '';
//            $q_shc3 = $checkExistFinancialyear[2]->q_shc ? $checkExistFinancialyear[2]->q_shc : '';
//            $quarter3 = $checkExistFinancialyear[2]->quarter ? $checkExistFinancialyear[2]->quarter : '';
//// end quarter 3
//// start quarter 4
//            $q_uphc4 = $checkExistFinancialyear[3]->q_uphc ? $checkExistFinancialyear[3]->q_uphc : '';
//            $q_phc4 = $checkExistFinancialyear[3]->q_phc ? $checkExistFinancialyear[3]->q_phc : '';
//            $q_shc4 = $checkExistFinancialyear[3]->q_shc ? $checkExistFinancialyear[3]->q_shc : '';
//            $quarter4 = $checkExistFinancialyear[3]->quarter ? $checkExistFinancialyear[3]->quarter : '';
//        }



        $data['_REQUEST'] = $_REQUEST;
        loadLayout('admin/hwc_planning/update_Quarter_Plan', 'admin', $data);
    }


    public function saveFinancialQuarter($value='')
    {
        $currentFinancialYear = getCurrentQuarterFYear('Y');
        $currentQuarter = getCurrentQuarterFYear('Q');
        extract($_POST);
 
        foreach ($q_uphc as $key => $valueUphc) {
           $CurrentFY = getCurrentQuarterFYear('Y');
            $CurrentFQ = getCurrentQuarterFYear('Q');

            if ($CurrentFQ == $key) {
                $storePlanningData = [
                'State_ID' => $year_State_ID,
                'financial_year' => $CurrentFY,
                'quarter' => $CurrentFQ,
                'q_uphc' => $q_uphc[$CurrentFQ],
                'q_phc' => $q_phc[$CurrentFQ],
                'q_shc' => $q_shc[$CurrentFQ]
            ];
           $restult = $this->HwcPlanning_model->financialQuarterStore($storePlanningData);
       }
    }
        
  if ($restult) {
            status_message('Quarterly Plan Update ');
        } else {
            error_message('error');
        }

                   redirect('HWCPlanningSheet/updateQuarterPlan/' . $year_State_ID . '/' . $year_financial_year);


        // showData($checkExistFinancialQuarter);
    }

}
