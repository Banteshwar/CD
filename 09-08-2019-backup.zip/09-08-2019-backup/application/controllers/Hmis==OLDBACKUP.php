<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Hmis extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
     
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
       
        $this->load->model('Dashboard_model');
		$this->load->model('programmanager/Hmis_model');
		
		 $this->load->model('hwc_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index() { 
	
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('HMIS', base_url('Hmis/form_list'));
        
        $data['page_type']='HMIS';
        $data['row'] = $this->Hmis_model->get_Hmis();
				       
        loadLayout('programmanager/Hmis/form_list', 'program_manager', $data);
    }
	
	public function form_add() { 
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('HMIS', base_url('Hmis/form_add'));
		
		$data['state']=$this->hwc_model->get_state();
        
        $data['page_type']='HMIS';
      
       
        loadLayout('programmanager/Hmis/form_add', 'program_manager', $data);
    }
	
	public function form_save()
	{
			
       if (isset($_POST['submit']))
		  {
			//echo "in";die;   
         // $this->form_validation->set_rules();
			 
         // if ($this->form_validation->run() == FALSE)
             //   {
					
                	 	//$data['state']=$this->hwc_model->get_state();
                	 	//redirect('Hmis/form_add');	
                       // $this->load->view('programmanager/nvhcp/nvhcp_form_add',$data);
               // }
              //  else
              //  {

           $data = array
				   (	 				
					
					'anc_registration'=> $this->input->post('areg'),
					'estimated_preg'=> $this->input->post('epreg'),
					
					'institution_delevery'=> $this->input->post('ins_del'),
					'estimated_delevery'=>$this->input->post('est_del'),
					'female_birth'=>$this->input->post('fbirth'),
					'male_birth'=>$this->input->post('mbirth'),
					'imr'=>$this->input->post('imr'),
					'mmr'=>$this->input->post('mmr'),
					'year'=>$this->input->post('e_year'),
					'month'=>$this->input->post('e_month'),
					'updated_by'=>  (isset($_SESSION['memberID']))
					
					
													
			  	);
				//echo "<pre>";
                //print_r($data);die;
                /////// chk availability /////////
                 
                 //$result = $this->Hmis_model->chkNvbdcp($this->input->post('state_name'),$this->input->post('e_year'),$this->input->post('type'));
                  
				 
                ///////////// end check availability ///////////
                $result =0;
                if($result>0)
                {
					
					
                 $this->session->set_flashdata("already_added","Record already added.");
                 
					
				  redirect('Hmis/add_form');					
						
                }
                else
                {
				$this->Hmis_model->insertHmis($data);

				$this->session->set_flashdata("success","Data has been submitted successfully.");
        
			    }
				
				//$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('Hmis/index');     
		  
		  //}

		  }
	}
	
	public function edit_form($id)
	{
		
	   //$data['state']=$this->hwc_model->get_state();
       $data['value'] = $this->Hmis_model->getHmis_byId($id);
	   
	 // echo print_r($data['value']); die;
	   
	
       $data['page_type']='HMIS';

	    loadLayout('programmanager/Hmis/form_edit', 'program_manager', $data);

	}
	
	public function form_update($id)
	{      
      if (isset($_POST['update']))
		  {
		  	 $data = array
				   (	 				
					
					'anc_registration'=> $this->input->post('areg'),
					'estimated_preg'=> $this->input->post('epreg'),
					
					'institution_delevery'=> $this->input->post('ins_del'),
					'estimated_delevery'=>$this->input->post('est_del'),
					'female_birth'=>$this->input->post('fbirth'),
					'male_birth'=>$this->input->post('mbirth'),
					'imr'=>$this->input->post('imr'),
					'mmr'=>$this->input->post('mmr'),
					'year'=>$this->input->post('e_year'),
					'month'=>$this->input->post('e_month'),
					'updated_by'=>  (isset($_SESSION['memberID']))
					
					
													
			  	);
                
      

		$result = $this->Hmis_model->updateHmis_byId($id,$data);
	

        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
			
	     }
         redirect(base_url('Hmis/edit_form/'. $id));

		  }
	}
	

public function delete($id)
     {
       $this->db->delete('hmis_master_table', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('nohp/index'));
     }
  
}
