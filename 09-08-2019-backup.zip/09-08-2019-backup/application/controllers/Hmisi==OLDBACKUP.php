<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Hmisi extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
     
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
       
        $this->load->model('Dashboard_model');
		$this->load->model('programmanager/Hmisi_model');
		
		 $this->load->model('hwc_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index() { 
	
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('HMIS', base_url('Hmisi/form_list'));
        
        $data['page_type']='HMIS';
        $data['row'] = $this->Hmisi_model->get_Hmisi();
				     
        loadLayout('programmanager/Hmis/iform_list', 'program_manager', $data);
    }
	
	public function form_add() { 
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('HMIS', base_url('Hmisi/form_add'));
		
		$data['state']=$this->hwc_model->get_state();
        
        $data['page_type']='HMIS';
      
       
        loadLayout('programmanager/Hmis/iform_add', 'program_manager', $data);
    }
	
	public function form_save()
	{
			
       if (isset($_POST['submit']))
		  {
			//echo "in";die;   
         // $this->form_validation->set_rules();
			 
         // if ($this->form_validation->run() == FALSE)
             //   {
					
                	 	//$data['state']=$this->hwc_model->get_state();
                	 	//redirect('Hmis/form_add');	
                       // $this->load->view('programmanager/nvhcp/nvhcp_form_add',$data);
               // }
              //  else
              //  {

           $data = array
				   (	 				
					
					'year'=> $this->input->post('e_year'),
					'quarter'=> $this->input->post('quarter'),
					
					'newborns'=> $this->input->post('nborn'),
					'reported_live_birth'=>$this->input->post('rlb'),
					'infants'=>$this->input->post('infants'),
					'total_estimated_infants'=>$this->input->post('tei'),
					'updated_by'=>  (isset($_SESSION['memberID']))
					
					
													
			  	);
				//echo "<pre>";
                //print_r($data);die;
                /////// chk availability /////////
                 
                 //$result = $this->Hmis_model->chkNvbdcp($this->input->post('state_name'),$this->input->post('e_year'),$this->input->post('type'));
                  
				 
                ///////////// end check availability ///////////
                $result =0;
                if($result>0)
                {
					
					
                 $this->session->set_flashdata("already_added","Record already added.");
                 
					
				  redirect('Hmisi/add_form');					
						
                }
                else
                {
				$this->Hmisi_model->insertHmisi($data);

				$this->session->set_flashdata("success","Data has been submitted successfully.");
        
			    }
				
				//$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('Hmisi/index');     
		  
		  //}

		  }
	}
	
	public function edit_form($id)
	{
		
	   //$data['state']=$this->hwc_model->get_state();
       $data['value'] = $this->Hmisi_model->getHmisi_byId($id);
	   
	 // echo print_r($data['value']); die;
	   
	
       $data['page_type']='HMIS';

	    loadLayout('programmanager/Hmis/iform_edit', 'program_manager', $data);

	}
	
	public function form_update($id)
	{      
      if (isset($_POST['update']))
		  {
		  	 $data = array
				   (	 				
					
					'year'=> $this->input->post('e_year'),
					'quarter'=> $this->input->post('quarter'),
					
					'newborns'=> $this->input->post('nborn'),
					'reported_live_birth'=>$this->input->post('rlb'),
					'infants'=>$this->input->post('infants'),
					'total_estimated_infants'=>$this->input->post('tei'),
					'updated_by'=>  (isset($_SESSION['memberID']))
					
					
													
			  	);
                
      

		$result = $this->Hmisi_model->updateHmisi_byId($id,$data);
	

        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
			
	     }
         redirect(base_url('Hmisi/edit_form/'. $id));

		  }
	}
	

public function delete($id)
     {
       $this->db->delete(' hmis_immunization', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('Hmisi/index'));
     }
  
}
