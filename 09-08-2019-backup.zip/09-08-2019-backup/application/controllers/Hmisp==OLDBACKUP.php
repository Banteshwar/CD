<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Hmisp extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
     
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
       
        $this->load->model('Dashboard_model');
		$this->load->model('programmanager/Hmisp_model');
		
		 $this->load->model('hwc_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index() { 
	
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('HMIS', base_url('Hmisp/form_list'));
        
        $data['page_type']='HMIS';
        $data['row'] = $this->Hmisp_model->get_Hmisp();
				     
        loadLayout('programmanager/Hmis/pform_list', 'program_manager', $data);
    }
	
	public function form_add() { 
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('HMIS', base_url('Hmisp/form_add'));
		
		$data['state']=$this->hwc_model->get_state();
        
        $data['page_type']='HMIS';
      
       
        loadLayout('programmanager/Hmis/pform_add', 'program_manager', $data);
    }
	
	public function form_save()
	{
			
       if (isset($_POST['submit']))
		  {
			//echo "in";die;   
         // $this->form_validation->set_rules();
			 
         // if ($this->form_validation->run() == FALSE)
             //   {
					
                	 	//$data['state']=$this->hwc_model->get_state();
                	 	//redirect('Hmis/form_add');	
                       // $this->load->view('programmanager/nvhcp/nvhcp_form_add',$data);
               // }
              //  else
              //  {

           $data = array
				   (	 				
					
					'year'=> $this->input->post('e_year'),
					'quarter'=> $this->input->post('quarter'),
					
					'total_ipd'=> $this->input->post('tipd'),
					'total_opd'=>$this->input->post('topd'),
					'labtest'=>$this->input->post('ltest'),
					'updated_by'=>  (isset($_SESSION['memberID']))
					
					
													
			  	);
				//echo "<pre>";
                //print_r($data);die;
                /////// chk availability /////////
                 
                 //$result = $this->Hmis_model->chkNvbdcp($this->input->post('state_name'),$this->input->post('e_year'),$this->input->post('type'));
                  
				 
                ///////////// end check availability ///////////
                $result =0;
                if($result>0)
                {
					
					
                 $this->session->set_flashdata("already_added","Record already added.");
                 
					
				  redirect('Hmisp/add_form');					
						
                }
                else
                {
				$this->Hmisp_model->insertHmisp($data);

				$this->session->set_flashdata("success","Data has been submitted successfully.");
        
			    }
				
				//$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('Hmisp/index');     
		  
		  //}

		  }
	}
	
	public function edit_form($id)
	{
		
	   //$data['state']=$this->hwc_model->get_state();
       $data['value'] = $this->Hmisp_model->getHmisp_byId($id);
	   
	 // echo print_r($data['value']); die;
	   
	
       $data['page_type']='HMIS';

	    loadLayout('programmanager/Hmis/pform_edit', 'program_manager', $data);

	}
	
	public function form_update($id)
	{      
      if (isset($_POST['update']))
		  {
		  	 $data = array
				   (	 				
					
					'year'=> $this->input->post('e_year'),
					'quarter'=> $this->input->post('quarter'),
					
					'total_ipd'=> $this->input->post('tipd'),
					'total_opd'=>$this->input->post('topd'),
					'labtest'=>$this->input->post('ltest'),
					'updated_by'=>  (isset($_SESSION['memberID']))
					
					
													
			  	);
                
      

		$result = $this->Hmisp_model->updateHmisp_byId($id,$data);
	

        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
			
	     }
         redirect(base_url('Hmisp/edit_form/'. $id));

		  }
	}
	

public function delete($id)
     {
       $this->db->delete('hmis_patient_service', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('Hmisp/index'));
     }
  
}
