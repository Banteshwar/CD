<?php

defined('BASEPATH') OR exit('No direct script access allowed');

//  require_once APPPATH . 'third_party/jcryption/sqAES.php';
//require_once APPPATH . 'third_party/jcryption/JCryption.php';
  

class Home extends CI_Controller {

    public function __construct() {
    parent::__construct();
    }

    public function index() { 
        //die("Hello");
        $this->load->view('template/m_header');
        $this->load->view('m_login');
        $this->load->view('template/m_footer');
    }

    public function login1111() {

       // die("Hello");

        //$this->load->library('session');
        global $db;
        $user = new Users($db);
        global $USER_ROLES;
        $error = array();
        $data['POST'] = $_POST;
        if ($user->is_logged_in()) {
            redirect('admin/home/index', 'refresh');
        }

        if (count($_POST) > 0) {
            //extract($_POST);
            if ($this->input->post('username') && $this->input->post('username') != '') {
                $username = $this->input->post('username');
                if (strlen($username) > 40) {
                    $error[] = 'Username should not be more than 40 characters long.';
                }
            } else {
                $error[] = "Please fill Username";
            }

            if ($this->input->post('password') && $this->input->post('password') != '') {
                $password = $this->input->post('password');
                if (strlen($password) > 40) {
                    $error[] = 'Password should not be more than 40 characters long.';
                }
            } else {
                $error[] = "Please fill Password";
            }
             if (!DEVELOPMENT) {
                if (!isset($_REQUEST['T3']) || !isset($_SESSION['security_code']) || $_SESSION['security_code'] != $_REQUEST['T3'] || empty($_SESSION['security_code'])) {
                $error[] = "Please enter valid security code";
            }
            if (isset($_SESSION['security_code'])) {
                unset($_SESSION['security_code']);
            }
            } 


  $data['msg'] ='';
  if(isset($_POST['submit']))
  {
   $data['msg'] = $this->checkCaptcha($_POST);
  }

  $code = $this->generateCode(6);
  $newdata = array('security_code'=> $code);
  $this->session->set_userdata($newdata);


            if (!DEVELOPMENT) {
				

                if (!isset($_REQUEST['T3']) || !isset($this->session->userdata['security_code']) || $this->session->userdata['security_code'] != $_REQUEST['T3'] || empty($this->session->userdata['security_code'])) {
                $error[] = "Please enter valid security code";
            }
            if (isset($this->session->userdata['security_code'])) {
                //unset($this->session->userdata['security_code']);
                $this->session->unset_userdata('security_code');
            }
            } 
           
           $data['error'] = $error;

            if (count($error) == 0) {
                if ($user->login($username, $password)) {
                    $user_row = $user->getUser();
                    $this->session->set_userdata('USER_NAME', ucfirst($user_row['username']));
                    $this->session->set_userdata('USER_EMAIL', $user_row['email']);
                    $this->session->set_userdata('USER_TYPE', $USER_ROLES[$user_row['role']]);
                    $this->session->set_userdata('FULL_NAME', $user_row['full_name']);
                    //$_SESSION['USER_NAME'] = ucfirst($user_row['username']);
                    //$_SESSION['USER_EMAIL'] = $user_row['email'];
                    //$_SESSION['USER_TYPE'] = $USER_ROLES[$user_row['role']];
                    //logged in return to index page
					
					
//                    if($user_row['role'] == 5) {
//                        redirect('dashboard/hwc_dashboard_state', 'refresh');
//                    }
//                    if($user_row['role'] == 6 ) {
//                        redirect('dashboard/hwc_dashboard_district', 'refresh');
//                    }
//                     redirect('dashboard/hwc_dashboard', 'refresh');
                    redirect('admin/home/index', 'refresh');
                } else {

                    loadLayout('m_login', 'public', $data);
                }
            } else {
                error_message(error_format($error));
                loadLayout('m_login', 'public', $data);
            }
        } else {

            loadLayout('m_login', 'public', 0);
        }


//        $this->load->view('template/t_header');
//        $this->load->view('admin/dashboard');
//        $this->load->view('template/t_footer');
    } 


    /* New Login Code */

    public function login() {

        global $db;

        $this->load->helper('url');
        $this->load->library('session');
        $user = new Users($db);
        
        global $USER_ROLES;
        $error = array();
        $data['POST'] = $_POST;
        if ($user->is_logged_in()) {
            
            redirect('admin/home/index', 'refresh');
        } 

  $data['msg'] ='';
  if(isset($_POST['submit']))
  {
   $data['msg'] = $this->checkCaptcha($_POST);

  }

  $code = $this->generateCode(6);

  $newdata = array('security_code'=> $code);
  $this->session->set_userdata($newdata);


        if (count($_POST) > 0) {
            //extract($_POST);
            
            if ($this->input->post('username') && $this->input->post('username') != '') {
                $username = $this->input->post('username');
                if (strlen($username) > 40) {
                    $error[] = 'Username should not be more than 40 characters long.';
                }
            } else {
                $error[] = "Please fill Username";
            }

            if ($this->input->post('password') && $this->input->post('password') != '') {
                $password = $this->input->post('password');
                if (strlen($password) > 40) {
                    $error[] = 'Password should not be more than 40 characters long.';
                }
            } else {
                $error[] = "Please fill Password";
            }

            /*if ($this->input->post('captcha') && $this->input->post('captcha') != '') {
				
				
                $captcha = $this->input->post('captcha');
                $ccode = $this->input->post('ccode');
                if ($captcha!=$ccode) {
                    $error[] = "You input wrong Captcha.";
                }
				

            } else {
                $error[] = "Please fill Captcha";
            }*/

             /* if (!DEVELOPMENT) {
                if (!isset($_REQUEST['T3']) || !isset($_SESSION['security_code']) || $_SESSION['security_code'] != $_REQUEST['T3'] || empty($_SESSION['security_code'])) {
                $error[] = "Please enter valid security code";
            }
            if (isset($_SESSION['security_code'])) {
                unset($_SESSION['security_code']);
            }
            } */  
           
           $data['error'] = $error;

            if (count($error) == 0) {
               
                if ($user->login($username, $password)) {
                    
                    $user_row = $user->getUser();
					
										
					$this->session->set_userdata('FULL_NAME', ucfirst($user_row['full_name']));
                    $this->session->set_userdata('USER_NAME', ucfirst($user_row['username']));
                    $this->session->set_userdata('USER_EMAIL', $user_row['email']);
                    $this->session->set_userdata('USER_TYPE', $user_row['role']);
					
					$redirect_url=trim($user_row['re_direct']);
					
					if($redirect_url)
					{
					redirect($redirect_url, 'refresh');
					}
					else{
					redirect('admin/home/index', 'refresh');
					}

                          
                } else {

                    loadLayout('m_login', 'public', $data);
                }
            } else {
                error_message(error_format($error));
                loadLayout('m_login', 'public', $data);
            }
        } else {

            loadLayout('m_login', 'public', $data);
        }
    }

    /* New Login Code Ended */



public function generateCode($characters)
 {
  /* list all possible characters, similar looking characters and vowels have been removed */
  $possible = '23456789bcdfghjkmnpqrstvwxyz';
  $code = '';
  $i = 0;
  while ($i < $characters)
  {
   $code .= substr($possible, mt_rand(0, strlen($possible)-1), 1);
   $i++;
  }
  return $code;
 }

 public function checkCaptcha($post)
 {

    //print_r($post);
  if($post['captcha'] == $post['ccode'])
  {
   return 'Success';
  }
  else
  {
   return 'Mismatch, try again';
  }
 }


 public function logout() {
        //session_destroy();
        //redirect('home/login');
        $this->session->sess_destroy();
        redirect('home/login');
    }

    public function aboutnin() {
        $this->load->view('template/m_header');
        $this->load->view('m_about_nin');
        $this->load->view('template/m_footer');
    }
 public function contactus() {
        $this->load->view('template/m_header');
        $this->load->view('m_contact_us.php');
        $this->load->view('template/m_footer');
    }
	
 public function policies() {
        $this->load->view('template/m_header');
        $this->load->view('policy');
        $this->load->view('template/m_footer');
    }

public function help() {
        $this->load->view('template/m_header');
        $this->load->view('help');
        $this->load->view('template/m_footer');
    }

public function term() {
        $this->load->view('template/m_header');
        $this->load->view('term');
        $this->load->view('template/m_footer');
    }

public function sitemap() {
        $this->load->view('template/m_header');
        $this->load->view('sitemap');
        $this->load->view('template/m_footer');
    }	
	
	
 public function jctest() {

        $this->load->view('welcome_message1');
    }

    public function jc() {
        //store encrypted data to a variable

   
        $postBefore = print_r($_POST, true);
        $this->jcryptionDir();
        //decrypt post data

        //show log
        header('Content-type: text/plain');
        echo "ENCRYPTED POST DATA \n======================\n";
        print_r($postBefore);
        echo "DECRYPTED POST DATA\n======================\n";
        print_r($_POST);
       $this->load->model('Dbtest_model');

          $this->Dbtest_model->db_test();


//        $this->load->view('template/m_header');
//        $this->load->view('index');
//        $this->load->view('template/m_footer');
    }

//    public function jcryption() {
//        if ($this->input->is_ajax_request()) {
//
//            $jc_obj = new JCryption(APPPATH . 'third_party/jcryption/keys/rsa_1024_pub.pem', APPPATH . 'third_party/jcryption/keys/rsa_1024_priv.pem');
//            $jc_obj->go();
//        } else {
//            echo 'Direct access not allowed.';
//        }
//    }




    /* New Code For Captcha */

    

    /* New Code Ended For Captcha */
}
