<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Hpe extends MY_Controller {
    private $user;

    public function __construct() {
        parent::__construct();           
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('programmanager/hpe_model');
        $this->load->model('Dashboard_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');
    }

    /*---------------------------Start Products ---------------------------------------------*/
    
    public function index() { 		
    	$this->products_view();
    }
	
	public function products_view(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('HPE', base_url('hpe/index'));
        //$this->mybreadcrumb->add('Products', base_url('hpe/index'));
        
        $data['page_type'] = 'HPE';
		
        $data['row']       = $this->hpe_model->get_hpe_product();
		
        loadLayout('programmanager/hpe/products/form_list', 'program_manager', $data);
    }
	
    public function products_add_form(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('HPE', base_url('hpe/index'));
		//$this->mybreadcrumb->add('Add Products', base_url('hpe/index'));
        $data['page_type'] = 'HPE';
		$data['products']  = $this->hpe_model->get_product_category();	
        loadLayout('programmanager/hpe/products/form_add', 'program_manager', $data);
    }
	
    private function products_validate(){     
$this->form_validation->set_rules('year', 'Year', 'trim|required');
		$this->form_validation->set_rules('month', 'Month', 'trim|required');	
        $this->form_validation->set_rules('products', 'Products', 'trim|required');
        $this->form_validation->set_rules('installed_capacity', 'Installed Capacity', 'trim|required');
        $this->form_validation->set_rules('monthly_production', 'Monthly Production', 'trim|required');       
        $this->form_validation->set_rules('total_production', 'Total Production', 'trim|required');       
        $this->form_validation->set_rules('manpower', 'Manpower', 'trim|required');       
		
        if($this->form_validation->run() == TRUE){
            $requestdata  =   array(
                "year"         		=>  $this->input->post('year'), 
"month"         		=>  $this->input->post('month'), 
"products"         		=>  $this->input->post('products'), 				
                "installed_capacity"    =>  $this->input->post('installed_capacity'),               
                "monthly_production"    =>  $this->input->post('monthly_production'),
                "total_production"    	=>  $this->input->post('total_production'),
                "manpower"    			=>  $this->input->post('manpower')
             ); 
            return $requestdata;
        }else{
            $this->form_validation->set_error_delimiters('', '');
            $message    = array("0",validation_errors());
            $this->session->set_flashdata('message', $message);
            return false;
        }
    }
	
    public function products_InsertForm(){	
        $requestdata    =   $this->products_validate();
		
        if(!empty($requestdata)){
            if($this->hpe_model->insertdata("tbl_hpe_products",$requestdata)){
                $message    = array("1","Successfully Submit");
            }else{
                $message    = array("0",$this->db->_error_message());
            }
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url("hpe/products_add_form"));
    }
	
   

    public function products_edit(){
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('HPE', base_url('hpe/index'));
		//$this->mybreadcrumb->add('Add Products', base_url('hpe/index'));
        $data['page_type'] = 'HPE';      
		$data['products']  = $this->hpe_model->get_product_category();	
        $data['row']   		=   $this->hpe_model->fetchwhere("tbl_hpe_products",array("id"=>$this->input->get('id')),"","row_array");		
        
		loadLayout('programmanager/hpe/products/form_add', 'program_manager', $data);
    }
	
    public function products_update(){
        $requestdata    =   $this->products_validate();
        	if(!empty($requestdata)){
	
			 if($this->hpe_model->updatedata("tbl_hpe_products",$requestdata,array("id"=>$this->input->post('id')))){
			    $message    = array("1","Successfully Update");
		
            }else{
                $message    = array("0",$this->db->_error_message());
                $this->session->set_flashdata('message', $message);
            }		
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('hpe/products_edit').'?action=edit&id='.$this->input->post('id'));
    }
	
    public function products_delete(){
        
		if($this->input->get('id')){
            $this->hpe_model->deletedata("tbl_hpe_products",array("id"=>$this->input->get('id')));
			 $message    = array("1","Successfully Deleted");
			  $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('hpe/products_view'),'location');
    }
    
    
    
    /*---------------------------Start Receivable ---------------------------------------------*/
    public function recev_view(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('HPE', base_url('hpe/index'));
        //$this->mybreadcrumb->add('Receivable', base_url('hpe/index'));        
        $data['page_type'] = 'HPE';		
        $data['row']       = $this->hpe_model->get_hpe_recev();
		
        loadLayout('programmanager/hpe/recev/form_list', 'program_manager', $data);
    }
	
    public function recev_add_form(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('HPE', base_url('hpe/index'));
		//$this->mybreadcrumb->add('Receivable', base_url('hpe/index'));
        $data['page_type'] = 'HPE';
		$data['products']  = $this->hpe_model->get_product_category();	
        loadLayout('programmanager/hpe/recev/form_add', 'program_manager', $data);
    }
	
    private function recev_validate(){  
$this->form_validation->set_rules('year', 'Year', 'trim|required');
		$this->form_validation->set_rules('month', 'Month', 'trim|required'); 	
        $this->form_validation->set_rules('category', 'Category', 'trim|required');
        $this->form_validation->set_rules('amt_due', 'Amount Due', 'trim|required');
        $this->form_validation->set_rules('amt_receive', 'Amount Received', 'trim|required');       
        $this->form_validation->set_rules('sale_services', 'Sales/Service', 'trim|required');       
        $this->form_validation->set_rules('balance_amt', 'Balance Amount', 'trim|required');       
		
        if($this->form_validation->run() == TRUE){
            $requestdata  =   array(
			"year"         		=>  $this->input->post('year'),  
			"month"         		=>  $this->input->post('month'),  
                "category"         		=>  $this->input->post('category'),        
                "amt_due"    =>  $this->input->post('amt_due'),               
                "amt_receive"    =>  $this->input->post('amt_receive'),
                "sale_services"    	=>  $this->input->post('sale_services'),
                "balance_amt"    			=>  $this->input->post('balance_amt')
             ); 
            return $requestdata;
        }else{
            $this->form_validation->set_error_delimiters('', '');
            $message    = array("0",validation_errors());
            $this->session->set_flashdata('message', $message);
            return false;
        }
    }
	
    public function recev_InsertForm(){	
        $requestdata    =   $this->recev_validate();
		
        if(!empty($requestdata)){
            if($this->hpe_model->insertdata("tbl_hpe_recev",$requestdata)){
                $message    = array("1","Successfully Submit");
            }else{
                $message    = array("0",$this->db->_error_message());
            }
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url("hpe/recev_add_form"));
    }   

    public function recev_edit(){
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('HPE', base_url('hpe/index'));
		//$this->mybreadcrumb->add('Receivable', base_url('hpe/index'));
        $data['page_type'] = 'HPE';      
		$data['products']  = $this->hpe_model->get_product_category();	
        $data['row']   	   =   $this->hpe_model->fetchwhere("tbl_hpe_recev",array("id"=>$this->input->get('id')),"","row_array");		
        
		loadLayout('programmanager/hpe/recev/form_add', 'program_manager', $data);
    }
	
    public function recev_update(){
        $requestdata    =   $this->recev_validate();
        	if(!empty($requestdata)){
	
			 if($this->hpe_model->updatedata("tbl_hpe_recev",$requestdata,array("id"=>$this->input->post('id')))){
			    $message    = array("1","Successfully Update");
		
            }else{
                $message    = array("0",$this->db->_error_message());
                $this->session->set_flashdata('message', $message);
            }		
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('hpe/recev_edit').'?action=edit&id='.$this->input->post('id'));
    }
	
    public function recev_delete(){
        
		if($this->input->get('id')){
            $this->hpe_model->deletedata("tbl_hpe_recev",array("id"=>$this->input->get('id')));
			 $message    = array("1","Successfully Deleted");
			  $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('hpe/recev_view'),'location');
    }
   
    /*---------------------------Start Pharma Retail Outlets ---------------------------------------------*/
    public function pharma_view(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('HPE', base_url('hpe/index'));
        //$this->mybreadcrumb->add('Receivable', base_url('hpe/index'));
        
        $data['page_type'] = 'HPE';
		
        $data['row']       = $this->hpe_model->get_hpe_pharma();
		
        loadLayout('programmanager/hpe/pharma/form_list', 'program_manager', $data);
    }
	
    public function pharma_add_form(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('HPE', base_url('hpe/index'));
		//$this->mybreadcrumb->add('Receivable', base_url('hpe/index'));
        $data['page_type'] = 'HPE';
		$data['products']  = $this->hpe_model->get_product_category();	
        loadLayout('programmanager/hpe/pharma/form_add', 'program_manager', $data);
    }
	
    private function pharma_validate(){     
$this->form_validation->set_rules('year', 'Year', 'trim|required');
		$this->form_validation->set_rules('month', 'Month', 'trim|required'); 	
        $this->form_validation->set_rules('amrit_outlets', 'Category', 'trim|required');
        $this->form_validation->set_rules('other_outlets', 'Amount Due', 'trim|required');
        $this->form_validation->set_rules('state_outlets', 'Amount Received', 'trim|required');       
        $this->form_validation->set_rules('beneficiaries', 'Sales/Service', 'trim|required');       
        $this->form_validation->set_rules('quantum_saving', 'Balance Amount', 'trim|required');       
        $this->form_validation->set_rules('manpower', 'Balance Amount', 'trim|required');       
		
        if($this->form_validation->run() == TRUE){
            $requestdata  =   array(
			"year"    =>  $this->input->post('year'),
			"month"    =>  $this->input->post('month'),
                "amrit_outlets"    =>  $this->input->post('amrit_outlets'),        
                "other_outlets"    =>  $this->input->post('other_outlets'),               
                "state_outlets"    =>  $this->input->post('state_outlets'),
                "beneficiaries"    =>  $this->input->post('beneficiaries'),
                "quantum_saving"   =>  $this->input->post('quantum_saving'),
                "manpower"   		=>  $this->input->post('manpower')
             ); 
            return $requestdata;
        }else{
            $this->form_validation->set_error_delimiters('', '');
            $message    = array("0",validation_errors());
            $this->session->set_flashdata('message', $message);
            return false;
        }
    }
	
    public function pharma_InsertForm(){	
        $requestdata    =   $this->pharma_validate();
		
        if(!empty($requestdata)){
            if($this->hpe_model->insertdata("tbl_hpe_pharma",$requestdata)){
                $message    = array("1","Successfully Submit");
            }else{
                $message    = array("0",$this->db->_error_message());
            }
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url("hpe/pharma_add_form"));
    }   

    public function pharma_edit(){
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('HPE', base_url('hpe/index'));
		//$this->mybreadcrumb->add('Receivable', base_url('hpe/index'));
        $data['page_type'] = 'HPE';      
		$data['products']  = $this->hpe_model->get_product_category();	
        $data['row']   		=   $this->hpe_model->fetchwhere("tbl_hpe_pharma",array("id"=>$this->input->get('id')),"","row_array");		
        
		loadLayout('programmanager/hpe/pharma/form_add', 'program_manager', $data);
    }
	
    public function pharma_update(){
        $requestdata    =   $this->pharma_validate();
        	if(!empty($requestdata)){
	
			 if($this->hpe_model->updatedata("tbl_hpe_pharma",$requestdata,array("id"=>$this->input->post('id')))){
			    $message    = array("1","Successfully Update");
		
            }else{
                $message    = array("0",$this->db->_error_message());
                $this->session->set_flashdata('message', $message);
            }		
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('hpe/pharma_edit').'?action=edit&id='.$this->input->post('id'));
    }
	
    public function pharma_delete(){
        
		if($this->input->get('id')){
            $this->hpe_model->deletedata("tbl_hpe_pharma",array("id"=>$this->input->get('id')));
			 $message    = array("1","Successfully Deleted");
			  $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('hpe/pharma_view'),'location');
    }
    /*---------------------------Start HindLabs Diagnostic Centres ---------------------------------------------*/
    
	public function hindlabs_view(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('HPE', base_url('pmssy/index'));
        //$this->mybreadcrumb->add('Hites', base_url('hpe/index'));
        
        $data['page_type'] = 'HPE';
		
        $data['row']       = $this->hpe_model->get_hpe_hindlabs();
		
        loadLayout('programmanager/hpe/hindlabs/form_list', 'program_manager', $data);
    }
	
    public function hindlabs_add_form(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('HPE', base_url('hpe/index'));
        //$this->mybreadcrumb->add('HindLabs', base_url('hpe/index'));
        $data['page_type'] = 'HPE';		
        loadLayout('programmanager/hpe/hindlabs/form_add', 'program_manager', $data);
    }
	
    private function hindlabs_validate(){  
		$this->form_validation->set_rules('year', 'Year', 'trim|required');
		$this->form_validation->set_rules('month', 'Month', 'trim|required'); 
		
        $this->form_validation->set_rules('centres', 'Centres', 'trim|required');
        $this->form_validation->set_rules('state_covered', 'Total Number of State/UT(s) Covered', 'trim|required');       
        $this->form_validation->set_rules('new_hindlabs', 'Proposed new HindLabs', 'trim|required');       
        $this->form_validation->set_rules('beneficiaries', 'Total Number of Beneficiaries', 'trim|required');       
        $this->form_validation->set_rules('quantum', 'Quantum of Savings (INR in Lakh)', 'trim|required');       
        $this->form_validation->set_rules('manpower', 'Manpower', 'trim|required');  
		$this->form_validation->set_rules('centres', 'Centres', 'trim|required');
		$this->form_validation->set_rules('centres', 'Centres', 'trim|required'); 
		
        if($this->form_validation->run() == TRUE){
            $requestdata  =   array(
				"year"         	 =>  $this->input->post('year'),   
				"month"         	 =>  $this->input->post('month'),   
                "centres"         	 =>  $this->input->post('centres'),        
                "no_labs"    		 =>  $this->input->post('no_labs'),               
                "no_imaging_centres" =>  $this->input->post('no_imaging_centres'),
                "state_covered" 	 =>  $this->input->post('state_covered'),
                "new_hindlabs"    	 =>  $this->input->post('new_hindlabs'),
                "beneficiaries"    	 =>  $this->input->post('beneficiaries'),
                "quantum"    			 =>  $this->input->post('quantum'),
                "manpower"    			 =>  $this->input->post('manpower'),
             ); 
            return $requestdata;
        }else{
            $this->form_validation->set_error_delimiters('', '');
            $message    = array("0",validation_errors());
            $this->session->set_flashdata('message', $message);
            return false;
        }
    }
	
    public function hindlabs_InsertForm(){	
        $requestdata    =   $this->hindlabs_validate();
		
        if(!empty($requestdata)){
            if($this->hpe_model->insertdata("tbl_hpe_hindlabs",$requestdata)){
                $message    = array("1","Successfully Submit");
            }else{
                $message    = array("0",$this->db->_error_message());
            }
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url("hpe/hindlabs_add_form"));
    }
	
   

    public function hindlabs_edit(){
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('HPE', base_url('hpe/index'));
		//$this->mybreadcrumb->add('HindLabs', base_url('hpe/index'));
        $data['page_type'] = 'HPE'; 
        $data['row']   		=   $this->hpe_model->fetchwhere("tbl_hpe_hindlabs",array("id"=>$this->input->get('id')),"","row_array");		
        
		loadLayout('programmanager/hpe/hindlabs/form_add', 'program_manager', $data);
    }
	
    public function hindlabs_update(){
        $requestdata    =   $this->hindlabs_validate();
        	if(!empty($requestdata)){
	
			 if($this->hpe_model->updatedata("tbl_hpe_hindlabs",$requestdata,array("id"=>$this->input->post('id')))){
			    $message    = array("1","Successfully Update");
		
            }else{
                $message    = array("0",$this->db->_error_message());
                $this->session->set_flashdata('message', $message);
            }		
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('hpe/hindlabs_edit').'?action=edit&id='.$this->input->post('id'));
    }
	
    public function hindlabs_delete(){
        
		if($this->input->get('id')){
            $this->hpe_model->deletedata("tbl_hpe_hindlabs",array("id"=>$this->input->get('id')));
			 $message    = array("1","Successfully Deleted");
			  $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('hpe/hindlabs_view'),'location');
    }
	
    /*---------------------------Start Hospitals(Lifes Spring) ---------------------------------------------*/
    public function hospitals_view(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('HPE', base_url('hpe/index'));
        //$this->mybreadcrumb->add('Hospitals', base_url('hpe/index'));
        
        $data['page_type'] = 'HPE';
		
        $data['row']       = $this->hpe_model->get_hpe_hostpitals();
		loadLayout('programmanager/hpe/hospitals/form_list', 'program_manager', $data);
    }
	
    public function hospitals_add_form(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('HPE', base_url('hpe/index'));
		//$this->mybreadcrumb->add('Hospitals', base_url('hpe/index'));
        $data['page_type'] = 'HPE';
		$data['products']  = $this->hpe_model->get_product_category();	
        loadLayout('programmanager/hpe/hospitals/form_add', 'program_manager', $data);
    }
	
    private function hospitals_validate(){ 
$this->form_validation->set_rules('year', 'Year', 'trim|required');
		$this->form_validation->set_rules('month', 'Month', 'trim|required'); 	
        $this->form_validation->set_rules('total_hospitals', 'Total Number of Hospitals', 'trim|required');
        $this->form_validation->set_rules('total_states', 'Total Number of State/UT(s) Covered', 'trim|required');
        $this->form_validation->set_rules('proposed_new_hospitals', 'Proposed new hospitals', 'trim|required');       
        $this->form_validation->set_rules('in_patients', 'Total Number of Beneficiaries:- In-Patients', 'trim|required');       
        $this->form_validation->set_rules('out_patients', 'Total Number of Beneficiaries:- Out-Patients', 'trim|required');       
        $this->form_validation->set_rules('quantum_savings', 'Balance Amount', 'trim|required');       
        $this->form_validation->set_rules('manpower', 'Balance Amount', 'trim|required');       
		
        if($this->form_validation->run() == TRUE){
            $requestdata  =   array(
			"year"    =>  $this->input->post('year'), 
			"month"    =>  $this->input->post('month'), 
                "total_hospitals"    =>  $this->input->post('total_hospitals'),        
                "total_states"       =>  $this->input->post('total_states'),               
                "proposed_new_hospitals" =>  $this->input->post('proposed_new_hospitals'),
                "in_patients"       =>  $this->input->post('in_patients'),
                "out_patients"      =>  $this->input->post('out_patients'),
                "quantum_savings"   =>  $this->input->post('quantum_savings'),
                "manpower"   		=>  $this->input->post('manpower')
             ); 
            return $requestdata;
        }else{
            $this->form_validation->set_error_delimiters('', '');
            $message    = array("0",validation_errors());
            $this->session->set_flashdata('message', $message);
            return false;
        }
    }
	
    public function hospitals_InsertForm(){	
        $requestdata    =   $this->hospitals_validate();
		
        if(!empty($requestdata)){
            if($this->hpe_model->insertdata("tbl_hpe_hospitals",$requestdata)){
                $message    = array("1","Successfully Submit");
            }else{
                $message    = array("0",$this->db->_error_message());
            }
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url("hpe/hospitals_add_form"));
    }   

    public function hospitals_edit(){
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('HPE', base_url('hpe/index'));
		//$this->mybreadcrumb->add('Receivable', base_url('hpe/index'));
        $data['page_type'] = 'HPE';      
		$data['products']  = $this->hpe_model->get_product_category();	
        $data['row']   	   = $this->hpe_model->fetchwhere("tbl_hpe_hospitals",array("id"=>$this->input->get('id')),"","row_array");
		loadLayout('programmanager/hpe/hospitals/form_add', 'program_manager', $data);
    }
	
    public function hospitals_update(){
        $requestdata    =   $this->hospitals_validate();
        	if(!empty($requestdata)){
	
			 if($this->hpe_model->updatedata("tbl_hpe_hospitals",$requestdata,array("id"=>$this->input->post('id')))){
			    $message    = array("1","Successfully Update");
		
            }else{
                $message    = array("0",$this->db->_error_message());
                $this->session->set_flashdata('message', $message);
            }		
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('hpe/hospitals_edit').'?action=edit&id='.$this->input->post('id'));
    }
	
    public function hospital_delete(){
        
		if($this->input->get('id')){
            $this->hpe_model->deletedata("tbl_hpe_hospitals",array("id"=>$this->input->get('id')));
			 $message    = array("1","Successfully Deleted");
			  $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('hpe/hospitals_view'),'location');
    }
    /*---------------------------Start Hites ---------------------------------------------*/
    public function hites_view(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('HPE', base_url('hpe/index'));
        //$this->mybreadcrumb->add('Hites', base_url('hpe/index'));
        
        $data['page_type'] = 'HPE';
		
        $data['row']       = $this->hpe_model->get_hpe_hites();
		
		//print_r($data);die;
		
        loadLayout('programmanager/hpe/hites/form_list', 'program_manager', $data);
    }
	
    public function hites_add_form(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('HPE', base_url('hpe/index'));
        $data['page_type'] = 'HPE';		
        loadLayout('programmanager/hpe/hites/form_add', 'program_manager', $data);
    }
	
    private function hites_validate(){ 
		$this->form_validation->set_rules('year', 'Year', 'trim|required');
		$this->form_validation->set_rules('month', 'Month', 'trim|required'); 	
        $this->form_validation->set_rules('category', 'Hites', 'trim|required');
        $this->form_validation->set_rules('project_hand', 'Total No of Projects in Hand PMC', 'trim|required');
        $this->form_validation->set_rules('project_completed', 'Total No of Projects Completed', 'trim|required');       
        $this->form_validation->set_rules('project_fund_disbursed', 'Projects Fund Disbursed', 'trim|required');       
        $this->form_validation->set_rules('manpower', 'Manpower', 'trim|required');       
        $this->form_validation->set_rules('ontime_completed', 'No of Projectrs Completed with in Scheduled time', 'trim|required');       
		
        if($this->form_validation->run() == TRUE){
            $requestdata  =   array(
			
                "year"         		 =>  $this->input->post('year'),
				"month"         		 =>  $this->input->post('month'),
				"category"         		 =>  $this->input->post('category'),				
                "project_hand"     =>  $this->input->post('project_hand'),               
                "project_completed"      =>  $this->input->post('project_completed'),
                "project_fund_disbursed" =>  $this->input->post('project_fund_disbursed'),
                "manpower"    			 =>  $this->input->post('manpower'),
                "ontime_completed"    	 =>  $this->input->post('ontime_completed')
             ); 
            return $requestdata;
        }else{
            $this->form_validation->set_error_delimiters('', '');
            $message    = array("0",validation_errors());
            $this->session->set_flashdata('message', $message);
            return false;
        }
    }
	
    public function hites_InsertForm(){	
        $requestdata    =   $this->hites_validate();
		
        if(!empty($requestdata)){
            if($this->hpe_model->insertdata("tbl_hpe_hites",$requestdata)){
                $message    = array("1","Successfully Submit");
            }else{
                $message    = array("0",$this->db->_error_message());
            }
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url("hpe/hites_add_form"));
    }
	
   

    public function hites_edit(){
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('HPE', base_url('hpe/index'));
        $data['page_type'] = 'HPE'; 
        $data['row']   		=   $this->hpe_model->fetchwhere("tbl_hpe_hites",array("id"=>$this->input->get('id')),"","row_array");		
        
		loadLayout('programmanager/hpe/hites/form_add', 'program_manager', $data);
    }
	
    public function hites_update(){
        $requestdata    =   $this->hites_validate();
        	if(!empty($requestdata)){
	
			 if($this->hpe_model->updatedata("tbl_hpe_hites",$requestdata,array("id"=>$this->input->post('id')))){
			    $message    = array("1","Successfully Update");
		
            }else{
                $message    = array("0",$this->db->_error_message());
                $this->session->set_flashdata('message', $message);
            }		
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('hpe/hites_edit').'?action=edit&id='.$this->input->post('id'));
    }
	
    public function hites_delete(){
        
		if($this->input->get('id')){
            $this->hpe_model->deletedata("tbl_hpe_hites",array("id"=>$this->input->get('id')));
			 $message    = array("1","Successfully Deleted");
			  $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('hpe/hites_view'),'location');
    }
    
    
    
	
	
}