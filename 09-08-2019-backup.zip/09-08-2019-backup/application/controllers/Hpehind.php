<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Hpehind extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
     
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
       
        $this->load->model('Dashboard_model');
		$this->load->model('programmanager/Hpehind_model');
		
		$this->load->model('hwc_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index($year_id='',$month='') { 
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('HPE', base_url('Hpehind/index'));
		
		if($year_id){
			$data['fin_year'] = $year_id;
		}else{
			$data['fin_year'] = getCurrYear();
		}	

		

        if($month){
			$data['fin_month'] = $month;
		}else{
			$data['fin_month'] = getCurrMonth(); 
		}		
			

        $data['page_type']='HPE';
       
		$data['state']  =  $this->Hpehind_model->get_Hind_State($data['fin_year'],$data['fin_month']);
		//$data['months'] =  $this->Righttoinfo_model->getmonth();

        loadLayout('programmanager/hpe/hindlabs/form', 'program_manager', $data);

    }
	
	
	public function form_save(){ 
	
       if (isset($_POST['submit'])){
        
		  $this->form_validation->set_rules('year_id','Year', 'required');
		  $this->form_validation->set_rules('financial_month', 'Month', 'required');
		/*  $this->form_validation->set_rules('RTI_Applications_Received', 'RTI Applications Received', 'required');
		  $this->form_validation->set_rules('RTI_Application_Disposed_Off', 'RTI Application Disposed Off', 'required');
		  $this->form_validation->set_rules('First_Appeal_Received', 'First Appeal Received', 'required');
		  $this->form_validation->set_rules('First_Appeal_Disposed_Off', 'First Appeal Disposed Off', 'required');*/
		  
			 
           if ($this->form_validation->run() == FALSE){
                $this->session->set_flashdata('required','Something went wrong. Please try again later.');	   
                redirect('Hpepharma/index/');	
		   } else {
		   	//var_dump($_POST);die;
	    					
                $this->Hpehind_model->saveHind($_POST);
				$this->session->set_flashdata("success","Data has been submitted successfully.");				
                redirect('Hpehind/index/'.$this->input->post("year_id").'/'.$this->input->post("financial_month"));
           }

		  }
	}
	
	 
public function change_val_ajax($y_val,$q_val){
		 
		 $data['state']=$this->Hpehind_model->get_Hind_State_ajax($y_val,$q_val);		 
		 
		 echo json_encode($data['state']);
		 die;	 
	 }
  
}
