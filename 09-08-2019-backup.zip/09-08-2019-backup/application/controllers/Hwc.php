<?php

defined('BASEPATH') OR exit('No direct script access allowed');

//  require_once APPPATH . 'third_party/jcryption/sqAES.php';
//require_once APPPATH . 'third_party/jcryption/JCryption.php';


class Hwc extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Hwc_model');
        $this->user = new Users();
        var_dump($this->user);die;
		
		if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
    }

    public function index() {
        global $db;
        global $OPERATION_STATUS_LIST_COLOR_CLASS;
        global $OPERATION_STATUS_LIST_ABBR;
        global $OPERATION_STATUS_LIST;
        global $CURRENT_USER_DISTRICT;
        global $CURRENT_USER_STATE;
        global $CURRENT_USER_ROLE;
        $user = $this->user;
        $state = 0;
        $district = 0;
        $healthBlock = 0;
        $taluka = 0;
        $proposed = 2;
        $queryWhere = array();
        $html_paging = '';
        if (isset($_POST['submit']) && $_POST['submit'] == 'PROPOSED') {
            $memberID = $_SESSION['memberID'];
            $checkeds = $this->input->post('facility_proposed');
            $population_coverage = $this->input->post('population_coverage');
            if ($checkeds != null OR $checkeds != '') {
                foreach ($checkeds as $key => $value) {
                    $data_insert = array(
                        'NIN_2_HFI' => $key,
                        'proposed_status' => $value,
                        'memberID' => $memberID,
                    );
                    $GetInsertedResponse = $this->Hwc_model->InsertUpdateProposed($data_insert);
                }
            }
            if (isset($population_coverage) && count($population_coverage) > 0) {

                $this->_updatePopulationCoverage($population_coverage);
            }
            status_message('Record Updated successfully');
        }


        if (isset($_REQUEST['submit'])) {
            extract($_REQUEST);
        }
        if (isHavingState($user)) {
            $state = $CURRENT_USER_STATE;
        }
        if (isHavingDistrict($user)) {
            $district = $CURRENT_USER_DISTRICT;
        }
        if (intval(trim($state)) != 0) {

            $queryWhere[] = "hf.State_ID= $state ";
        }
        if (intval(trim($district)) != 0) {

            $queryWhere[] = "hf.District_ID= $district ";
        }
        if (intval(trim($taluka)) != 0) {

            $queryWhere[] = " hf.Taluka_ID=$taluka ";
        }
        if (intval(trim($healthBlock)) != 0) {
            $queryWhere[] = " hf.HealthBlock_ID=$healthBlock ";
        }

        if (isset($proposed_status)) {

            if (count(array_intersect(array(0, 1, 2), $proposed_status)) == count($proposed_status)) {
                $queryWhere[] = "hwcp.proposed_status IN (" . implode(',', $proposed_status) . ")";
            } else {
                die("<h2>Attached Found!</h2>");
            }
        }


        if (isset($HWC_entry_status)) {

            if (count(array_intersect(array(0, 1), $HWC_entry_status)) == count($HWC_entry_status)) {

                if (in_array('0', $HWC_entry_status)) {
                    $queryWhere[] = " ( hwc.status IN (" . implode(',', $HWC_entry_status) . ") OR hwc.status is NULL ) ";
                } else {
                    $queryWhere[] = "hwc.status IN (" . implode(',', $HWC_entry_status) . ") ";
                }
            } else {
                die("<h2>Attached Found!</h2>");
            }
        }

        if (isset($verify_status) && sizeof($verify_status) > 0) {
            if (count(array_intersect(array(1, 2), $verify_status)) == count($verify_status)) {
                $queryWhere[] = "hwc.verify_status IN (" . implode(',', $verify_status) . ")";
            }
        }/* else{
          // $queryWhere[] = "hwc.verify_status IN (0,1,2) ";
          } */
        // print_r($queryWhere);
        if (isset($HFI_Type) && sizeof($HFI_Type) > 0) {
            // showData($HFI_Type);
            if (count(array_intersect(array(1, 3, 99), $HFI_Type)) == count($HFI_Type)) {
                $queryWhere[] = "  hf.HFI_Type IN ( " . implode(',', $HFI_Type) . " )";
            }
        } else {
            $HFI_Type = array(1, 3, 99);
            $queryWhere[] = "  hf.HFI_Type IN ( " . implode(',', $HFI_Type) . " )";
        }

        if (!count($queryWhere) > 0) {
            $queryWhere[] = 1;
        }



        $filterArray['WHERE'] = $queryWhere;
        $result = $this->Hwc_model->getHWCFacilityList($filterArray);
        $result_list = $result['result'];
        $foundRows = $result['total'];
        $data['_REQUEST'] = $_REQUEST;
        $data['facility_list'] = $result_list;
        $data['user'] = $user;
        $data['html_paging'] = pagination($foundRows);

        if (isset($_GET['SEARCH'])) {
            
        }



        loadLayout('admin/hwc', 'admin', $data);
    }
    function _updatePopulationCoverage($population_coverage) {
        if (isset($population_coverage) && count($population_coverage) > 0) {
            foreach ($population_coverage as $key => $value) {
                $ProposedRow = $this->Hwc_model->getProposedExist($key);

                $ninID = $ProposedRow['NIN_2_HFI'];
                $PC = $ProposedRow['population_coverage'];
                $data_insert = array(
                    'NIN_2_HFI' => $ninID,
                    'population_coverage' => $value
                );
                $GetInsertedResponse = $this->Hwc_model->InsertUpdateProposed($data_insert);
                status_message('Population Coverage Record Updated successfully');
            }
        }
    }
    public function hwc_form() {
        global $CURRENT_USER_STATE;  // maintain current USER Belonging State
        global $CURRENT_USER_DISTRICT;  // maintain current USER Belonging District
        //print_r($_POST);//die();
        $NIN_2_HFI = $this->uri->segment(3);
        // $HFI_Type = $this->uri->segment(4);
        $this->load->model('Hwc_model');
        $data['facility'] = getFacilityInfo($NIN_2_HFI);
        $data['ninID'] = $NIN_2_HFI;
        $data['HWCInfo'] = $this->Hwc_model->getHWCInfo($NIN_2_HFI);
        if (isset($_POST['submit']) && $_POST['submit'] == 'HWC_FORM') {
            extract($_POST);
            $verify_status = $_POST['verify_status'] == 2 ? 0 : $_POST['verify_status'];
            $hr_mo_mbbs = isset($_POST['hr_mo_mbbs']) ? $hr_mo_mbbs : null;
            $mlhp_posted = isset($_POST['mlhp_posted']) ? $mlhp_posted : null;
            $traning_hr_mos_staff_nurses = isset($_POST['traning_hr_mos_staff_nurses']) ? $traning_hr_mos_staff_nurses : null;
            $traning_hr_mpw_ashas = isset($_POST['traning_hr_mpw_ashas']) ? $traning_hr_mpw_ashas : null;
            $it_equipment_desktop = isset($_POST['it_equipment_desktop']) ? $it_equipment_desktop : null;
            $service_cervical_cancer = isset($_POST['service_cervical_cancer']) ? $service_cervical_cancer : null;
            $cervical_cancer_specify = isset($_POST['cervical_cancer_specify']) ? $cervical_cancer_specify : null;
            $training_mos = isset($_POST['training_mos']) ? $training_mos : null;
            $mlhp_type = isset($_POST['mlhp_type']) ? $mlhp_type : null;
            $traning_ashas = isset($_POST['traning_ashas']) ? $traning_ashas : null;
            $remark_specify = isset($_POST['remark_specify']) ? $remark_specify : null;
            $hr_staff_nurses = isset($_POST['hr_staff_nurses']) ? $hr_staff_nurses : null;
            $remarkother = isset($_POST['mlhp_type']) == 4 ? $mlhp_type : null;
            $gender = isset($_POST['gender']) == 4 ? $gender : null;
            // $traning_staff_nurses = isset($_POST['traning_staff_nurses']) ? $traning_staff_nurses : null;
            // $formType = $formType;
            $HwcFormData = [
                'NIN_2_HFI' => $NIN_2_HFI,
                'hr_total' => $hr_total,
                'hr_mo_mbbs' => $hr_mo_mbbs,
                'mlhp_posted' => $mlhp_posted,
                'traning_hr_mos_staff_nurses' => $traning_hr_mos_staff_nurses,
                'traning_hr_mpw_ashas' => $traning_hr_mpw_ashas,
                'population_enumeration' => $population_enumeration,
                'individuals_enumerated' => $individuals_enumerated,
                'service_hypertension' => $service_hypertension,
                'hypertension_specify' => $hypertension_specify,
                'service_diabetes' => $service_diabetes,
                'diabetes_specify' => $diabetes_specify,
                'service_oral_cancer' => $service_oral_cancer,
                'oral_cancer_specify' => $oral_cancer_specify,
                'service_breast_cancer' => $service_breast_cancer,
                'breast_cancer_specify' => $breast_cancer_specify,
                'service_cervical_cancer' => $service_cervical_cancer,
                'cervical_cancer_specify' => $cervical_cancer_specify,
                'medicines_available' => $medicines_available,
                'diagnostics_available' => $diagnostics_available,
                'it_equipment_tablet' => $it_equipment_tablet,
                'it_equipment_desktop' => $it_equipment_desktop,
                'it_internet_connectivity' => $it_internet_connectivity,
                'it_phc_ncd_application' => $it_phc_ncd_application,
                'infra_repairing' => $infra_repairing,
                'infra_building' => $infra_building,
                'wellness' => $wellness,
                'infra_branding' => $infra_branding,
                'verify_status' => $verify_status,
                'hr_mpw' => $hr_mpw,
                'hr_asha' => $hr_asha,
                'mlhp_type' => $mlhp_type,
                'traning_ashas' => $traning_ashas,
                'training_mpwf' => $training_mpwf,
                'hr_staff_nurses' => $hr_staff_nurses,
                // 'traning_staff_nurses' => $traning_staff_nurses,
                'training_mos' => $training_mos,
                'remark_specify' => $remark_specify,
                'hr_mpw_m' => $hr_mpw_m,
                'gender' => $gender,
            ];

            $popCovData = [
                'population_coverage' => $population_coverage
            ];
            // showData($HwcFormData);die();
            // print_r($HwcFormData);
            // $validation = 2;
            if ($validation = $this->check_validation($formType, $remarkother, $mlhp_posted)) {
                if (!empty($data['HWCInfo'])) {
                    // showData($HwcFormData);die();
                    $this->db->set($HwcFormData);
                    // $this->db->set($population_coverage);
                    $getResponse = $this->Hwc_model->updateHwc($HwcFormData, $NIN_2_HFI, $popCovData);
                    $data['HWCInfo'] = $this->Hwc_model->getHWCInfo($NIN_2_HFI);
                    updateCriteria($NIN_2_HFI, $data['facility']['HFI_Type']);
                    status_message('Record Updated successfully');
                    redirect('hwc/hwc_view/' . $NIN_2_HFI);
                } else {
                    $getResponse = $this->Hwc_model->store($HwcFormData, $NIN_2_HFI, $popCovData);
                    updateCriteria($NIN_2_HFI, $data['facility']['HFI_Type']);
                    status_message('Record created successfully');
                    redirect('hwc/hwc_view/' . $NIN_2_HFI);
                }
            }/* else{
              echo "error";
              } */
        }


        loadLayout('admin/hwc_form', 'admin', $data);
    }
    public function hwc_view() {

        $NIN_2_HFI = $this->uri->segment(3);
        $this->load->model('Hwc_model');
        $data['HWCInfo'] = $this->Hwc_model->getHWCInfo($NIN_2_HFI);
        $data['facility'] = getFacilityInfo($NIN_2_HFI);
        $data['user'] = $this->user;
        loadLayout('admin/hwc_view', 'admin', $data);
    }
    public function hwc_view_popup() {

        $NIN_2_HFI = $this->uri->segment(3);
        $this->load->model('Hwc_model');
        $data['HWCInfo'] = $this->Hwc_model->getHWCInfo($NIN_2_HFI);
        $data['facility'] = getFacilityInfo($NIN_2_HFI);

        loadLayout('admin/hwc/hwc_view_popup', 'popup', $data);
    }
    public function my_function($whether_proposed) {

        if ($whether_proposed == 1 || $whether_proposed == 2) {
            return true;
        } else {
            $this->form_validation->set_message('my_function', 'Please Select Yes OR No');
            return false;
        }
    }
    public function others($others) {
        // showData($others);die();
        if ($others == 1 || $others == 2 || $others == 3 || $others || 4) {
            return true;
        } else {
            $this->form_validation->set_message('others', 'Please Select atleast one field.');
            return false;
        }
    }
    public function check_validation($formType = null, $remarkother, $mlhp_posted = null) {
        $validation_rules = array();
        if ($remarkother == 4) {
            $validation_rules[] = array(
                'field' => 'remark_specify',
                'label' => 'Specify remark',
                'rules' => 'trim|required'
            );
        }
        if ($formType == 2) {
            $validation_rules[] = array(
                'field' => 'mlhp_posted',
                'label' => 'MLHP in position',
                'rules' => 'trim|is_natural_no_zero|callback_my_function[' . $this->input->post('mlhp_posted') . ']'
            );
        }
        if ($mlhp_posted == 1) {
            if ($formType == 2) {
                $validation_rules[] = array(
                    'field' => 'mlhp_type',
                    'label' => 'MLHP Type',
                    'rules' => 'trim|required'
                        // 'rules' => 'trim|is_natural_no_zero|callback_others[' . $this->input->post('mlhp_type') . ']'
                );
            }
        }
        if ($formType == 1) {
            $validation_rules[] = array(
                'field' => 'hr_mo_mbbs',
                'label' => 'MBBS-Mo in position',
                'rules' => 'trim|required|is_natural'
            );
        }
        if ($formType == 1) {
            $validation_rules[] = array(
                'field' => 'training_mos',
                'label' => 'MOs in position',
                'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $this->input->post('training_mos') . ']'
            );
        }
        if ($formType == 1) {
            $validation_rules[] = array(
                'field' => 'hr_staff_nurses',
                'label' => 'Staff Nurses',
                'rules' => 'trim|required|is_natural'
            );
        }
        /* if ($formType == 2) {
          $validation_rules[] = array(
          'field' => 'traning_hr_mpw_ashas',
          'label' => 'MPW, Asha training',
          'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $this->input->post('traning_hr_mpw_ashas') . ']'
          );
          } */
        if ($formType == 1) {
            $validation_rules[] = array(
                'field' => 'traning_hr_mos_staff_nurses',
                'label' => 'Mos, Staff Nurses training',
                'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $this->input->post('traning_hr_mos_staff_nurses') . ']'
            );
        }
        /* if ($formType == 1) {
          $validation_rules[] = array(
          'field' => 'service_cervical_cancer',
          'label' => 'Cervical cancer',
          'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $this->input->post('service_cervical_cancer') . ']'
          );
          } */
        if ($formType == 1) {
            $validation_rules[] = array(
                'field' => 'it_equipment_desktop',
                'label' => 'Desktop/ laptop',
                'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $this->input->post('it_equipment_desktop') . ']'
            );
        }
        if ($formType == 1 || $formType == 2) {
            $validation_rules[] = array(
                'field' => 'hr_total',
                'label' => 'Human Resource',
                'rules' => 'trim|required|is_natural_no_zero'
            );
        }
        if ($formType == 1 || $formType == 2) {
            $validation_rules[] = array(
                'field' => 'population_coverage',
                'label' => 'Population Coverage',
                'rules' => 'trim|required|is_natural_no_zero'
            );
        }
        if ($formType == 1 || $formType == 2) {
            $validation_rules[] = array(
                'field' => 'population_enumeration',
                'label' => 'Population enumeration',
                'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $this->input->post('population_enumeration') . ']'
            );
        }
        if ($formType == 1 || $formType == 2) {
            $validation_rules[] = array(
                'field' => 'service_hypertension',
                'label' => 'Hypertension',
                'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $this->input->post('service_hypertension') . ']'
            );
        }
        if ($formType == 1 || $formType == 2) {
            $validation_rules[] = array(
                'field' => 'service_diabetes',
                'label' => 'Diabetes',
                'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $this->input->post('service_diabetes') . ']'
            );
        }

        if ($formType == 1 || $formType == 2) {
            $validation_rules[] = array(
                'field' => 'service_oral_cancer',
                'label' => 'Oral Cancer',
                'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $this->input->post('service_oral_cancer') . ']'
            );
        }

        if ($formType == 1 || $formType == 2) {
            $validation_rules[] = array(
                'field' => 'service_breast_cancer',
                'label' => 'Breast Cancer',
                'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $this->input->post('service_breast_cancer') . ']'
            );
        }
        if ($formType == 1 || $formType == 2) {
            $validation_rules[] = array(
                'field' => 'medicines_available',
                'label' => 'Medicines available',
                'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $this->input->post('medicines_available') . ']'
            );
        }
        if ($formType == 1 || $formType == 2) {
            $validation_rules[] = array(
                'field' => 'diagnostics_available',
                'label' => 'Diagnostics available',
                'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $this->input->post('diagnostics_available') . ']'
            );
        }
        if ($formType == 2) {
            $validation_rules[] = array(
                'field' => 'it_equipment_tablet',
                'label' => 'Tablets',
                'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $this->input->post('it_equipment_tablet') . ']'
            );
        }
        if ($formType == 1 || $formType == 2) {
            $validation_rules[] = array(
                'field' => 'it_internet_connectivity',
                'label' => 'Internet Connectivity',
                'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $this->input->post('it_internet_connectivity') . ']'
            );
        }
        if ($formType == 1 || $formType == 2) {
            $validation_rules[] = array(
                'field' => 'it_phc_ncd_application',
                'label' => 'CPHC- NCD application',
                'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $this->input->post('it_phc_ncd_application') . ']'
            );
        }
        if ($formType == 1 || $formType == 2) {
            $validation_rules[] = array(
                'field' => 'infra_repairing',
                'label' => 'Infrastructure Repair',
                'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $this->input->post('infra_repairing') . ']'
            );
        }
        if ($formType == 1 || $formType == 2) {
            $validation_rules[] = array(
                'field' => 'infra_branding',
                'label' => 'Branding',
                'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $this->input->post('infra_branding') . ']'
            );
        }
        if ($formType == 1 || $formType == 2) {
            $validation_rules[] = array(
                'field' => 'hr_mpw',
                'label' => 'NPW (F)',
                'rules' => 'trim|required|is_natural'
            );
        }
        if ($formType == 1 || $formType == 2) {
            $validation_rules[] = array(
                'field' => 'hr_asha',
                'label' => 'ASHA',
                'rules' => 'trim|required|is_natural'
            );
        }
        if ($formType == 1 || $formType == 2) {
            $validation_rules[] = array(
                'field' => 'traning_ashas',
                'label' => 'traning_ashas',
                'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $this->input->post('traning_ashas') . ']'
            );
        }
        if ($formType == 1 || $formType == 2) {
            $validation_rules[] = array(
                'field' => 'training_mpwf',
                'label' => 'training_mpwf',
                'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $this->input->post('training_mpwf') . ']'
            );
        }
        if ($formType == 1 || $formType == 2) {
            $validation_rules[] = array(
                'field' => 'wellness',
                'label' => 'Wellness',
                'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $this->input->post('wellness') . ']'
            );
        }
        if ($formType == 1 || $formType == 2) {
            $validation_rules[] = array(
                'field' => 'infra_building',
                'label' => 'Infra Building',
                'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $this->input->post('infra_building') . ']'
            );
        }
        $this->form_validation->set_rules($validation_rules);
        $this->form_validation->set_error_delimiters('<div class="error" style="color:#e74c3c">', '</div>');
        // showData(form_error());
        if ($this->form_validation->run() == FALSE) {
            return false;
        } else {
            return true;
        }
    }
    public function makeProposed($ninID) {
        $NIN_2_HFI = $ninID = $this->uri->segment(3);
        $proposed_status = $this->uri->segment(4);

        $facilityInfo = getFacilityInfo($NIN_2_HFI);

        $facilityName = $facilityInfo['HFI_Name'];

        if ($facilityName) {
            $facilityName;
        } else {
            $facilityName = '';
        }
        // showData($ninID);die();
        if ($proposed_status != '' && $proposed_status == 1) {
            $memberID = $_SESSION['memberID'];
            $data_insert = array(
                'NIN_2_HFI' => $ninID,
                'memberID' => $memberID,
                'proposed_status' => $proposed_status
            );
            $GetInsertedResponse = $this->Hwc_model->InsertUpdateProposed($data_insert);
            status_message($facilityName . ' hwc Proposed successfully.');
            // redirect('hwc/');
        } else {
            error_message(' Something Wrong for make Proposed.');
        }
        $this->load->library('user_agent');
        redirect($_SERVER['HTTP_REFERER']);
        // redirect('hwc/');
        exit;
    }
    public function makeProposedReject() {
        extract($_POST);
        $DATA = json_decode($DATA, TRUE);
        $NIN_2_HFI = $DATA['NIN_2_HFI'];
        $data['facility_info'] = getFacilityInfo($NIN_2_HFI);
        $data['NIN_2_HFI'] = $NIN_2_HFI;

        loadLayout('admin/hwc/ProposedReject', 'popup', $data);
    }
    public function removeProposed($value = '') {
        $ninID = $this->uri->segment(3);
        $proposed_status = $this->uri->segment(4);
        // print_r($ninID);die();
        $p_remarks = $this->input->post('p_remarks');
        // print_r($p_remarks);die();
        // showData(getFacilityInfo($ninID));die();
        if ($proposed_status != '' && $proposed_status == 2) {
            if (getFacilityInfo($ninID)) {
                $memberID = $_SESSION['memberID'];
                $data_insert = array(
                    'proposed_status' => $proposed_status,
                    'p_remark' => $p_remarks
                );
                $GetInsertedResponse = $this->Hwc_model->removeProposed($data_insert, $ninID);
                status_message(' Remove HWC successfully.');
                redirect('hwc');
            } else {
                error_message('Something wrong in ninID.');
                redirect('hwc');
            }
        } else {
            error_message(' Something Wrong for Remove Proposed.');
            redirect('hwc');
        }
    }
    public function hwc_verify($value = '') {
        $ninID = $this->uri->segment(3);
        $verifyStatus = $this->uri->segment(4);
        if (!empty($ninID) && !empty($verifyStatus)) {
            if ($verifyStatus == 1) {
                $verifyProposed = [
                    'verify_status' => $verifyStatus
                ];
                $verifyProposedResponse = $this->Hwc_model->verifyProposed($verifyProposed, $ninID);
                status_message('HWC Verified successfully.');
                redirect('hwc/hwc_view/' . $ninID);
            } else {
                error_message('Something wrong in verify Proposed');
                redirect('hwc/hwc_view/' . $ninID);
            }
        } else {
            error_message('Something wrong Please contact to admin.');
            redirect('hwc');
        }
    }
    // reject remark status
    public function hwc_reject($value = '') {
        $this->form_validation->set_rules('remarks', 'remarks', 'required');
        $this->form_validation->run();
        $error = $this->form_validation->error_array();
        $ninID = $this->uri->segment(3);
        $verifyStatus = $this->input->post('verify_status');
        $remarks = trim($this->input->post('remarks'));
        if (count($error) > 0) {
            $responseArray = array('status' => 'error', 'status_msg' => 'Required remarks.');
            //showData2($responseArray);
            JSONArrayResponse($responseArray);
            exit;
        } elseif (!empty($ninID) && !empty($verifyStatus)) {
            if ($verifyStatus == 2) {
                $rejectData = [
                    'verify_status' => $verifyStatus,
                    'remarks' => $remarks
                ];
                $this->Hwc_model->rejectHwc($rejectData, $ninID);
                $responseArray = array('status' => 'success', 'status_msg' => '  Updated Successfully', 'return_url' => '');
                // $responseArray = array('status' => 'success', 'status_msg' => '  Updated Successfully');
                status_message('HWC Application Rejected successfully.');
                JSONArrayResponse($responseArray);
                exit;
            } else {
                $responseArray = array('status' => 'error', 'status_msg' => '');
                //showData2($responseArray);
                JSONArrayResponse($responseArray);
                exit;
            }
        } else {
            error_message('Something wrong ninID and reject Statement.');
        }
    }
    public function hwc_report($value = '') {
        global $OPERATION_STATUS_LIST_COLOR_CLASS;
        global $OPERATION_STATUS_LIST_ABBR;
        global $OPERATION_STATUS_LIST;
        global $CURRENT_USER_DISTRICT;
        global $CURRENT_USER_STATE;
        global $CURRENT_USER_ROLE;
        $user = $this->user;
        $state = array();
        $district = array();
        $healthBlock = 0;
        $taluka = 0;
        $proposed = 2;
        $queryWhere = array();
        $District_Flag = false;
        $data = array();
        if (isset($_REQUEST)) {
            extract($_REQUEST);
        }

        if (count($state) > 0) {
            $queryWhere[] = "hf.State_ID  IN ( " . implode(',', $state) . " )";
        }
        if (!count($state) > 1) {
            if (count($district) > 0) {
                $queryWhere[] = "hf.District_ID   IN ( " . implode(',', $district) . " )";
                $District_Flag = true;
            }
        }
        if (intval(trim($taluka)) != 0) {

            $queryWhere[] = " hf.Taluka_ID=$taluka ";
        }
        if (intval(trim($healthBlock)) != 0) {
            $queryWhere[] = " hf.HealthBlock_ID=$healthBlock ";
        }
        if (isset($HFI_Type) && sizeof($HFI_Type) > 0) {
            // showData($HFI_Type);
            if (count(array_intersect(array(1, 3, 99), $HFI_Type)) == count($HFI_Type)) {
                $queryWhere[] = "  hf.HFI_Type IN ( " . implode(',', $HFI_Type) . " )";
            }
        } else {
            $HFI_Type = array(1, 3, 99);
            $queryWhere[] = "  hf.HFI_Type IN ( " . implode(',', $HFI_Type) . " )";
        }
        // showData($_REQUEST);die();
        if (!count($queryWhere) > 0) {
            $queryWhere[] = 1;
        }
        $filterArray['WHERE'] = $queryWhere;
        $result = $this->Hwc_model->getHWCReport($filterArray);

        $data['result'] = $result;
        $data['_REQUEST'] = $_REQUEST;
        $data['user'] = $user;

        $data['District_Flag'] = $District_Flag;

        loadLayout('admin/hwc_report', 'admin', $data);
    }
//
//    public function facility_serch() {
//  global $OPERATION_STATUS_LIST_COLOR_CLASS;
//        global $OPERATION_STATUS_LIST_ABBR;
//        global $OPERATION_STATUS_LIST;
//        global $CURRENT_USER_DISTRICT;
//        global $CURRENT_USER_STATE;
//        global $CURRENT_USER_ROLE;
//        $user = $this->user;
//        $state = array();
//        $district = array();
//        $healthBlock = 0;
//        $taluka = 0;
//        $proposed = 2;
//        $queryWhere = array();
//        $District_Flag = false;
//
//
//
//
//    }
}
