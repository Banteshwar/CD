<?php

defined('BASEPATH') OR exit('No direct script access allowed');

//  require_once APPPATH . 'third_party/jcryption/sqAES.php';
//require_once APPPATH . 'third_party/jcryption/JCryption.php';


class HwcPlanning extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Hwc_model');
        // $this->load->model('HwcPlaning');
        $this->load->model('HwcPlaningYear_model');
        $this->load->model('HwcPlanningQuarter_model');
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
    }

    public function planning_view($param = '') {

        $data['getPlanningYearViews'] = $this->HwcPlaningYear_model->getPlanningView();
        // showData($data['getPlanningYearViews']);die();
        loadLayout('admin/planning_view', 'admin', $data);
    }

    /* public function getPlanningQuarterViews($financialYear='')
      {
      echo "test";die();
      $this->HwcPlanningQuarter_model->getPlanningQuarterView($financialYear);
      } */

      public function planning_edit($param = '') {
        $State_ID = $this->uri->segment(3); 
        $financial_year = $this->uri->segment(4); 
        $data['State_ID'] = $State_ID;

        $data['financial_year'] = $financial_year;
        $data['checkExistFinancialyear'] = $this->HwcPlaningYear_model->StateIDFinancialYearExist($State_ID,$financial_year);
        // showData($data['checkExistFinancialyear']);//die();
        // echo $financial_year;die();
        // echo $State_ID;die();
        try {
            
        } catch (Exception $e) {
            showData($e);die();
        }
        loadLayout('admin/planning_edit', 'admin', $data);
    }

    public function planningForm($value = '') {
        global $CURRENT_USER_STATE;
        // showData($CURRENT_USER_STATE);die();
        // echo getCurrentQuarterFYear('Y');die();
        $currentYear = getCurrentQuarterFYear('Y');
        $currentQuarter = getCurrentQuarterFYear('Q');

        // showData($currentQuarter);die();
        try {
            if (isset($_POST['submit']) && $_POST['submit'] == 'PLANNING_FORM') {
                 // die();
                // showData($_POST);die();
                extract($_POST);
                
                if($financial_year_url != '' && $State_ID_url != ''){
                  
                // showData($financial_year_url);die();
                $planningFormYearQ = [];
                  // first quarter
                  $planningFormYearQ[] = [
                  'financial_year' => $financial_year_url,
                  'State_ID'       => $State_ID_url,
                  'quarter'        => $quarter1 == 'Q1' ? $quarter1 : 'Q1',
                  'q_uphc'         => $q_uphc1,
                  'q_phc'          => $q_phc1,
                  'q_shc'          => $q_shc1,
                  ];
                  // second quarter
                  $planningFormYearQ[] = [
                  'financial_year' => $financial_year_url,
                  'State_ID'       => $State_ID_url,
                  'quarter'        => $quarter2 == 'Q2' ? $quarter2 : 'Q2',
                  'q_uphc'         => $q_uphc2,
                  'q_phc'          => $q_phc2,
                  'q_shc'          => $q_shc2,
                  ];
                  // third quarter
                  $planningFormYearQ[] = [
                  'financial_year' => $financial_year_url,
                  'State_ID'       => $State_ID_url,
                  'quarter'        => $quarter3 == 'Q3' ? $quarter3 : 'Q3',
                  'q_uphc'         => $q_uphc3,
                  'q_phc'          => $q_phc3,
                  'q_shc'          => $q_shc3,
                  ];
                  // fourth quarter
                  $planningFormYearQ[] = [
                  'financial_year' => $financial_year_url,
                  'State_ID'       => $State_ID_url,
                  'quarter'        => $quarter4 == 'Q4' ? $quarter4 : 'Q4',
                  'q_uphc'         => $q_uphc4,
                  'q_phc'          => $q_phc4,
                  'q_shc'          => $q_shc4,
                  ]; 
                  // showData($planningFormYearQ);//die();
                 /* showData($planningFormYearQ1);
                  showData($planningFormYearQ2);
                  showData($planningFormYearQ3);
                  showData($planningFormYearQ4);*/
                  //die();
                  $getResponse = $this->HwcPlanningQuarter_model->quarterStore(array($planningFormYearQ));
                  // showData($getResponse);die();

                 }else{
                    $planningFormYear = [
                      'financial_year' => $financial_year,
                      'State_ID' => $CURRENT_USER_STATE,
                      'y_uphc' => $y_uphc,
                      'y_phc' => $y_phc,
                      'y_shc' => $y_shc,
                  ];
                  // showData($planningFormYear);die();

                  $getResponse = $this->HwcPlaningYear_model->planningStore($planningFormYear);
                }                
                redirect('HwcPlanning/planning_view');
            }
        } catch (Exception $e) {
            showData($e);
        }
    }

    public function state_mlhp($param = '') {


       $data='';

       global $CURRENT_USER_STATE;  // maintain current USER Belonging State 

       
        global $CURRENT_USER_DISTRICT;  // maintain current USER Belonging District


        $financial_year= getCurrentQuarterFYear('Y');

         $data = $this->Hwc_model->getStatusMlhp($CURRENT_USER_STATE,$financial_year);

         if (isset($_POST['submit']) && $_POST['submit'] == 'STATE_FORM') { 

           $FormData = [
                'total_gnm_nurse' => $_POST['total_gnm_nurse'],
                'total_bsc_nurse' => $_POST['total_bsc_nurse'],
                'total_ayurvedic' => $_POST['total_ayurvedic'],
                'others_specify' => $_POST['others_specify'],
                'remarks' => $_POST['remarks'],
                'total_gnm_trained_nurse' => $_POST['total_gnm_trained_nurse'],
                'total_bsc_trained_nurse' => $_POST['total_bsc_trained_nurse'],
                'total_trained_ayurvedic' => $_POST['total_trained_ayurvedic'],
                'trained_others_specify' => $_POST['trained_others_specify'],
                'trained_remarks' => $_POST['trained_remarks'],
                'total_gnm_posted_nurse' => $_POST['total_gnm_posted_nurse'],
                'total_bsc_posted_nurse' => $_POST['total_bsc_posted_nurse'],
                'total_posted_ayurvedic' => $_POST['total_posted_ayurvedic'],
                'posted_others_specify' => $_POST['posted_others_specify'],
                'posted_remarks' => $_POST['posted_remarks'],
                'total_gnm_planned_nurse' => $_POST['total_gnm_planned_nurse'],
                'total_bsc_planned_nurse' => $_POST['total_bsc_planned_nurse'],
                'total_planned_ayurvedic' => $_POST['total_planned_ayurvedic'],
                'planned_others_specify' => $_POST['planned_others_specify'],
                'planned_remarks' => $_POST['planned_remarks']
                
              ];

         
           if(count($data)>0 && $data!=0)
           {
               
          $getResponse = $this->Hwc_model->updateStatusMlhp($FormData,$CURRENT_USER_STATE,$financial_year);
          } else
          {

             $FormData = [
                'financial_year' => $financial_year,
                'state_id' => $CURRENT_USER_STATE,
                'total_gnm_nurse' => $_POST['total_gnm_nurse'],
                'total_bsc_nurse' => $_POST['total_bsc_nurse'],
                'total_ayurvedic' => $_POST['total_ayurvedic'],
                'others_specify' => $_POST['others_specify'],
                'remarks' => $_POST['remarks'],
                'total_gnm_trained_nurse' => $_POST['total_gnm_trained_nurse'],
                'total_bsc_trained_nurse' => $_POST['total_bsc_trained_nurse'],
                'total_trained_ayurvedic' => $_POST['total_trained_ayurvedic'],
                'trained_others_specify' => $_POST['trained_others_specify'],
                'trained_remarks' => $_POST['trained_remarks'],
                'total_gnm_posted_nurse' => $_POST['total_gnm_posted_nurse'],
                'total_bsc_posted_nurse' => $_POST['total_bsc_posted_nurse'],
                'total_posted_ayurvedic' => $_POST['total_posted_ayurvedic'],
                'posted_others_specify' => $_POST['posted_others_specify'],
                'posted_remarks' => $_POST['posted_remarks'],
                'total_gnm_planned_nurse' => $_POST['total_gnm_planned_nurse'],
                'total_bsc_planned_nurse' => $_POST['total_bsc_planned_nurse'],
                'total_planned_ayurvedic' => $_POST['total_planned_ayurvedic'],
                'planned_others_specify' => $_POST['planned_others_specify'],
                'planned_remarks' => $_POST['planned_remarks']
              ];

          $GetInsertedResponse = $this->Hwc_model->InsertStatusMlhp($FormData);

         
           

          }

           redirect('HwcPlanning/view_state_mlhp');

         //echo 'this is testing...'; die;

         }

        loadLayout('admin/state_mlhp', 'admin', $data);
    }
    
    public function program_study() {

        $data='';

       global $CURRENT_USER_STATE;  // maintain current USER Belonging State 

       
        global $CURRENT_USER_DISTRICT;  // maintain current USER Belonging District


        $financial_year= getCurrentQuarterFYear('Y');

         $data = $this->Hwc_model->getProgramInfo($CURRENT_USER_STATE,$financial_year);

         if (isset($_POST['submit']) && $_POST['submit'] == 'PROGRAM_FORM') {

           $FormData = [
                'submit_proposal' => $_POST['submit_proposal'],
                'await_inspection' => $_POST['await_inspection'],
                'pending_notification_ignou' => $_POST['pending_notification_ignou'],
                'study_center_remarks' => $_POST['study_center_remarks'],
                'required' => $_POST['required'],
                'notified' => $_POST['notified'],
                'additional_centres' => $_POST['additional_centres']
              ];

         
           if(count($data)>0 && $data!=0)
           {
               
          $getResponse = $this->Hwc_model->updateProgram($FormData,$CURRENT_USER_STATE,$financial_year);
          } else
          {

             $FormData = [
                'financial_year' => $financial_year,
                'state_id' => $CURRENT_USER_STATE,
                'submit_proposal' => $_POST['submit_proposal'],
                'await_inspection' => $_POST['await_inspection'],
                'pending_notification_ignou' => $_POST['pending_notification_ignou'],
                'study_center_remarks' => $_POST['study_center_remarks'],
                'required' => $_POST['required'],
                'notified' => $_POST['notified'],
                'additional_centres' => $_POST['additional_centres']
              ];

          $GetInsertedResponse = $this->Hwc_model->InsertProgram($FormData);

         
           

          }

           redirect('HwcPlanning/view_program_study');

         //echo 'this is testing...'; die;

         }

       

        loadLayout('admin/program_study', 'admin', $data);
    }

     public function view_state_mlhp($param = '') {

       $data='';

        global $CURRENT_USER_STATE;  // maintain current USER Belonging State 
      
        global $CURRENT_USER_DISTRICT;  

         $financial_year= getCurrentQuarterFYear('Y');



         $data = $this->Hwc_model->getStatusMlhp($CURRENT_USER_STATE,$financial_year);

        loadLayout('admin/view_state_mlhp', 'admin', $data);
    }
     public function view_program_study($param = '') {

      $data='';

        global $CURRENT_USER_STATE;  // maintain current USER Belonging State 
      
        global $CURRENT_USER_DISTRICT;  

         $financial_year= getCurrentQuarterFYear('Y');



         $data = $this->Hwc_model->getProgramInfo($CURRENT_USER_STATE,$financial_year);


        loadLayout('admin/view_program_study', 'admin',  $data);
    }
    

}
