

<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Hwcreport extends MY_Controller {

    private $user;

    public function __construct() {
        parent::__construct();
   
        $this->load->model('Facility_model');
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
    }

    public function hwc_report() {

        global $db;
        global $OPERATION_STATUS_LIST_COLOR_CLASS;
        global $OPERATION_STATUS_LIST_ABBR;
        global $OPERATION_STATUS_LIST;
        global $CURRENT_USER_DISTRICT;
        global $CURRENT_USER_STATE;
        global $CURRENT_USER_ROLE;


        $user = $this->user;
        $state = 0;
        $district = 0;
        $healthBlock = 0;
        $taluka = 0;
        $queryWhere = array();
        $html_paging = '';


        showData($_REQUEST);


        if (isset($_REQUEST['submit'])) {
            extract($_REQUEST);
        }

   
            if (isHavingState($user)) {
            $state = $CURRENT_USER_STATE;
        }

        if (isHavingDistrict($user)) {
            $district = $CURRENT_USER_DISTRICT;
        }


        if (intval(trim($state)) != 0) {

            $queryWhere[] = "hf.State_ID= $state ";
        }



        if (intval(trim($district)) != 0) {

            $queryWhere[] = "hf.District_ID= $district ";
        }

        if (intval(trim($taluka)) != 0) {

                $queryWhere[] = " hf.Taluka_ID=$taluka ";
        }


        if (intval(trim($healthBlock)) != 0) {

            $queryWhere[] = " hf.HealthBlock_ID=$healthBlock ";
        }

        if (!count($queryWhere) > 0) {
            $queryWhere[] = 1;
        }
         $filterArray['WHERE'] = $queryWhere;

        $result_list = $this->Facility_model->getFacilityList($filterArray);
        //showData($result_list);


        $data['facility_list'] = $result_list;
        $data['user'] = $user;
        $data['html_paging'] = $html_paging;
        $data['REQUEST'] = $_REQUEST;


  loadLayout('admin/hwc_report_list', 'admin', $data);
    }

}
