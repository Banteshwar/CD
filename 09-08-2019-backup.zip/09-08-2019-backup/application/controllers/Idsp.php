<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Idsp extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
     
     
      
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('hwc_model');
        $this->load->model('Dashboard_model');
        $this->load->model('Report_model');
        $this->load->model('programmanager/Idsp_model');

     $this->load->model('Programmanager_model');
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index() { 
   
        $this->mybreadcrumb->add('Home', base_url('secretary/page/index'));
        $this->mybreadcrumb->add('IDSP', base_url('Idsp/idsp_list'));
        
        $data['page_type']='idsp';

       $data['idsp']=$this->Idsp_model->idsp_list();
       
    loadLayout('programmanager/Idsp/idsp_list', 'program_manager', $data);
    }
  
  

  public function idsp_add() { 
     
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('IDSP', base_url('Idsp/idsp_add'));
        $data['state']=$this->hwc_model->get_state();
        $data['page_type']='idsp';
        
       
    loadLayout('programmanager/Idsp/idsp_add', 'program_manager', $data);
    }
    

   public function idsp_submit(){
         if (isset($_POST['submit']))
          {
             
          $this->form_validation->set_rules('Completeness_of_Syndromic', 'Completeness_of_Syndromic', 'required');
          
         
         
          if ($this->form_validation->run() == FALSE)
                {

                         redirect('Idsp/idsp_add');    
                      
                }
                else
                {
                     $insert=array(
'state_id'=>$this->input->post('state_id'),
'Completeness_of_Syndromic'=>$this->input->post('Completeness_of_Syndromic'),
'Completeness_of_Presumptive'=>$this->input->post('Completeness_of_Presumptive'),
'Completeness_of_Lab_Confirmed'=>$this->input->post('Completeness_of_Lab_Confirmed'),
'human_samples_in_disease_outbreaks'=>$this->input->post('human_samples_in_disease_outbreaks'),
'date'=>$this->input->post('date')



);
   $result = $this->Idsp_model->chkidsp($this->input->post('state_id'),$this->input->post('date'));
                  
                  

                ///////////// end check availability ///////////
                
                if($result>0)
                {
                    
                    
                 $this->session->set_flashdata("already_added","Record already added.");
                 
                    
                     redirect('Idsp/idsp_add');                    
                        
                }
                else
                {
                $this->Idsp_model->insertidsp($insert);

                $this->session->set_flashdata("success","Data has been submitted successfully.");
        
                }
                
                //$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('Idsp/index');     
          
          }

        }
    }
    
    public function idsp_edit($id){
       $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('IDSP', base_url('Idsp/idsp_update'));
        $data['page_type']='idsp';     
        $data['state']=$this->hwc_model->get_state($id);
        $data['value'] = $this->Idsp_model->idsp_edit_show($id);
        
       
        loadLayout('programmanager/Idsp/idsp_update', 'program_manager', $data);

    }
    public function idsp_update()
    {      

      if (isset($_POST['update']))
          {
                $id = $this->input->post('id');

             $data = array
                   (                    
                    
                   'state_id'=>$this->input->post('state_id'),
'Completeness_of_Syndromic'=>$this->input->post('Completeness_of_Syndromic'),
'Completeness_of_Presumptive'=>$this->input->post('Completeness_of_Presumptive'),
'Completeness_of_Lab_Confirmed'=>$this->input->post('Completeness_of_Lab_Confirmed'),
'human_samples_in_disease_outbreaks'=>$this->input->post('human_samples_in_disease_outbreaks'),
'date'=>$this->input->post('date'),
                    'updated_date'=> $this->input->post(date('updated_date')),

                    'updated_by'=>  (isset($_SESSION['memberID']))
                                                    
                );
     

                $result = $this->Idsp_model->idsp_update_data($id,$data);
               
        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
            
         }
           redirect('Idsp/index',$id);

          }
    }
    public function delete($id)
     {
       $this->db->delete('idsp_master_tbl', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('Idsp/index'));
     }
    

}

