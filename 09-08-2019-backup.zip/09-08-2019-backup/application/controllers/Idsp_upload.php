<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Idsp_upload extends MY_Controller {
    private $user;

    public function __construct() {
        parent::__construct();           
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('programmanager/ddap_model');
        $this->load->model('Dashboard_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if(!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');
				
    }
	

    public function index(){ 
		
       /* $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Service Delivery', base_url('ddap/ddap_user_form'));
        
        $data['page_type']='Health Service Delivery';
       
        loadLayout('admin/ddap_user_form', 'program_manager', $data);
		
		*/
		
		$this->view();
    }
	
	 public function add_form(){  
        
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('DDAP', base_url('ddap/qa_form_list'));
        
        $data['states']    = $this->ddap_model->get_state();
		$data['districts'] = $this->ddap_model->get_district();
        $data['page_type'] = 'DDAP';

        loadLayout('programmanager/ddap/ddap_form_add', 'program_manager', $data);
    }
	
	private function validate(){          
        $this->form_validation->set_rules('statename', 'State Name', 'trim|required');
        $this->form_validation->set_rules('districtname', 'District Name', 'trim|required');
        $this->form_validation->set_rules('name', 'Center Name', 'trim|required');
		$this->form_validation->set_rules('address', 'Address', 'trim|required');
        
		
        if($this->form_validation->run() == TRUE){
            $requestdata  =   array(
                "statename"         =>  $this->input->post('statename'),        
                "districtname"      =>  $this->input->post('districtname'),               
                "name"         		=>  $this->input->post('name'),
				"address"           =>  $this->input->post('address')
            ); 
            return $requestdata;
        }else{
            $this->form_validation->set_error_delimiters('', '');
            $message    = array("0",validation_errors());
            $this->session->set_flashdata('message', $message);
            return false;
        }
    }
	
	public function InsertForm(){	
        $requestdata    =   $this->validate();
		//var_dump($requestdata);die;
        if(!empty($requestdata)){
            if($this->ddap_model->insertdata("tbl_center",$requestdata)){
                $message    = array("1","Successfully Submit");
            }else{
                $message    = array("0",$this->db->_error_message());
            }
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url("ddap/add_form"));
    }
	
	public function view(){  
		$this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('DDAP', base_url('ddap/ddap_user_form'));        
        $data['page_type'] = 'DDAP';
		$data['row']    = $this->ddap_model->get_center();
		
        loadLayout('programmanager/ddap/ddap_form_list', 'program_manager', $data);
	}


	public function editCenter(){
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('DDAP', base_url('ddap/qa_form_list'));
        
        $data['states']     = $this->ddap_model->get_state();
		$data['districts']  = $this->ddap_model->get_district();
        $data['row']   		=   $this->ddap_model->fetchwhere("tbl_center",array("id"=>$this->input->get('id')),"","row_array");
		
        $data['page_type'] = 'Health Service Delivery';
		loadLayout('programmanager/ddap/ddap_form_add', 'program_manager', $data);
    }
	
    public function updateCenter(){
        $requestdata    =   $this->validate();
        	if(!empty($requestdata)){
	
			 if($this->ddap_model->updatedata("tbl_center",$requestdata,array("id"=>$this->input->post('id')))){
			    $message    = array("1","Successfully Update");
		
            }else{
                $message    = array("0",$this->db->_error_message());
                $this->session->set_flashdata('message', $message);
            }		
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('ddap/editCenter').'?action=edit&id='.$this->input->post('id'));
    }
	
    public function deleteCenter(){
        
		if($this->input->get('id')){
            $this->ddap_model->deletedata("tbl_center",array("id"=>$this->input->get('id')));
			 $message    = array("1","Successfully Deleted");
			  $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('ddap/view'),'location');
    }	
	
	
	public function getDistrict($id) 
	{ 
		$result = $this->db->where("State_ID",$id)->get("m_district")->result();
        echo json_encode($result);
	}
	
	
	/*------------Upload Excel---------------*/
	
	
	public function UploadExcel(){ 
		$this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('DDAP', base_url('ddap/ddap_form_add'));        
        $data['page_type'] = 'IDSP';
		$data['row']       = $this->ddap_model->get_center();		
        loadLayout('programmanager/Idsp/uploadExcel', 'program_manager', $data);
	}
	
	public function uploadexceldata(){
           
        
           if($_FILES['image']['name']!=''){   
            
                $file_ext = pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION);

                if($file_ext!='csv'){
                     
                    $message=array("0","File Type is Not Supported! Please Upload CSV File");                
                     
                }else{
                     
                     if(!is_dir('download/excel/'.date('d-m-Y'))){
                        mkdir('./download/excel/'.date('d-m-Y'),0777,TRUE);
                    }			

                    $config['upload_path']='./download/excel/'.date('d-m-Y');
                    $config['allowed_types']='csv';
                    $config['max_size']='1000000';
                    $config['max_width'] = '0';
                    $config['max_height'] = '0';
                    $config['remove_spaces'] = true;
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);

                    if(! $this->upload->do_upload('image')){
                        $message    = array("0",strip_tags($this->upload->display_errors()));
                    }else{
                        $upload_ques = $this->upload->data();
                        $requestdata['image']='download/excel/'.$upload_ques['file_name'];
                    }
                    $count = 0;
                    $fp = fopen($_FILES['image']['tmp_name'],'r') or die("can't open file");
                     
                      
                    while($csv_line = fgetcsv($fp,10000)){



                    	
                        if ($count > 0) {

                        	

                        $inData    =   array(
                            'weak_no'   =>  $csv_line[0],
                            'Id_no'     =>  $csv_line[1],
                            'state'     =>  $csv_line[2],
                            'districk'  =>  $csv_line[3],
                            'disease'   =>  $csv_line[4],
                            'cases'     =>  $csv_line[5],
                            'deaths'    =>  $csv_line[6],
                            'date_of_outbreak'   =>  $csv_line[7],
                            'comments'    =>  $csv_line[8],
                        );
                        $id_no =   $csv_line[1];

                        $sql_check	=	$this->db->query("select * from `tbl_outbreaks_hfm` where `Id_no`='".$id_no."'");
                        $row_check	=	$sql_check->row_array();
                        $this->load->library('email'); 
                      // die;
                        if(empty($row_check)){                    
                            $inData['Id_no'] =   $id_no;
                            if($this->db->insert("tbl_outbreaks_hfm",$inData)){
                                $message=array("1","File Uploaded Successfully");
                            }else{
                                $message=array("0",$this->db->_error_message());
                            }
                        }else{

                            $this->db->where("Id_no",$id_no);
                            $this->db->update("tbl_outbreaks_hfm" , $inData);                    
                            $message=array("1","Record Successfully Updated");
                        }
                    }
                    $count++;
                   }
                    
                }  

                }else{
                    $message=array("0","No File selected");
                }
        $this->session->set_flashdata('message', $message);
        redirect(base_url("Idsp_upload/uploadexcel"));
        fclose($fp) or die("can't close file");

    }
	
	public function downloadExcel(){		
		
   
	
	
	
       $result     =   $this->ddap_model->getCenterList();
//showData($result1);die;
        
        
        $filename   =   "ServiceDeliveryForm".date("Y-m-d-h-i-s");
        header("Content-type: application/csv");
        header("Content-Disposition: attachment; filename=\"".$filename.".csv\"");
        header("Pragma: no-cache");
        header("Expires: 0");
        
        $headerarray    =   "";
        
            $headerarray    =   array("A"=>"Center Name","B"=>"No. of persons who availed Drug Deaddiction OPD services from Deaddiction Treatment Clinics.","C"=>"No. of persons who availed inpatient treatment services from Drug Dependence Treatment Centers");
        
        $handle = fopen('php://output', 'w');
        fputcsv($handle, $headerarray);
       
       // showData($result_list1);die;
        foreach($result as $rows){
            
               $dataarray  =   array("A"=>$rows['name'],"B"=>"","C"=>"");
            
            fputcsv($handle, $dataarray); 
        } 
        fclose($handle);
        exit;  
        
} 
		
		
		
	}