<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Ihd extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
     
     
      
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('hwc_model');
        $this->load->model('Dashboard_model');
        $this->load->model('Report_model');
        $this->load->model('programmanager/Ihd_model');

     $this->load->model('Programmanager_model');
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index() { 
   
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('SON', base_url('Ihd/son_list'));
        
        $data['page_type']='ihd';

       $data['row']=$this->Ihd_model->son_list();
       
    loadLayout('programmanager/Ihd/son_list', 'program_manager',$data);
    }
  
  

  public function son_add() { 
     
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('SON', base_url('Ihd/son_add'));
        $data['page_type']='ihd';
        
       
    loadLayout('programmanager/Ihd/son_add', 'program_manager', $data);
    }
    

   public function son_submit(){
         if (isset($_POST['submit']))
          {
             
          $this->form_validation->set_rules('noof_application_son', 'listoff_hospitals', 'required');
          
         
         
          if ($this->form_validation->run() == FALSE)
                {

                         redirect('Ihd/son_add');    
                      
                }
                else
                {
                     $insert=array(
'noof_application_son'=>$this->input->post('noof_application_son'),
'issued_son'=>$this->input->post('issued_son'),
'pending_son'=>$this->input->post('pending_son'),
'noof_application_enc'=>$this->input->post('noof_application_enc'),
'issued_enc'=>$this->input->post('issued_enc'),
'pending_enc'=>$this->input->post('pending_enc')




);
  
                  
                  

                ///////////// end check availability ///////////
                
                if($result)
                {
                    
                    
                 $this->session->set_flashdata("already_added","Record already added.");
                 
                    
                     redirect('Ihd/son_add');                    
                        
                }
                else
                {
                $this->Ihd_model->insertson($insert);

                $this->session->set_flashdata("success","Data has been submitted successfully.");
        
                }
                
                //$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('Ihd/index');     
          
          }

        }
    }
    
    public function son_edit($id){
       $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('SOn', base_url('Ihd/son_update'));
        $data['page_type']='ihd';     
        $data['state']=$this->hwc_model->get_state($id);
        $data['value'] = $this->Ihd_model->son_edit_show($id);
        
       
        loadLayout('programmanager/Ihd/son_update', 'program_manager', $data);

    }
    public function son_update()
    {      

      if (isset($_POST['update']))
          {
                $id = $this->input->post('id');

             $data = array
                   (                    
                    
                  'noof_application_son'=>$this->input->post('noof_application_son'),
'issued_son'=>$this->input->post('issued_son'),
'pending_son'=>$this->input->post('pending_son'),
'noof_application_enc'=>$this->input->post('noof_application_enc'),
'issued_enc'=>$this->input->post('issued_enc'),
'pending_enc'=>$this->input->post('pending_enc'),
                    'updated_date'=> $this->input->post(date('updated_date')),

                    'updated_by'=>  (isset($_SESSION['memberID']))
                                                    
                );
     

                $result = $this->Ihd_model->son_update_data($id,$data);
               
        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
            
         }
           redirect('Ihd/index',$id);

          }
    }
    public function delete($id)
     {
       $this->db->delete('son_master_tbl', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('Ihd/index'));
     }
    
public function index2() { 
   
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('FVMS', base_url('Ihd/fvms_list'));
        
        $data['page_type']='ihd';

       $data['row']=$this->Ihd_model->fvms_list();
       
    loadLayout('programmanager/Ihd/fvms_list', 'program_manager',$data);
    }
  
  

  public function fvms_add() { 
     
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('FVMS', base_url('Ihd/fvms_add'));
        $data['page_type']='ihd';
        
       
    loadLayout('programmanager/Ihd/fvms_add', 'program_manager', $data);
    }
    

   public function fvms_submit(){
         if (isset($_POST['submit']))
          {
             
          $this->form_validation->set_rules('subject', 'listoff_hospitals', 'required');
          
         
         
          if ($this->form_validation->run() == FALSE)
                {

                         redirect('Ihd/fvms_add');    
                      
                }
                else
                {
                     $insert=array(
'subject'=>$this->input->post('subject'),
'meeting_venues'=>$this->input->post('meeting_venues'),
'fromdate'=>$this->input->post('fromdate'),
'noof_delegates'=>$this->input->post('noof_delegates'),
'todate'=>$this->input->post('todate')





);
  
                  
                  

                ///////////// end check availability ///////////
                
                if($insert)
                {
                    $this->Ihd_model->insertfvms($insert);
                    $this->session->set_flashdata("success","Data has been submitted successfully.");
              
                }
                else
                {
                

                $this->session->set_flashdata("error","Data has been submitted successfully.");
        
                }
                
                //$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('Ihd/index2');     
          
          }

        }
    }
    
    public function fvms_edit($id){
       $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('FVMS', base_url('Ihd/fvms_update'));
        $data['page_type']='ihd';     
        $data['state']=$this->hwc_model->get_state($id);
        $data['value'] = $this->Ihd_model->fvms_edit_show($id);
        
       
        loadLayout('programmanager/Ihd/fvms_update', 'program_manager', $data);

    }
    public function fvms_update()
    {      

      if (isset($_POST['update']))
          {
                $id = $this->input->post('id');

             $data = array
                   (                    
                    
                  'subject'=>$this->input->post('subject'),
'meeting_venues'=>$this->input->post('meeting_venues'),
'fromdate'=>$this->input->post('fromdate'),
'noof_delegates'=>$this->input->post('noof_delegates'),

                    'updated_date'=> $this->input->post(date('updated_date')),

                    'updated_by'=>  (isset($_SESSION['memberID']))
                                                    
                );
     

                $result = $this->Ihd_model->fvms_update_data($id,$data);
               
        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
            
         }
           redirect('Ihd/index2',$id);

          }
    }
    public function delete2($id)
     {
       $this->db->delete('fvms_master_tbl', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('Ihd/index2'));
     }
    


/* ======================  twinkle mou code ================= */

public function mouadd_form(){  
        
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('MOU', base_url('Ihd/index'));

        $data['country']    = $this->Ihd_model->get_country();

        $data['page_type'] = 'ihd';

        loadLayout('programmanager/Ihd/mou_form', 'program_manager', $data);
    }
	
	private function validate(){          
        $this->form_validation->set_rules('subject', 'Subject', 'trim|required');
        $this->form_validation->set_rules('type', 'Type', 'trim|required');
        $this->form_validation->set_rules('country', 'Country/Group', 'trim|required');
        $this->form_validation->set_rules('date_of_signing', 'Date of Signing', 'trim|required');
     
        $this->form_validation->set_rules('sunset_clause', 'Sunset Clause', 'trim|required');
        $this->form_validation->set_rules('auto_renewal', 'AutoRenewal Clause', 'trim|required');
		    $this->form_validation->set_rules('select_cycle', 'Select Cycle', 'trim|required');
        $this->form_validation->set_rules('date_next_level', 'Date of Next Renewal', 'trim|required');
        $this->form_validation->set_rules('status', 'Status', 'trim|required');

        if($this->form_validation->run() == TRUE){
          $dt='';
          if( date('Y-m-d',strtotime($this->input->post('date_of_cabinet_approval')))=='1970-01-01'){
             $dt='';
          }else{
            $dt = date('Y-m-d',strtotime($this->input->post('date_of_cabinet_approval')));
          }
            $requestdata  =   array(
                "subject"                    =>  $this->input->post('subject'),
                "type"               =>  $this->input->post('type'), 
                //"country"               =>  implode(',',$this->input->post('country')), 
                 "country"               =>  $this->input->post('country'),              
                "date_of_signing"      =>  date('Y-m-d',strtotime($this->input->post('date_of_signing'))),
                "date_of_ratification"       =>  $this->input->post('date_of_ratification'),
                "cabinet_approval"        =>  $this->input->post('cabinet_approval'),
                "date_of_cabinet_approval"  =>$dt, 
                "sunset_clause"          =>  $this->input->post('sunset_clause'),
                "auto_renewal"      =>  $this->input->post('auto_renewal'),
                "select_cycle"                      =>  $this->input->post('select_cycle'),
                "date_next_level"      =>  $this->input->post('date_next_level'),
                 "status"                      =>  $this->input->post('status')
            ); 

            return $requestdata;

        }else{
            $this->form_validation->set_error_delimiters('', '');
            $message    = array("0",validation_errors());
            $this->session->set_flashdata('message', $message);
            return false;
        }
    }
	
	public function mouinsertForm(){	
        $requestdata    =   $this->validate();
		//var_dump($requestdata);die;
        if(!empty($requestdata)){
            if($this->Ihd_model->insertdata("tbl_mou",$requestdata)){
                $message    = array("1","Successfully Submit");
                 redirect(base_url('Ihd/mouview'));
            }else{
                $message    = array("0",$this->db->_error_message());
            }
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url("Ihd/mouview"));
    }
	
	public function mouview(){  

		$this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('MOU', base_url('Ihd/mouadd_form'));        
        $data['country']    = $this->Ihd_model->get_country();
       // $data['districts']    = $this->Ihd_model->get_district();
        $data['page_type'] = 'ihd';
		    $data['row']    = $this->Ihd_model->get_mouform();

//prin($data['row']); die;
        loadLayout('programmanager/Ihd/mou_list', 'program_manager', $data);
	}


	public function moueditForm(){
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('MOU', base_url('Ihd/mouview'));
        
        $data['country']     = $this->Ihd_model->get_country();
		    $data['row']         =   $this->Ihd_model->fetchwhere("tbl_mou",array("id"=>$this->input->get('id')),"","row_array");
        $data['page_type'] = 'ihd';
		loadLayout('programmanager/Ihd/mou_form', 'program_manager', $data);
    }
	
    public function mouupdateform(){
        $requestdata    =   $this->validate();
        	if(!empty($requestdata)){
	
			 if($this->Ihd_model->updatedata("tbl_mou",$requestdata,array("id"=>$this->input->post('id')))){
			    $message    = array("1","Successfully Update");
		 redirect(base_url("Ihd/mouview"));
            }else{
                $message    = array("0",$this->db->_error_message());
                $this->session->set_flashdata('message', $message);
            }		
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('Ihd/moueditForm').'?action=edit&id='.$this->input->post('id'));
    }
	
    public function moudeleteForm(){
        
		if($this->input->get('id')){
            $this->Ihd_model->deletedata("tbl_mou",array("id"=>$this->input->get('id')));
			 $message    = array("1","Successfully Deleted");
			  $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('Ihd/mouview'),'location');
    }
}
/* ====================== end =============================== */