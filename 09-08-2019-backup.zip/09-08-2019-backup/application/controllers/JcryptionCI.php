<?php

defined('BASEPATH') OR exit('No direct script access allowed');
  require_once APPPATH . 'third_party/jcryption/sqAES.php';
require_once APPPATH . 'third_party/jcryption/JCryption.php';

class JcryptionCI extends MY_Controller {

    public function index() {
        if ($this->input->is_ajax_request()) {

            $jc_obj = new JCryption(APPPATH . 'third_party/jcryption/keys/rsa_1024_pub.pem', APPPATH . 'third_party/jcryption/keys/rsa_1024_priv.pem');
            $jc_obj->go();
        } else {
            echo 'Direct access not allowed.';
        }
    }

    public function jcryptionDir() {

        require_once APPPATH . 'third_party/jcryption/sqAES.php';
        require_once APPPATH . 'third_party/jcryption/JCryption.php';
        return JCryption::decrypt();
       
    }

//    public function jcryption() {
//        if ($this->input->is_ajax_request()) {
//
//            $jc_obj = new JCryption(APPPATH . 'third_party/jcryption/keys/rsa_1024_pub.pem', APPPATH . 'third_party/jcryption/keys/rsa_1024_priv.pem');
//            $jc_obj->go();
//        } else {
//            echo 'Direct access not allowed.';
//        }
//    }
}
