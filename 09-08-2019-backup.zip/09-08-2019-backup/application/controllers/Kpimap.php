<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Kpimap extends CI_Controller {
    private $user;

    public function __construct() {
        parent::__construct();
       
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
        $this->load->library('mybreadcrumb');

        $this->load->driver('cache');
    }

    public function index() { 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('KPI Map', base_url('kpimap/index'));  
        $data['page_type']='KPI Map';
        loadLayout('admin/kpimap', 'admin', $data);
    }
	
	

     

}
