<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Login extends CI_Controller {
	function __construct(){
        parent::__construct();
        $this->load->model('Loginmodel','',TRUE);
	    $this->table        =   "tbl_ip";
    }
	
    public function index(){
        $data['page_title']	=	"Login Page";
	 $code = $this->generateCode(6);
  $newdata = array('security_code'=> $code);
  $this->session->set_userdata($newdata);
        $this->load->view('login/login',$data);
        //$this->session->sess_destroy();
			
    }

    
	public function getlogin(){
		
		 if(!$this->checkCaptcha($_POST))
		 {
			$message    = "Error In Captcha";
            $this->session->set_flashdata('message', $message);
            redirect(base_url());
		 }
		 else{
		 
        $this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
        $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean|callback_validatelogin');
        if($this->form_validation->run() == FALSE){
            $message    = "Invalid Login Details";
            $this->session->set_flashdata('message', $message);
            redirect(base_url());
        }
        else
        {
           redirect(base_url('dashboard'));
        }
		
		 }
		 
    }
    //Validating user request for login
    public function validatelogin(){
       
        $credentials      =   array(
            "username"=>$this->input->post('username'),
            "password"=>md5($this->input->post('password'))
        );
		
        return $this->Loginmodel->getlogin($credentials);
    }
	
	public function generateCode($characters)
 {
  /* list all possible characters, similar looking characters and vowels have been removed */
  $possible = '23456789bcdfghjkmnpqrstvwxyz';
  $code = '';
  $i = 0;
  while ($i < $characters)
  {
   $code .= substr($possible, mt_rand(0, strlen($possible)-1), 1);
   $i++;
  }
  return $code;
 }
 
 public function checkCaptcha($post)
 {

    //print_r($post);
  if($post['captcha'] == $post['ccode'])
  {
   return '1';
  }
  else
  {
   return '0';
  }
 }
		
}