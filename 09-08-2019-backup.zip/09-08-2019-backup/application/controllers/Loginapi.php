<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Loginapi extends MY_Controller {

    public function __construct() { 
        parent::__construct();
        $this->load->library('portalLogin');        
    }

	public function login(){
		$result  =  $this->portalLogin->login();
		if($result){
			echo "Success";
		}else{
			echo "Failed";
		}
		
	}

}
