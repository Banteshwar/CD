<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Mdiabetes extends MY_Controller {
    private $user;

    public function __construct() {
        parent::__construct();

        $this->load->helper('commondata_helper');

        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('programmanager/Mdiabetes_model');
                
        $this->user = new Users();

        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');
    }
	

    public function index() { 
		
		$this->view();
    }
	
	 public function add_form(){  
        
        $this->mybreadcrumb->add('Home', base_url('secretary/page/index'));
        $this->mybreadcrumb->add('m-Diabetes', base_url('Mdiabetes/index'));
        
        $data['page_type'] = 'm-Diabetes';

        loadLayout('programmanager/mdiabetes/mdiabetes_form', 'program_manager', $data);
    }
	
	private function validate(){          
        $this->form_validation->set_rules('persons_registered_application', 'Persons registered on application', 'trim|required');

        if($this->form_validation->run() == TRUE){
            $requestdata  =   array(
                "persons_registered_application"          =>  $this->input->post('persons_registered_application')
            ); 
            return $requestdata;
        }else{
            $this->form_validation->set_error_delimiters('', '');
            $message    = array("0",validation_errors());
            $this->session->set_flashdata('message', $message);
            return false;
        }
    }
	
	public function insertForm(){	
        $requestdata    =   $this->validate();
		//var_dump($requestdata);die;
        if(!empty($requestdata)){
            if($this->Mdiabetes_model->insertdata("tbl_mdiabetes",$requestdata)){
                $message    = array("1","Successfully Submit");
            }else{
                $message    = array("0",$this->db->_error_message());
            }
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url("Mdiabetes/add_form"));
    }
	
	public function view(){  
		$this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('m-Diabetes', base_url('Mdiabetes/add_form'));        
        //$data['states']    = $this->Mdiabetes_model->get_state();
       // $data['districts']    = $this->Mdiabetes_model->get_district();
        $data['page_type'] = 'm-Diabetes';
		$data['row']    = $this->Mdiabetes_model->get_mdiabetesform();
//var_dump($data['row']); die;
        loadLayout('programmanager/mdiabetes/mdiabetes_form_list', 'program_manager', $data);
	}


	public function editForm(){
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('m-Diabetes', base_url('Mdiabetes/index'));
       
		$data['row']         =   $this->Mdiabetes_model->fetchwhere("tbl_mdiabetes",array("id"=>$this->input->get('id')),"","row_array");
        $data['page_type'] = 'm-Diabetes';
		loadLayout('programmanager/mdiabetes/mdiabetes_form', 'program_manager', $data);
    }
	
    public function updateForm(){
        $requestdata    =   $this->validate();
        	if(!empty($requestdata)){
	
			 if($this->Mdiabetes_model->updatedata("tbl_mdiabetes",$requestdata,array("id"=>$this->input->post('id')))){
			    $message    = array("1","Successfully Update");
		
            }else{
                $message    = array("0",$this->db->_error_message());
                $this->session->set_flashdata('message', $message);
            }		
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('Mdiabetes/editForm').'?action=edit&id='.$this->input->post('id'));
    }
	
    public function deleteForm(){
        
		if($this->input->get('id')){
            $this->Mdiabetes_model->deletedata("tbl_mdiabetes",array("id"=>$this->input->get('id')));
			 $message    = array("1","Successfully Deleted");
			  $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('Mdiabetes/view'),'location');
    }	
	
	
	
		
		
	}