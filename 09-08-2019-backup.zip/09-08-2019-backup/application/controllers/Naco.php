<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Qa extends MY_Controller 
{
    private $user;

    public function __construct() 
    {
        parent::__construct();
      
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        
        $this->load->model('Naco_model');
        $this->load->model('hwc_model');
        $this->load->model('Report_model');
        $this->load->library('form_validation');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index() 
    {  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('NACO', base_url('naco/naco_form_list'));
        
        $data['page_type']='Naco';
        $data['row'] = $this->Naco_model->naco_list();
         
        loadLayout('admin/naco/naco_form_list', 'program_manager', $data);
    }


    // Load Add QA form page
    public function add_form() 
    {  
        
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('NACO', base_url('qa/qa_form_list'));
        
        $data['state']=$this->hwc_model->get_state();
        $data['page_type']='Qa';

        loadLayout('admin/qa/qa_form_add', 'program_manager', $data);
    }


    // Insert QA form function
    public function insert_qa_form()
    {
        $table='qa_master_table';

        $this->form_validation->set_rules('statename', 'State Name', 'required');
        $this->form_validation->set_rules('financialyear', 'Financial Year', 'required');
        $this->form_validation->set_rules('quarter', 'Quarter Period', 'required');
        $this->form_validation->set_rules('nqasfacility', 'NQAS Facility Count', 'required');
         
          if ($this->form_validation->run() == FALSE)
                {               
                    $data['state']=$this->hwc_model->get_state();
                    redirect('Qa/add_form');
                }
                else
                {
                    $data = array
                    (   
                        'state_id'                =>  $this->input->post('statename'),
                        'financial_year'          =>  $this->input->post('financialyear'),
                        'quarter'                 =>  $this->input->post('quarter'),
                        'nqas_facilities_count'   =>  $this->input->post('nqasfacility'),             
                        'updated_by'              =>  (isset($_SESSION['memberID']))
                    );

                $query =$this->Qa_model->qa_insert($data,$table);
                
                if($query)
                {                   
                    $this->session->set_flashdata("success","QA form data has been saved successfully.");
                     redirect('Qa/index');  
                }
                else
                {       
                    $this->session->set_flashdata("error","Failed to save QA form data, Please Try again!!");               
                }

            redirect('Qa/add_form');
        }
    }

    // Edit QA form
    public function edit_qaform($id)
    {
       $data['state']=$this->hwc_model->get_state();
       $data['value'] = $this->Qa_model->getQA_byId($id);
       $data['page_type']='Qa';
       loadLayout('admin/qa/qa_form_edit', 'program_manager', $data);
    }

    public function update_qaform($id)
    {      
          if (isset($_POST['updateqaform']))
          {
            $data = array
            (                    
                'state_id'                =>  $this->input->post('statename'),
                'financial_year'          =>  $this->input->post('financialyear'),
                'quarter'                 =>  $this->input->post('quarter'),
                'nqas_facilities_count'   =>  $this->input->post('nqasfacility'),
                'updated_date'            =>  date("Y-m-d H:i:s"),            
                'updated_by'              =>  (isset($_SESSION['memberID']))                                                
             );
                     

            $result = $this->Qa_model->updateQA_byId($id,$data);

            if($result)
            {
                $this->session->set_flashdata('success','Record Updated Successfully');
                 redirect('Qa/index'); 

            }
            else
            {
                $this->session->set_flashdata('error','Something went wrong. Please try again later.');        
            }
                redirect(base_url('Qa/edit_qaform/'. $id));
            }
    }
       
}
