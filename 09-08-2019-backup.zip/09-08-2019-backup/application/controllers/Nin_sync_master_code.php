<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Nin_sync_master_code extends MY_Controller {

    private $user;
    public $_db;

    public function __construct() {
        parent::__construct();
        $this->load->helper('nin_dashboard');
        $this->load->model('hwc_model');
        global $db;
        $this->_db = $db;
        $this->user = new Users();
    }

    public function index() {
        global $db;

        $get_state_arr = getStatesList();

        $get_state_arr[0] = 'ADMIN';
        //showData($get_state_arr);
        foreach ($get_state_arr as $stateid => $statename)
        {
            $functionalFacilities    =  getNINFunctionalFacilities('',$stateid);
            $nin_functionalStateWiseFacilities = getNINFunctionalStateWiseFacilities();
            $nin_totalFacilitiesOperationalStatus   =   getFacilitiesOperationalStatus();
            $nin_totalConfirmedVerified =   getNINTotalConfirmedVerified();
            $nin_totalFacilitiesOperationalStatusStateWise  = getFacilitiesOperationalStatus(TRUE);
            $nin_functionalFacilitiesStateWise  =   getNINFunctionalFacilities(TRUE);
            $nin_totalConfirmedVerifiedStateWise    =   getNINTotalConfirmedVerified(TRUE);
            $nin_totalRuralUrbanVerifiedStateWise   =   getNINTotalRuralUrbanVerified(TRUE);
            $nin_totalRuralUrbanVerified    =   getNINTotalRuralUrbanVerified(); 
            
            

           //$query = "insert into nin_top_dashboard (`financial_year`,`total_functional_facilities`,`nin_functionalStateWiseFacilities`,`nin_totalFacilitiesOperationalStatus`,`nin_totalConfirmedVerified`,`nin_totalFacilitiesOperationalStatusStateWise`,`nin_functionalFacilitiesStateWise`,`nin_totalConfirmedVerifiedStateWise`,`nin_totalRuralUrbanVerifiedStateWise`,`nin_totalRuralUrbanVerified`,`state_id`) values (1819,'".serialize($functionalFacilities)."','".serialize($nin_functionalStateWiseFacilities)."','".serialize($nin_totalFacilitiesOperationalStatus)."','".serialize($nin_totalConfirmedVerified)."','".serialize($nin_totalFacilitiesOperationalStatusStateWise)."','".serialize($nin_functionalFacilitiesStateWise)."','".serialize($nin_totalConfirmedVerifiedStateWise)."','".serialize($nin_totalRuralUrbanVerifiedStateWise)."','".serialize($nin_totalRuralUrbanVerified)."','".$stateid."')" ;
           //echo  $query; die;
            
          $query  = "update nin_top_dashboard set financial_year ='1819' ,  total_functional_facilities = '".serialize($functionalFacilities)."' , nin_functionalStateWiseFacilities = '".serialize($nin_functionalStateWiseFacilities)."' , nin_totalFacilitiesOperationalStatus = '".serialize($nin_totalFacilitiesOperationalStatus)."' , nin_totalConfirmedVerified = '".serialize($nin_totalConfirmedVerified)."', nin_totalFacilitiesOperationalStatusStateWise = '".serialize($nin_totalFacilitiesOperationalStatusStateWise)."' , nin_functionalFacilitiesStateWise = '".serialize($nin_functionalFacilitiesStateWise)."' , nin_totalConfirmedVerifiedStateWise = '".serialize($nin_totalConfirmedVerifiedStateWise)."' , nin_totalRuralUrbanVerifiedStateWise = '".serialize($nin_totalRuralUrbanVerifiedStateWise)."', nin_totalRuralUrbanVerified = '".serialize($nin_totalRuralUrbanVerified)."', state_id = '".$stateid."'   where state_id = '".$stateid."' ";

            $rec = $this->_db->query($query);
                
        }
            if($rec){
                echo "row affected";
            }else{
                echo "not affected";
            }
    }



}