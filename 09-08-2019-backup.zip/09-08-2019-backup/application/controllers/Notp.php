<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Notp extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
     
     
      
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('hwc_model');
        $this->load->model('Dashboard_model');
        $this->load->model('Report_model');
        $this->load->model('programmanager/Notp_model');

     $this->load->model('Programmanager_model');
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index() { 
   
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('NOTP', base_url('Notp/notp_list'));
        
        $data['page_type']='notp';

       $data['notp']=$this->Notp_model->notp_list();
       
    loadLayout('programmanager/Notp/notp_list', 'program_manager', $data);
    }
  
  

  public function notp_add() { 
     
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('NOTP', base_url('Notp/notp_add'));
        $data['state']=$this->hwc_model->get_state();
        $data['page_type']='notp';
        
       
    loadLayout('programmanager/Notp/notp_add', 'program_manager', $data);
    }
    

   public function notp_submit(){
         if (isset($_POST['submit']))
          {
             
          $this->form_validation->set_rules('state_id', 'state_id', 'required');
          
         
         
          if ($this->form_validation->run() == FALSE)
                {

                         redirect('Notp/notp_add');    
                      
                }
                else
                {
                     $insert=array(
'state_id'=>$this->input->post('state_id'),
'notp_organs_act'=>$this->input->post('notp_organs_act'),
'notp_human_organs_amendment'=>$this->input->post('notp_human_organs_amendment'),

'year'=>$this->input->post('year')



);
   $result = $this->Notp_model->chknotp($this->input->post('state_id'),$this->input->post('year'));
                  
                  

                ///////////// end check availability ///////////
                
                if($result>0)
                {
                    
                    
                 $this->session->set_flashdata("already_added","Record already added.");
                 
                    
                     redirect('Notp/notp_add');                    
                        
                }
                else
                {
                $this->Notp_model->insertnotp($insert);

                $this->session->set_flashdata("success","Data has been submitted successfully.");
        
                }
                
                //$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('Notp/index');     
          
          }

        }
    }
    
    public function notp_edit($id){
       $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('NOTP', base_url('Notp/notp_update'));
        $data['page_type']='notp';     
        $data['state']=$this->hwc_model->get_state($id);
        $data['value'] = $this->Notp_model->notp_edit_show($id);
        
       
        loadLayout('programmanager/Notp/notp_update', 'program_manager', $data);

    }
    public function notp_update()
    {      

      if (isset($_POST['update']))
          {
                $id = $this->input->post('id');

             $data = array
                   (                    
                    
                   'state_id'=>$this->input->post('state_id'),
'notp_organs_act'=>$this->input->post('notp_organs_act'),
'notp_human_organs_amendment'=>$this->input->post('notp_human_organs_amendment'),
'year'=>$this->input->post('year'),
                    'updated_date'=> $this->input->post(date('updated_date')),

                    'updated_by'=>  (isset($_SESSION['memberID']))
                                                    
                );
     

                $result = $this->Notp_model->notp_update_data($id,$data);
               
        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
            
         }
           redirect('Notp/index',$id);

          }
    }
    public function delete($id)
     {
       $this->db->delete('notp_master_tbl', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('Notp/index'));
     }
    

}

