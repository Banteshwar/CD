<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Npcdcs extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
     
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
       
        $this->load->model('Dashboard_model');
		$this->load->model('programmanager/Npcdcs_model');
		
		$this->load->model('hwc_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index($year_id='',$month='') { 
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Npcdcs', base_url('Npcdcs/index'));
		
		if($year_id){
			$data['fin_year'] = $year_id;
		}else{
			$data['fin_year'] = getCurrYear();
		}
		

        /* if($month){
			$data['fin_month'] = $month;
		}else{
			$data['fin_month'] = get2Month(); 
		} */

if($month){
			$data['fin_month'] = $month;
		}else{
			$data['fin_month'] = getcurrent2Month(); 
		}		
				
        $data['page_type']='NPCDCS';
       
		$data['state']  =  $this->Npcdcs_model->get_Npcdcs_State($year_id,$month);
		//$data['months'] =  $this->Righttoinfo_model->getmonth();

        loadLayout('programmanager/npcdcs/formnpcdcs', 'program_manager', $data);

    }
	
	
	
	public function form_save(){ 
	//print_r($_POST);die;
       if (isset($_POST['submit'])){
        
		  $this->form_validation->set_rules('e_year','Year', 'required');
		  $this->form_validation->set_rules('e_month', 'Month', 'required');
			 
           if ($this->form_validation->run() == FALSE){
                $this->session->set_flashdata('required','Something went wrong. Please try again later.');	   
                redirect('Npcdcs/index/');	
		   } else {
	    					
             $this->Npcdcs_model->saveNpcdcs($_POST);
                
				$this->session->set_flashdata("success","Data has been submitted successfully.");				
                redirect('Npcdcs/index/'.$this->input->post("e_year").'/'.$this->input->post("e_month"));
           }

		  }
	}
	
	 
public function change_val_ajax($y_val,$y_month){
		 
		 $data['state']=$this->Npcdcs_model->get_Npcdcs_State_ajax($y_val,$y_month);		 
		 echo json_encode($data['state']);
		 die;	 
	 }
  
}
