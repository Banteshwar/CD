<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Nrcp extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
     
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
       
        $this->load->model('Dashboard_model');
		$this->load->model('programmanager/Nrcp_model');
		
		 $this->load->model('hwc_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index() { 
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Diseases Control', base_url('nrcp/nvhcp_form_list'));
        
        $data['page_type']='NRCP';
        $data['row'] = $this->Nrcp_model->get_NRCPs();
				       
        loadLayout('programmanager/nrcp/form_list', 'program_manager', $data);
    }
	
	/* public function add_form() { 
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Diseases Control', base_url('nrcp/nvhcp_form_list'));
		
		$data['state']=$this->hwc_model->get_state();
        
        $data['page_type']='NRCP';
      
       
        loadLayout('programmanager/nrcp/form_add', 'program_manager', $data);
    } */
	
	
	/* Rocky Start New */
	
	public function add_form() { 
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Diseases Control', base_url('nrcp/nvhcp_form_list'));
		
		$data['state']=$this->hwc_model->get_state();
        
        $data['page_type']='NRCP';
      
       
        loadLayout('programmanager/nrcp/form_add', 'program_manager', $data);
    }
	
	
	public function form_save()
	{ 
       if (isset($_POST['submit']))
		  {
			     
         // $this->form_validation->set_rules('state_name', 'State', 'required');
		   $this->form_validation->set_rules('e_quarter', 'Quarter', 'required');
		  $this->form_validation->set_rules('e_year', 'Year', 'required');
			 
          if ($this->form_validation->run() == FALSE)
                {
                	 	//$data['state']=$this->hwc_model->get_state();
                	 	redirect('nrcp/add_form');	
                       // $this->load->view('programmanager/nvhcp/nvhcp_form_add',$data);
                }
                else
                {

           $data = array
				   (	 				
					
					//'state_id'=> $this->input->post('state_name'),
					'e_year'=> $this->input->post('e_year'),
					'e_quarter'=> $this->input->post('e_quarter'),
					
					//'Animal_Bite_cases_reported'=> $this->input->post('Animal_Bite_cases_reported'),
					//'Human_rabies_cases_reported'=>$this->input->post('Human_rabies_cases_reported'),
					//'Vaccine_availability_status'=>$this->input->post('Vaccine_availability_status'),
					
					'updated_by'=>  (isset($_SESSION['memberID']))
													
			  	);
                
                /////// chk availability /////////
                 
                 /* $result = $this->Nrcp_model->chkNRCP($this->input->post('state_name'),$this->input->post('e_year'),$this->input->post('e_quarter')); */
				 
				 $result = $this->Nrcp_model->chkNRCP($this->input->post('e_year'),$this->input->post('e_quarter'));
                  
				 
                ///////////// end check availability ///////////
                
                if($result>0)
                {
					
					
                 $this->session->set_flashdata("already_added","Record already added.");
                 
					
				  redirect('nrcp/add_form');					
						
                }
                else
                {
				$this->Nrcp_model->insertNRCP($data);

				$this->session->set_flashdata("success","Data has been submitted successfully.");
        
			    }
				
				//$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('nrcp/index');     
		  
		  }

		  }
	}
	
	/* Rocky Ended */
	
	/* public function form_save()
	{ 
       if (isset($_POST['submit']))
		  {
			     
          $this->form_validation->set_rules('state_name', 'State', 'required');
		   $this->form_validation->set_rules('e_quarter', 'Quarter', 'required');
		  $this->form_validation->set_rules('e_year', 'Year', 'required');
			 
          if ($this->form_validation->run() == FALSE)
                {
                	 	//$data['state']=$this->hwc_model->get_state();
                	 	redirect('nrcp/add_form');	
                       // $this->load->view('programmanager/nvhcp/nvhcp_form_add',$data);
                }
                else
                {

           $data = array
				   (	 				
					
					'state_id'=> $this->input->post('state_name'),
					'e_year'=> $this->input->post('e_year'),
					'e_quarter'=> $this->input->post('e_quarter'),
					
					'Animal_Bite_cases_reported'=> $this->input->post('Animal_Bite_cases_reported'),
					'Human_rabies_cases_reported'=>$this->input->post('Human_rabies_cases_reported'),
					'Vaccine_availability_status'=>$this->input->post('Vaccine_availability_status'),
					
					'updated_by'=>  (isset($_SESSION['memberID']))
													
			  	);
                
                /////// chk availability /////////
                 
                 $result = $this->Nrcp_model->chkNRCP($this->input->post('state_name'),$this->input->post('e_year'),$this->input->post('e_quarter'));
                  
				 
                ///////////// end check availability ///////////
                
                if($result>0)
                {
					
					
                 $this->session->set_flashdata("already_added","Record already added.");
                 
					
				  redirect('nrcp/add_form');					
						
                }
                else
                {
				$this->Nrcp_model->insertNRCP($data);

				$this->session->set_flashdata("success","Data has been submitted successfully.");
        
			    }
				
				//$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('nrcp/index');     
		  
		  }

		  }
	} */
	
	public function edit_form($id)
	{
	   $data['state']=$this->hwc_model->get_state();
       $data['value'] = $this->Nrcp_model->getNRCP_byId($id);
	   
	  // echo print_r($data['value']); die;
	   
	
       $data['page_type']='NRCP';

	    loadLayout('programmanager/nrcp/form_edit', 'program_manager', $data);

	}
	
	public function form_update($id)
	{      
      if (isset($_POST['update']))
		  {
		  	 $data = array
				   (	

                    'state_id'=> $this->input->post('state_name'),
					'e_year'=> $this->input->post('e_year'),
					'e_quarter'=> $this->input->post('e_quarter'),
					
					'Animal_Bite_cases_reported'=> $this->input->post('Animal_Bite_cases_reported'),
					'Human_rabies_cases_reported'=>$this->input->post('Human_rabies_cases_reported'),
					'Vaccine_availability_status'=>$this->input->post('Vaccine_availability_status'),
					
					
					'updated_date'=> date("Y-m-d H:i:s"),
					
					'updated_by'=>  (isset($_SESSION['memberID']))
													
			  	);
                
      

		$result = $this->Nrcp_model->updateNRCP_byId($id,$data);
	

        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
			
	     }
         redirect(base_url('nrcp/edit_form/'. $id));

		  }
	}
	

public function delete($id)
     {
       $this->db->delete('nrcp_master_table', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('nrcp/index'));
     }
  
}
