<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Ntcp extends MY_Controller 
{
    private $user;

    public function __construct() 
    {
        parent::__construct();
      
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('programmanager/Ddap_model');
        $this->load->model('programmanager/Ntcp_model');
        $this->load->model('Hwc_model');
        $this->load->model('Report_model');
        $this->load->library('form_validation');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');
    }

    public function index() 
    { 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('National Tobacco Control Programme ', base_url('ntcp/ntcp_form_list'));
        
        $data['page_type']='Ntcp';
        $data['states']=$this->Hwc_model->get_state();
	//	var_dump($data['states']);die;
        $data['row'] = $this->Ntcp_model->ntcp_list();
        loadLayout('programmanager/ntcp/ntcp_form_list', 'program_manager', $data);
    }



//----------------------START KPI FORM CRUD OPERATIONS----------------//

    // Load Add NTCP form page
    public function add_form() 
    {    
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('National Tobacco Control Programme', base_url('ntcp/ntcp_form_list'));
        
        $data['state']=$this->Hwc_model->get_state();
        $data['page_type']='Ntcp';

        loadLayout('programmanager/ntcp/ntcp_form_add', 'program_manager', $data);
    }


    //Insert NTCP form function
    public function insert_ntcp_form()
    {
      if (isset($_POST['submitqaform']))
      {
        
        $table='ntcp_master_table';
        
        $this->form_validation->set_rules('financial_year', 'Financial Year', 'required');
        $this->form_validation->set_rules('financial_month', 'Month Period', 'required');
        $this->form_validation->set_rules('statename', 'State Name', 'required');
        $this->form_validation->set_rules('district_no', 'District Number', 'required');
        $this->form_validation->set_rules('fine_imposed', ' Amount of Fine', 'required');
        $this->form_validation->set_rules('tccs_no', 'TCCS Count', 'required');
        $this->form_validation->set_rules('cotpa_cases_no', 'COTPA Cases Count', 'required');
        $this->form_validation->set_rules('persons_service_no', 'Persons availing services', 'required');
        $this->form_validation->set_rules('districts_tccs_no', 'No . of Districts', 'required');
        $this->form_validation->set_rules('quitline_centre_name', 'Quitline Centre Name', 'required');
        $this->form_validation->set_rules('quitlinecalls_no', 'Quitline No. of Calls', 'required');     
        $this->form_validation->set_rules('reg_quitters_no', 'Registered No. of Quitters', 'required');
        $this->form_validation->set_rules('persons_quit_no', 'No. of Persons Quitline', 'required');

        $this->form_validation->set_rules('seats_quitline', 'No. of Seats Quitline', 'required');

                  
        if ($this->form_validation->run() == FALSE)
        {                
            $data['states']=$this->Hwc_model->get_state();
            redirect('Ntcp/add_form');
        }
        else
        {
                        
            $data = array
            (   
                'financial_year'     =>  $this->input->post('financial_year'),
                'financial_month'    =>  $this->input->post('financial_month'),
                'state_id'           =>  $this->input->post('statename'),
                'district_no'        =>  $this->input->post('district_no'),
                'fine_imposed'       =>  $this->input->post('fine_imposed'),
                'tccs_no'            =>  $this->input->post('tccs_no'),
                'cotpa_cases_no'     =>  $this->input->post('cotpa_cases_no'),
                'persons_service_no' =>  $this->input->post('persons_service_no'), 
                'districts_tccs_no'  =>  $this->input->post('districts_tccs_no'),
                'quitline_centre_name' =>  $this->input->post('quitline_centre_name'),
                'quitlinecalls_no'   =>  $this->input->post('quitlinecalls_no'),
                'reg_quitters_no'    =>  $this->input->post('reg_quitters_no'),
                'persons_quit_no'    =>  $this->input->post('persons_quit_no'),           
                'seats_quitline'    =>  $this->input->post('seats_quitline'),
                //'states_quitline'    =>  implode(',', $this->input->post('states_quitline')),
                'updated_by'         =>  (isset($_SESSION['memberID']))
            );

                $query =$this->Ntcp_model->ntcp_insert($data,$table);
                
                if($query)
                {                   
                    $this->session->set_flashdata("success","NTCP form data has been saved successfully.");
                    redirect('Ntcp/index');  
                }
                else
                {       
                    $this->session->set_flashdata("error","Failed to save NTCP form data, Please Try again!!");               
                }
       
            redirect('Ntcp/add_form');
        }
    }
  }

    // Edit QA form
    public function edit_ntcpform($id)
    {
       $data['states']=$this->Hwc_model->get_state();
       $data['value'] = $this->Ntcp_model->getNTCP_byId($id);
       $data['page_type']='Ntcp';
       loadLayout('programmanager/ntcp/ntcp_form_edit', 'program_manager', $data);
    }

    public function update_ntcpform($id)
    {                $id = $this->input->post('id');

          if (isset($_POST['update']))
          {
            $data = array
            (                    
               'financial_year'     =>  $this->input->post('financial_year'),
               'financial_month'    =>  $this->input->post('financial_month'),
               'state_id'           =>  $this->input->post('statename'),
               'district_no'        =>  $this->input->post('district_no'),
               'fine_imposed'       =>  $this->input->post('fine_imposed'),
               'tccs_no'            =>  $this->input->post('tccs_no'),
               'cotpa_cases_no'     =>  $this->input->post('cotpa_cases_no'),
               'persons_service_no' =>  $this->input->post('persons_service_no'), 
               'districts_tccs_no'  =>  $this->input->post('districts_tccs_no'),
               'quitline_centre_name' =>  $this->input->post('quitline_centre_name'),
               'quitlinecalls_no'   =>  $this->input->post('quitlinecalls_no'),
               'reg_quitters_no'    =>  $this->input->post('reg_quitters_no'),
               'persons_quit_no'    =>  $this->input->post('persons_quit_no'),
               'seats_quitline'    =>  $this->input->post('seats_quitline'),
               //'states_quitline'    =>  $this->input->post('states_quitline'),
               'updated_date'       =>  date("Y-m-d H:i:s"),            
               'updated_by'         =>  (isset($_SESSION['memberID']))                                                
             );                 

            $result = $this->Ntcp_model->updateNTCP_byId($id,$data);

            if($result)
            {
                $this->session->set_flashdata('success','Record Updated Successfully');
                redirect('Ntcp/index'); 
            }
            else
            {
                $this->session->set_flashdata('error','Something went wrong. Please try again later.');        
            }
                redirect(base_url('Ntcp/edit_ntcpform/'. $id));
            }
    }

    public function delete($id)
    {
       $this->db->delete('ntcp_master_table', array('id' => $id));
       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('Ntcp/index'));
    }

   //----------------------END KPI FORM CRUD OPERATIONS----------------//





    //----------------------START KPI FORM CRUD OPERATIONS----------------//

    public function viewcentre()
    { 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('National Tobacco Control Programme', base_url('ntcp/centre_form_list'));        
        $data['page_type'] = 'Ntcp';
        $data['row']    = $this->Ntcp_model->ntcpcentre_list();
        
        loadLayout('programmanager/ntcp/centre_form_list', 'program_manager', $data);
    }

    // Load Add Centre form page
    public function add_centre() 
    {    
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('National Tobacco Control Programme', base_url('ntcp/centre_form_list'));
        
        $data['states']=$this->Hwc_model->get_state();
        $data['page_type']='Ntcp';

        loadLayout('programmanager/ntcp/centre_form_add', 'program_manager', $data);
    }

    //Insert Centre form function
    public function insert_centre()
    {
        $table='ntcpcentre_master_table';
        
        $this->form_validation->set_rules('institution_name', 'Quitline Centre Name', 'required');
        $this->form_validation->set_rules('statename', 'State Name', 'required');
        $this->form_validation->set_rules('districtname', 'District Number', 'required');
        $this->form_validation->set_rules('address', 'Quitline Address', 'required');
         
        if ($this->form_validation->run() == FALSE)
        {               
            $data['states']=$this->Hwc_model->get_state();
            redirect('Ntcp/add_centre');
        }
        else
        {
            $data = array
            (               
                'state_id'           =>  $this->input->post('statename'),
                'district_id'        =>  $this->input->post('districtname'),          
                'institution_name'   =>  $this->input->post('institution_name'),
                'address'            =>  $this->input->post('address'),
                'updated_by'         =>  (isset($_SESSION['memberID']))
            );

                $query =$this->Ntcp_model->ntcpcentre_insert($data,$table);
                
                if($query)
                {                   
                    $this->session->set_flashdata("success","Centre form data has been saved successfully.");
                    redirect('Ntcp/viewcentre');  
                }
                else
                {       
                    $this->session->set_flashdata("error","Failed to save Centre form data, Please Try again!!");               
                }
       
            redirect('Ntcp/viewcentre');
        }
    }


    // Delete Centr Form Data
    public function deletecentre($id)
    {
       $this->db->delete('ntcpcentre_master_table', array('id' => $id));
       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('Ntcp/viewcentre'));
    }

    // Edit NTCP Centre form
    public function edit_centre($id)
    {
       $data['states']=$this->Hwc_model->get_state();
       $data['districts']  = $this->Ddap_model->get_district();
       $data['value'] = $this->Ntcp_model->getNTCPCENTRE_byId($id);
      /* echo "<pre>";
       print_r($data['districts']); die;*/
       $data['page_type']='Ntcp';
       loadLayout('programmanager/ntcp/centre_form_edit', 'program_manager', $data);
    }

    public function update_centre($id)
    {      
          if (isset($_POST['updatecentreform']))
          {
                $data = array
                (                    
                   'state_id'           =>  $this->input->post('statename'),
                   'district_id'        =>  $this->input->post('districtname'),          
                   'institution_name'   =>  $this->input->post('institution_name'),
                   'address'            =>  $this->input->post('address'),
                   'updated_date'       =>  date("Y-m-d H:i:s"),            
                   'updated_by'         =>  (isset($_SESSION['memberID']))                                                
                 );                 

                $result = $this->Ntcp_model->updateNTCPcentre_byId($id,$data);

                if($result)
                {
                    $this->session->set_flashdata('success','Record Updated Successfully');
                    redirect('Ntcp/viewcentre'); 
                }
                else
                {
                    $this->session->set_flashdata('error','Something went wrong. Please try again later.');        
                }
                    redirect(base_url('Ntcp/edit_centre/'. $id));
            }
    }


    //------------Upload Excel---------------//
    
    
    /*public function UploadExcel(){ 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Service Delivery', base_url('ddap/ddap_user_form'));        
        $data['page_type'] = 'Health Service Delivery';
        $data['row']       = $this->ddap_model->get_center();       
        loadLayout('programmanager/ddap/uploadExcel', 'program_manager', $data);
    }
    
    public function uploadexceldata()
    {        
        if($_FILES['image']['name']!=''){           
            if(!is_dir('download/excel/'.date('d-m-Y'))){
                mkdir('./download/excel/'.date('d-m-Y'),0777,TRUE);
            }
            $config['upload_path']='./download/excel/'.date('d-m-Y');
            $config['allowed_types']='csv';
            $config['max_size']='100000';
            $config['max_width'] = '0';
            $config['max_height'] = '0';
            $config['remove_spaces'] = true;
            $this->load->library('upload', $config);
            $this->upload->initialize($config);

            if(! $this->upload->do_upload('image')){
                $message    = array("0",strip_tags($this->upload->display_errors()));
            }else{
                $upload_ques = $this->upload->data();
                $requestdata['image']='download/excel/'.$upload_ques['file_name'];
            }
            $count = 0;
            $fp = fopen($_FILES['image']['tmp_name'],'r') or die("can't open file");
            
            while($csv_line = fgetcsv($fp,10000)){
            echo $count   =  count($csv_line);die;
            
            if ($count > 0) {
          
                $inData    =   array(
                    'centerID'                =>  $csv_line[0],
                    'deaddiction_treatment'   =>  $csv_line[1],
                    'dependence_treatment'    =>  $csv_line[2],
                );
                
                $centerID =   $csv_line[1];
                
                $sql_check  =   $this->db->query("select * from `tbl_ddap` where `centerID`='".$centerID."'");
                $row_check  =   $sql_check->row_array();
                $this->load->library('email'); 

                if(empty($row_check)){                    
                    $inData['centerID'] =   $centerID;
                    if($this->db->insert("tbl_ddap",$inData)){
                        $message=array("1","File Uploaded Successfully");
                    }else{
                        $message=array("0",$this->db->_error_message());
                    }
                }else{
                   
                    $this->db->where("centerID",$centerID);
                    $this->db->update("tbl_ddap" , $inData);                    
                    $message=array("1","Record Successfully Updated");
                }
              }
            }
        }else{
            $message=array("0","No File selected");
        }
        $this->session->set_flashdata('message', $message);
        redirect(base_url("ddap/uploadexcel"));
        fclose($fp) or die("can't close file");

    }*/
    

   //----------------------END KPI FORM CRUD OPERATIONS----------------//
 
}
