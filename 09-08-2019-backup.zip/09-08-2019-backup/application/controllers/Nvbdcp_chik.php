<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Nvbdcp_chik extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
     
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
       
        $this->load->model('Dashboard_model');
		$this->load->model('programmanager/Nvbdcp_chik_model');
		
		 $this->load->model('hwc_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index() { 
	
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('NVBDCP', base_url('Nvbdcp/chik_form_list'));
        
        $data['page_type']='NVBDCP';
        $data['row'] = $this->Nvbdcp_chik_model->get_Nvbd_chik();
				       
        loadLayout('programmanager/Nvbdcp/chik_form_list', 'program_manager', $data);
    }
	
	public function form_add() { 
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('NVBDCP', base_url('Nvbdcp_chik/form_add'));
		
		$data['state']=$this->hwc_model->get_state();
        
        $data['page_type']='NVBDCP';
      
       
        loadLayout('programmanager/Nvbdcp/chik_form_add', 'program_manager', $data);
    }
	
	public function form_save()
	{ 
       if (isset($_POST['submit']))
		  {
			   
          $this->form_validation->set_rules('e_year', 'type', 'required');
			 
          if ($this->form_validation->run() == FALSE)
                {
					
                	 	//$data['state']=$this->hwc_model->get_state();
                	 	redirect('Nvbdcp_chik/form_add');	
                       // $this->load->view('programmanager/nvhcp/nvhcp_form_add',$data);
                }
                else
                {

            $data = array
				   (	 				
					
					'year'=> $this->input->post('e_year'),
					'entry_type'=> $this->input->post('type'),
					
					'month'=> $this->input->post('e_month'),
					'state'=>$this->input->post('state_name'),
					'total_suspected'=>$this->input->post('tsc'),
					'total_confirmed'=>$this->input->post('tcc'),
					'sentinel'=>$this->input->post('nss'),
					
					'updated_by'=>  (isset($_SESSION['memberID']))
					
					
													
			  	);
               // print_r($data);die;
                /////// chk availability /////////
                 
                 $result = $this->Nvbdcp_chik_model->chkNvbdcpchik($this->input->post('state_name'),$this->input->post('e_year'),$this->input->post('type'));
                  
				 
                ///////////// end check availability ///////////
                
                if($result>0)
                {
					
					
                 $this->session->set_flashdata("already_added","Record already added.");
                 
					
				  redirect('Nvbdcp_chik/add_form');					
						
                }
                else
                {
				$this->Nvbdcp_chik_model->insertNvbdcpchik($data);

				$this->session->set_flashdata("success","Data has been submitted successfully.");
        
			    }
				
				//$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('Nvbdcp_chik/index');     
		  
		  }

		  }
	}
	
	public function edit_form($id)
	{
		
	   $data['state']=$this->hwc_model->get_state();
       $data['value'] = $this->Nvbdcp_chik_model->getNvbdcpchik_byId($id);
	   
	 // echo print_r($data['value']); die;
	   
	
       $data['page_type']='NVBDCP';
		
	    loadLayout('programmanager/Nvbdcp/chik_form_edit', 'program_manager', $data);

	}
	
	public function form_update($id)
	{      
      if (isset($_POST['update']))
		  {
		  	 $data = array
				   (	 				
					
					'year'=> $this->input->post('e_year'),
					'entry_type'=> $this->input->post('type'),
					
					'month'=> $this->input->post('e_month'),
					'state'=>$this->input->post('state_name'),
					'total_suspected'=>$this->input->post('tsc'),
					'total_confirmed'=>$this->input->post('tcc'),
					'sentinel'=>$this->input->post('nss'),
					'updated_by'=>  (isset($_SESSION['memberID']))
					
					
													
			  	);
                
      

		$result = $this->Nvbdcp_chik_model->updateNvbdcpchik_byId($id,$data);
	

        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
			
	     }
         redirect(base_url('Nvbdcp_chik/edit_form/'. $id));

		  }
	}
	

public function delete($id)
     {
       $this->db->delete('nvbdcp_chikungunya_table', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('Nvbdcp_chik/index'));
     }
  
}
