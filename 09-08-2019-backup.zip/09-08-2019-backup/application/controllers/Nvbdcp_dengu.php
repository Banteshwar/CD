<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Nvbdcp_dengu extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
     
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
       
        $this->load->model('Dashboard_model');
		$this->load->model('programmanager/Nvbdcp_dengu_model');
		
		$this->load->model('hwc_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index($year_id='',$month='') { 
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Disease control', base_url('Nvbdcp_dengu/index'));
		
		if($year_id){
			$data['fin_year'] = $year_id;
		}else{
			$data['fin_year'] = getCurrYear('Monthly');
		}	


        if($month){
			$data['fin_month'] = $month;
		}else{
			$data['fin_month'] = getCurrMonth('Monthly'); 
		}		
			

        $data['page_type']='NVBDCP';
       
		$data['state']  =  $this->Nvbdcp_dengu_model->get_State($data['fin_year'],$data['fin_month']);
		//$data['months'] =  $this->Righttoinfo_model->getmonth();

        loadLayout('programmanager/Nvbdcp/form4', 'program_manager', $data);

    }
	
	
	public function form_save(){ 
	
       if (isset($_POST['submit'])){
        
		  $this->form_validation->set_rules('year_id','Year', 'required');
		  $this->form_validation->set_rules('financial_month', 'Month', 'required');
		
			 
           if ($this->form_validation->run() == FALSE){
                $this->session->set_flashdata('required','Something went wrong. Please try again later.');	   
                redirect('Nvbdcp_dengu/index/');	
		   } else {
		   	
	    					
                $this->Nvbdcp_dengu_model->saveDengu($_POST);
				$this->session->set_flashdata("success","Data has been submitted successfully.");				
                redirect('Nvbdcp_dengu/index/'.$this->input->post("year_id").'/'.$this->input->post("financial_month"));
           }

		  }
	}
	

	public function deleteNvbdcpdengue($id){

     $ss=$this->db->delete('nvbdcp_dengu_table', array('id' => $id));
	   
	   if($ss){
		   echo "1";
	   }else{
		   echo "0";
	   }
    }
	 
public function change_val_ajax($y_val,$q_val){
		 
		 $data['state']=$this->Nvbdcp_dengu_model->get_Dengu_State_ajax($y_val,$q_val);		 
		 
		 echo json_encode($data['state']);
		 die;	 
	 }
  
}
