<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class nvbdcp_jap extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
     
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
       
        $this->load->model('Dashboard_model');
		$this->load->model('programmanager/nvbdcp_jap_model');
		
		 $this->load->model('hwc_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index() { 
	
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Disease control', base_url('Nvbdcp/jap_form_list'));
        
        $data['page_type']='NVBDCP';
        $data['row'] = $this->nvbdcp_jap_model->get_Nvbd_jap();
				       
        loadLayout('programmanager/Nvbdcp/jap_form_list', 'program_manager', $data);
    }
	
	public function form_add() { 
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Disease control', base_url('nvbdcp_jap/form_add'));
		
		$data['state']=$this->hwc_model->get_state();
        
        $data['page_type']='NVBDCP';
      
       
        loadLayout('programmanager/Nvbdcp/jap_form_add', 'program_manager', $data);
    }
	
	public function form_save()
	{ 
       if (isset($_POST['submit']))
		  {
			   
          $this->form_validation->set_rules('e_year', 'type', 'required');
			 
          if ($this->form_validation->run() == FALSE)
                {
					
                	 	//$data['state']=$this->hwc_model->get_state();
                	 	redirect('nvbdcp_jap/form_add');	
                       // $this->load->view('programmanager/nvhcp/nvhcp_form_add',$data);
                }
                else
                {

            $data = array
				   (	 				
					
					'year'=> $this->input->post('e_year'),
					'entry_type'=> $this->input->post('type'),
					
					'month'=> $this->input->post('e_month'),
					'state'=>$this->input->post('state_name'),
					'total_case'=>$this->input->post('tcase'),
					'death'=>$this->input->post('death'),
					'endemic'=>$this->input->post('ed'),
					'vaccination'=>$this->input->post('ndv'),
					'je_vaccination'=>$this->input->post('ndcv'),
					'updated_by'=>  (isset($_SESSION['memberID']))
					
					
													
			  	);
               // print_r($data);die;
                /////// chk availability /////////
                 
                 $result = $this->nvbdcp_jap_model->chkNvbdcpjap($this->input->post('state_name'),$this->input->post('e_year'),$this->input->post('type'));
                  
				 
                ///////////// end check availability ///////////
                
                if($result>0)
                {
					
					
                 $this->session->set_flashdata("already_added","Record already added.");
                 
					
				  redirect('nvbdcp_jap/add_form');					
						
                }
                else
                {
				$this->nvbdcp_jap_model->insertNvbdcpjap($data);

				$this->session->set_flashdata("success","Data has been submitted successfully.");
        
			    }
				
				//$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('nvbdcp_jap/index');     
		  
		  }

		  }
	}
	
	public function edit_form($id)
	{
		
	   $data['state']=$this->hwc_model->get_state();
       $data['value'] = $this->nvbdcp_jap_model->getNvbdcpjap_byId($id);
	   
	 // echo print_r($data['value']); die;
	   
	
       $data['page_type']='NVBDCP';
		
	    loadLayout('programmanager/Nvbdcp/jap_form_edit', 'program_manager', $data);

	}
	
	public function form_update($id)
	{      
      if (isset($_POST['update']))
		  {
		  	 $data = array
				   (	 				
					'year'=> $this->input->post('e_year'),
					'entry_type'=> $this->input->post('type'),
					
					'month'=> $this->input->post('e_month'),
					'state'=>$this->input->post('state_name'),
					'total_case'=>$this->input->post('tcase'),
					'death'=>$this->input->post('death'),
					'endemic'=>$this->input->post('ed'),
					'vaccination'=>$this->input->post('ndv'),
					'je_vaccination'=>$this->input->post('ndcv'),
					'updated_by'=>  (isset($_SESSION['memberID']))
					
					
													
			  	);
                
      

		$result = $this->nvbdcp_jap_model->updateNvbdcpjap_byId($id,$data);
	

        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
			
	     }
         redirect(base_url('nvbdcp_jap/edit_form/'. $id));

		  }
	}
	

public function delete($id)
     {
       $this->db->delete('nvbdcp_encephalitis_table', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('nvbdcp_jap/index'));
     }
  
}
