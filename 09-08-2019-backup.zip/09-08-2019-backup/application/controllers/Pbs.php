<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Pbs extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
     
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
       
        $this->load->model('Dashboard_model');
		$this->load->model('programmanager/Pbs_new_model');
		
		$this->load->model('hwc_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index($year_id='',$month='') { 
	 
        $this->mybreadcrumb->add('Home', base_url('secretary/page/index'));
        $this->mybreadcrumb->add('PBS', base_url('pbs/newform'));
		
		if($year_id){
			$data['fin_year'] = $year_id;
		}else{
			$data['fin_year'] = getYearFull();
		}	

        if($month){
			$data['fin_month'] = $month;
		}else{
			$data['fin_month'] = get2Month(); 
		}		
		$data['curr'] = getcurrent2Month(); 			
        $data['page_type']='PBS';
       
		$data['state']  =  $this->Pbs_new_model->get_Ambulances_State($year_id,$month);
		//$data['months'] =  $this->Righttoinfo_model->getmonth();

        loadLayout('programmanager/pbs/newform', 'program_manager', $data);

    }
	
	
	
	public function form_save(){ 
	//print_r($_POST);die;
       if (isset($_POST['submit'])){
        
		  $this->form_validation->set_rules('e_year','Year', 'required');
		  $this->form_validation->set_rules('e_month', 'Month', 'required');
		  		/*  $this->form_validation->set_rules('trained_NCD_mgmt', 'Personnel trained in NCD management', 'required');

		  $this->form_validation->set_rules('trained_NCD_appl', 'Personnel trained on NCD application', 'required');

		  $this->form_validation->set_rules('enrolled_NCD_appl', 'Persons enrolled in NCD application', 'required');

		  $this->form_validation->set_rules('persons_screened', 'Persons screened', 'required');*/

		
		  
			 
           if ($this->form_validation->run() == FALSE){
                $this->session->set_flashdata('required','Something went wrong. Please try again later.');	   
                redirect('Pbs/index/');	
		   } else {
	    					
             $this->Pbs_new_model->saveAmbulances($_POST);
                
				 $this->session->set_flashdata("success","Data has been submitted successfully of Month " .$this->input->post("e_month"). " and ". $this->input->post("e_year"));			
                redirect('Pbs/index/'.$this->input->post("e_year").'/'.$this->input->post("e_month"));
           }

		  }
	}
	
	 
public function change_val_ajax($y_val,$y_month){
		 
		 $data['state']=$this->Pbs_new_model->get_Ambulances_State_ajax($y_val,$y_month);		 
		 echo json_encode($data['state']);
		 die;	 
	 }
  
}
