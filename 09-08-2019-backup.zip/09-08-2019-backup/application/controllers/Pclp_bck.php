<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Pclp extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
     
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
       
        $this->load->model('Dashboard_model');
		$this->load->model('programmanager/Pclpnew_model');
		
		$this->load->model('hwc_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index($year_id='',$q_id='') { 
	
        $this->mybreadcrumb->add('Home', base_url('secretary/page/index'));
       // $this->mybreadcrumb->add('HASDHFD', base_url('pclp/index'));
        $this->mybreadcrumb->add('PCLP', base_url('pclp/index'));
		
		if($year_id)
		{
		$data['fin_year'] = $year_id;
		}
		else{
		$data['fin_year'] = getCurrFinYear();
		}	

        if($q_id)
		{
		$data['fin_querter'] = $q_id;
		}
		else{
		$data['fin_querter'] = getCurrQuarter(); 
		}			
		
        
        $data['page_type']='PCLP';
      
		$data['rows']  =  $this->Pclpnew_model->get_Ambulances_State($data['fin_year'],$data['fin_querter']);
        $data['gstate']=$this->Pclpnew_model->getstate();       		       
        loadLayout('programmanager/pclp/pclp_new', 'program_manager', $data);
    }
	
	public function form_save(){ 	
	
      // if(isset($_POST['submit'])){		
     
		  $this->form_validation->set_rules('year_id', 'Year', 'required');
		  $this->form_validation->set_rules('q_id', 'Quarter', 'required');		  
			 
          if($this->form_validation->run() == FALSE){
			
        	    $this->session->set_flashdata('required','Something went wrong. Please try again later.');
			   
        	 	redirect('pclp/index/');	
		  }else{             
						
	        $this->Pclpnew_model->saveAmbulances($_POST);
			$this->session->set_flashdata("success","Data has been submitted successfully of Quarter " .$this->input->post("q_id"). " and ". $this->input->post("year_id"));    
		    redirect('pclp/index/'.$this->input->post("year_id").'/'.$this->input->post("q_id"));
		   }

		//}
	}	
	
	public function change_val_ajax($y_val,$q_val){	
	
	   $data['state']=$this->Pclpnew_model->get_Ambulances_State_ajax($y_val,$q_val);
	   echo json_encode($data['state']);
	   die;
	}

	 public function deletePclp($id){

     $ss=$this->db->delete('pclp_master_table', array('id' => $id));
	   
	   if($ss){
		   echo "1";
	   }else{
		   echo "0";
	   }
    }
	  
}
