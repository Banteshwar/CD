<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Pmndp extends MY_Controller {
    private $user;

    public function __construct() {
        parent::__construct();

        $this->load->helper('commondata_helper');

        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('programmanager/Pmndp_model');
                
        $this->user = new Users();

        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');
    }
    

    public function index() { 
        
        $this->view();
    }
    
     public function add_form(){  
        
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('PM-NDP', base_url('Pmndp/index'));
        
        $data['page_type'] = 'PM-NDP';

        loadLayout('programmanager/pmndp/pm_ndp_form', 'program_manager', $data);
    }
    
    private function validate(){          
        $this->form_validation->set_rules('dialysis_functional', 'Total number of districts', 'trim|required');
        $this->form_validation->set_rules('dialysis_centres', 'Total No. of functional  Dialysis centres', 'trim|required');
        $this->form_validation->set_rules('dialysis_machines', 'Total No. of functional Dialysis Machines', 'trim|required');
        $this->form_validation->set_rules('dialysis_sessions_held', 'Cumulative No. of Dialysis sessions held', 'trim|required');

        if($this->form_validation->run() == TRUE){
            $requestdata  =   array(
                "dialysis_functional"          =>  $this->input->post('dialysis_functional'),
                "dialysis_centres"          =>  $this->input->post('dialysis_centres'),        
                "dialysis_machines"         =>  $this->input->post('dialysis_machines'), 
                "dialysis_sessions_held"          =>  $this->input->post('dialysis_sessions_held')
            ); 
            return $requestdata;
        }else{
            $this->form_validation->set_error_delimiters('', '');
            $message    = array("0",validation_errors());
            $this->session->set_flashdata('message', $message);
            return false;
        }
    }
    
    public function insertForm(){   
        $requestdata    =   $this->validate();
        //var_dump($requestdata);die;
        if(!empty($requestdata)){
            if($this->Pmndp_model->insertdata("tbl_pm_ndp",$requestdata)){
                $message    = array("1","Successfully Submit");
            }else{
                $message    = array("0",$this->db->_error_message());
            }
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url("Pmndp/add_form"));
    }
    
    public function view(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('PM-NDP', base_url('Pmndp/add_form'));        
       
        $data['page_type'] = 'PM-NDP';
        $data['row']    = $this->Pmndp_model->get_pmndpform();
//var_dump($data['row']); die;
        loadLayout('programmanager/pmndp/pm_ndp_list', 'program_manager', $data);
    }


    public function editForm(){
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('PM-NDP', base_url('Pmndp/index'));
       
        $data['row']         =   $this->Pmndp_model->fetchwhere("tbl_pm_ndp",array("id"=>$this->input->get('id')),"","row_array");
        $data['page_type'] = 'PM-NDP';
        loadLayout('programmanager/pmndp/pm_ndp_form', 'program_manager', $data);
    }
    
    public function updateForm(){
        $requestdata    =   $this->validate();
            if(!empty($requestdata)){
    
             if($this->Pmndp_model->updatedata("tbl_pm_ndp",$requestdata,array("id"=>$this->input->post('id')))){
                $message    = array("1","Successfully Update");
        
            }else{
                $message    = array("0",$this->db->_error_message());
                $this->session->set_flashdata('message', $message);
            }       
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('Pmndp/editForm').'?action=edit&id='.$this->input->post('id'));
    }
    
    public function deleteForm(){
        
        if($this->input->get('id')){
            $this->Pmndp_model->deletedata("tbl_pm_ndp",array("id"=>$this->input->get('id')));
             $message    = array("1","Successfully Deleted");
              $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('Pmndp/view'),'location');
    }   
    
    
    
        
        
    }