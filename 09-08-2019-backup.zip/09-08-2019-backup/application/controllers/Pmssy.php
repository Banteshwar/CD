<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Pmssy extends MY_Controller {
    private $user;

    public function __construct() {
        parent::__construct();

        $this->load->helper('commondata_helper');

        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('programmanager/pmssy_model');
                
        $this->user = new Users();

        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');
    }
	

    public function index() { 
		
		$this->view();
    }
	
	 public function add_form(){  
        
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('PMSSY', base_url('pmssy/index'));
        
        $data['states']    = $this->pmssy_model->get_state();

		$data['districts'] = $this->pmssy_model->get_district();

        $data['page_type'] = 'Healthcare Infrastructure';

        loadLayout('programmanager/pmssy/pmssy_form', 'program_manager', $data);
    }
	
	private function validate(){          
        $this->form_validation->set_rules('statename', 'State Name', 'trim|required');
        $this->form_validation->set_rules('districtname', 'AIIMS', 'trim|required');
        $this->form_validation->set_rules('avg_daily_opd', 'Average Daily OPD', 'trim|required');
        $this->form_validation->set_rules('monthly_ipd', 'Monthly IPD', 'trim|required');
		$this->form_validation->set_rules('pg_seats', 'PG Seats', 'trim|required');
        $this->form_validation->set_rules('mbbs_seats', 'MBBS Seats', 'trim|required');
        $this->form_validation->set_rules('speciality_functional', 'Speciality Functional', 'trim|required');
        $this->form_validation->set_rules('super_speciality_functional', 'Super Speciality Functional', 'trim|required');
        $this->form_validation->set_rules('faculty_in_position', 'Faculty In position', 'trim|required');
        $this->form_validation->set_rules('non_faculty_in_position', 'Non-Faculty In position', 'trim|required');
		//$this->form_validation->set_rules('remarks', 'Remarks', 'trim|required');

        if($this->form_validation->run() == TRUE){
            $requestdata  =   array(
                "statename"                    =>  $this->input->post('statename'),
                "aiims_district"               =>  $this->input->post('districtname'),        
                "avg_daily_opd"                =>  $this->input->post('avg_daily_opd'),               
                "monthly_ipd"         	       =>  $this->input->post('monthly_ipd'),
				"pg_seats"                     =>  $this->input->post('pg_seats'),
                "mbbs_seats"                   =>  $this->input->post('mbbs_seats'),
                "speciality_functional"        =>  $this->input->post('speciality_functional'),
                "super_speciality_functional"  =>  $this->input->post('super_speciality_functional'),
                "faculty_in_position"          =>  $this->input->post('faculty_in_position'),
                "non_faculty_in_position"      =>  $this->input->post('non_faculty_in_position'),
                "remarks"                      =>  $this->input->post('remarks')
            ); 
            return $requestdata;
        }else{
            $this->form_validation->set_error_delimiters('', '');
            $message    = array("0",validation_errors());
            $this->session->set_flashdata('message', $message);
            return false;
        }
    }
	
	public function insertForm(){	
        $requestdata    =   $this->validate();
		//var_dump($requestdata);die;
        if(!empty($requestdata)){
            if($this->pmssy_model->insertdata("tbl_pmssy_form_b",$requestdata)){
                $message    = array("1","Successfully Submit");
            }else{
                $message    = array("0",$this->db->_error_message());
            }
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url("pmssy/add_form"));
    }
	
	public function view(){  
		$this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('PMSSY', base_url('pmssy/add_form'));        
        //$data['states']    = $this->pmssy_model->get_state();
       // $data['districts']    = $this->pmssy_model->get_district();
        $data['page_type'] = 'Healthcare Infrastructure';
		$data['row']    = $this->pmssy_model->get_pmssyform();
//var_dump($data['row']); die;
        loadLayout('programmanager/pmssy/pmssy_form_list', 'program_manager', $data);
	}


	public function editForm(){
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('PMSSY', base_url('pmssy/index'));
        
        $data['states']     = $this->pmssy_model->get_state();
		$data['districts']  = $this->pmssy_model->get_district();
       // $data['row']   		=   $this->pmssy_model->fetchwhere("tbl_pmssy_form_B",$this->input->get('id'));
		 $data['row']         =   $this->pmssy_model->fetchwhere("tbl_pmssy_form_b",array("id"=>$this->input->get('id')),"","row_array");
        $data['page_type'] = 'Healthcare Infrastructure';
		loadLayout('programmanager/pmssy/pmssy_form', 'program_manager', $data);
    }
	
    public function updateForm(){
        $requestdata    =   $this->validate();
        	if(!empty($requestdata)){
	
			 if($this->pmssy_model->updatedata("tbl_pmssy_form_b",$requestdata,array("id"=>$this->input->post('id')))){
			    $message    = array("1","Successfully Update");
		
            }else{
                $message    = array("0",$this->db->_error_message());
                $this->session->set_flashdata('message', $message);
            }		
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('pmssy/editForm').'?action=edit&id='.$this->input->post('id'));
    }
	
    public function deleteForm(){
        
		if($this->input->get('id')){
            $this->pmssy_model->deletedata("tbl_pmssy_form_b",array("id"=>$this->input->get('id')));
			 $message    = array("1","Successfully Deleted");
			  $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('pmssy/view'),'location');
    }	
	
	
	public function getDistrict($id) 
	{ 
		$result = $this->db->where("State_Code_LG",$id)->get("m_district_lg")->result();
       
        echo json_encode($result);
	}
	
	
	 
		
		
		
	}