<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class PmssyOtherAiims extends MY_Controller {
    private $user;

    public function __construct() {
        parent::__construct();

        $this->load->helper('commondata_helper');

        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('programmanager/pmssyOtherAiims_model');
                
        $this->user = new Users();

        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');
    }
	

    public function index() { 
		
		$this->view();
    }
	
	 public function add_form(){  
        
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('PMSSY', base_url('PmssyOtherAiims/index'));
        
        $data['states']    = $this->pmssyOtherAiims_model->get_state();

		$data['districts'] = $this->pmssyOtherAiims_model->get_district();

        $data['page_type'] = 'Healthcare Infrastructure';

        loadLayout('programmanager/pmssy/pmssyOtherAiims_form', 'program_manager', $data);
    }
	
	private function validate(){          
        $this->form_validation->set_rules('statename', 'State Name', 'trim|required');
        $this->form_validation->set_rules('districtname', 'AIIMS', 'trim|required');
        $this->form_validation->set_rules('cabinet_approval', 'Date of Cabinet Approval', 'trim|required');
        $this->form_validation->set_rules('civil_work', 'Progress of Civil Work', 'trim|required');
		//$this->form_validation->set_rules('start_opd', 'Start of OPD', 'trim|required');
        $this->form_validation->set_rules('status_ipd', 'Status of IPD', 'trim|required');
       // $this->form_validation->set_rules('status_mbbs', 'Status of MBBS Classes', 'trim|required');
      //  $this->form_validation->set_rules('target_completion', 'Target Date of Completion', 'trim|required');
       // $this->form_validation->set_rules('faculty_in_position', 'Faculty In position', 'trim|required');
	//	$this->form_validation->set_rules('remarks', 'Remarks', 'trim|required');

        if($this->form_validation->run() == TRUE){
            $requestdata  =   array(
                "statename"                    =>  $this->input->post('statename'),
                "aiims_district"               =>  $this->input->post('districtname'),        
                "cabinet_approval"             =>  $this->input->post('cabinet_approval'),               
                "civil_work"         	       =>  $this->input->post('civil_work'),
				"start_opd"                    =>  $this->input->post('start_opd'),
                "status_ipd"                   =>  $this->input->post('status_ipd'),
                "status_mbbs"                  =>  $this->input->post('status_mbbs'),
                "target_completion"            =>  $this->input->post('target_completion'),
                "faculty_in_position"          =>  $this->input->post('faculty_in_position'),
                "remarks"                      =>  $this->input->post('remarks')
            ); 
            return $requestdata;
        }else{
            $this->form_validation->set_error_delimiters('', '');
            $message    = array("0",validation_errors());
            $this->session->set_flashdata('message', $message);
            return false;
        }
    }
	
	public function insertForm(){	
        $requestdata    =   $this->validate();
		//var_dump($requestdata);die;
        if(!empty($requestdata)){
            if($this->pmssyOtherAiims_model->insertdata("tbl_pmssy_form_b_other",$requestdata)){
                $message    = array("1","Successfully Submit");
            }else{
                $message    = array("0",$this->db->_error_message());
            }
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url("PmssyOtherAiims/add_form"));
    }
	
	public function view(){  
		$this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('PMSSY', base_url('PmssyOtherAiims/add_form'));        
        //$data['states']    = $this->pmssyOtherAiims_model->get_state();
       // $data['districts']    = $this->pmssyOtherAiims_model->get_district();
        $data['page_type'] = 'Healthcare Infrastructure';
		$data['row']    = $this->pmssyOtherAiims_model->get_pmssyform();
//var_dump($data['row']); die;
        loadLayout('programmanager/pmssy/pmssyOtherAiims_list', 'program_manager', $data);
	}


	public function editForm(){
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('PMSSY', base_url('PmssyOtherAiims/index'));
        
        $data['states']     = $this->pmssyOtherAiims_model->get_state();
		$data['districts']  = $this->pmssyOtherAiims_model->get_district();
      
		 $data['row']         =   $this->pmssyOtherAiims_model->fetchwhere("tbl_pmssy_form_b_other",array("id"=>$this->input->get('id')),"","row_array");
        $data['page_type'] = 'Healthcare Infrastructure';
		loadLayout('programmanager/pmssy/pmssyOtherAiims_form', 'program_manager', $data);
    }
	
    public function updateForm(){
        $requestdata    =   $this->validate();
        	if(!empty($requestdata)){
	
			 if($this->pmssyOtherAiims_model->updatedata("tbl_pmssy_form_b_other",$requestdata,array("id"=>$this->input->post('id')))){
			    $message    = array("1","Successfully Update");
		
            }else{
                $message    = array("0",$this->db->_error_message());
                $this->session->set_flashdata('message', $message);
            }		
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('PmssyOtherAiims/editForm').'?action=edit&id='.$this->input->post('id'));
    }
	
    public function deleteForm(){
        
		if($this->input->get('id')){
            $this->pmssyOtherAiims_model->deletedata("tbl_pmssy_form_b_other",array("id"=>$this->input->get('id')));
			 $message    = array("1","Successfully Deleted");
			  $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('PmssyOtherAiims/view'),'location');
    }	
	
	
	public function getDistrict($id) 
	{ 
		$result = $this->db->where("State_Code_LG",$id)->get("m_district_lg")->result();
        echo json_encode($result);
	}
	
	
	 
		
		
		
	}