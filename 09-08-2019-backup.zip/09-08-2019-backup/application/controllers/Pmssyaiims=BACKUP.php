<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Pmssyaiims extends MY_Controller {
    private $user;

    public function __construct() {
        parent::__construct();
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('programmanager/Pmssyaiims_model');
                
        $this->user = new Users();

        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');
    }
    

    public function index() { 
        
        $this->view();
    }
    
     public function add_form(){  
        
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('PMSSY', base_url('Pmssyaiims/index'));
        
        $data['states']    = $this->Pmssyaiims_model->get_state();

        $data['districts'] = $this->Pmssyaiims_model->get_district();

        $data['page_type'] = 'Healthcare Infrastructure';

        loadLayout('programmanager/pmssy/pmssyAiims_form', 'program_manager', $data);
    }
    
    private function validate(){          
        $this->form_validation->set_rules('statename', 'State Name', 'trim|required');
        $this->form_validation->set_rules('districtname', 'District', 'trim|required');
        $this->form_validation->set_rules('pmc', 'PMC Appointed', 'trim|required');
        $this->form_validation->set_rules('new_aiims', 'New AIIMS Announced', 'trim|required');
        $this->form_validation->set_rules('turnkey', 'Turnkey Tender Awarded', 'trim|required');

        if($this->form_validation->run() == TRUE){
            $requestdata  =   array(
                "statename"       =>  $this->input->post('statename'),
                "district"        =>  $this->input->post('districtname'),        
                "pmc"             =>  $this->input->post('pmc'),               
                "new_aiims"      =>  $this->input->post('new_aiims'),
                "turnkey"         =>  $this->input->post('turnkey')
            ); 
            return $requestdata;
        }else{
            $this->form_validation->set_error_delimiters('', '');
            $message    = array("0",validation_errors());
            $this->session->set_flashdata('message', $message);
            return false;
        }
    }
    
    public function insertForm(){   
        $requestdata    =   $this->validate();
        //var_dump($requestdata);die;
        if(!empty($requestdata)){
            if($this->Pmssyaiims_model->insertdata("pmssyiims",$requestdata)){
                $message    = array("1","Successfully Submit");
            }else{
                $message    = array("0",$this->db->_error_message());
            }
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url("Pmssyaiims/add_form"));
    }
    
    public function view(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('Pmssyaiims/add_form'));        
        //$data['states']    = $this->Pmssyaiims_model->get_state();
       // $data['districts']    = $this->Pmssyaiims_model->get_district();
        $data['page_type'] = 'Healthcare Infrastructure';
        $data['row']    = $this->Pmssyaiims_model->get_pmssyform();
//var_dump($data['row']); die;
        loadLayout('programmanager/pmssy/pmssyAiims_form_list', 'program_manager', $data);
    }


    public function editForm(){
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('PMSSY', base_url('Pmssyaiims/index'));
        
        $data['states']     = $this->Pmssyaiims_model->get_state();
        $data['districts']  = $this->Pmssyaiims_model->get_district();
       // $data['row']          =   $this->Pmssyaiims_model->fetchwhere("tbl_pmssy_form_B",$this->input->get('id'));
         $data['row']         =   $this->Pmssyaiims_model->fetchwhere("pmssyiims",array("id"=>$this->input->get('id')),"","row_array");
        $data['page_type'] = 'Healthcare Infrastructure';
        loadLayout('programmanager/pmssy/pmssyAiims_form', 'program_manager', $data);
    }
    
    public function updateForm(){
        $requestdata    =   $this->validate();
            if(!empty($requestdata)){
    
             if($this->Pmssyaiims_model->updatedata("pmssyiims",$requestdata,array("id"=>$this->input->post('id')))){
                $message    = array("1","Successfully Update");
        
            }else{
                $message    = array("0",$this->db->_error_message());
                $this->session->set_flashdata('message', $message);
            }       
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('Pmssyaiims/editForm').'?action=edit&id='.$this->input->post('id'));
    }
    
    public function deleteForm(){
        
        if($this->input->get('id')){
            $this->Pmssyaiims_model->deletedata("pmssyiims",array("id"=>$this->input->get('id')));
             $message    = array("1","Successfully Deleted");
              $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('Pmssyaiims/view'),'location');
    }   
    
    
    public function getDistrict($id) 
    { 
        $result = $this->db->where("State_Code_LG",$id)->get("m_district_lg")->result();
        echo json_encode($result);
    }
    
    
     
        
        
        
    }