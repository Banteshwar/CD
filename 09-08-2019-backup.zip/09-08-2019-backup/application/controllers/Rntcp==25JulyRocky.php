<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Rntcp extends MY_Controller {
    private $user;

    public function __construct() {
        parent::__construct();           
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('programmanager/Rntcp_model');
        $this->load->model('Dashboard_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');
    }

        
    public function index() { 		
    	$this->rntcp_view();
    }
	
	public function rntcp_view()
    {  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Rntcp', base_url('rntcp/index'));
         $this->mybreadcrumb->add('Rntcp', base_url('rntcp/index'));       
        $data['page_type'] = 'Rntcp';
		$data['row'] = $this->Rntcp_model->get_rntcp();
        $data['states']    = $this->Rntcp_model->get_state();
		
		loadLayout('programmanager/rntcp/rntcp_form_list', 'program_manager', $data);
    }
	
    public function rntcp_add_form(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Rntcp', base_url('rntcp/index'));
		$this->mybreadcrumb->add('Rntcp', base_url('rntcp/index'));
        $data['page_type'] = 'Rntcp';	
		$data['states']    = $this->Rntcp_model->get_state();

        loadLayout('programmanager/rntcp/rntcp_form_add', 'program_manager', $data);
    }
	
    private function rntcp_validate(){      

        $this->form_validation->set_rules('state_id', 'State Name', 'trim|required');    
        $this->form_validation->set_rules('financial_year', 'Financial Year', 'trim|required');
        $this->form_validation->set_rules('month', 'Month', 'trim|required');
        
        $this->form_validation->set_rules('state_category', 'State Category', 'trim|required');
              
        $this->form_validation->set_rules('state_tbindex_score', 'State TB Index Score ', 'trim|required');
        $this->form_validation->set_rules('state_ranking_reportingmonth', 'State Ranking (reporting month)', 'trim|required');
        $this->form_validation->set_rules('state_ranking_previousmonth', 'State Ranking (previous month)', 'trim|required');
        $this->form_validation->set_rules('staterank_gainloss', 'Rank Gain/Loss', 'trim|required');
        $this->form_validation->set_rules('annual_target', 'Annual target', 'trim|required');
        $this->form_validation->set_rules('target_reportingmonth', 'Target till reporting month', 'trim|required');
        $this->form_validation->set_rules('achievement_reporting_month', 'Achievement till reporting month', 'trim|required');
        $this->form_validation->set_rules('achievement_reportingmonth_previousyear', 'Achievement till reporting month, in previous year', 'trim|required');
        $this->form_validation->set_rules('tbnotification_gainloss', '% Gain/Loss', 'trim|required');
        $this->form_validation->set_rules('no_of_benefeciaries', 'No. of beneficiaries ', 'trim|required');
         $this->form_validation->set_rules('total_amount_paid', 'Total amount paid', 'trim|required');


       if($this->form_validation->run() == TRUE){
            $requestdata  =   array(
        

        "state_id"    =>  $this->input->post('state_id'),   
        "financial_year"    =>  $this->input->post('financial_year'),        
        "month"        =>  $this->input->post('month'),        
                    
        "state_category"    =>  $this->input->post('state_category'),        
        "state_tbindex_score" =>  $this->input->post('state_tbindex_score'),		
        
        "state_ranking_reportingmonth" =>  $this->input->post('state_ranking_reportingmonth'),
        "state_ranking_previousmonth" =>  $this->input->post('state_ranking_previousmonth'),
        "staterank_gainloss" =>  $this->input->post('staterank_gainloss'),
        "annual_target"=>$this->input->post('annual_target'),
        "target_reportingmonth" =>  $this->input->post('target_reportingmonth'),
        "achievement_reporting_month" =>  $this->input->post('achievement_reporting_month'),
        
        "achievement_reportingmonth_previousyear" =>  $this->input->post('achievement_reportingmonth_previousyear'),
        
        "tbnotification_gainloss" =>  $this->input->post('tbnotification_gainloss'),
        "no_of_benefeciaries" =>  $this->input->post('no_of_benefeciaries'),
        "total_amount_paid" =>  $this->input->post('total_amount_paid'),
        
        'updated_by' =>  (isset($_SESSION['memberID']))	
             ); 
            return $requestdata;
        }else{
            $this->form_validation->set_error_delimiters('', '');
            $message    = array("0",validation_errors());
            $this->session->set_flashdata('message', $message);
            return false;
        }
    }
	
    public function rntcp_InsertForm(){	

        $requestdata    =   $this->rntcp_validate();
		//print_r( $requestdata);die;
        if(!empty($requestdata)){
            //echo "inm";die;
            if($this->Rntcp_model->insertdata("rntcp_master_table",$requestdata)){
                $message    = array("1","Successfully Submitted");
            }else{
                $message    = array("0",$this->db->_error_message());
            }
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url("rntcp/rntcp_view"));
    }
	
    public function rntcp_edit(){
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Rntcp', base_url('rntcp/index'));
        $data['page_type'] = 'Rntcp'; 
		$data['states']    = $this->Rntcp_model->get_state();		
        $data['row']   =  $this->Rntcp_model->fetchwhere("rntcp_master_table",array("id"=>$this->input->get('id')),"","row_array");	

		loadLayout('programmanager/rntcp/rntcp_form_add', 'program_manager', $data);
    }
	
    public function rntcp_update(){
        $requestdata    =   $this->rntcp_validate();
        //print_r( $requestdata);die;
        	if(!empty($requestdata)){
	
			 if($this->Rntcp_model->updatedata("rntcp_master_table",$requestdata,array("id"=>$this->input->post('id')))){
			    $message    = array("1","Successfully Updated");
		
            }else{
                $message    = array("0",$this->db->_error_message());
                $this->session->set_flashdata('message', $message);
            }		
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('rntcp/rntcp_edit').'?action=edit&id='.$this->input->post('id'));
    }
	
    public function rntcp_delete(){
        
		if($this->input->get('id')){
            $this->Rntcp_model->deletedata("rntcp_master_table",array("id"=>$this->input->get('id')));
			 $message    = array("1","Successfully Deleted");
			  $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('rntcp/rntcp_view'),'location');
    }


    /*------------Upload Excel---------------*/

    /*public function UploadExcel(){ 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Rntcp', base_url('rntcp/rntcp_form_add'));        
        $data['page_type'] = 'Rntcp';
        $data['row']       = $this->Rntcp_model->get_rntcp();       
        loadLayout('programmanager/rntcp/uploadExcel', 'program_manager', $data);
    }
    
    public function uploadexceldata(){
        //echo "in";die;
        
           if($_FILES['image']['name']!=''){   
            
                $file_ext = pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION);

                if($file_ext!='csv'){
                     
                    $message=array("0","File Type is Not Supported! Please Upload CSV File");                
                     
                }else{
                     
                     if(!is_dir('download/excel/'.date('d-m-Y'))){
                       // echo "in";die;
                        mkdir('./download/excel/'.date('d-m-Y'),0777,TRUE);
                    }           

                    $config['upload_path']='./download/excel/'.date('d-m-Y');
                    $config['allowed_types']='csv'|'xlsx'|'xls';
                    $config['max_size']='1000000';
                    $config['max_width'] = '0';
                    $config['max_height'] = '0';
                    $config['remove_spaces'] = true;
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);

                    if(! $this->upload->do_upload('image')){

                        $message    = array("0",strip_tags($this->upload->display_errors()));
                    }else{
                        $upload_ques = $this->upload->data();
                        $requestdata['image']='download/excel/'.$upload_ques['file_name'];
                    }
                    $count = 0;
                    $fp = fopen($_FILES['image']['tmp_name'],'r') or die("can't open file");
                            
                    while($csv_line = fgetcsv($fp,10000) ){
                        //print_r($csv_line);die;
         
                        if ($count > 0) {

                        $inData    =   array(
                            'id'   =>  $csv_line[0],
                            //'financial_year'   =>  $csv_line[1],
                            //'month'   =>  $csv_line[2],
                            'state_id'   =>  $csv_line[1],
                            'state_category' =>  $csv_line[2],
                            'state_tbindex_score'  =>  $csv_line[3],
                            'state_ranking_reportingmonth' =>  $csv_line[4],
                            'state_ranking_previousmonth' =>  $csv_line[5],
                            'staterank_gainloss'    =>  $csv_line[6],
                        );

                        $id =   $csv_line[1];

                        $sql_check  =   $this->db->query("select * from `rntcp_master_table` where `id`='".$id."'");
                        $row_check  =   $sql_check->row_array();
                        $this->load->library('email'); 
                      // die;
                        if(empty($row_check)){                    
                            $inData['id'] =   $id;
                            if($this->db->insert("rntcp_master_table",$inData)){
                                $message=array("1","File Uploaded Successfully!! " );
                            }else{
                                $message=array("0",$this->db->_error_message());
                            }
                        }else{

                            $this->db->where("id",$id);
                           
                            $this->db->update("rntcp_master_table" , $inData);                    
                            $message=array("1","Record Successfully Updated");
                        }
                    }
                    $count++;
                   }
                    
                }  

                }else{
                    $message=array("0","No File selected");
                }
        $this->session->set_flashdata('message', $message);
        redirect(base_url("rntcp/uploadexcel"));
        fclose($fp) or die("can't close file");

    }
    
    public function downloadExcel()
    {        
       $result     =   $this->Rntcp_model->get_rntcp();
        //showData($result1);die;
         
        $filename   =   "HFMDashboardInputSheet".date("Y-m-d-h-i-s");
        header("Content-type: application/csv");
        header("Content-Disposition: attachment; filename=\"".$filename.".csv\"");
        header("Pragma: no-cache");
        header("Expires: 0");
        
        $headerarray    =   "";
        
            $headerarray    =   array("A"=>"Name of State/UT","B"=>"State Category",
                "C"=>"State TB Index Score","D"=>"State Ranking",
                "E"=>"State Ranking for Previous Month", "F"=>"Rank Gain/Loss");
        
        $handle = fopen('php://output', 'w');
        fputcsv($handle, $headerarray);
       
       // showData($result_list1);die;
        foreach($result as $rows){
            
               $dataarray  =   array("A"=>$rows['name'],"B"=>"","C"=>"","D"=>"","E"=>"","F"=>"");
            
            fputcsv($handle, $dataarray); 
        } 
        fclose($handle);
        exit;  
        
} */
}