<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Test extends MY_Controller {

    private $user;

    public function __construct() {
        parent::__construct();
        $this->load->helper('hwc_dashboard');
        $this->load->model('hwc_model');
        global $db;
        $this->db = $db;
        $this->user = new Users();

        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
    }

    public function uc() {
        global $db;
        $query = "select
                          hf.NIN_2_HFI,
                          hf.State_ID,
                          hf.District_ID,
                          hf.HFI_Type,
                          hf.confirmed_flag,
                          hf.verified_flag,
                          hf.operational_Status,
                          hwc.status,
                          hwc.verify_status,
                           hwc.remarks,
                            hwcp.p_remark,
                          hwcp.proposed_status,
                          hwcp.population_coverage
                          from " . TB_HMIS_HEALTH_FACILITIES . " hf
                         left join " . TB_T_HWC . " hwc on hf.NIN_2_HFI =hwc.NIN_2_HFI
                         left join " . TB_T_HWC_PROPOSED . " hwcp on hf.NIN_2_HFI =hwcp.NIN_2_HFI
                         where hwc.verify_status=1 OR hwcp.proposed_status=1 ";
        $stmt = $db->query($query);
        $row2 = $stmt->fetchAll();
        foreach ($row2 as $row) {
            updateCriteria($row['NIN_2_HFI'], $row['HFI_Type']);
        }
    }

    public function glogin() {
        $user = $this->user;
    }

}
