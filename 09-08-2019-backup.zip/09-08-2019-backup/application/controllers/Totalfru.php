<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Totalfru extends MY_Controller {
    private $user;

    public function __construct() {
        parent::__construct();           
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('programmanager/totalfru_model');
        $this->load->model('Dashboard_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');
    }

    /*---------------------------Start totalfru ---------------------------------------------*/
    
    public function index() { 		
    	$this->totalfru_view();
    }
	
	public function totalfru_view(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Total FRU', base_url('totalfru/index'));
                
        $data['page_type'] = 'FRU';
        $data['row']       = $this->totalfru_model->get_totalfru();
        loadLayout('programmanager/totalfru/form_list', 'program_manager', $data);
    }
	
    public function totalfru_add_form(){  
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Total FRU', base_url('totalfru/index'));
        $data['page_type'] = 'FRU';
		$data['row']  = $this->totalfru_model->get_totalfru();	
        loadLayout('programmanager/totalfru/form_add', 'program_manager', $data);
    }
	
    private function totalfru_validate(){          
        $this->form_validation->set_rules('total_fru', 'Total FRU', 'trim|required');               
		
        if($this->form_validation->run() == TRUE){
            $requestdata  =   array(
                "total_fru"           =>  $this->input->post('total_fru')
             ); 
            return $requestdata;
        }else{
            $this->form_validation->set_error_delimiters('', '');
            $message    = array("0",validation_errors());
            $this->session->set_flashdata('message', $message);
            return false;
        }
    }
	
 
    public function totalfru_edit(){
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Total FRU', base_url('totalfru/index'));
        $data['page_type'] = 'FRU';
        $data['row']   		=   $this->totalfru_model->fetchwhere("totalfru_master_table",array("id"=>$this->input->get('id')),"","row_array");		
        loadLayout('programmanager/totalfru/form_add', 'program_manager', $data);
    }
	
    public function totalfru_update(){
        $requestdata    =   $this->totalfru_validate();
        	if(!empty($requestdata)){
	
			 if($this->totalfru_model->updatedata("totalfru_master_table",$requestdata,array("id"=>$this->input->post('id')))){
			    $message    = array("1","Successfully Update");
		
            }else{
                $message    = array("0",$this->db->_error_message());
                $this->session->set_flashdata('message', $message);
            }		
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('totalfru/totalfru_edit').'?action=edit&id='.$this->input->post('id'));
    }
	
    public function totalfru_delete(){
        
		if($this->input->get('id')){
            $this->totalfru_model->deletedata("totalfru_master_table",array("id"=>$this->input->get('id')));
			$message    = array("1","Successfully Deleted");
			$this->session->set_flashdata('message', $message);
        }
        redirect(base_url('totalfru/totalfru_view'),'location');
    }
    
    
}