<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Treemap extends MY_Controller {
    private $user;

    public function __construct() {
        parent::__construct();
       
        
        //global $db;
        //$this->db = $db;
       
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
        $this->load->library('mybreadcrumb');

        $this->load->driver('cache');
    }

    public function index() { 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Tree Map', base_url('treemap/treemap'));
        
        $data['page_type']='Tree Map';
        
        loadLayout('admin/treemap', 'admin', $data);
    }


     

}
