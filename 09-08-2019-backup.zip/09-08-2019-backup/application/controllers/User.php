<?php

defined('BASEPATH') OR exit('No direct script access allowed');

//require_once APPPATH . 'third_party/jcryption/sqAES.php';
//require_once APPPATH . 'third_party/jcryption/JCryption.php';

class User extends MY_Controller {
    private $user;

    public function __construct() {
        parent::__construct();
        $this->user = new Users();
    }

        public function index() {

            redirect('user/dashboard');
		}

    public function dashboard() {
      if (!$this->user->is_logged_in()) {
               redirect('home/login');
        }


        $this->load->view('template/t_header');
        $this->load->view('admin/dashboard', $data = null);
        $this->load->view('template/t_footer');
    }

    public function user_list() {
        global $db;
        $user = $this->user;
        $data = null;
        
       



        if ($user->hasPermission('DELETE_USER')) {
            //show message from add / edit page
            if (isset($_GET['deluser'])) {

                if (!checkCSRF()) {
                    error_message(CSRF_ERROR);
                }
                //if user id is 1 ignore
                else if ($_GET['deluser'] != '1' && $_GET['deluser'] != $_SESSION['memberID']) {
                    $stmt = $db->prepare('DELETE FROM ' . TB_T_MEMBERS . ' WHERE memberID = :memberID');
                    $stmt->execute(array(':memberID' => $_GET['deluser']));
                    status_message('User deleted Successfuly!');
                }
            }
        }

        try {
            $state = 0;
            if (isset($_REQUEST['state'])) {
                $state = intval($_REQUEST['state']);
            }
            if (isHavingState($user)) {
                $state = $CURRENT_USER_STATE;
            }
            if ($state != 0) {
                $queryWhere[] = ' ' . TB_T_MEMBERS . '.State_ID = ' . $state;
            }

            $district = 0;
            if (isset($_REQUEST['district'])) {
                $district = intval($_REQUEST['district']);
            }
            if (isHavingDistrict($user)) {
                $district = $CURRENT_USER_DISTRICT;
            }
            if ($district != 0) {
                $queryWhere[] = ' ' . TB_T_MEMBERS . '.District_ID = ' . $district;
            }
            if (isset($_REQUEST['user_email'])) {
                $user_email = trim(filter_var($_REQUEST['user_email'], FILTER_SANITIZE_STRING));
                $queryWhere[] = ' (' . TB_T_MEMBERS . '.username like \'%' . $user_email . '%\' OR ' . TB_T_MEMBERS . '.email like \'%' . $user_email . '%\') ';
            }
            $where = '';
            if (isset($queryWhere)) {
                $where = ' where ' . implode(' AND ', $queryWhere);
            }


            $stmt = $db->query('SELECT SQL_CALC_FOUND_ROWS ' . TB_T_MEMBERS . '.*, ' . TB_M_STATES . '.State_Name , ' . TB_M_DISTRICTS . '.District_Name'
                    . ' FROM ' . TB_T_MEMBERS
                    . ' LEFT JOIN ' . TB_M_STATES . '  on  ' . TB_M_STATES . '.State_ID = ' . TB_T_MEMBERS . '.State_ID '
                    . ' LEFT JOIN ' . TB_M_DISTRICTS . ' on  ' . TB_M_DISTRICTS . '.District_ID = ' . TB_T_MEMBERS . '.District_ID  and ' . TB_M_DISTRICTS . '.State_ID = ' . TB_T_MEMBERS . '.State_ID '
                    . $where
                    . '  ORDER BY State_Name,District_Name DESC ' . limit());

            $foundRows = $db->query('SELECT FOUND_ROWS()')->fetchColumn();
            //print_r($foundRows);
            $html_paging = pagination($foundRows);
        } catch (PDOException $e) {
            echo $e->getMessage();
        }

        $data['users_list'] = $stmt->fetchAll();
        $data['html_paging'] = $html_paging;
        $data['user'] = $user;
        $data['_POST'] = $_POST;
        loadLayout('admin/user_list', 'admin', $data);
    }

    public function user_add() {
        global $db;
        global $USER_ROLES;
        $error = array();

        $user = $this->user;
        $data = null;
        //check permission
        if ($_POST) {
            extract($_POST);

//DELETE USER
            if (isset($_GET['action']) && $_GET['action'] == 'DELETE_USER' && isset($_POST['USER_ID'])) {
// check permission
                if ($user->hasPermission('DELETE_USER')) {
                    if (!checkCSRF()) {
                        $error[] = CSRF_ERROR;
                    }
                    if (isset($error) && count($error) > 0) {
                        $errors = error_format($error);
                        error_message($errors);

                        //   $responseArray = array('status' => 'error', 'status_msg' => $errors, 'token' => generatetoken());
                    } elseif ($_POST['USER_ID'] != '1' && $_POST['USER_ID'] != $_SESSION['memberID']) {

                        $stmt = $db->prepare('DELETE FROM ' . TB_T_MEMBERS . ' WHERE memberID = :memberID');
                        $stmt->execute(array(':memberID' => $_POST['USER_ID']));

                        status_message('User Deleted Successfuly!');
                        //   $responseArray = array('status' => 'success', 'status_msg' => 'User Deleted Successfuly!', 'return_url' => ROOT_PATH . 'users.php');
                    }
                } else {
                    //  $responseArray = array('status' => 'error', 'status_msg' => 'Permission Error..! <br>You are not allowed to perform this operation.', 'token' => generatetoken());
                }
            }


//ADD USER
            if (isset($_GET['action']) && $_GET['action'] == 'ADD_USER') {

//if form has been submitted process it
                if ($user->hasPermission('ADD_USER')) {
                    if (count($_POST) > 0) {
                        if (1) {
//very basic validation
                            if (!checkCSRF()) {
                                $error[] = CSRF_ERROR;
                            }
                            $username = trim(filter_var($username, FILTER_SANITIZE_STRING));

                            if ($username == '') {
                                $error[] = 'Please enter the username.';
                            } else if (strlen($username) > 40) {
                                $error[] = 'Username should not be more than 40 characters long.';
                            } else if ($user->isUsernameExist($username)) {
                                //$memberID
                                $error[] = 'Username already exits.';
                            }

                            if (trim($password) == '') {
                                $error[] = 'Please enter the password.';
                            } else if (strlen($password) > 40) {
                                $error[] = 'Password should not be more than 40 characters long.';
                            }

                            if (trim($passwordConfirm) == '') {
                                $error[] = 'Please confirm the password.';
                            }

                            if ($password != $passwordConfirm) {
                                $error[] = 'Passwords do not match.';
                            }

                            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                                $error[] = 'Invalid email format.';
                            } else if ($user->isUserEmailExist($email)) {
                                $error[] = 'Email already exits.';
                            }

// check if State and District of User
                            if (isset($state) && $state != '0') {
                                if (!isValidStateId($state)) {
                                    $error[] = 'Invalid selected State.';
                                }
                            }

                            if (isset($district) && isset($state) && $district != '0') {
                                if (!isValidDistrictId($state, $district)) {
                                    $error[] = 'Invalid selected District.';
                                }
                            }

                            if (isset($status) && $status != '') {
                                $status = intVal($status);
                            } else {
                                $status = 0;
                            }

                            if (!isset($role) || $role == 3 || !array_key_exists($role, $USER_ROLES)) {
                                $error[] = 'Invalid Role Assigned!';
                            }
//update all role except Super Admin (3)

                            if (count($error) == 0) {


                                $hashedpassword = $user->password_hash($password, PASSWORD_BCRYPT);

                                try {

//insert into database
                                    $stmt = $db->prepare('INSERT INTO ' . TB_T_MEMBERS . ' (username,password,State_ID,District_ID,email,status,role,createOn, updatedOn) VALUES (:username, :password, :State_ID, :District_ID, :email, :status, :role, NOW(), NOW())');

                                    $stmt->execute(array(
                                        ':username' => $username,
                                        ':password' => $hashedpassword,
                                        ':State_ID' => intVal($state),
                                        ':District_ID' => intVal($district),
                                        ':email' => $email,
                                        ':status' => $status,
                                        ':role' => $role
                                    ));

//redirect to index page
                                    status_message('User add  Successfully!');
                                    //     $responseArray = array('status' => 'success', 'status_msg' => 'User add  Successfully!', 'return_url' => ROOT_PATH . 'users.php');
                                } catch (PDOException $e) {
                                    echo $e->getMessage();
                                }
                            }
                        } else {
                            $error[] = "Duplicate Submission!";
                        }
                    }
                } else {
                    $error[] = 'You are not allowed to perform this operation';

                    //   $responseArray = array('status' => 'error', 'status_msg' => 'Permission Error..! <br>You are not allowed to perform this operation.', 'token' => generatetoken());
                }
            }
        }

        if (count($error) > 0) {
            error_message(error_format($error));
            // $responseArray = array('status' => 'error', 'status_msg' => $errors, 'token' => generatetoken());
        }


        $data['user'] = $user;
        $data['_REQUEST'] = $_REQUEST;
        loadLayout('admin/user_add', 'admin', $data);
    }

    public function user_view() {
        global $db;
        $user = $this->user;
        $data = null;
        loadLayout('admin/user_view', 'admin', $data);
    }
	
	
	/////////////// bs code generate password by excel sheet and download it ///// after use please remove//
    public function bulkpasswordgenerate()
    {
        if ($this->input->post('savebulk')) {
			
			
            $fileExt = strtolower(pathinfo($_FILES['uploadexcel']['name'], PATHINFO_EXTENSION));
        
            $this->load->library('excel');
            $this->load->library('upload');

            $config['upload_path'] = './uploads/bulkpassword/';
			
			           
            $config['allowed_types'] = 'xlsx|xls';
            $config['remove_spaces'] = true;
            $config['file_name'] = 'bulkpassword_'.date('d-m-Y-h-i-s');

            $this->upload->initialize($config);

            if (!$this->upload->do_upload('uploadexcel')) {
                $error = array('error' => $this->upload->display_errors());

               echo print_r($error); die;
                //$this->session->set_flashdata('err_msg', '<div class="alert alert-danger text-center">'.$error['error'].'</div>');
            } else {
                $data = array('upload_data' => $this->upload->data());

                $loadfile = $_FILES['uploadexcel']['tmp_name'];
            
                $objPHPExcel = PHPExcel_IOFactory::load($loadfile);

                foreach ($objPHPExcel ->getWorksheetIterator() as $worksheet) {
                    $highestRow =$worksheet->getHighestRow();

                    for ($row =1; $row<=$highestRow; $row++) {
                        $State_ID_Name = utf8_encode($worksheet->getCellByColumnAndRow(0, $row)->getValue());
                        $District_ID =utf8_encode($worksheet->getCellByColumnAndRow(1, $row)->getValue());
                        $State_ID =utf8_encode($worksheet->getCellByColumnAndRow(2, $row)->getValue());
                        $Role =utf8_encode($worksheet->getCellByColumnAndRow(3, $row)->getValue());
                        


                        ////// set new excel file value with password //////////

                        $this->excel->setActiveSheetIndex(0);

                        $this->excel->getActiveSheet()->setTitle('Password List'); 
                    
                        if ($row==1) {
                            $this->excel->getActiveSheet()->SetCellValue('A'.$row, $State_ID_Name);
                            $this->excel->getActiveSheet()->SetCellValue('B'.$row, $District_ID);
                            $this->excel->getActiveSheet()->SetCellValue('C'.$row, $State_ID);
                            $this->excel->getActiveSheet()->SetCellValue('D'.$row, $Role);
                            
                            $this->excel->getActiveSheet()->SetCellValue('E'.$row, 'Password');
                        } else {
							
						
                            //////// generate password ////

                            //$upassword=generate_password(10);
							
							$user = $this->user;
							
							$upassword=generate_password(10); 
							 
							$hashedpassword = $user->password_hash($upassword, PASSWORD_BCRYPT); 

                            ///////// end generate password /////
							
							///////////// insert data in db/
							
							 global $db;
							
							 $stmt = $db->prepare('INSERT INTO ' . TB_T_MEMBERS . ' (username,password,State_ID,District_ID,status,role,createOn, updatedOn) VALUES (:username, :password, :State_ID, :District_ID, :status, :role, NOW(), NOW())');

                    $stmt->execute(array(
                        ':username' => $State_ID_Name,
                        ':password' => $hashedpassword,
                        ':State_ID' => intVal($State_ID),
                        ':District_ID' => intVal($District_ID),
                       
                        ':status' => 1,
                        ':role' => $Role
                    ));
					
					
					///////////////////////
					
					///////////// find state name
					
					 $this->db->select('State_Name');
             $this->db->from('m_state');
       
              $this->db->where('State_ID', $State_ID);
              $query = $this->db->get();
              $result_array = $query->result_array();
			  
			  if(count($result_array)>0)
			  {
			  
			  $state_name=$result_array[0]['State_Name'];
			  }
			  else
			  {
				  $state_name='';
			  }
			  
			  ///////////// find dist name
					
					 $this->db->select('District_Name');
             $this->db->from('m_district');
       
              $this->db->where('District_ID', $District_ID);
              $query = $this->db->get();
              $result_array = $query->result_array();
			  
			  if(count($result_array)>0)
			  {
			  
			  $district_name=$result_array[0]['District_Name'];
			  }
			  else
			  {
				  $district_name='';
			  }
			  
			  //echo print_r($result_array); die;
		
		////////////////

							 
                            $this->excel->getActiveSheet()->SetCellValue('A'.$row, $State_ID_Name);
                            $this->excel->getActiveSheet()->SetCellValue('B'.$row, $district_name);
                            $this->excel->getActiveSheet()->SetCellValue('C'.$row, $state_name);
                            $this->excel->getActiveSheet()->SetCellValue('D'.$row, $Role);

                           
                       
                            $this->excel->getActiveSheet()->SetCellValue('E'.$row, $upassword);
							
							
							
							
                            
                        }
         

                        ////////// set  new excel file value with passowrd ////
                    }
                }

                ////// create new excel file with password //////////

                $filename=$config['file_name'].'_withpass.'.$fileExt; //save our workbook as this file name

                header('Content-Type: application/vnd.ms-excel'); //mime type

                header('Content-Disposition: attachment;filename="'.$filename.'"'); //tell browser what's the file name

                header('Cache-Control: max-age=0'); //no cache

                $objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel2007');

                $savefilename = './uploads/bulkpassword/'.$filename;
                $objWriter->save($savefilename);
                ob_end_clean();
                $objWriter->save('php://output');

                ////// end create new excel file with password //////////
            }
        }


       // $data['main_content'] = 'admin/stateloginkayakalp/bulkpasswordgenerate';
		// $this->load->view('template/templatePage', $data);
		  $data = null;
		 loadLayout('admin/bulkpasswordgenerate', 'admin', $data);
       
    }
    

    //////////// end bs code to genereate password by excel sheet and downlaod it ///

}
