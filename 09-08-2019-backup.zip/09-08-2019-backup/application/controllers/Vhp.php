<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Vhp extends MY_Controller { 
    private $user;

    public function __construct() {  

        parent::__construct();
     
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
       
        $this->load->model('Dashboard_model');
		$this->load->model('programmanager/Vhp_model');
		 $this->load->model('programmanager/Cmha_model');
		
		 $this->load->model('hwc_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index() { 
	 
        $this->mybreadcrumb->add('Home', base_url('secretary/page/index'));
        $this->mybreadcrumb->add('VHP', base_url('vhp/form_list'));
        
        $data['page_type']='VHP';
        $data['row'] = $this->Vhp_model->get_VHPs();
				       
        loadLayout('programmanager/vhp/form_list', 'program_manager', $data);
    }
	
	public function add_form() { 
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('VHP', base_url('vhp/form_list'));
		
		$data['state']=$this->hwc_model->get_state();
        
        $data['page_type']='VHP';
      
       
        loadLayout('programmanager/vhp/form_add', 'program_manager', $data);
    }
	
	public function form_save()
	{ 
       if (isset($_POST['submit']))
		  {
			     
          $this->form_validation->set_rules('state_name', 'State', 'required');
		  
			 
          if ($this->form_validation->run() == FALSE)
                {
                	 	//$data['state']=$this->hwc_model->get_state();
                	 	redirect('vhp/add_form');	
                       // $this->load->view('programmanager/nvhcp/nvhcp_form_add',$data);
                }
                else
                {

           $data = array
				   (	 				
					
					'state_id'=> $this->input->post('state_name'),
					
					
					'Regional_Laboratory'=> $this->input->post('Regional_Laboratory'),
					
					
					
					'updated_by'=>  (isset($_SESSION['memberID']))
													
			  	);
                
                /////// chk availability /////////
                 
                // $result = $this->Amrcp_model->chkAMRCP($this->input->post('state_name'),$this->input->post('e_year'),$this->input->post('e_quarter'));
                  
				 
                ///////////// end check availability ///////////
                
                if($result>0)
                {
					
					
                 $this->session->set_flashdata("already_added","Record already added.");
                 
					
				  redirect('vhp/add_form');					
						
                }
                else
                {
				$this->Vhp_model->insertVHP($data);

				$this->session->set_flashdata("success","Data has been submitted successfully.");
        
			    }
				
				//$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('vhp/index');     
		  
		  }

		  }
	}
	
	public function edit_form($id)
	{
	   $data['state']=$this->hwc_model->get_state();
       $data['value'] = $this->Vhp_model->getVHP_byId($id);
	   
	  // echo print_r($data['value']); die;
	   
	
       $data['page_type']='VHP';

	    loadLayout('programmanager/vhp/form_edit', 'program_manager', $data);

	}
	
	public function form_update($id)
	{      
      if (isset($_POST['update']))
		  {
		  	 $data = array
				   (	

                    'state_id'=> $this->input->post('state_name'),
										
					'Regional_Laboratory'=> $this->input->post('Regional_Laboratory'),
					
					
					
					
					'updated_date'=> date("Y-m-d H:i:s"),
					
					'updated_by'=>  (isset($_SESSION['memberID']))
													
			  	);
                
      

		$result = $this->Vhp_model->updateVHP_byId($id,$data);
	

        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
			
	     }
         redirect(base_url('vhp/edit_form/'. $id));

		  }
	}
	
	
	
	

public function delete($id)
     {
       $this->db->delete('vhp_regional_lab_master_table', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('vhp/index'));
     }
	 
	 
	 public function index2() { 
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('VHP', base_url('vhp/form_list'));
        
        $data['page_type']='VHP';
        $data['row'] = $this->Vhp_model->get_VHPs2();
		
		
				       
        loadLayout('programmanager/vhp/form_list2', 'program_manager', $data);
    }
	
	public function add_form2() { 
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('VHP', base_url('vhp/form_list'));
		
		 $data['states']    = $this->Cmha_model->get_state();

		$data['districts'] = $this->Cmha_model->get_district();
		
		
        
        $data['page_type']='VHP';
      
       
        loadLayout('programmanager/vhp/form_add2', 'program_manager', $data);
    }
	
	public function form_save2()
	{ 
       if (isset($_POST['submit']))
		  {
			     
          $this->form_validation->set_rules('statename', 'State', 'required');
		  
		   $this->form_validation->set_rules('districtname', 'State', 'required');
		  
			 
          if ($this->form_validation->run() == FALSE)
                {
                	 	//$data['state']=$this->hwc_model->get_state();
                	 	redirect('vhp/add_form2');	
                       // $this->load->view('programmanager/nvhcp/nvhcp_form_add',$data);
                }
                else
                {

           $data = array
				   (	 				
					
					'state_id'=> $this->input->post('statename'),
					
					
					'district_id'=> $this->input->post('districtname'),
					
					
					
					'updated_by'=>  (isset($_SESSION['memberID']))
													
			  	);
                
                /////// chk availability /////////
                 
                // $result = $this->Amrcp_model->chkAMRCP($this->input->post('state_name'),$this->input->post('e_year'),$this->input->post('e_quarter'));
                  
				 
                ///////////// end check availability ///////////
                
                if($result>0)
                {
					
					
                 $this->session->set_flashdata("already_added","Record already added.");
                 
					
				  redirect('vhp/add_form2');					
						
                }
                else
                {
				$this->Vhp_model->insertVHP2($data);

				$this->session->set_flashdata("success","Data has been submitted successfully.");
        
			    }
				
				//$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('vhp/index2');     
		  
		  }

		  }
	}
	
	public function edit_form2($id)
	{
	   $data['state']=$this->hwc_model->get_state();
	   
	   
       $data['value'] = $this->Vhp_model->getVHP_byId2($id);
	   
	  
	   
	    $data['states']    = $this->Cmha_model->get_state();

		$data['districts'] = $this->Cmha_model->get_district();
	   
	  // echo print_r($data['value']); die;
	   
	
       $data['page_type']='VHP';

	    loadLayout('programmanager/vhp/form_edit2', 'program_manager', $data);

	}
	
	public function form_update2($id)
	{      
      if (isset($_POST['update']))
		  {
		  	 $data = array
				   (	

                    'state_id'=> $this->input->post('statename'),
					
					 'district_id'=> $this->input->post('districtname'),
										
					
					
					
					
					
					'updated_date'=> date("Y-m-d H:i:s"),
					
					'updated_by'=>  (isset($_SESSION['memberID']))
													
			  	);
                
      

		$result = $this->Vhp_model->updateVHP_byId2($id,$data);
	

        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
			
	     }
         redirect(base_url('vhp/edit_form2/'. $id));

		  }
	}
  
  public function delete2($id)
     {
       $this->db->delete('vhp_district_lab_master_table', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('vhp/index2'));
     }
	 
	 public function getDistrict($id) 
	{ 
		$result = $this->db->where("State_ID",$id)->get("m_district")->result();
        echo json_encode($result);
	}
	 
}
