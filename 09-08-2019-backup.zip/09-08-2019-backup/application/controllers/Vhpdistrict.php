<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Vhpdistrict extends MY_Controller { 
    private $user;

    public function __construct() {  

        parent::__construct();
     
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
       
        $this->load->model('Dashboard_model');
		$this->load->model('programmanager/Vhp_district_model');
		 $this->load->model('programmanager/Cmha_model');
		
		 $this->load->model('hwc_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

   public function index($year_id='',$month='') { 
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('VHP', base_url('Vhpdistrict/index'));
		
		if($year_id){
			$data['fin_year'] = $year_id;
		}else{
			$data['fin_year'] = getCurrYear();
		}		

        if($month){
			$data['fin_month'] = $month;
		}else{
			$data['fin_month'] = getCurrMonth(); 
		}		
	
        $data['page_type']='VHP';
        $data['row']    = $this->Vhp_district_model->get_Ambulances_State();
		//$data['state']  =  $this->Vhp_district_model->get_Ambulances_State($data['fin_year'],$data['fin_month']);
		$data['states'] =  $this->Vhp_district_model->getstate();
		$data['districts'] = $this->Vhp_district_model->get_district();

        loadLayout('programmanager/vhp/formdistrict', 'program_manager', $data);

    }

    public function view(){  
		
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('VHP', base_url('Vhpdistrict/index'));     
        $data['page_type'] = 'VHP';
		$data['row']    = $this->Vhp_district_model->get_Ambulances_State();
		//echo "<pre>"; print_r($data['row']); die;
        loadLayout('programmanager/vhp/vhp_list', 'program_manager', $data);
	}

    private function validate(){          
        $this->form_validation->set_rules('year_id', 'Year', 'trim|required');
        $this->form_validation->set_rules('month', 'Month', 'trim|required');
        $this->form_validation->set_rules('state_id', 'State', 'trim|required');
		$this->form_validation->set_rules('district_id', 'District', 'trim|required');
        
		
        if($this->form_validation->run() == TRUE){
            $requestdata  =   array(
                "year"         =>  $this->input->post('year_id'),        
                "month"        =>  $this->input->post('month'),               
                "state_id"     =>  $this->input->post('state_id'),
				"district_id"  =>  $this->input->post('district_id')
            ); 

            /*$check  = $this->db->query("select * from vhp_district_lab_master_table where year = '".$requestdata['year']."' and month = '".$requestdata['month']."' ");
            
            $checkrow  = $check->row_array();

            if($checkrow){
            	$message    = array("0","Record already exist!!!");
            	$msg = $this->session->set_flashdata('message', $message);
				return $msg;
            }else{
            	return $requestdata;
            }*/
            return $requestdata;
            
        }else{
            $this->form_validation->set_error_delimiters('', '');
            $message    = array("0",validation_errors());
            $this->session->set_flashdata('message', $message);
            return false;
        }
    }

 
	public function InsertForm(){	
        $requestdata    =   $this->validate();
		//var_dump($requestdata);die;
        if(!empty($requestdata)){
            if($this->Vhp_district_model->insertdata("vhp_district_lab_master_table",$requestdata)){
                $message    = array("1","Successfully Submit");
            }else{
                $message    = array("0",$this->db->_error_message());
            }
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url("vhpdistrict/"));
    }	

    public function editForm(){
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('VHP', base_url('Vhpdistrict/index'));
        
        $data['states'] =  $this->Vhp_district_model->getstate();
		$data['districts'] = $this->Vhp_district_model->get_district();
        $data['row']   		=   $this->Vhp_district_model->fetchwhere("vhp_district_lab_master_table",array("id"=>$this->input->get('id')),"","row_array");


        if($this->input->get('year')){
			$data['fin_year'] = $this->input->get('year');
		}else{
			$data['fin_year'] = getCurrYear();
		}		

        if($this->input->get('month')){
			$data['fin_month'] = $this->input->get('month');
		}else{
			$data['fin_month'] = getCurrMonth(); 
		}

		$data['state']  =  $this->Vhp_district_model->get_vhp_State($data['fin_year'],$data['fin_month']);
		
        $data['page_type']='VHP';
		loadLayout('programmanager/vhp/formdistrict', 'program_manager', $data);
    }

    public function updateForm(){
        $requestdata    =   $this->validate();
        	if(!empty($requestdata)){
	
			 if($this->Vhp_district_model->updatedata("vhp_district_lab_master_table",$requestdata,array("id"=>$this->input->post('id')))){
			    $message    = array("1","Successfully Update");
		
            }else{
                $message    = array("0",$this->db->_error_message());
                $this->session->set_flashdata('message', $message);
            }		
            $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('Vhpdistrict/view').'?action=edit&id='.$this->input->post('id'));
    }
	
    public function deleteForm(){
        
		if($this->input->get('id')){
            $this->Vhp_district_model->deletedata("vhp_district_lab_master_table",array("id"=>$this->input->get('id')));
			 $message    = array("1","Successfully Deleted");
			  $this->session->set_flashdata('message', $message);
        }
        redirect(base_url('Vhpdistrict/view'),'location');
    }


	 
public function change_val_ajax($y_val,$y_month)
     {
		 
		 $data['state']=$this->Vhp_district_model->get_Ambulances_State_ajax($y_val,$y_month);
		 
		//echo print_r($data['state']); die;
		 
		 echo json_encode($data['state']);
		
		
		
		die;
	// $data['state']=$this->Ambulance_model->get_Ambulances_State($fin_year,$fin_querter);
	 
	 }	
	

		public function getDistrict($id) 
	{ 
		$result = $this->db->where("State_Code_LG",$id)->get("m_district_lg")->result();
        echo json_encode($result);
	}
	

	
	 
}
