<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Ahs extends MY_Controller {
    private $user;

    public function __construct() {
        
        parent::__construct();
       
        
      
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
       
    }

    public function index() { 
    
      
       
        
        $data['header'] = "Allied Health Sciences";
        
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('AHS', base_url('admin/ahs'));
     
               
        $data['page_type']='Health Human Resources';
        loadLayout('admin/ahs/ahs', 'admin', $data);
        
    }
}
