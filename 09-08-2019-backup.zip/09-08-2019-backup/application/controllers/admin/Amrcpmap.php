<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Amrcpmap extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
		
        $this->load->model('admin/Amrcpmap_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }
	
	/* function checkifAnyValueMoreThanZero($total_kpi) {
		 $checkifAnyValueMoreThanZero =  FALSE;
		 
		$totalVars = explode(",", $total_kpi);		
		 foreach($totalVars as $vars) {
			 $Nums = explode(":", $vars);
			// print_r($Nums);
			 if(isset(trim($Nums[1]) != '0') {
				  $checkifAnyValueMoreThanZero =  TRUE;
				  break;
			 }
		 }
		return $checkifAnyValueMoreThanZero;
	} */
	
    public function index() { 
	 
		

        $data['map_data'] = $this->Amrcpmap_model->get_map_data();
        $data['total_header'] = $this->Amrcpmap_model->get_total_header();
        $data['total_kpi'] = $this->Amrcpmap_model->get_total_kpi();
		
		/* if(!$this->checkifAnyValueMoreThanZero($data['total_kpi']['total_kpi'])) {
			 $data['total_kpi'] = array();
		} */
		 
		
		
        $data['table_data'] = $this->Amrcpmap_model->get_table_data();
        $data['table_header'] = $this->Amrcpmap_model->get_table_header('amrcp_master_table');

        $data['all_kpi'] = $this->Amrcpmap_model->get_array_kpi();
        foreach($data['all_kpi'] as $keys=>$vals){
                $data['kpi_table_data'][$keys]=$this->Amrcpmap_model->get_table_kpi_data($vals);

        }

	    $data['header'] = "NATIONAL PROGRAMME ON AMR CONTAINMENTS";
        $data['headerY'] = "NATIONAL PROGRAMME ON AMR CONTAINMENT"; 

        $data['GoToPortalText']  = "AMR Portal";
        $data['GoToPortalLink']  = "#";

		$data['row']    = $this->Amrcpmap_model->get_mdiabetesform();
        $this->mybreadcrumb->add('Home', base_url());
        //$this->mybreadcrumb->add('Surveillance', base_url('admin/Surveillance'));
        $this->mybreadcrumb->add('Amrcp', base_url('amrcpmap/index'));
               
        $data['page_type']='Surveillance';
        ////loadLayout('admin/block_amr', 'admin', $data); /* comment by rocky */
		loadLayout('admin/block', 'admin', $data);
        //loadLayout('admin/pczdmap/pczdmap', 'admin', $data);
		
    }


  
    

     

}
