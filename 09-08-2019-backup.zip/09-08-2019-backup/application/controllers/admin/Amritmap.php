<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Amritmap extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
		
        $this->load->model('admin/Amritmap_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() { 
	 
		

        $data['map_data'] = $this->Amritmap_model->get_map_data();
        $data['total_header'] = $this->Amritmap_model->get_total_header();
        $data['total_kpi'] = $this->Amritmap_model->get_total_kpi();
        $data['table_data'] = $this->Amritmap_model->get_table_data();
        $data['table_header'] = $this->Amritmap_model->get_table_header('amrit_master_tbl');;
	    $data['header'] = "AMRIT";
        $data['headerY'] = "AMRIT"; 
		//$data['row']    = $this->Amritmap_model->get_mdiabetesform();
        $this->mybreadcrumb->add('Home', base_url());
       // $this->mybreadcrumb->add('Surveillance', base_url('admin/Surveillance'));
        $this->mybreadcrumb->add('Amrit', base_url('Amrit'));
         $data['amrit']=$this->Amritmap_model->amrit_list();       
        $data['page_type']='Health Service Delivery';
        loadLayout('admin/amritmap/amritmap', 'admin', $data);
		
    }


  
    

     

}
