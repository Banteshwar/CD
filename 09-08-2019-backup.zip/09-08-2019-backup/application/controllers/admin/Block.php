<?php
error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');

class Block extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
		
       // $this->load->model('centraldashboard/Pmssy_model');
        $this->load->model('admin/Block_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index($slug = NULL) { 
	
	   
		

       /*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		/*
        if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
	   */
        
		
		/*---------End User Permission----------*/	
		switch($slug)
		{
		// $data['view'] = $this->Pmssy_model->get_PMSSYs();
        // $data['map_data'] = $this->Block_model->get_map_data();
		case "ambulance":

		//$data['table_header'] = $this->Block_model->get_table_header('ambulance_master_table');
         //$data['headerY'] = "Total Ambulances";         
         //$data['total_header'] = $this->Block_model->get_total_header();
         
         	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        //$this->mybreadcrumb->add('Healthcare Infrastructure', base_url('admin/HealthcareInfrastructure'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Healthcare Infrastructure';
         
         $data['header'] = "Nation Wide Ambulances  ";
         $data['GoToPortalText']  = "";
         $data['GoToPortalLink']  = "#";
		$data['total_kpi'] = $this->Block_model->get_total_kpi($slug);
         $data['table_data'] = $this->Block_model->get_table_data($slug);
         $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
         $data['kpi_table_data']=array();
         foreach($data['all_kpi'] as $keys=>$vals){
                $data['kpi_table_data'][$keys]=$this->Block_model->get_table_kpi_data($slug,$vals);
		
         }
		break;

		case "pmssy":
   
		//foreach()
   		$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('admin/HealthcareInfrastructure'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Healthcare Infrastructure';

		$url="https://dashboard.nhp.gov.in/pmssy/pms/api/centraldashboard";
		$project_url="https://dashboard.nhp.gov.in/pmssy/pms/api/project_status";
		$project_tbl=$this->Block_model->get_PMSSY_api($project_url);
		$result_tbl=$this->Block_model->get_PMSSY_api($url);
        $final=$this->Block_model->get_PMSSY_table();
	   //echo "<pre />";print_r($final);die;
       
         $data['header'] = "Pradhan Mantri Swasthya Suraksha Yojana (PMSSY)";
         $data['GoToPortalText']  = "PMSSY Dashboard"; 
		 $data['KpiText']  = "PMSSY";
          $data['GoToPortalLink']  = "#";
        // $data['GoToPortalLink']  = "https://dashboard.nhp.gov.in/pmssy/dashboard";
         
        // $data['PortaliframeURL'] ='https://dashboard.nhp.gov.in/pmssy/dashboard'; // It has Iframe not available remove this or blank this variable
         $data['PortaliframeURL'] ='https://dashboard.nhp.gov.in/pmssy/pms/';
         $data['show_kpi_view'] = TRUE;  // It has KPIS
         
         
         $data['total_kpi'] = $this->Block_model->get_total_kpi($slug);
         $data['table_data'] = $this->Block_model->get_table_data($slug);
         $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
         $data['kpi_table_data']=array();
		 //$data['kpi_table_data'][0]=$result_tbl;
		 //$data['kpi_table_data'][1]=$result_tbl;
		 //$data['kpi_table_data'][2]=$result_tbl;
		 //$data['kpi_table_data'][3]=$result_tbl;
         foreach($data['all_kpi'] as $keys=>$vals){
            $data['kpi_table_data'][$keys]=$this->Block_model->get_table_kpi_data($slug,$vals);
         }
		break;
		case "mera_aspataal":
   /*
   	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Quality of Health Services', base_url('admin/Qualityhealthservices'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Quality of Health Services';
       
		 
			 $data['header'] = "Mera Aspataal  ";
         $data['GoToPortalText'] = "Mera Aspataal Portal";
        $data['GoToPortalLink']  = "https://admin-meraaspataal.nhp.gov.in";
			$dat = $this->Block_model->get_total_kpi($slug);
       $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);

		$str="";
		foreach($dat as $tdata)
			$str.=",".$tdata['total_kpi'];
			$data['total_kpi']=array();
			$data['total_kpi']['total_kpi']=substr($str,1,strlen($str));
		break;
        */

        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Quality of Health Services', base_url('admin/Qualityhealthservices'));
        $this->mybreadcrumb->add('Mera Aspataal', base_url('admin/home'));
        $data['page_type']='Quality of Health Services';
       
         
        $data['header'] = "Mera Aspataal  ";
        $data['GoToPortalText'] = "Mera Aspataal Portal";
      
        $dat = $this->Block_model->get_total_kpi($slug);
		$data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		
		//$data['GoToPortalLink']  = 'https://admin-meraaspataal.nhp.gov.in/api/CHIDashboard';
		//$data['PortaliframeURL'] ='https://admin-meraaspataal.nhp.gov.in/api/CHIDashboard'; // It has Iframe not available remove this or blank this variable
         $data['show_kpi_view'] = TRUE; 
	
         $data['GoToPortalLink']="#";
        //$data['GoToPortalLink']  = 'https://admin-meraaspataal.nhp.gov.in/dashboard';
        $ch = curl_init();

        $url ='https://admin-meraaspataal.nhp.gov.in/api/chiLogin';
        $apikey = 'HWC_CENTRAL_DASHBORD_LOGIN2018';

        $postData = array(
            'apikey' => $apikey,
            'source' => 'central_dashboard'
             
        );

        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postData,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_SSL_VERIFYHOST => 0,            // don't verify ssl 
                CURLOPT_SSL_VERIFYPEER => false
        ));

        $output = curl_exec($ch);
      //  print_r($output); exit;
        if (curl_errno($ch)) {
            // print_r (curl_error($ch));  
        }
        curl_close($ch);

        $portalurl = 'https://admin-meraaspataal.nhp.gov.in/';

        if($output){
            $output_object = json_decode($output);
            $return["return_url"]=  $output_object->return_url; 
            $return["status"]=  $output_object->status;
            $return["message"] =$output_object->message;
            $return["json"] = json_encode($return);
            //echo json_encode($return);
            $portalurl  = $output_object->return_url;
        }

         $data['PortaliframeURL'] = $portalurl ;


        $str="";
        foreach($dat as $tdata)
            $str.=",".$tdata['total_kpi'];
            $data['total_kpi']=array();
            $data['total_kpi']['total_kpi']=substr($str,1,strlen($str));
        break;
		case "elderly":
   
   	  $this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Health Service Delivery', base_url('admin/healthservice'));
        $this->mybreadcrumb->add($slug, base_url(''));
        $data['page_type']='Health Service Delivery';
        
		 $data['header'] = "Elderly  ";
         $data['GoToPortalText']  = "Elderly Portal";
         $data['GoToPortalLink']  = "#";
         
          $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
          
		$data['total_kpi'] = $this->Block_model->get_total_kpi($slug);

			break;
		case "ors":
 
   	$this->mybreadcrumb->add('Home', base_url('admin/home'));
       // $this->mybreadcrumb->add('Quality of Health Services', base_url('admin/Qualityhealthservices'));
        $this->mybreadcrumb->add('ORS', base_url('admin/home'));
        $data['page_type']='Quality of Health Services';
        
		$data['header'] = "Online Registration System  (ORS)";
         $data['GoToPortalText']  = "ORS  Portal";
         $data['GoToPortalLink']  = "#";
        // $data['GoToPortalLink']  = "https://ors.gov.in/copp/dashboard.jsp";
		//  $data['orsicon']  = "<img src='".base_url('assets/images/icon/logo.png')."'>";
         
          $data['PortaliframeURL'] ='https://dashboard.ehospital.gov.in/dashboard-testing2/ORSHomePage2.xhtml'; 
         //$data['show_kpi_view'] = TRUE;  // It has KPIS
      $dat= $this->Block_model->get_total_kpi($slug);
	  $data['total_kpi']=$dat[0];
//echo "<pre>";print_r($dat);die;
	  $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		
		$data['kpi_table_data']=array();
         foreach($data['all_kpi'] as $keys=>$vals){
                $data['kpi_table_data'][$keys]=$this->Block_model->get_table_kpi_data($slug,$vals);	}
		break;

		case "qa":
   
   	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('admin/HealthcareInfrastructure'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Healthcare Infrastructure';
        
			 $data['header'] = "Quality Assurance   ";
         $data['GoToPortalText']  = "Quality Assurance  Portal";
         $data['GoToPortalLink']  = "#";
			$dat = $this->Block_model->get_total_kpi($slug);
       $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		
		$str="";
		foreach($dat as $tdata)
			$str.=",".$tdata['State_Name'].":".$tdata['count'];
			$data['total_kpi']=array();
			$data['total_kpi']['total_kpi']=substr($str,1,strlen($str));
			 $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		//echo "<pre>";print_r($data['all_kpi']);die;
         $data['kpi_table_data']=array();
         foreach($data['all_kpi'] as $keys=>$vals){
                $data['kpi_table_data'][$keys]=$this->Block_model->get_table_kpi_data($slug,$vals['state_id']);	
		         }
		break;

		case "ehospital":
   
   error_reporting(0);
   
   	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Quality of Health Services', base_url('admin/Qualityhealthservices'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Quality of Health Services';
        
			 $data['header'] = "e-Hospital";
         $data['GoToPortalText']  = "eHospital  Portal";
          $data['GoToPortalLink']="#";
       //  $data['GoToPortalLink']  = "https://dashboard.ehospital.gov.in/dashboard-testing2/";
		 // $data['orsicon']  = "<img src='".base_url('assets/images/icon/ehospital-logo.png')."'>";
         
        $data['PortaliframeURL'] ='https://dashboard.ehospital.gov.in/dashboard-testing2/EhospitalHomePage2.xhtml'; // It has Iframe not available remove this or blank this variable
    //    $data['show_kpi_view'] = TRUE;  // It has KPIS
         
	$data['total_kpi']  = $this->Block_model->get_total_kpi($slug);
   
	  $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		
		$data['kpi_table_data']=array();
         foreach($data['all_kpi'] as $keys=>$vals){
                $data['kpi_table_data'][$keys]=$this->Block_model->get_table_kpi_data($slug,$vals);	}
		break;

		case "cghs":
   
   	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Health Service Delivery', base_url('admin/healthservice'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Health Service Delivery';
        
			 $data['header'] = "Central Government Health Scheme (CGHS)";
         $data['GoToPortalText']  = "CGHS  Dashboard";
         $data['GoToPortalLink']  = "#";
		//  $data['orsicon']  = "<img src='".base_url('assets/images/icon/CGHS_logo.png')."'>";
		  $data['PortaliframeURL'] ='https://cghs.nic.in/dashboard/dashboardnew_WH.jsp'; // It has Iframe not available remove this or blank this variable
         $data['show_kpi_view'] = TRUE;  // It has KPIS
		 
			$dat = $this->Block_model->get_total_kpi($slug);
      
            $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		$str="";
		foreach($dat as $tdata)
			$str.=",".$tdata['total_kpi'];
			$data['total_kpi']=array();
			$data['total_kpi']['total_kpi']=substr($str,1,strlen($str));
       $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		break;

		case "rch":
   
   	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Health Service Delivery', base_url('admin/healthservice'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Health Service Delivery';
        
			 $data['header'] = "Reproductive and Child Health(RCH)";
         $data['GoToPortalText']  = "RCH  Portal";
	//	 $data['orsicon']  = "<img src='".base_url('assets/images/icon/rch-logo.png')."'>";
         $data['GoToPortalLink']  = "#";
		$data['PortaliframeURL'] ='https://rchrpt.nhm.gov.in/RCHRPT/Dashboard/PortalDashboard.aspx'; // It has Iframe not available remove this or blank this variable
         $data['show_kpi_view'] = TRUE;  // It has KPIS 
			$dat = $this->Block_model->get_total_kpi($slug);
       $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		$str="";
		foreach($dat as $tdata)
			$str.=",".$tdata['total_kpi'];
			$data['total_kpi']=array();
			$data['total_kpi']['total_kpi']=substr($str,1,strlen($str));
       $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
       $data['kpi_table_data']=array();
         foreach($data['all_kpi'] as $keys=>$vals){
                $data['kpi_table_data'][$keys]=$this->Block_model->get_table_kpi_data($slug,$vals); 
                 }
		break;

	case "mou":
 
 	 $this->mybreadcrumb->add('Home', base_url('admin/home'));
      //  $this->mybreadcrumb->add('International Health', base_url('admin/internationalhealth'));
        $this->mybreadcrumb->add('MOU', base_url('admin/home'));
        $data['page_type']='International Health';
        
			 $data['header'] = "Memorandum of Understanding (MOU)";
         $data['GoToPortalText']  = "MOU  Portal";
         $data['GoToPortalLink']  = "#";
			$dat = $this->Block_model->get_total_kpi($slug);
		//echo "<pre>";print_r($dat);die;
		$str="";
		foreach($dat as $key=>$value)
			$str.=",".$key.":".$value;
			$data['total_kpi']=array();
			$data['total_kpi']['total_kpi']=substr($str,1,strlen($str));
			$data['table_data'] = $this->Block_model->get_table_data($slug);
         $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
         $data['kpi_table_data']=array();
         foreach($data['all_kpi'] as $keys=>$vals){
                $data['kpi_table_data'][$keys]=$this->Block_model->get_table_kpi_data($slug,$vals);	
		         }
				 
		break;

		case "fvms":
   
   	   $this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('International Health', base_url('admin/internationalhealth'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='International Health';
        
			 $data['header'] = "Foreign Visit Management System (FVMS)";
         $data['GoToPortalText']  = "FVMS  Portal";
         $data['GoToPortalLink']  = "#";
			$dat = $this->Block_model->get_total_kpi($slug);
       $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		//echo "<pre>";print_r($dat);die;
		$str="";
		foreach($dat as $key=>$value)
			$str.=",".$key.":".$value;
			$data['total_kpi']=array();
			$data['total_kpi']['total_kpi']=substr($str,1,strlen($str));
			$data['table_data'] = $this->Block_model->get_table_data($slug);
         $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
         $data['kpi_table_data']=array();
         foreach($data['all_kpi'] as $keys=>$vals){
                $data['kpi_table_data'][$keys]=$this->Block_model->get_table_kpi_data($slug,$vals);	
		         }
		break;

		case "tobacco":

	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Surveillance', base_url('admin/surveillance'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Surveillance';
        
         $data['header'] = "Quit Tobacco  ";
         $data['GoToPortalText']  = "Quit Tobacco Portal";
         $data['GoToPortalLink']  = "http://117.239.178.202/serverdash/";
         
          $data['PortaliframeURL'] ='https://mh.nhp.org.in/serverdash/central_dashboard.html'; // It has Iframe not available remove this or blank this variable
         $data['show_kpi_view'] = TRUE;  // It has KPIS

		$data['total_kpi'] = $this->Block_model->get_total_kpi($slug);
    $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		break;	

		case "mdiabetes":
   
   	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('admin/HealthcareInfrastructure'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Healthcare Infrastructure';

        $data['PortaliframeURL'] ='https://mh.nhp.org.in/serverdash/central_dashboard.html'; // It has Iframe not available remove this or blank this variable
         $data['show_kpi_view'] = TRUE; 

         $data['header'] = "mDiabetes  ";
         $data['GoToPortalText']  = "mDiabetes Portal";
         $data['GoToPortalLink']  = "http://117.239.178.202/serverdash/central_dashboard.html";;
         
         
		//echo "hello"; die;
		
         
        
    $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		break;	

		case "notto":
   
   	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('admin/HealthcareInfrastructure'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Healthcare Infrastructure';

         $data['header'] = "National Organ & Tissue Transplant Organisation(Notto)  ";
         $data['GoToPortalText']  = "Notto Portal";
         $data['GoToPortalLink']  = "#";
		$data['total_kpi'] = $this->Block_model->get_total_kpi($slug);
    $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		break;	

		case "son":
   
    $this->mybreadcrumb->add('Home', base_url('admin/home'));
       // $this->mybreadcrumb->add('International Health', base_url('admin/internationalhealth'));
        $this->mybreadcrumb->add('SON', base_url('admin/home'));
        $data['page_type']='International Health';

         $data['header'] = "Statement of Need (SON)  ";
         $data['GoToPortalText']  = "SON Portal";
         $data['GoToPortalLink']  = "#";
		$data['total_kpi'] = $this->Block_model->get_total_kpi($slug);
   
    $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		break;	

			case "nvhcp":
      
      	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Health Service Delivery', base_url('admin/healthservice'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Health Service Delivery';

         $data['header'] = "National Viral Hepatitis Control Program (NVHCP)";
         $data['GoToPortalText']  = "NVHCP Portal";
         $data['GoToPortalLink']  = "#";
		$data['total_kpi'] = $this->Block_model->get_total_kpi($slug);
		$data['table_data'] = $this->Block_model->get_table_data($slug);
         $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
         $data['kpi_table_data']=array();
         foreach($data['all_kpi'] as $keys=>$vals){
                $data['kpi_table_data'][$keys]=$this->Block_model->get_table_kpi_data($slug,$vals);	
		         }

		break;	
		
			case "naco":
      
      	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Surveillance', base_url('admin/surveillance'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Surveillance';

         $data['header'] = "National Aids Control Organization (NACO)  ";
         $data['GoToPortalText']  = "NACO Portal";
         $data['GoToPortalLink']  = "#";
		$data['total_kpi'] = $this->Block_model->get_total_kpi($slug);
		$data['table_data'] = $this->Block_model->get_table_data($slug);
         $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
         $data['kpi_table_data']=array();
         foreach($data['all_kpi'] as $keys=>$vals){
                $data['kpi_table_data'][$keys]=$this->Block_model->get_table_kpi_data($slug,$vals);	
		         }

		break;	
		
		
		
		default:
			show_404();
		break;
		}	
        loadLayout('admin/block', 'admin', $data);
		
    }


  
    

     

}
