<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Block extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
		
       // $this->load->model('centraldashboard/Pmssy_model');
        $this->load->model('admin/Block_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index($slug = NULL) { 
		

       /*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
	
        
		
		/*---------End User Permission----------*/	
		switch($slug)
		{
		// $data['view'] = $this->Pmssy_model->get_PMSSYs();
        // $data['map_data'] = $this->Block_model->get_map_data();
		case "ambulance":

		//$data['table_header'] = $this->Block_model->get_table_header('ambulance_master_table');
         //$data['headerY'] = "Total Ambulances";         
         //$data['total_header'] = $this->Block_model->get_total_header();
         
         	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('admin/HealthcareInfrastructure'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Healthcare Infrastructure';
         
         $data['header'] = "Nation Wide Ambulances  ";
         $data['GoToPortalText']  = "";
         $data['GoToPortalLink']  = "#";
		$data['total_kpi'] = $this->Block_model->get_total_kpi($slug);
         $data['table_data'] = $this->Block_model->get_table_data($slug);
         $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
         $data['kpi_table_data']=array();
         foreach($data['all_kpi'] as $keys=>$vals){
                $data['kpi_table_data'][$keys]=$this->Block_model->get_table_kpi_data($slug,$vals);
		
         }
		break;

		case "pmssy":
   
   	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('admin/HealthcareInfrastructure'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Healthcare Infrastructure';

		//$data['table_header'] = $this->Block_model->get_table_header('ambulance_master_table');
         //$data['headerY'] = "Total Ambulances";         
         //$data['total_header'] = $this->Block_model->get_total_header();
         
         $data['header'] = "Pradhan Mantri Swasthya Suraksha Yojana (PMSSY)";
         $data['GoToPortalText']  = "PMSSY Portal";
         $data['GoToPortalLink']  = "https://dashboard.nhp.gov.in/pmssy/dashboard";
		$data['total_kpi'] = $this->Block_model->get_total_kpi($slug);
        $data['table_data'] = $this->Block_model->get_table_data($slug);
         $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
         $data['kpi_table_data']=array();
         foreach($data['all_kpi'] as $keys=>$vals){
                $data['kpi_table_data'][$keys]=$this->Block_model->get_table_kpi_data($slug,$vals);
         }
		break;
		case "mera_aspataal":
   
   	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Quality of Health Services', base_url('admin/Qualityhealthservices'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Quality of Health Services';
        
			 $data['header'] = "Mera Aspataal  ";
         $data['GoToPortalText']  = "Mera Aspataal Portal";
         $data['GoToPortalLink']  = "#";
			$dat = $this->Block_model->get_total_kpi($slug);
       $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);

		$str="";
		foreach($dat as $tdata)
			$str.=",".$tdata['total_kpi'];
			$data['total_kpi']=array();
			$data['total_kpi']['total_kpi']=substr($str,1,strlen($str));
		break;
		case "elderly":
   
   	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Health Service Delivery', base_url('admin/healthservice'));
        $this->mybreadcrumb->add($slug, base_url(''));
        $data['page_type']='Health Service Delivery';
        
			         $data['header'] = "Elderly  ";
         $data['GoToPortalText']  = "Elderly Portal";
         $data['GoToPortalLink']  = "#";
         
          $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
          
		$data['total_kpi'] = $this->Block_model->get_total_kpi($slug);

			break;
		case "ors":
   
   	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Quality of Health Services', base_url('admin/Qualityhealthservices'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Quality of Health Services';
        
			 $data['header'] = "Online Registration System  (ORS)";
         $data['GoToPortalText']  = "ORS  Portal";
         $data['GoToPortalLink']  = "https://ors.gov.in/copp/dashboard.jsp";
			$dat = $this->Block_model->get_total_kpi($slug);
       $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		$str="";
		foreach($dat as $tdata)
			$str.=",".$tdata['total_kpi'];
			$data['total_kpi']=array();
			$data['total_kpi']['total_kpi']=substr($str,1,strlen($str));
		break;

		case "qa":
   
   	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('admin/HealthcareInfrastructure'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Healthcare Infrastructure';
        
			 $data['header'] = "Quality Assurance   ";
         $data['GoToPortalText']  = "Quality Assurance  Portal";
         $data['GoToPortalLink']  = "#";
			$dat = $this->Block_model->get_total_kpi($slug);
       $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		
		$str="";
		foreach($dat as $tdata)
			$str.=",".$tdata['State_Name'].":".$tdata['count'];
			$data['total_kpi']=array();
			$data['total_kpi']['total_kpi']=substr($str,1,strlen($str));
			 $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		//echo "<pre>";print_r($data['all_kpi']);die;
         $data['kpi_table_data']=array();
         foreach($data['all_kpi'] as $keys=>$vals){
                $data['kpi_table_data'][$keys]=$this->Block_model->get_table_kpi_data($slug,$vals['state_id']);	
		         }
		break;

		case "ehospital":
   
   	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Quality of Health Services', base_url('admin/Qualityhealthservices'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Quality of Health Services';
        
			 $data['header'] = "eHospital   ";
         $data['GoToPortalText']  = "eHospital  Portal";
         $data['GoToPortalLink']  = "http://dashboard.ehospital.gov.in/dashboard-testing2/";
			$dat = $this->Block_model->get_total_kpi($slug);
       $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		$str="";
		foreach($dat as $tdata)
			$str.=",".$tdata['total_kpi'];
			$data['total_kpi']=array();
			$data['total_kpi']['total_kpi']=substr($str,1,strlen($str));
		break;

		case "cghs":
   
   	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Health Service Delivery', base_url('admin/healthservice'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Health Service Delivery';
        
			 $data['header'] = "Central Government Health Scheme (CGHS)";
         $data['GoToPortalText']  = "CGHS  Portal";
         $data['GoToPortalLink']  = "#";
			$dat = $this->Block_model->get_total_kpi($slug);
      
            $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		$str="";
		foreach($dat as $tdata)
			$str.=",".$tdata['total_kpi'];
			$data['total_kpi']=array();
			$data['total_kpi']['total_kpi']=substr($str,1,strlen($str));
       $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		break;

		case "rch":
   
   	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Health Service Delivery', base_url('admin/healthservice'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Health Service Delivery';
        
			 $data['header'] = "Reproductive and Child Health(RCH)   ";
         $data['GoToPortalText']  = "RCH  Portal";
         $data['GoToPortalLink']  = "#";
			$dat = $this->Block_model->get_total_kpi($slug);
       $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		$str="";
		foreach($dat as $tdata)
			$str.=",".$tdata['total_kpi'];
			$data['total_kpi']=array();
			$data['total_kpi']['total_kpi']=substr($str,1,strlen($str));
       $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		break;

	case "mou":
 
 	 $this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('International Health', base_url('admin/internationalhealth'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='International Health';
        
			 $data['header'] = "A memorandum of understanding (MOU)";
         $data['GoToPortalText']  = "MOU  Portal";
         $data['GoToPortalLink']  = "#";
			$dat = $this->Block_model->get_total_kpi($slug);
		//echo "<pre>";print_r($dat);die;
		$str="";
		foreach($dat as $key=>$value)
			$str.=",".$key.":".$value;
			$data['total_kpi']=array();
			$data['total_kpi']['total_kpi']=substr($str,1,strlen($str));
			$data['table_data'] = $this->Block_model->get_table_data($slug);
         $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
         $data['kpi_table_data']=array();
         foreach($data['all_kpi'] as $keys=>$vals){
                $data['kpi_table_data'][$keys]=$this->Block_model->get_table_kpi_data($slug,$vals);	
		         }
		break;

		case "fvms":
   
   	   $this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('International Health', base_url('admin/internationalhealth'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='International Health';
        
			 $data['header'] = "Foreign Visit Management System (FVMS)";
         $data['GoToPortalText']  = "FVMS  Portal";
         $data['GoToPortalLink']  = "#";
			$dat = $this->Block_model->get_total_kpi($slug);
       $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		//echo "<pre>";print_r($dat);die;
		$str="";
		foreach($dat as $key=>$value)
			$str.=",".$key.":".$value;
			$data['total_kpi']=array();
			$data['total_kpi']['total_kpi']=substr($str,1,strlen($str));
			$data['table_data'] = $this->Block_model->get_table_data($slug);
         $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
         $data['kpi_table_data']=array();
         foreach($data['all_kpi'] as $keys=>$vals){
                $data['kpi_table_data'][$keys]=$this->Block_model->get_table_kpi_data($slug,$vals);	
		         }
		break;

		case "tobacco":

	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Surveillance', base_url('admin/surveillance'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Surveillance';
        
         $data['header'] = "Quit Tobacco  ";
         $data['GoToPortalText']  = "Quit Tobacco Portal";
         $data['GoToPortalLink']  = "http://117.239.178.202/serverdash/";
		$data['total_kpi'] = $this->Block_model->get_total_kpi($slug);
    $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		break;	

		case "mdiabetes":
   
   	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('admin/HealthcareInfrastructure'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Healthcare Infrastructure';

         $data['header'] = "mDiabetes  ";
         $data['GoToPortalText']  = "mDiabetes Portal";
         $data['GoToPortalLink']  = "http://117.239.178.202/serverdash/";
		$data['total_kpi'] = $this->Block_model->get_total_kpi($slug);
    $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		break;	

		case "notto":
   
   	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('admin/HealthcareInfrastructure'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Healthcare Infrastructure';

         $data['header'] = "National Organ & Tissue Transplant Organisation(Notto)  ";
         $data['GoToPortalText']  = "Notto Portal";
         $data['GoToPortalLink']  = "#";
		$data['total_kpi'] = $this->Block_model->get_total_kpi($slug);
    $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		break;	

		case "son":
   
    $this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('International Health', base_url('admin/internationalhealth'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='International Health';

         $data['header'] = "Statement of Need(SON)  ";
         $data['GoToPortalText']  = "SON Portal";
         $data['GoToPortalLink']  = "#";
		$data['total_kpi'] = $this->Block_model->get_total_kpi($slug);
   
    $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
		break;	

			case "nvhcp":
      
      	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Health Service Delivery', base_url('admin/healthservice'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Health Service Delivery';

         $data['header'] = "National Viral Hepatitis Control Program (NVHCP)";
         $data['GoToPortalText']  = "NVHCP Portal";
         $data['GoToPortalLink']  = "#";
		$data['total_kpi'] = $this->Block_model->get_total_kpi($slug);
		$data['table_data'] = $this->Block_model->get_table_data($slug);
         $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
         $data['kpi_table_data']=array();
         foreach($data['all_kpi'] as $keys=>$vals){
                $data['kpi_table_data'][$keys]=$this->Block_model->get_table_kpi_data($slug,$vals);	
		         }

		break;	
		
			case "naco":
      
      	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Surveillance', base_url('admin/surveillance'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Surveillance';

         $data['header'] = "National Aids Control Organization (NACO)  ";
         $data['GoToPortalText']  = "NACO Portal";
         $data['GoToPortalLink']  = "#";
		$data['total_kpi'] = $this->Block_model->get_total_kpi($slug);
		$data['table_data'] = $this->Block_model->get_table_data($slug);
         $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
         $data['kpi_table_data']=array();
         foreach($data['all_kpi'] as $keys=>$vals){
                $data['kpi_table_data'][$keys]=$this->Block_model->get_table_kpi_data($slug,$vals);	
		         }

		break;	
		
		
		
		default:
			show_404();
		break;
		}	
        loadLayout('admin/block', 'admin', $data);
		
    }


  
    

     

}
