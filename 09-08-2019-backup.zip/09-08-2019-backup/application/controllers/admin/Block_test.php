<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Block_test extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
		
       // $this->load->model('centraldashboard/Pmssy_model');
        $this->load->model('admin/Block_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() {
	
	   
		

       /*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
	
        
		$slug = 'mera_aspataal';
		
     	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        //$this->mybreadcrumb->add('Quality of Health Services', base_url('admin/Qualityhealthservices'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Quality of Health Services';
       
		 
		$data['header'] = "Mera Aspataal  ";
        $data['GoToPortalText'] = "Mera Aspataal Portal";
      
			$dat = $this->Block_model->get_total_kpi($slug);
       $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);


        $ch = curl_init();

        $url ='https://admin-meraaspataal.nhp.gov.in/api/chiLogin';
        $apikey = 'HWC_CENTRAL_DASHBORD_LOGIN2018';

        $postData = array(
            'apikey' => $apikey,
            'source' => 'central_dashboard'
             
        );

        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postData,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_SSL_VERIFYHOST => 0,            // don't verify ssl 
                CURLOPT_SSL_VERIFYPEER => false
        ));

        $output = curl_exec($ch);
        //print_r($output);
        if (curl_errno($ch)) {
             //print_r (curl_error($ch));   
            
        }
        curl_close($ch);

        $portalurl = 'https://admin-meraaspataal.nhp.gov.in/';

        if($output){
            $output_object = json_decode($output);
            $return["return_url"]=  $output_object->return_url; 
            $return["status"]=  $output_object->status;
            $return["message"] =$output_object->message;
            $return["json"] = json_encode($return);
            //echo json_encode($return);
           $portalurl = $output_object->return_url;
        }
        echo   $portalurl;
         $data['GoToPortalLink']  = $portalurl;
         $data['PortaliframeURL'] =$portalurl; // It has Iframe not available remove this or blank this variable
         $data['show_kpi_view'] = TRUE;  //


		$str="";
		foreach($dat as $tdata)
			$str.=",".$tdata['total_kpi'];
			$data['total_kpi']=array();
			$data['total_kpi']['total_kpi']=substr($str,1,strlen($str));

        loadLayout('admin/block', 'admin', $data);
		
    }
  
    

     

}
