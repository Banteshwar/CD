<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Budget extends MY_Controller {
    private $user;

    public function __construct() {
        parent::__construct();
        $this->load->helper('sync_master');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('hwc_model');
        $this->load->model('Dashboard_model');
         $this->load->model('Meraaspataal_model');
        $this->load->model('Report_model');
		$this->load->library('smslib');
        
        //global $db;
        //$this->db = $db;
       
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
        $this->load->library('mybreadcrumb');

        $this->load->driver('cache');
    }

    public function index() {
        $this->mybreadcrumb->add('Home', base_url());
       // $this->mybreadcrumb->add('Health Service Delivery', base_url('admin/healthservice'));
        //$this->mybreadcrumb->add('Healthcare Infrastructure', base_url('admin/HealthcareInfrastructure')); 
        $this->mybreadcrumb->add('Budget', base_url('admin/budget'));

         $api_program_name = 'elderly';

        $url = 'http://mohfwbudget.nhp.gov.in/Api/chi_dashboard_report';

        $ch  = curl_init($url);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);

        if (curl_errno($ch)) {
            $error_msg = curl_error($ch);
            
        }
        curl_close($ch);

        if (isset($error_msg)) {
            $this->api_call_log($api_program_name,'Unexpected',$error_msg);
            return; // API call was unsuccessful
        } 

        $data  =  json_decode($response,true);
        //echo "<pre>"; print_r($data); die;
         $data['page_type']='Healthcare Infrastructure';
        loadLayout('admin/budget_dashboard_report', 'admin', $data);  
    }
	
	public function budget_dhr() {
        $this->mybreadcrumb->add('Home', base_url());
       // $this->mybreadcrumb->add('Health Service Delivery', base_url('admin/healthservice'));
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('admin/HealthcareInfrastructure')); 
        $this->mybreadcrumb->add('Budget', base_url('admin/budget'));

         $api_program_name = 'elderly';

        $url = 'http://mohfwbudget.nhp.gov.in/Api/dashboard_report_dhr  ';

        $ch  = curl_init($url);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);

        if (curl_errno($ch)) {
            $error_msg = curl_error($ch);
            
        }
        curl_close($ch);

        if (isset($error_msg)) {
            $this->api_call_log($api_program_name,'Unexpected',$error_msg);
            return; // API call was unsuccessful
        } 

        $data  =  json_decode($response,true);
         $data['page_type']='Healthcare Infrastructure';
        loadLayout('admin/centraldashboard_dhr', 'admin', $data);  
    }
	
	public function budget_mohfw() {
        $this->mybreadcrumb->add('Home', base_url());
       // $this->mybreadcrumb->add('Health Service Delivery', base_url('admin/healthservice'));
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('admin/HealthcareInfrastructure')); 
        $this->mybreadcrumb->add('Budget', base_url('admin/budget'));

         $api_program_name = 'elderly';

        $url = 'http://mohfwbudget.nhp.gov.in/Api/dashboard_report_mohfw';

        $ch  = curl_init($url);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);

        if (curl_errno($ch)) {
            $error_msg = curl_error($ch);
            
        }
        curl_close($ch);

        if (isset($error_msg)) {
            $this->api_call_log($api_program_name,'Unexpected',$error_msg);
            return; // API call was unsuccessful
        } 

        $data  =  json_decode($response,true);
         $data['page_type']='Healthcare Infrastructure';
        loadLayout('admin/centraldashboard_mohfw', 'admin', $data);  
    }

    public function budget_js() {
        $this->mybreadcrumb->add('Home', base_url());
       // $this->mybreadcrumb->add('Health Service Delivery', base_url('admin/healthservice'));
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('admin/HealthcareInfrastructure')); 
        $this->mybreadcrumb->add('Budget', base_url('admin/budget'));

         $api_program_name = 'elderly';

        $url = 'http://mohfwbudget.nhp.gov.in/Api/js_19_20';

        $ch  = curl_init($url);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);

        if (curl_errno($ch)) {
            $error_msg = curl_error($ch);
            
        }
        curl_close($ch);

        if (isset($error_msg)) {
            $this->api_call_log($api_program_name,'Unexpected',$error_msg);
            return; // API call was unsuccessful
        } 

        $data  =  json_decode($response,true);
         $data['page_type']='Healthcare Infrastructure';
        loadLayout('admin/centraldashboard_js', 'admin', $data);  
    }
}
