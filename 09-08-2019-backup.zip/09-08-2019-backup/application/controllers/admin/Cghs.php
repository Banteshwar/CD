<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Cghs extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
		
        $this->load->model('admin/Cghs_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() { 
       /*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link); 
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
			
		/*---------End User Permission----------*/	
		
		 //$data['view'] = $this->Cghs_model->get_CGHS();
         //$data['map_data'] = $this->Cghs_model->get_map_data();
       
          $data['all_kpi'] = $this->Cghs_model->get_array_kpi();
         $data['total_kpi'] = $this->Cghs_model->get_total_kpi();      
         //$data['cghs_kpis'] = $this->Cghs_model->cghs_kpis();
           $data['GoToPortalText']  = "";
         $data['GoToPortalLink']  = "#";
         //$data['total_header'] = $this->Cghs_model->get_total_header();
         $data['table_data'] = $this->Cghs_model->get_table_data();
         $data['table_header'] = $this->Cghs_model->get_table_header('cghs_master_table');;
		
         $data['header'] = "Central Government Health Scheme";
         $data['headerY'] = "CGHS";   
         $this->mybreadcrumb->add('Home', base_url());
         //$this->mybreadcrumb->add('Central Government Health Scheme', base_url('dashboard/index'));
         $this->mybreadcrumb->add('CGHS', base_url('admin/Cghs'));
         $data['page_type']='Health Service Delivery';
         loadLayout('admin/block', 'admin', $data);
		
    }
}
