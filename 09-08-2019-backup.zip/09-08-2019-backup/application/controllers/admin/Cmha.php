<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Cmha extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
		
        $this->load->model('admin/Cmha_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() { 
	 
        $data['total_kpi'] = $this->Cmha_model->get_total_kpi();
        $data['header'] = "NATIONAL MENTAL HEALTH PROGRAMME";
        $data['GoToPortalText']  = "CMHA Portal";
        $data['GoToPortalLink']  = "#";

        $data['all_kpi'] = $this->Cmha_model->get_array_kpi();
         $data['kpi_table_data']=array();
         foreach($data['all_kpi'] as $keys=>$vals){
                $data['kpi_table_data'][$keys]=$this->Cmha_model->get_table_kpi_data($vals);
        
         }  

        $this->mybreadcrumb->add('Home', base_url());
       // $this->mybreadcrumb->add('Health Service Delivery', base_url('admin/healthservice'));
        $this->mybreadcrumb->add('CMHA', base_url('admin/cmha'));
               
        $data['page_type']='Health Service Delivery';
        loadLayout('admin/block', 'admin', $data);
		
    }
}
