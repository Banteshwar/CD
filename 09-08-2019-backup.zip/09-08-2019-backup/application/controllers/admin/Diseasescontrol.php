<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Diseasescontrol extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
		
       
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() { 
	 
      	$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Diseases Control', base_url('admin/diseasescontrol'));
        $data['page_type']='Diseases Control';
        loadLayout('admin/diseases_control', 'admin', $data);
    }


  
    

     

}
