<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Fdsi extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
		
        $this->load->model('admin/Drugsdiagnostics_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() { 
	 
		

        $data['row'] = $this->Drugsdiagnostics_model->getDiagnosticServiecsTotal();
               
        $data['page_type']='Health Service Delivery';
        loadLayout('admin/fdsimap/fdsimap', 'admin', $data);
		
    }


  
    

     

}
