<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class HealthcareInfrastructure extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
		$this->load->model('admin/Nhm_model');
        $this->load->model('admin/Fru_model');
		$this->load->model('Dashboard_model');
        $this->load->helper('dashboard');
		
        $this->load->model('admin/HealthcareInfrastructure_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() { 
	 
       //$msgdata="hi kunal";
       

       //echo $this->smslib->sendSMS('9990624477',$msgdata);
       // die;
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('dashboard/ninportal'));
        
        $data['page_type']='Healthcare Infrastructure';
        //$data['kiosk'] = $this->Dashboard_model->get_kiosk();
        /* ============ data fetch to master table code ============ */
       // $ninmasterrec = fetchNINsyncdata();
            
        //$data['functionalFacilities']  = unserialize($ninmasterrec['total_functional_facilities']);
       // $data['functionalFacilities'] = getNINFunctionalFacilities('','');
        
      //  $ID = 0;
       // $State_ID = 0;
        
       // $syncrec = fetchsyncdata($ID, $State_ID);
       // $data['getApprovedState']  = unserialize($syncrec['getApprovedState']);
       // $data['HWCGraphReport']  = unserialize($syncrec['hwcGraphReport']);
        /* ================ end ==================== */
       //$data['getApprovedState'] = getApprovedData(0, 0);
		//$data['health'] = $this->HealthcareInfrastructure_model->get_healthd();
        loadLayout('admin/health_infra', 'admin', $data);
		
    }


  
    

     

}
