<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Healthservice extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
		
        $this->load->model('admin/Healthservice_model');
        $this->load->model('admin/Rntcp_model');
        $this->load->model('admin/Nvhcp_model');
        $this->load->model('admin/Npcb_model');
        $this->load->model('admin/Cmha_model');
        $this->load->model('admin/Idsp_model');
        //$this->load->model('admin/Emr_model');
     
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() { 
	 
      /*---------Start User Permission----------*/
        
        $user  =  $this->user;
        $user_row = $user->getUser();
        $url  =  json_decode($user_row['page_access'],true);
        
        $link = $_SERVER['PHP_SELF'];
        $link_array = explode('/',$link);
        $page = end($link_array);
        
        if($user_row['role']!="Admin"){
            if(!in_array($page,$url)){      
                echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
            }
        }       
        /*---------End User Permission----------*/
      
        $data['fetch_date'] = $this->Healthservice_model->fetch_curr_date(); 
       
        
        $data['hmis_curr_date'] = $this->Healthservice_model->hmis_curr_date(); 
        $data['amrit_curr_date'] = $this->Healthservice_model->amrit_curr_date(); 
        $data['rch_curr_date'] = $this->Healthservice_model->rch_curr_date(); 
        $data['ors_curr_date'] = $this->Healthservice_model->ors_curr_date(); 
        $data['fetch_curr_date'] = $this->Healthservice_model->fetch_notto_currdate(); 
        $data['amrit'] = $this->Healthservice_model->newerinitamrit();
        $data['cghs_kpis'] = $this->Healthservice_model->cghs_kpis(); 
        $data['nohp_sum_data'] = $this->Healthservice_model->nohp_sum_data();
        $data['immunization'] = $this->Healthservice_model->immunization();
        $data['familyplanning'] = $this->Healthservice_model->familyplanning();
        $data['adolescent'] = $this->Healthservice_model->adolescent_Health();
        $data['npcb'] = $this->Npcb_model->get_totalRecordNPCBs();
        $data['cmha'] = $this->Cmha_model->get_totalRecordCmha();
        $data['idsp'] = $this->Idsp_model->get_totalRecordIDSP();
      



       
        $data['result'] = getPMSMAReport();
        $data['result1'] = getLAQSHAYReport();

        $data['result2'] = $this->Nvhcp_model->get_totalRecordNVHCPs();
        $data['result3'] = $this->Rntcp_model->get_totalRecordRNTCP();
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Service Delivery', base_url('admin/healthservice'));


        $data['page_type']='Health Service Delivery';
        loadLayout('admin/healthService/health_service', 'admin', $data);
		
    }


  
    

     

}
