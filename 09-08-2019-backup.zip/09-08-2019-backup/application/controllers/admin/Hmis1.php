<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Hmis1 extends MY_Controller {
    private $user;

    public function __construct() {
        
        parent::__construct();
        
        
        $this->load->model('admin/Hmis_model');
        $this->load->helper('commondata_helper');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');

    }

    public function index() { 
    
         $data['GoToPortalLink']='#';
         $data['GoToPortalText']  = "Go To Portal";
         $data['total_kpi'] = $this->Hmis_model->get_total_kpi();
         //print_r($data['total_kpi']);die;
         $data['header'] = "Ncdc";     
      //   $data['total_header'] = $this->Ncdc_model->get_total_header();
         $data['all_kpi'] = $this->Hmis_model->get_array_kpi();
         $data['kpi_table_data']=array();
         foreach($data['all_kpi'] as $keys=>$vals){
             $data['kpi_table_data'][$keys] = $this->Hmis_model->get_table_kpi_data($vals);
         }
         $data['header'] = "";
        
         $this->mybreadcrumb->add('Home', base_url('admin/home'));
         $this->mybreadcrumb->add('hmis1', base_url('admin/hmis1'));
     
               
         $data['page_type']='Health Human Resources';
         loadLayout('admin/hmis1', 'admin', $data);
        
    }
}
