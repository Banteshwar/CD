<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Hwc extends MY_Controller {
    private $user;

    public function __construct() {
        
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('admin/HealthcareInfrastructure_model');
        //$this->load->model('admin/Nvhcp_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() { 
     
        $data['view'] = $this->Nvhcp_model->fetch_nvhcp();
            
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('dashboard/ninportal'));
        $data['hwcapprove']   =  $this->HealthcareInfrastructure_model->get_hwc();
        $data['map_data'] = $this->HealthcareInfrastructure_model->get_map_data();
       // echo "<pre>";print_r($data['map_data']);die;

         $data['header'] = "AB-HWC Approved ";
         $data['headerY'] = "AB-HWC Approved";
         $data['total_kpi'] = $this->HealthcareInfrastructure_model->get_total_kpi();         
         $data['total_header'] = $this->HealthcareInfrastructure_model->get_total_header();
         $data['table_data'] = $this->HealthcareInfrastructure_model->get_table_data();
         $data['table_header'] = $this->HealthcareInfrastructure_model->get_table_header('hwc_master_table');

        $data['page_type']  ='Healthcare Infrastructure';
        loadLayout('admin/hwc', 'admin', $data);
        
    }


  
    

     

}
