<?php 

 class Ihip extends CI_Controller{
	 private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
		
        $this->load->model('admin/Fru_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() { 

        $user  =  $this->user;
        $user_row = $user->getUser();
        $url  =  json_decode($user_row['page_access'],true);
        
        $link = $_SERVER['PHP_SELF'];
        $link_array = explode('/',$link);
        $page = end($link_array);
        $data['header'] = "Integrated Health Information Platform";
	    $data['page_type'] ='Surveillance';

        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Surveillance', base_url('admin/Surveillance'));
        $this->mybreadcrumb->add('IHIP', base_url('admin/ihip'));
       
		loadLayout('admin/ihip', 'admin', $data);
	}
}