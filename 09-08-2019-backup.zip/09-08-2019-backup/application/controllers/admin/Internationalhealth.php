<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Internationalhealth extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
		$this->load->model('admin/Nhm_model');
		$this->load->model('admin/Son_model');
		$this->load->model('Dashboard_model');
        $this->load->helper('dashboard');
		
        
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() { 
	 
       $user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
			
		/*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Internationl Health', base_url(''));
		//$data['total_tour']=$this->Dashboard_model->total_foreign_tour();
		//$data['active_mou']=$this->Dashboard_model->total_active_mou();
		//$data['total_recordsSON']=$this->Son_model->get_totalSONrecords();

		
        
		
		// find date last update master table ////////
		
		 $this->db->select('*');
         $this->db->from('last_update_sync_master');
         $query=$this->db->get();
		 $last_update[]='';
		 if($query->num_rows()>0){
			 $data_arr = $query->result_array(); 
					foreach($data_arr as $result){
						$last_update[$result['program']]=$result['updated_date'];
					}
					
					 $data['last_update_sync_master']= $last_update;
					
		 }
		 else{
			 $data['last_update_sync_master']= $last_update;
		 }
		
		  		
		// end find date last update master table ////////
		
        $data['page_type']='International Health';
        loadLayout('admin/internationalhealth', 'admin', $data);
		
    }


  
    

     

}
