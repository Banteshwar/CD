<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Me1 extends MY_Controller {
    private $user;

    public function __construct() {
        
        parent::__construct();
        
        
       // $this->load->model('admin/Fvms_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');

    }

    public function index() { 
    
      
        
        $data['header'] = " Medical Education";
    
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Me1', base_url('admin/me1'));
     
               
        $data['page_type']='Health Human Resources';
        loadLayout('admin/me1/me1', 'admin', $data);
        
    }
}
