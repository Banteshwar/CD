<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Meraaspataal extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
         $this->load->model('Dashboard_model');
		
       // $this->load->model('centraldashboard/Pmssy_model');
        //$this->load->model('admin/Ncd_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() { 

	
      
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		if($user_row['role']!="Admin"){
			if(!in_array($page,$url)){		
				echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
			}
		}		
		/*---------End User Permission----------*/		
	
       	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        //$this->mybreadcrumb->add('Quality of Health Services', base_url('admin/qualityhealthservices'));
        $this->mybreadcrumb->add('Mera Aspataal', base_url('admin/meraaspataal'));
        //$data['remote_site_url'] = 'http://pssadmin.mahiti.org/api/chiLogin';
        $data['remote_site_url']   = 'http://admin.meraaspataal.nhp.gov.in/api/chiLogin';									  
		
		/////////////////// master database sync code here ///////
       $result = syncMeraAspataaldatabase();
        ////////////////// end master database sync code /////////
	   
       foreach($result as $row){
            $result   =  $this->Dashboard_model->updateRecord($row);            
       }
        
		$data['record'] =  $this->Dashboard_model->get_all_record();
        /*echo "<pre>";
        print_r($data['record']);die;*/
		$data['record1']=  $this->Dashboard_model->get_record();
        /*echo "<pre>";
        print_r($data['record1']);die;*/
        $data['page_type'] = 'Quality of Health Services';
        loadLayout('admin/meraaspataal_old', 'admin', $data);
		
    }


  
    

     

}
