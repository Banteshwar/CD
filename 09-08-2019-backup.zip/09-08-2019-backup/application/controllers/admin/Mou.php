<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Mou extends MY_Controller {
    private $user;

    public function __construct() {
        
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        
        $this->load->model('admin/Mou_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() { 
    
        /*$data['map_data'] = $this->Idsp_model->get_map_data();
        $data['total_header'] = $this->Idsp_model->get_total_header();*/
        //$data['total_kpi'] = $this->Mou_model->get_total_kpi();
        $data['table_data'] = $this->Mou_model->get_table_data();
        $data['table_header'] = $this->Mou_model->get_table_header('tbl_mou');
        
        $data['header'] = "MOU";
        $data['headerY'] = "MOU";  
        $this->mybreadcrumb->add('Home', base_url());
        //$this->mybreadcrumb->add('MOU', base_url('admin/Mou'));
        $this->mybreadcrumb->add('MOU', base_url('admin/Mou'));
               
        $data['page_type']='International Health';
        loadLayout('admin/mou/mou', 'admin', $data);
        
    }
}
