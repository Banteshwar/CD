<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Ncd extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
		
       // $this->load->model('centraldashboard/Pmssy_model');
        $this->load->model('admin/Ncd_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() { 

	
        $data['total_kpi'] = $this->Ncd_model->get_total_kpi();
         $data['header'] = "Non Communicable Diseases Screening (NCD)";
         $data['GoToPortalText']  = "NCD";
         $data['GoToPortalLink']  = "#";       
         $data['total_header'] = $this->Ncd_model->get_total_header();
         $data['PortaliframeURL'] ='https://ncd.nhp.gov.in:8080/ncdkpi/'; // It has Iframe not available remove this or blank this variable
        //$data['all_kpi'] = $this->Ncd_model->get_array_kpi();
        /* $data['kpi_table_data']=array();
         foreach($data['all_kpi'] as $keys=>$vals){
                $data['kpi_table_data'][$keys]=$this->Ncd_model->get_table_kpi_data($vals);
        
         }*/
			
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        //$this->mybreadcrumb->add('Surveillance', base_url('admin/surveillance'));
        $this->mybreadcrumb->add('NCD', base_url('admin/ncd'));
        $data['page_type']='Surveillance';
        loadLayout('admin/block', 'admin', $data);
		
    }


  
    

     

}
