<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Ncdc extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
		
        $this->load->model('admin/Ncdc_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() { 

         $data['GoToPortalLink']='#';
         $data['GoToPortalText']  = "Go To Portal";
         
         $data['total_kpi'] = $this->Ncdc_model->get_total_kpi();
         //print_r($data['total_kpi']);die;
         $data['header'] = "Ncdc / MOU SIGNED BETWEEN GOVT. OF INDIA AND STATE GOVT";     
         $data['total_header'] = $this->Ncdc_model->get_total_header();
         $data['all_kpi'] = $this->Ncdc_model->get_array_kpi();
         $data['kpi_table_data']=array();
         foreach($data['all_kpi'] as $keys=>$vals){
             $data['kpi_table_data'][$keys] = $this->Ncdc_model->get_table_kpi_data($vals);
         }
       
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        //$this->mybreadcrumb->add('Surveillance', base_url('admin/ncdc'));
        $this->mybreadcrumb->add('NCDC', base_url('admin/Ncdc'));
        $data['page_type']='Surveillance';
        loadLayout('admin/block', 'admin', $data);
     
    }

}
