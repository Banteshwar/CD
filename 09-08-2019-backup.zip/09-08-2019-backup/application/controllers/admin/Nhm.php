<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Nhm extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
		
       // $this->load->model('programmanager/Nhm_model');
        $this->load->model('admin/Nhm_model');    
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() { 
	 
		$data['total_kpi'] = $this->Nhm_model->get_total_kpi();
        $data['header'] = "National Health Mission Finance";
        $data['GoToPortalText']  = "NHM Portal";
        $data['GoToPortalLink']  = "#";       
        $data['total_header'] = $this->Nhm_model->get_total_header();
        //$data['table_data'] = $this->Nhm_model->get_table_data();
        // $data['table_header'] = $this->Nhm_model->get_table_header('ambulance_master_table');

        $data['all_kpi'] = $this->Nhm_model->get_array_kpi();
        $data['kpi_table_data']=array();
        foreach($data['all_kpi'] as $keys=>$vals){
            $data['kpi_table_data'][$keys]=$this->Nhm_model->get_table_kpi_data($vals);
        }
//echo "<pre>"; print_r($data['kpi_table_data'][$keys]); die;
       //$data['row'] = $this->nhm_model->get_nhm_finance();
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
       // $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('admin/HealthcareInfrastructure'));
        $this->mybreadcrumb->add('NHM Finance', base_url('admin/nhm'));
        $data['page_type']='Healthcare Infrastructure';
        loadLayout('admin/block', 'admin', $data);
        //loadLayout('admin/nhmfinance/nhmfinance', 'admin', $data);
		
    }


  
    

     

}
