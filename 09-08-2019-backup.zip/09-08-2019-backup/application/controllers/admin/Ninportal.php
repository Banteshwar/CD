<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Ninportal extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
        $this->load->model('hwc_model');
        $this->load->model('Dashboard_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }


    public function index() { 
		
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        //$this->mybreadcrumb->add('Healthcare Infrastructure', base_url('admin/HealthcareInfrastructure'));
        $this->mybreadcrumb->add('NIN Portal', base_url('admin/ninportal'));


        /////////////////// master database sync code here ///////

        //$data['SYNC_NIN'] = syncNINdatabase();

        ////////////////// end master database sync code /////////

        ////////// show state ////////////

        if($this->input->get('state_name'))
        {
            $state_id=$this->input->get('state_name');
        }
        else
        {
            $state_id='';
        } 
        $data['searh_state_id']=$state_id;
            
        if ( ! $nin_state = $this->cache->file->get('nin_state'))
        {
            $nin_state=$this->hwc_model->get_state();
            $this->cache->file->save('nin_state', $nin_state, 300);
        }
            $data['state'] = $nin_state;
            $data['state'] = $nin_state; 
            $data['state_name'] = $this->hwc_model->get_statename($state_id);
        ////////// end show state ////////////
        
         /*
            $ninmasterrec = fetchNINsyncdata($state_id);
            
            $data['functionalFacilities']  = unserialize($ninmasterrec['total_functional_facilities']);
            $data['functionalStateWiseFacilities']  = unserialize($ninmasterrec['nin_functionalStateWiseFacilities']);
            $data['totalFacilitiesOperationalStatus']  = unserialize($ninmasterrec['nin_totalFacilitiesOperationalStatus']);
            $data['totalConfirmedVerified']  = unserialize($ninmasterrec['nin_totalConfirmedVerified']);
            $data['totalFacilitiesOperationalStatusStateWise']  = unserialize($ninmasterrec['nin_totalFacilitiesOperationalStatusStateWise']);
            $data['functionalFacilitiesStateWise']  = unserialize($ninmasterrec['nin_functionalFacilitiesStateWise']);
            $data['totalConfirmedVerifiedStateWise']  = unserialize($ninmasterrec['nin_totalConfirmedVerifiedStateWise']);
            $data['totalRuralUrbanVerifiedStateWise']  = unserialize($ninmasterrec['nin_totalRuralUrbanVerifiedStateWise']);
            $data['totalRuralUrbanVerified']  = unserialize($ninmasterrec['nin_totalRuralUrbanVerified']); 
            */
            
          /*  echo "<pre>";
            print_r($ninmasterrec); die;
             */
            
       
        
        if( ! $nin_functionalStateWiseFacilities = $this->cache->file->get('nin_functionalStateWiseFacilities'))
        {
            $nin_functionalStateWiseFacilities= getNINFunctionalStateWiseFacilities();
            $this->cache->file->save('nin_functionalStateWiseFacilities', $nin_functionalStateWiseFacilities, 36000);
        }
        $data['functionalStateWiseFacilities'] = $nin_functionalStateWiseFacilities;
			
			
		
		if( ! $NINFunctionalFacilities = $this->cache->file->get('NINFunctionalFacilities'.$state_id))
        {
            $NINFunctionalFacilities= getNINFunctionalFacilities('',$state_id);
            $this->cache->file->save('NINFunctionalFacilities'.$state_id, $NINFunctionalFacilities, 36000);
        }         
         $data['functionalFacilities'] = $NINFunctionalFacilities;
           
		 if( ! $ITInfrastructureStateWise = $this->cache->file->get('ITInfrastructureStateWise'))
        {
            $ITInfrastructureStateWise = getITInfrastructureStateWise();
            $this->cache->file->save('ITInfrastructureStateWise', $ITInfrastructureStateWise, 36000);
        }
		//print_r($ITInfrastructureStateWise); echo "nin"; exit;
        $data['ITInfrastructureStateWise'] = $ITInfrastructureStateWise;
		   
        /*
        if ( ! $nin_functionalFacilitiesStateWise = $this->cache->file->get('nin_functionalFacilitiesStateWise'))
        {
            $nin_functionalFacilitiesStateWise=getNINFunctionalFacilities(TRUE);
            $this->cache->file->save('nin_functionalFacilitiesStateWise', $nin_functionalFacilitiesStateWise, 3600);
        }
            $data['functionalFacilitiesStateWise'] = $nin_functionalFacilitiesStateWise;
        
        if( ! $nin_totalConfirmedVerified = $this->cache->file->get('nin_totalConfirmedVerified'))
        {
            $nin_totalConfirmedVerified=getNINTotalConfirmedVerified();
            $this->cache->file->save('nin_totalConfirmedVerified', $nin_totalConfirmedVerified, 3600);
        }
            $data['totalConfirmedVerified'] = $nin_totalConfirmedVerified;

        if ( ! $nin_totalConfirmedVerifiedStateWise = $this->cache->file->get('nin_totalConfirmedVerifiedStateWise'))
        {
            $nin_totalConfirmedVerifiedStateWise=getNINTotalConfirmedVerified(TRUE);
            $this->cache->file->save('nin_totalConfirmedVerifiedStateWise', $nin_totalConfirmedVerifiedStateWise, 3600);
        }
            $data['totalConfirmedVerifiedStateWise'] = $nin_totalConfirmedVerifiedStateWise;
        
        
        if ( ! $nin_totalRuralUrbanVerified = $this->cache->file->get('nin_totalRuralUrbanVerified'))
        {
            $nin_totalRuralUrbanVerified=getNINTotalRuralUrbanVerified(); 
            $this->cache->file->save('nin_totalRuralUrbanVerified', $nin_totalRuralUrbanVerified, 3600);
        }
            $data['totalRuralUrbanVerified'] = $nin_totalRuralUrbanVerified;

        if ( ! $nin_totalRuralUrbanVerifiedStateWise = $this->cache->file->get('nin_totalRuralUrbanVerifiedStateWise'))
        {
            $nin_totalRuralUrbanVerifiedStateWise=getNINTotalRuralUrbanVerified(TRUE);
            $this->cache->file->save('nin_totalRuralUrbanVerifiedStateWise', $nin_totalRuralUrbanVerifiedStateWise, 3600);
        }
            $data['totalRuralUrbanVerifiedStateWise'] =  $nin_totalRuralUrbanVerifiedStateWise;
        
        if ( ! $nin_totalFacilitiesOperationalStatus = $this->cache->file->get('nin_totalFacilitiesOperationalStatus'))
        {
            $nin_totalFacilitiesOperationalStatus=getFacilitiesOperationalStatus();
            $this->cache->file->save('nin_totalFacilitiesOperationalStatus', $nin_totalFacilitiesOperationalStatus, 3600);
        }
        
            $data['totalFacilitiesOperationalStatus'] = $nin_totalFacilitiesOperationalStatus; 

        if ( ! $nin_totalFacilitiesOperationalStatusStateWise = $this->cache->file->get('nin_totalFacilitiesOperationalStatusStateWise'))
        {
            $nin_totalFacilitiesOperationalStatusStateWise= getFacilitiesOperationalStatus(TRUE);
            $this->cache->file->save('nin_totalFacilitiesOperationalStatusStateWise', $nin_totalFacilitiesOperationalStatusStateWise, 3600);
        }
        
            $data['totalFacilitiesOperationalStatusStateWise'] =  $nin_totalFacilitiesOperationalStatusStateWise;



$data = getCacheData('getNINFunctionalFacilities');
print_r($data);
$data = getCacheData('getNINFunctionalsss');
print_r($data);
exit;

$data['totalITInfrastructureStateWise'] = getITInfrastructureStateWise();
echo "<pre>"; print_r($totalITInfrastructureStateWise); exit;
*/


//$data['functionalStateWiseFacilities'] = getNINFunctionalStateWiseFacilities();
//$data['functionalFacilities'] = getNINFunctionalFacilities('',$state_id);


//$data['totalConfirmedVerified'] =getNINTotalConfirmedVerified();
//$data['totalConfirmedVerifiedStateWise'] = getNINTotalConfirmedVerified(TRUE);
//$data['totalRuralUrbanVerified'] =getNINTotalRuralUrbanVerified();
//$data['totalRuralUrbanVerifiedStateWise'] = getNINTotalRuralUrbanVerified(TRUE);
//$data['totalFacilitiesOperationalStatus'] = getFacilitiesOperationalStatus();
//$data['totalFacilitiesOperationalStatusStateWise'] = getFacilitiesOperationalStatus(TRUE);

            $data['remote_site_url'] = 'https://nin.nhp.gov.in/cdapilogin.php';
            $data['page_type']='Healthcare Infrastructure';
        $data['updated_page'] = date('d M  Y');
         
         // find date last update master table ////////
        
         $this->db->select('*');
         $this->db->from('last_update_sync_master');
         $query=$this->db->get();
         $last_update[]='';
         if($query->num_rows()>0){
             $data_arr = $query->result_array(); 
                    foreach($data_arr as $result){
                        $last_update[$result['program']]=$result['updated_date'];
                    }
                    
                     $data['last_update_sync_master']= $last_update;
                    
         }
         else{
             $data['last_update_sync_master']= $last_update;
         }
                
        // end find date last update master table ////////
   
            loadLayout('admin/nin_portal', 'admin', $data);
    }


     

}
