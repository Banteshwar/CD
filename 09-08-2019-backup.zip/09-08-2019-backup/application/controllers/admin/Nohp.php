<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Nohp extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
		
        $this->load->model('admin/Nohp_model');
		
		$this->load->model('admin/Pmssy_model2');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() { 
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
		/*---------End User Permission----------*/	
		
		$data['total_kpi'] = $this->Nohp_model->get_total_kpi();
         $data['header'] = "National Oral Health Programme";
         $data['GoToPortalText']  = "NOHP Portal";
         $data['GoToPortalLink']  = "#";
        
        //$data['table_data'] = $this->Nohp_model->get_table_data();
         //$data['table_header'] = $this->Pmssy_model2->get_table_header('ambulance_master_table');
         $data['all_kpi'] = $this->Nohp_model->get_array_kpi();
         $data['kpi_table_data']=array();
         foreach($data['all_kpi'] as $keys=>$vals){
                $data['kpi_table_data'][$keys]=$this->Nohp_model->get_table_kpi_data($vals);

         }
        
			
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        //$this->mybreadcrumb->add('Health Service Delivery', base_url('admin/healthservice'));
        $this->mybreadcrumb->add('NOHP', base_url('admin/nohp'));
               
        $data['page_type']='Health Service Delivery';
       // loadLayout('admin/nohp/nohp', 'admin', $data);
		
		 loadLayout('admin/block', 'admin', $data);
		
    }


  
    

     

}
