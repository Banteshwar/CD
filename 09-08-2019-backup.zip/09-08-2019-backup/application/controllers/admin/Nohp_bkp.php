<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Nohp extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
		
        $this->load->model('admin/Nohp_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() { 
	 

        //$data['map_data'] = $this->Nohp_model->get_map_data();
        $data['total_header'] = $this->Nohp_model->get_total_header();
        $data['total_kpi'] = $this->Nohp_model->get_total_kpi();
        $data['table_data'] = $this->Nohp_model->get_table_data();
        $data['table_header'] = $this->Nohp_model->get_table_header('nohp_master_table');
        
			
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Service Delivery', base_url('admin/healthservice'));
        $this->mybreadcrumb->add('NOHP', base_url('admin/nohp'));
               
        $data['page_type']='Health Service Delivery';
        loadLayout('admin/nohp/nohp', 'admin', $data);
		
    }


  
    

     

}
