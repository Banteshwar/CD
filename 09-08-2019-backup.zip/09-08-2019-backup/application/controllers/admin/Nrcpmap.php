<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Nrcpmap extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
		
        $this->load->model('admin/Nrcpmap_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() { 
	 
		

        $data['map_data'] = $this->Nrcpmap_model->get_map_data();
        $data['total_header'] = $this->Nrcpmap_model->get_total_header();
        $data['total_kpi'] = $this->Nrcpmap_model->get_total_kpi();
        $data['table_data'] = $this->Nrcpmap_model->get_table_data();
        $data['table_header'] = $this->Nrcpmap_model->get_table_header('nrcp_master_table');;
	    $data['header'] = "NATIONAL RABIES CONTROL PROGRAMME";
        $data['headerY'] = "NATIONAL RABIES CONTROL PROGRAMME"; 
		$data['row']    = $this->Nrcpmap_model->get_mdiabetesform();
        $this->mybreadcrumb->add('Home', base_url());
        //$this->mybreadcrumb->add('Surveillance', base_url('admin/Surveillance'));
        $this->mybreadcrumb->add('NRCP', base_url('nrcp'));
               
        $data['page_type']='Health Service Delivery';
        loadLayout('admin/nrcpmap/nrcpmap', 'admin', $data);
		
    }


  
    

     

}
