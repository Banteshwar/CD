<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Nuhm extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
		
        $this->load->model('admin/Nuhm_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() { 

        $user  =  $this->user;
        $user_row = $user->getUser();
        $url  =  json_decode($user_row['page_access'],true);
        
        $link = $_SERVER['PHP_SELF'];
        $link_array = explode('/',$link);
        $page = end($link_array);

        $data['total_kpi'] = $this->Nuhm_model->get_total_kpi();
         $data['header'] = "National Urban Health Mission";
         $data['GoToPortalText']  = "Go to Portal";
         $data['GoToPortalLink']  = "#";       
         $data['total_header'] = $this->Nuhm_model->get_total_header();
         $data['table_data'] = $this->Nuhm_model->get_table_data();
 
         $data['all_kpi'] = $this->Nuhm_model->get_array_kpi();
         $data['kpi_table_data']=array();
         foreach($data['all_kpi'] as $keys=>$vals)
         {
                $data['kpi_table_data'][$keys]=$this->Nuhm_model->get_table_kpi_data($vals);
         }
        
                  
        $data['page_type'] ='Surveillance';
            
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        //$this->mybreadcrumb->add('Surveillance', base_url('admin/Surveillance'));
        $this->mybreadcrumb->add('Nuhm', base_url('admin/Nuhm'));
       
       
        loadLayout('admin/block', 'admin', $data);
		
    }   

}
