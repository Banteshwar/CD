<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Nursing extends MY_Controller {
    private $user;

    public function __construct() {
        
        parent::__construct();
       
        
      
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
       
    }

    public function index() { 
    
      
       
        
        $data['header'] = "Nursing";
        
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Dashboard Nursing', base_url('admin/me1'));
     
               
        $data['page_type']='Health Human Resources';
        loadLayout('admin/nursing/nursing', 'admin', $data);
        
    }
}
