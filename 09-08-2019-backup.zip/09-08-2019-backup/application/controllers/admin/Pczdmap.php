<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Pczdmap extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
		
        $this->load->model('admin/Pczdmap_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() { 
	 
		

        $data['map_data'] = $this->Pczdmap_model->get_map_data();
        $data['total_header'] = $this->Pczdmap_model->get_total_header();
        $data['total_kpi'] = $this->Pczdmap_model->get_total_kpi();
        $data['table_data'] = $this->Pczdmap_model->get_table_data();
        $data['table_header'] = $this->Pczdmap_model->get_table_header('pczd_master_table');

        $data['all_kpi'] = $this->Pczdmap_model->get_array_kpi();
        foreach($data['all_kpi'] as $keys=>$vals){
                $data['kpi_table_data'][$keys]=$this->Pczdmap_model->get_table_kpi_data($vals);

        }

	    $data['header'] = "PREVENTION AND CONTROL OF ZOONOTIC DISEASES";
        $data['headerY'] = "PREVENTION AND CONTROL OF ZOONOTIC DISEASES"; 

        $data['GoToPortalText']  = "PCZD Portal";
        $data['GoToPortalLink']  = "#";

		//$data['row']    = $this->Pczdmap_model->get_mdiabetesform();
        $this->mybreadcrumb->add('Home', base_url());
        //$this->mybreadcrumb->add('Surveillance', base_url('admin/Surveillance'));
        $this->mybreadcrumb->add('PCZD', base_url('pczd/index'));
               
        $data['page_type']='Surveillance';
        loadLayout('admin/block', 'admin', $data);
        //loadLayout('admin/pczdmap/pczdmap', 'admin', $data);
		
    }


  
    

     

}
