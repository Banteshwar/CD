<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Pmssy2 extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
		
       // $this->load->model('centraldashboard/Pmssy_model');
        $this->load->model('admin/Pmssy_model2');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() { 

	$this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('admin/HealthcareInfrastructure'));
        $this->mybreadcrumb->add($slug, base_url('admin/home'));
        $data['page_type']='Healthcare Infrastructure';

		$url="https://dashboard.nhp.gov.in/pmssy/pms/api/centraldashboard";
		$project_url="https://dashboard.nhp.gov.in/pmssy/pms/api/project_status";
		$project_tbl=$this->Block_model->get_PMSSY_api($project_url);
		$result_tbl=$this->Block_model->get_PMSSY_api($url);
       $final=$this->Block_model->get_PMSSY_table();
	   //echo "<pre />";print_r($final);die;
       
         $data['header'] = "Pradhan Mantri Swasthya Suraksha Yojana (PMSSY)";
         $data['GoToPortalText']  = "PMSSY Portal"; 
         $data['GoToPortalLink']  = "https://dashboard.nhp.gov.in/pmssy/dashboard";
         
         $data['PortaliframeURL'] ='https://dashboard.nhp.gov.in/pmssy/dashboard'; // It has Iframe not available remove this or blank this variable
         $data['show_kpi_view'] = TRUE;  // It has KPIS
         
         
         $data['total_kpi'] = $this->Block_model->get_total_kpi($slug);
       $data['table_data'] = $this->Block_model->get_table_data($slug);
        $data['all_kpi'] = $this->Block_model->get_array_kpi($slug);
         $data['kpi_table_data']=array();
		 //$data['kpi_table_data'][0]=$result_tbl;
		 //$data['kpi_table_data'][1]=$result_tbl;
		 //$data['kpi_table_data'][2]=$result_tbl;
		 //$data['kpi_table_data'][3]=$result_tbl;
         foreach($data['all_kpi'] as $keys=>$vals){
                $data['kpi_table_data'][$keys]=$this->Block_model->get_table_kpi_data($slug,$vals);
         }
	 
       /*---------Start User Permission----------*/
		
		$user  =  $this->user;
		$user_row = $user->getUser();
		$url  =  json_decode($user_row['page_access'],true);
		
		$link = $_SERVER['PHP_SELF'];
		$link_array = explode('/',$link);
		$page = end($link_array);
		
				
		/*---------End User Permission----------*/	
		
		// $data['view'] = $this->Pmssy_model->get_PMSSYs();
        // $data['map_data'] = $this->Pmssy_model2->get_map_data();
         $data['total_kpi'] = $this->Pmssy_model2->get_total_kpi();
         $data['header'] = " ";
         $data['GoToPortalText']  = "PMSSY Portal";
         $data['GoToPortalLink']  = "#";

        // $data['headerY'] = "Total Ambulances";         
         //$data['total_header'] = $this->Pmssy_model2->get_total_header();
         $data['table_data'] = $this->Pmssy_model2->get_table_data();
         //$data['table_header'] = $this->Pmssy_model2->get_table_header('ambulance_master_table');
         $data['all_kpi'] = $this->Pmssy_model2->get_array_kpi();
         $data['kpi_table_data']=array();
         foreach($data['all_kpi'] as $keys=>$vals){
                $data['kpi_table_data'][$keys]=$this->Pmssy_model2->get_table_kpi_data($vals);

         }
         	
        $this->mybreadcrumb->add('Home', base_url());
        //$this->mybreadcrumb->add('Healthcare Infrastructure', base_url('admin/HealthcareInfrastructure'));
        $this->mybreadcrumb->add('PMSSY', base_url('admin/pmssy2'));
        $data['page_type']='Healthcare Infrastructure';
        loadLayout('admin/pmssy2', 'admin', $data);
		
    }


  
    

     

}
