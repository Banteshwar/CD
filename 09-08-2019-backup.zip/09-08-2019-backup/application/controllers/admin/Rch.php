<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Rch extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
		
       // $this->load->model('centraldashboard/Pmssy_model');
        $this->load->model('admin/Rch_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() { 

	
        
         $data['header'] = "Reproductive and Child Health (RCH) ";
         $data['GoToPortalText']  = "Rch Portal";
         $data['GoToPortalLink']  = "#";       
         //$data['total_header'] = $this->Rch_model->get_total_header();https://rchrpt.nhm.gov.in/RCHRPT/Dashboard/PortalDashboard_mohfw.aspx

       //$data['PortaliframeURL'] ='https://rchrpt.nhm.gov.in/RCHRPT/Dashboard/PortalDashboard.aspx'; // It has Iframe not available remove this or blank this variable
	   $data['PortaliframeURL'] ='https://rchrpt.nhm.gov.in/RCHRPT/Dashboard/PortalDashboard_mohfw.aspx';

       $data['show_kpi_view'] = TRUE;  // It has KPIS 
       /* $data['all_kpi'] = $this->Rch_model->get_array_kpi();
         $data['kpi_table_data']=array();
         foreach($data['all_kpi'] as $keys=>$vals){
                $data['kpi_table_data'][$keys]=$this->Rch_model->get_table_kpi_data($vals);
        
         }*/
        $dat = $this->Rch_model->get_total_kpi();

        
        $str="";
        foreach($dat as $tdata)
            $str.=",".$tdata['total_kpi'];
            $data['total_kpi']=array();
            $data['total_kpi']['total_kpi']=substr($str,1,strlen($str));
       $data['all_kpi'] = $this->Rch_model->get_array_kpi();
       $data['kpi_table_data']=array();
         foreach($data['all_kpi'] as $keys=>$vals){
                $data['kpi_table_data'][$keys]=$this->Rch_model->get_table_kpi_data($vals); 
                 }
			
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        //$this->mybreadcrumb->add('Health Service Delivery', base_url('admin/healthservice'));
        $this->mybreadcrumb->add('RCH', base_url('admin/rch'));
        $data['page_type']='Health Service Delivery';
        loadLayout('admin/block', 'admin', $data);
		
    }


  
    

     

}
