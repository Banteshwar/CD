<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Rntcp extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
		
        $this->load->model('admin/Rntcp_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() { 

        $data['total_kpi'] = $this->Rntcp_model->get_total_kpi();
        $data['header'] = "Revised National Tuberculosis Control Programme";
        $data['GoToPortalText']  = "Nikshay Dashboard";
        $data['KpiText']  = "RNTCP Dashboard";
         $data['PortaliframeURL'] ='https://reports.nikshay.in/Reports/TBNotification'; // It has Iframe not available remove this or blank this variable
         $data['show_kpi_view'] = TRUE;  // It has KPIS
        $data['GoToPortalLink']  = "#";       
        $data['total_header'] = $this->Rntcp_model->get_total_header();
         //$data['table_data'] = $this->Rntcp_model->get_table_data();
        // $data['table_header'] = $this->Rntcp_model->get_table_header('ambulance_master_table');

        $data['all_kpi'] = $this->Rntcp_model->get_array_kpi();
        $data['kpi_table_data']=array();
        foreach($data['all_kpi'] as $keys=>$vals){
            $data['kpi_table_data'][$keys]=$this->Rntcp_model->get_table_kpi_data($vals);
        
        }
            
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        //$this->mybreadcrumb->add('Health Service Delivery', base_url('admin/healthservice'));
        $this->mybreadcrumb->add('RNTCP', base_url('admin/rntcp'));
        $data['page_type']='Health Service Delivery';
        loadLayout('admin/block', 'admin', $data);
		
    }


  
    

     

}
