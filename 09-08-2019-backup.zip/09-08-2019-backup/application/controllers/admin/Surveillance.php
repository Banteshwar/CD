<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Surveillance extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
		
        $this->load->model('admin/Surveillance_model');
       // $this->load->model('admin/Idsp_model');
       // $this->load->model('admin/Ntcp_model');
       
        //$this->load->model('admin/Naco_model');
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() { 
	 
      /*---------Start User Permission----------*/
        
       /* $user  =  $this->user;
        $user_row = $user->getUser();
        $url  =  json_decode($user_row['page_access'],true);
        
        $link = $_SERVER['PHP_SELF'];
        $link_array = explode('/',$link);
        $page = end($link_array);
        
        if($user_row['role']!="Admin"){
            if(!in_array($page,$url)){      
                echo "<h1>Access Denied, You don't have permission to access this page</h1>";die;
            }
        }  */     
        /*---------End User Permission----------*/
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        $this->mybreadcrumb->add('Surveillance', base_url(''));

        /*
		$data['totaldata']    = $this->Surveillance_model->get_totalMdiabities();
		
		$data['nrcptotal']    = $this->Surveillance_model->get_totalNrcpdata();
		
		$data['pclptotal']    = $this->Surveillance_model->get_totalPclpdata();
		
		$data['pczdtotal']    = $this->Surveillance_model->get_totalPczddata();
		
		$data['vhptotal']    = $this->Surveillance_model->get_totalVhpdata();

		$data['total_nppcd'] = $this->Surveillance_model->total_get_nppcd();

		$data['total_hmis'] = $this->Surveillance_model->total_get_hmis();

		$data['total_get_hmispatient'] = $this->Surveillance_model->total_get_hmispatient();

		$data['total_get_hmisImmuni'] = $this->Surveillance_model->total_get_hmisImmuni();

		$data['total_nppcf'] = $this->Surveillance_model->total_get_nppcf();

		$data['total_tobbaco'] = $this->Surveillance_model->total_get_tobbaco();

        */

        //$data['idsp'] = $this->Idsp_model->get_totalRecordIDSP();

       // $data['ntcp'] = $this->Ntcp_model->get_totalRecordNTCP();
		//$data['ddap'] = $this->Ddap_model->get_totalRecordDDAP();
       // $data['naco'] = $this->Naco_model->get_totalRecordNACO();
		
        $data['page_type']='Surveillance';
        loadLayout('admin/survilance/survilance', 'admin', $data);
    }
}
