<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Page extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
     
      $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
		 
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
       
        $this->load->model('Dashboard_model');
		$this->load->model('jointsecretary/Page_model');
		
		$this->load->library('mybreadcrumb');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        //$this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index() { 
	 
        //$this->mybreadcrumb->add('Home', '#');
        //$this->mybreadcrumb->add('Program List', base_url('secretary/page'));
        
         $data['page_type']='JointSecretary';
		 global $db;
        $user = new Users($db);
		 $user_row = $user->getUser();
		
		 //$user_row[6]='21';
		
        $data['program_list'] = $this->Page_model->get_List($user_row[6]);
		
				
	    loadLayout('jointsecretary/page/form_list', 'jointsecretary', $data);
    }
	
	
	
	
	
  
}
