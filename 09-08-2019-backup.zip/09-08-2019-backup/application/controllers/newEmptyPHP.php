<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_Controller {

    private $user;

    public function __construct() { 
        parent::__construct();
        $this->load->helper('hwc_dashboard');
		$this->load->helper('nin_dashboard');
        $this->load->model('hwc_model');
        $this->load->model('Dashboard_model');
        global $db;
        $this->db = $db;
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }
		$this->load->library('mybreadcrumb');
    }

    public function index() {

    	//redirect('dashboard/healthinfratotalfunctional');

        
/*
        if($this->input->server('REQUEST_METHOD')=="POST"){
            $post=$this->input->post();
            $this->form_validation->set_rules('financial_year','Financial Year','trim|required|xss_clean');
            if($this->form_validation->run()==FALSE){   
                $data['errors'] = validation_errors();
                $this->session->set_flashdata('msg', $data['errors']);
                redirect('Dashboard');
            }else{
                $f_year = $post['financial_year'];
            }
        }else{
            $f_year = "2018-19";    
        }
        $data['fy_list']=$this->Dashboard_model->get_all_financial_year();
        $data['state_count']=$this->Dashboard_model->get_state_count();
        $data['rgc_count']=$this->Dashboard_model->get_rgc_count();
        $data['district_count'] = $this->Dashboard_model->get_district_count();
        $data['all_services_count'] = $this->Dashboard_model->all_service_total($f_year,NULL); 
		
        $fund_allocation = $this->Dashboard_model->get_all_fund_allocation($f_year);
        $fund_utilization = $this->Dashboard_model->get_all_fund_utilization($f_year);  
        $data['fund_allocation'] = $fund_allocation[0];
        $data['fund_utilization'] = $fund_utilization[0];
        $data['ENC'] = $this->Dashboard_model->get_all_ncd_cell($f_year,5,NULL);    
        $data['ROS'] = $this->Dashboard_model->get_all_ncd_cell($f_year,6,NULL);    
        $data['OL'] = $this->Dashboard_model->get_all_ncd_cell($f_year,7,NULL); 
        $data['dh_services'] = $this->Dashboard_model->all_service_facility_wise($f_year,'DH',NULL);    
        $data['chc_services'] = $this->Dashboard_model->all_service_facility_wise($f_year,'CHC',NULL);  
        $data['phc_services'] = $this->Dashboard_model->all_service_facility_wise($f_year,'PHC',NULL);  
        $data['sc_services'] = $this->Dashboard_model->all_service_facility_wise($f_year,'SC',NULL);    
        $data['all_state_funds'] = $this->Dashboard_model->get_all_state_funds($f_year);
        $data['financial_year'] = $f_year;
        $data['title'] = "National";
        $data['state_color']=$this->Dashboard_model->get_unsaved_state_data($f_year);
        $data['max_month']= max(array_column($data['state_color'], 'month'));
        $data['month_name'] = $this->Dashboard_model->get_month_name_by_id($data['max_month']);
        $this->load->view('template/Header');
        $this->load->view('dashboard',$data);
        $this->load->view('template/footer');

*/



        

        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('dashboard/healthinfratotalfunctional'));
        
        $data['page_type']='Healthcare Infrastructure';

        $data['functionalFacilities'] = getNINFunctionalFacilities('','');

          $data['getApprovedState'] = getApprovedData(0, 0);

         loadLayout('admin/health_infra', 'admin', $data);
    }

//    public function hwc_dashboard() {
//        $user = $this->user;
//        $data['focusWiseStateDetails'] = $this->hwc_model->getFocusWiseStateDetails();
//        //echo print_r($data['focusWiseStateDetails']); die;
//        $data['user'] = $user;
//        loadLayout('admin/dashboard/hwc_dashboard', 'admin', $data);
//    }
//    public function hwc_dashboard_national() {
//        loadLayout('admin/dashboard/hwc_dashboard_national', 'admin', 0);
//    }
//    public function hwc_dashboard_state() {
//        global $CURRENT_USER_STATE;
//        $user = $this->user;
//
//        if (isset($_GET['state'])) {
//            $stateID = $_GET['state'];
//        } else {
//            $stateID = $CURRENT_USER_STATE;
//        }
//        $data['dashboardDetail'] = dashboardDetail($stateID);
//        $data['user'] = $user;
//        $data['HWC_Report'] = getHWCReport(1, $stateID);
//
//        loadLayout('admin/dashboard/hwc_dashboard_state', 'admin', $data);
//    }
//    public function hwc_dashboard_district() {
//        global $CURRENT_USER_DISTRICT;
//
//        /*if (isset($_GET['state'])) {
//            $stateID = $_GET['state'];
//        } else {
//            $stateID = null;
//        }*/
//
//        $data['HWC_Report'] = getHWCReport(2, $CURRENT_USER_DISTRICT);
//
//  

     
          

         

           
//    }

    public function dashboard() { 
    	$this->mybreadcrumb->add('Home', base_url());
    	$this->mybreadcrumb->add('Healthcare Infrastructure', base_url('dashboard/healthinfratotalfunctional'));
    	$this->mybreadcrumb->add('HWC', base_url('dashboard/dashboard'));
		$data['page_type']='Healthcare Infrastructure';
        global $CURRENT_USER_STATE;
        global $CURRENT_USER_DISTRICT;
        $_REQUEST;
        $user = $this->user;
        $user_row = $user->getUser();
        $DASHBOARD = 0;
        $state = 0;
        $district = 0;
        $ID = 0;
        $TYPE = 0;
        $data_temp = 0;

       

        if (isset($_REQUEST['state']) || (isset($_REQUEST['TYPE']) && $_REQUEST['TYPE'] == 'STATE')) {
            if (isset($_REQUEST['TYPE'])) {
                $state = intval($_REQUEST['ID']);
            } else {
                $state = intval($_REQUEST['state']);
            }
            $ID = $state;
            $DASHBOARD = 1;

            $template = array('page' => 'admin/dashboard/hwc_dashboard_state_district', 'type' => 'popup');
        }
        if (isset($_REQUEST['district']) || (isset($_REQUEST['TYPE']) && $_REQUEST['TYPE'] == 'DISTRICT')) {
            if (isset($_REQUEST['TYPE'])) {
                $district = intval($_REQUEST['ID']);
            } else {
                $district = intval($_REQUEST['district']);
            }
            $ID = $district;
            $DASHBOARD = 2;
            $template = array('page' => 'admin/dashboard/hwc_dashboard_state_district', 'type' => 'popup');
        }

        if (!isset($_REQUEST['TYPE'])) {
            if (isHavingState($user)) {
                $state = $CURRENT_USER_STATE;  // used by following selection
                $DASHBOARD = 1;
                $ID = $state;
                $template = array('page' => 'admin/dashboard/dashboard', 'type' => 'admin');
            } if (isHavingDistrict($user)) {
//getDistrictName($CURRENT_USER_STATE, $CURRENT_USER_DISTRICT);
                $district = $CURRENT_USER_DISTRICT; // used by following selection
                $ID = $district;
                $template = array('page' => 'admin/dashboard/dashboard', 'type' => 'admin');
                $DASHBOARD = 2;
            } else if ($user_row['role'] == 3 && $state == 0 && $DASHBOARD == 0) {
                $ID = 0;
                $type = 0;




                $data['focusWiseStateDetails'] = $this->hwc_model->getFocusWiseStateDetails();



                $template = array('page' => 'admin/dashboard/hwc_dashboard', 'type' => 'admin');
            }
        }

        $data['data_temp'] = $_REQUEST;
        $data['_REQUEST'] = $_REQUEST;
        $data['user'] = $user;

         



        $data['entry_status_graph_data'] = getGraphData($DASHBOARD, $ID);
        $data['HWC_Report'] = getHWCReport($DASHBOARD, $ID);
        $data['HWCGraphReport'] = getHWCGraphReport($DASHBOARD, $ID);
        $data['HWCGraphCAReport'] = getHWCGraphCAReport($DASHBOARD, $ID);
        $data['getApprovedState'] = getApprovedData($DASHBOARD, $ID);
        $data['DASHBOARD'] = $DASHBOARD;
        $data['HWC_CA_Report'] = getHWCCAReport($DASHBOARD, $ID);



        loadLayout($template['page'], $template['type'], $data);

//        loadLayout('admin/dashboard/hwc_dashboard_state_district', 'popup', $data);
    }
	
	public function dashboard_ajax(){
		die('dsfs');
		$state_code = $this->input->post('state_code');
		$financial_year = $this->input->post('financial_year');
		if($financial_year!=""){
			$f_year = $financial_year;
		}else{
			$f_year = "2018-19";	
		}
		if($state_code!=""){
			$data['district_count'] = $this->Dashboard_model->get_district_count($state_code);
			$data['fund_allocation'] = $this->Dashboard_model->get_state_fund_allocation($state_code,$f_year);
			$data['fund_utilization'] = $this->Dashboard_model->get_state_fund_utilization($state_code,$f_year);
			$data['services'] = $this->Dashboard_model->state_all_service($f_year,$state_code);
			$data['ncd_enc'] = $this->Dashboard_model->get_ncd_cell($f_year,$state_code,5);
			$data['ncd_ros'] = $this->Dashboard_model->get_ncd_cell($f_year,$state_code,6);
			$data['ncd_ol'] = $this->Dashboard_model->get_ncd_cell($f_year,$state_code,7);
			$data['dh'] = $this->Dashboard_model->facility_wise_state_service($f_year,$state_code,'DH');
			$data['chc'] = $this->Dashboard_model->facility_wise_state_service($f_year,$state_code,'CHC');
			$data['phc'] = $this->Dashboard_model->facility_wise_state_service($f_year,$state_code,'PHC');
			$data['sc'] = $this->Dashboard_model->facility_wise_state_service($f_year,$state_code,'SC');
			$state_name=$this->StateReport_model->get_state_by_code($state_code);
			$data['title']=$state_name['state_name'];
		}else{
			$data['district_count']['no_of_district'] =  0;
		}
		$json_data = json_encode($data);
		print_r($json_data) ;
		exit();
	}
	

	public function pmsma() {

		  

			$data['page_type']='Healthcare Infrastructure';
        //loadLayout('admin/pmsma', 'admin',  $data);
		loadLayout('admin/new_pmsma', 'admin',  $data);
    }
	
	public function healthinfratotalfunctional() { 


		$this->mybreadcrumb->add('Home', base_url());
 $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('dashboard/healthinfratotalfunctional'));
$this->mybreadcrumb->add('NIN Portal', base_url('dashboard/healthinfratotalfunctional'));

     ////////// show state ////////////

		 if($this->input->get('state_name'))
		 {
		 	$state_id=$this->input->get('state_name');
		 }
		 else
		 {
		 $state_id='';
		 }

          $data['searh_state_id']=$state_id;
            
         $data['state'] = $this->hwc_model->get_state(); 


         $data['state_name'] = $this->hwc_model->get_statename($state_id);
         

        ////////// end show state ////////////		
	
		
		$data['functionalStateWiseFacilities'] = getNINFunctionalStateWiseFacilities();
		
		$data['functionalFacilities'] = getNINFunctionalFacilities('',$state_id);
		$data['functionalFacilitiesStateWise'] = getNINFunctionalFacilities(TRUE);
		
		$data['totalConfirmedVerified'] = getNINTotalConfirmedVerified();
		$data['totalConfirmedVerifiedStateWise'] = getNINTotalConfirmedVerified(TRUE);
		
		$data['totalRuralUrbanVerified'] = getNINTotalRuralUrbanVerified(); 
		$data['totalRuralUrbanVerifiedStateWise'] =  getNINTotalRuralUrbanVerified(TRUE);

		$data['totalFacilitiesOperationalStatus'] = getFacilitiesOperationalStatus();  
		$data['totalFacilitiesOperationalStatusStateWise'] =  getFacilitiesOperationalStatus(TRUE);
		
		$data['page_type']='Healthcare Infrastructure';
	
	    $data['updated_page'] = date('d M  Y');

        loadLayout('admin/health_infra_total_function', 'admin', $data);	
				
       
    }

    public function kiosk() { 

       

        $this->mybreadcrumb->add('Home', base_url());
 $this->mybreadcrumb->add('Healthcare Infrastructure', base_url('dashboard/healthinfratotalfunctional'));
$this->mybreadcrumb->add('Kiosk', base_url('dashboard/kiosk'));

$data['page_type']='Healthcare Infrastructure';
    
        $data['updated_page'] = date('d M  Y');

        loadLayout('admin/kiosk', 'admin', $data);

}
	
	public function healthinfrafacilities() { 
	
	       $this->mybreadcrumb->add('Home', base_url());
$this->mybreadcrumb->add('Healthcare Infrastructure', base_url('dashboard/healthinfratotalfunctional'));
$this->mybreadcrumb->add('Clinical Establishment', base_url('dashboard/healthinfrafacilities'));


	    
			$data['page_type']='Healthcare Infrastructure';
        loadLayout('admin/health_infra_facilities', 'admin', $data);
		
		
    }
	
	public function healthinfraaiims() { 

		$this->mybreadcrumb->add('Home', base_url());
$this->mybreadcrumb->add('Healthcare Infrastructure', base_url('dashboard/healthinfratotalfunctional'));
$this->mybreadcrumb->add('PMSSY', base_url('dashboard/healthinfraaiims'));
		
		$data['page_type']='Healthcare Infrastructure';
        loadLayout('admin/health_infra_aiims', 'admin', $data);
    }
	
	public function healthinframedicalcolleges() { 
		$this->mybreadcrumb->add('Home', base_url());
$this->mybreadcrumb->add('Healthcare Infrastructure', base_url('dashboard/healthinfratotalfunctional'));
$this->mybreadcrumb->add('HMIS', base_url('dashboard/healthinframedicalcolleges'));
		$data['page_type']='Healthcare Infrastructure';;
        loadLayout('admin/health_infra_medicalcolleges', 'admin', $data);
    }
	
	public function healthinfratotalhealthhuman() { 
	
	   $this->mybreadcrumb->add('Home', base_url());
$this->mybreadcrumb->add('Health Human Resources', base_url('dashboard/healthinfratotalhealthhuman'));
         $this->mybreadcrumb->add('HMIS', base_url('dashboard/healthinfratotalhealthhuman'));

		$data['page_type']='Health Human Resources';
        loadLayout('admin/health_infra_healthhuman', 'admin', $data);
    }

    public function healthservice() { 


        $data['all_elderly_count'] = $this->Dashboard_model->all_elderly_total(); 
        $data['fetch_curr_date'] = $this->Dashboard_model->fetch_curr_date(); 
        $data['hmis_curr_date'] = $this->Dashboard_model->hmis_curr_date(); 
        $data['amrit_curr_date'] = $this->Dashboard_model->amrit_curr_date(); 
        $data['rch_curr_date'] = $this->Dashboard_model->rch_curr_date(); 
        $data['ors_curr_date'] = $this->Dashboard_model->ors_curr_date(); 
        $data['fetch_curr_date'] = $this->Dashboard_model->fetch_notto_currdate(); 



    	$this->mybreadcrumb->add('Home', base_url());
$this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));


		$data['page_type']='Health Service Delivery';
        loadLayout('admin/health_service', 'admin', $data);
    }
	
	public function healthserviceopd() { 

		$data['hmis_curr_date'] = $this->Dashboard_model->hmis_curr_date(); 

		$data['h_s_opd'] = $this->Dashboard_model->all_elderly_total(); 


		$this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));
        $this->mybreadcrumb->add('HWC', base_url('dashboard/healthserviceopd'));

		$data['page_type']='Health Service Delivery';
        loadLayout('admin/health_service_opd', 'admin', $data);
    }
	
	public function newerinitamrit() { 
		$data['amrit_curr_date'] = $this->Dashboard_model->amrit_curr_date(); 

		$this->mybreadcrumb->add('Home', base_url());
		$this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));
		$this->mybreadcrumb->add('AMRIT', base_url('dashboard/newerinitamrit'));

		$data['page_type']='Health Service Delivery';
        loadLayout('admin/newer_init_amrit', 'admin', $data);
    }

	
	
	
	public function newerinittotalvolunteers() { 

$this->mybreadcrumb->add('Home', base_url());
$this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));
$this->mybreadcrumb->add('PMSMA', base_url('dashboard/newerinittotalvolunteers'));

			$data['page_type']='Health Service Delivery';
        //loadLayout('admin/newer_init_totalvolunteers', 'admin', $data);
		
		loadLayout('admin/new_pmsma', 'admin', $data);
    }
	
	public function healthserviceeligiblecouple() { 
		$data['rch_curr_date'] = $this->Dashboard_model->rch_curr_date(); 

		$this->mybreadcrumb->add('Home', base_url());
$this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));
$this->mybreadcrumb->add('RCH Portal', base_url('dashboard/healthserviceeligiblecouple'));

		$data['page_type']='Health Service Delivery';
        loadLayout('admin/health_service_eligiblecouple', 'admin', $data);
    }
	
	public function healthservicetotalchcrating() { 
		$data['page_type']='';
        loadLayout('admin/health_service_totalchcrating', 'admin', $data);
    }
	
	public function healthserviceessentialdrugs() { 
		$data['page_type']='Health Service Delivery';
        loadLayout('admin/health_service_essentialdrugs', 'admin', $data);
    }
	
	
	
	public function healthservicecghsbeneficiaries() { 

		$this->mybreadcrumb->add('Home', base_url());
$this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));
$this->mybreadcrumb->add('CGHS', base_url('dashboard/healthservicecghsbeneficiaries'));

		$data['page_type']='Health Service Delivery';
        loadLayout('admin/health_service_cghsbeneficiaries', 'admin', $data);
    }

    public function diseasescontrol() { 

    	$this->mybreadcrumb->add('Home', base_url());
$this->mybreadcrumb->add('Diseases Control', base_url('dashboard/diseasescontrol'));

		$data['page_type']='Diseases Control';
        loadLayout('admin/diseases_control', 'admin', $data);
    }
	
	public function healthserviceoutbreaks() {

	    $this->mybreadcrumb->add('Home', base_url());
    $this->mybreadcrumb->add('Diseases Control', base_url('dashboard/diseasescontrol'));
    $this->mybreadcrumb->add('Outbreaks (IDSP)', base_url('dashboard/healthserviceoutbreaks'));

		$data['page_type']='Diseases Control';
        loadLayout('admin/health_service_outbreaks', 'admin', $data);
    }
	
	public function healthserviceannualtb() {

	    $this->mybreadcrumb->add('Home', base_url());
$this->mybreadcrumb->add('Diseases Control', base_url('dashboard/diseasescontrol'));
$this->mybreadcrumb->add('Nikshay', base_url('dashboard/healthserviceannualtb'));


		$data['page_type']='Diseases Control';
        loadLayout('admin/health_service_healthserviceannualtb', 'admin', $data);
    }
	
	 public function swachhta() { 

	 	$this->mybreadcrumb->add('Home', base_url());
$this->mybreadcrumb->add('Diseases Control', base_url('dashboard/diseasescontrol'));
$this->mybreadcrumb->add('Swachhta', base_url('dashboard/swachhta'));

	 	$data['page_type']='Diseases Control';
        loadLayout('admin/swachhta', 'admin',  $data);
    }
	
	public function newerinitonlineappointments() { 
	
        $data['ors_curr_date'] = $this->Dashboard_model->ors_curr_date(); 

        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));
        $this->mybreadcrumb->add('ORS', base_url('dashboard/newerinitonlineappointments'));

		$data['page_type']='Health Service Delivery';
        loadLayout('admin/newer_init_onlineappointments', 'admin', $data);
    }
	
	public function newerinitpledgeregistry() { 
		$data['fetch_curr_date'] = $this->Dashboard_model->fetch_notto_currdate(); 

$this->mybreadcrumb->add('Home', base_url());
$this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));
$this->mybreadcrumb->add('NOTTO', base_url('dashboard/newerinitpledgeregistry'));

		$data['page_type']='Health Service Delivery';
        loadLayout('admin/newer_init_pledgeregistry', 'admin', $data);
    }
	
	public function laqshya() { 

       //$data['laqshya_data'] = $this->Dashboard_model->get_laqshya_data(); 

		$this->mybreadcrumb->add('Home', base_url());
		$this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));
		$this->mybreadcrumb->add('LAQSHYA Portal', base_url('dashboard/laqshya'));

		$data['page_type']='Health Service Delivery';
        loadLayout('admin/laqshya', 'admin', $data);
    }

    public function elderly() { 

        $data['all_elderly_count'] = $this->Dashboard_model->all_elderly_total(); 
        $data['fetch_curr_date'] = $this->Dashboard_model->fetch_curr_date(); 
        $data['state_count'] = $this->Dashboard_model->state_count();
        $data['district_count'] = $this->Dashboard_model->district_count();
        $data['rgc_count'] = $this->Dashboard_model->rgc_count();

        //print $data['state_count']['no_of_state']; die;

        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Service Delivery', base_url('dashboard/healthservice'));
        $this->mybreadcrumb->add('Elderly', base_url('dashboard/elderly'));
		
		$data['page_type']='Health Service Delivery';
        loadLayout('admin/elderly2', 'admin', $data);
    }
	
	
    


    



    
	
	public function qualityhealthservices() { 

		$this->mybreadcrumb->add('Home', base_url());
$this->mybreadcrumb->add('Quality of Health Services', base_url('dashboard/qualityhealthservices'));


		$data['page_type']='Quality of Health Services';
        loadLayout('admin/quality_health_services', 'admin', $data);
    }
	
	public function qualityhealthpatient() { 

		$this->mybreadcrumb->add('Home', base_url());
     $this->mybreadcrumb->add('Quality of Health Services', base_url('dashboard/qualityhealthservices'));
$this->mybreadcrumb->add('Mera Aspatal', base_url('dashboard/qualityhealthpatient'));


		$data['page_type']='Quality of Health Services';
        loadLayout('admin/quality_health_patient', 'admin', $data);
    }
	
	public function qualityhealthchcrating() { 

		$this->mybreadcrumb->add('Home', base_url());
$this->mybreadcrumb->add('Quality of Health Services', base_url('dashboard/qualityhealthservices'));
$this->mybreadcrumb->add('HMIS', base_url('dashboard/qualityhealthchcrating'));

	    $data['page_type']='Quality of Health Services';
        loadLayout('admin/quality_health_chcrating', 'admin', $data);
    }

    public function drugsdiagnostics() { 

    	$this->mybreadcrumb->add('Home', base_url());
$this->mybreadcrumb->add('Drugs & Diagnostics', base_url('dashboard/drugsdiagnostics'));


		$data['page_type']='Drugs-Diagnostics';
        loadLayout('admin/drugs_diagnostics', 'admin', $data);
    }
	
	public function qualityhealthessentialdrugs() { 

		$this->mybreadcrumb->add('Home', base_url());
$this->mybreadcrumb->add('Drugs & Diagnostics', base_url('dashboard/drugsdiagnostics'));
$this->mybreadcrumb->add('eAushadhi (DVDMS)', base_url('dashboard/qualityhealthessentialdrugs'));

		$data['page_type']='Drugs-Diagnostics';
        loadLayout('admin/quality_health_essentialdrugs', 'admin', $data);
    }
	
	public function qualityhealthapplicationsapproved() { 
		$this->mybreadcrumb->add('Home', base_url());
$this->mybreadcrumb->add('Drugs & Diagnostics', base_url('dashboard/drugsdiagnostics'));
$this->mybreadcrumb->add('Sugam', base_url('dashboard/qualityhealthapplicationsapproved'));

		$data['page_type']='Drugs-Diagnostics';
        loadLayout('admin/quality_health_applicationsapproved', 'admin', $data);
    }
	

	
	public function newerinituserregisteredmissedcalls() { 

		$this->mybreadcrumb->add('Home', base_url());
$this->mybreadcrumb->add('IVR Based App', base_url('dashboard/newerinituserregisteredmissedcalls'));


		$data['page_type']='IVR Based App';
        loadLayout('admin/newer_init_userregisteredmissedcalls', 'admin', $data);
    }



    public function meraaspataal() { 

		$this->mybreadcrumb->add('Home', base_url());
$this->mybreadcrumb->add('IVR Based App', base_url('dashboard/newerinituserregisteredmissedcalls'));
$this->mybreadcrumb->add('Mera Aspataal', base_url('dashboard/meraaspataal'));

		$data['page_type']='IVR Based App';
        loadLayout('admin/meraaspataal', 'admin', $data);
    }

    public function tobacco() { 

		$this->mybreadcrumb->add('Home', base_url());
$this->mybreadcrumb->add('IVR Based App', base_url('dashboard/newerinituserregisteredmissedcalls'));
$this->mybreadcrumb->add('Tobacco & Diabetes', base_url('dashboard/tobacco'));

		$data['page_type']='IVR Based App';
        loadLayout('admin/tobacco', 'admin', $data);
    }
	
	
	
	public function newerinittotaldownloads() { 
		$data['page_type']='Mobile Apps';
        loadLayout('admin/newer_init_totaldownloads', 'admin', $data);
    }
	

	public function ihic() { 
		$this->mybreadcrumb->add('Home', base_url());
$this->mybreadcrumb->add('IHIC', base_url('dashboard/ihic'));

		$data['page_type']='IHIC';
        loadLayout('admin/ihic', 'admin', $data);
    }

	public function fvms() { 

		$this->mybreadcrumb->add('Home', base_url());
$this->mybreadcrumb->add('IHIC', base_url('dashboard/ihic'));
$this->mybreadcrumb->add('FVMS (IHIC)', base_url('dashboard/fvms'));

		$data['page_type']='IHIC';
        loadLayout('admin/fvms', 'admin', $data);
    }
	
	public function mou() { 

		$this->mybreadcrumb->add('Home', base_url());
$this->mybreadcrumb->add('IHIC', base_url('dashboard/ihic'));
$this->mybreadcrumb->add('MOU (IHIC)', base_url('dashboard/mou'));

		$data['page_type']='IHIC';
        loadLayout('admin/mou', 'admin', $data);
    }
	
	public function son() { 

		$this->mybreadcrumb->add('Home', base_url());
       $this->mybreadcrumb->add('IHIC', base_url('dashboard/ihic'));
       $this->mybreadcrumb->add('SON (IHIC)', base_url('dashboard/son'));

		$data['page_type']='IHIC';
        loadLayout('admin/son', 'admin', $data);
    }
	
	
	
	

	
	
	
	
	
	
	
	
	
	
		
	 
	
	
	
	
	 

}
