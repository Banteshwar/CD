<?php
$error = array();
$responseArray = array();
if ($user->is_logged_in()) {


    //DELETE USER
    if (isset($_GET['action']) && $_GET['action'] == 'CHANGE_PASSWORD' && isset($_POST)) {
// check permission
        if ($user->hasPermission('CHANGE_PASSWORD')) {
      
         

            if (!checkCSRF()) {
                $error[] = CSRF_ERROR;
            }

            if (trim($password) == '') {
                $error[] = 'Please enter the password.';
            }
            if (trim($passwordConfirm) == '') {
                $error[] = 'Please confirm the password.';
            }

            if ($password != $passwordConfirm) {
                $error[] = 'Passwords do not match.';
            }

            ///Password Strength Check Start
            // ==========Add by Dharam  =====================

            $pwd = $password;

            if (strlen($pwd) < 8) {
                $error[] = "Password must be at least 8 characters.";
            }

            if (strlen($pwd) > 40) {
                $error[] = "Password too long ( Maximum length – 40).";
            }


            if (!preg_match("#[0-9]+#", $pwd)) {
                $error[] = "Password must include at least one number.";
            }


            if (!preg_match("#[a-z]+#", $pwd)) {
                $error[] = "Password must include at least one letter.";
            }


            if (!preg_match("#[A-Z]+#", $pwd)) {
                $error[] = "Password must include at least one uppercase character.";
            }

            if (!preg_match("#\W+#", $pwd)) {
                $error[] = "Password must include at least one special character.";
            }
            $user_row = $user->getUser();
            if (check_password_history($pwd, $user_row['memberID'])) {
                $error[] = "Sorry! You entered an old password.";
            }

        
        if (count($error) == 0) {


                        if (!$user->password_verify($current_password, $user_row['password']) == 1) {
                            $error[] = 'Invalid Current Password.';
                        }
                
                if (count($error) == 0) {

                    $hashedpassword = $user->password_hash($password, PASSWORD_BCRYPT);

                            $password_history = $hashedpassword;

                            //update into database
                            $stmt = $db->prepare('UPDATE ' . TB_T_MEMBERS . ' SET password = :password, lastPasswordChangeDate = NOW() WHERE memberID = :memberID');
                            $stmt->execute(array(
                                ':password' => $hashedpassword,
                                ':memberID' => $user_row['memberID']
                            ));

                    //    Update History table - Add By Dharam
                    if (userHistoryExist($user_row['memberID'])) {
                                $password_history = getPasswordHistory($user_row['memberID']);
                                $old_password_array = explode('|||', $password_history);
                                $size_of_array = sizeof($old_password_array);
                                //print_r($old_password_array);


                                if ($size_of_array > 3) {
                                    $old_password_array = array_slice($old_password_array, -3);
                                    $password_history = implode('|||', $old_password_array);
                                }


                                $password_history = $password_history . '|||' . $hashedpassword;
                                $stmt = $db->prepare('UPDATE login_history SET password_history = :password WHERE memberID = :memberID');

                                $stmt->execute(array(
                                    ':password' => $password_history,
                                    ':memberID' => $user_row['memberID']
                                ));
                    } else {

                        $stmt = $db->prepare('INSERT INTO `login_history` ( `memberID`, `password_history`) VALUES (:memberID,:password)');
                                $stmt->execute(array(
                                    ':password' => $hashedpassword . '|||',
                                    ':memberID' => $user_row['memberID']
                                ));
                            }

                         //   status_message("Password Updated Successfully!");
                }
            }

            if (count($error) != 0) {
                $errors = error_format($error);
                $responseArray = array('status' => 'error', 'status_msg' => $errors, 'token' => generatetoken());
            } else {
                $responseArray = array('status' => 'success', 'status_msg' => 'Password Updated Successfully', 'return_url' => '');
            }
        } else {
            $responseArray = array('status' => 'error', 'status_msg' => 'Permission Error..! <br>You are not allowed to perform this operation.!', 'token' => generatetoken());
        }
    }



    //DELETE USER
   elseif (isset($_GET['action']) && $_GET['action'] == 'DELETE_USER' && isset($_POST['USER_ID'])) {
// check permission
    if ($user->hasPermission('DELETE_USER')) {
        if (!checkCSRF()) {
            $error[] = CSRF_ERROR;
        }
        if (isset($error) && count($error) > 0) {
            $errors = error_format($error);
            $responseArray = array('status' => 'error', 'status_msg' => $errors, 'token' => generatetoken());
        }
//
        elseif ($_POST['USER_ID'] != '1' && $_POST['USER_ID'] != $_SESSION['memberID']) {

            $stmt = $db->prepare('DELETE FROM ' . TB_T_MEMBERS . ' WHERE memberID = :memberID');
            $stmt->execute(array(':memberID' => $_POST['USER_ID']));

            status_message('User Deleted Successfuly!');
            $responseArray = array('status' => 'success', 'status_msg' => 'User Deleted Successfuly!');
            }
    } else {
        $responseArray = array('status' => 'error', 'status_msg' => 'Permission Error..! <br>You are not allowed to perform this operation.!', 'token' => generatetoken());
    }
}


//ADD USER
    elseif (isset($_GET['action']) && $_GET['action'] == 'ADD_USER') {
//if form has been submitted process it
   if ($user->hasPermission('ADD_USER')) {
            global $USER_ROLES;
            if (count($_POST) > 0) {
        if (1) {
//very basic validation
            if (!checkCSRF()) {
                $error[] = CSRF_ERROR;
            }
            $username = trim(filter_var($username, FILTER_SANITIZE_STRING));

                if ($username == '') {
                $error[] = 'Please enter the username.';
            } else if (strlen($username) > 40) {
                $error[] = 'Username should not be more than 40 characters long.';
            } else if ($user->isUsernameExist($username)) {
                //$memberID
                $error[] = 'Username already exits.';
            }

            if (trim($password) == '') {
                $error[] = 'Please enter the password.';
            } else if (strlen($password) > 40) {
                $error[] = 'Password should not be more than 40 characters long.';
            }

            if (trim($passwordConfirm) == '') {
                $error[] = 'Please confirm the password.';
            }

            if ($password != $passwordConfirm) {
                $error[] = 'Passwords do not match.';
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $error[] = 'Invalid email format.';
            } else if ($user->isUserEmailExist($email)) {
                $error[] = 'Email already exits.';
            }

// check if State and District of User
            if (isset($state) && $state != '0') {
                if (!isValidStateId($state)) {
                    $error[] = 'Invalid selected State.';
                }
            }

            if (isset($district) && isset($state) && $district != '0') {
                if (!isValidDistrictId($state, $district)) {
                    $error[] = 'Invalid selected District.';
                }
            }

            if (isset($status) && $status != '') {
                $status = intVal($status);
            } else {
                $status = 0;
            }

            if (!isset($role) || $role == 3 || !array_key_exists($role, $USER_ROLES)) {
                $error[] = 'Invalid Role Assigned!';
            }
//update all role except Super Admin (3)

            if (count($error) == 0) {
                $hashedpassword = $user->password_hash($password, PASSWORD_BCRYPT);
                        try {

//insert into database
                    $stmt = $db->prepare('INSERT INTO ' . TB_T_MEMBERS . ' (username,password,State_ID,District_ID,email,status,role,createOn, updatedOn) VALUES (:username, :password, :State_ID, :District_ID, :email, :status, :role, NOW(), NOW())');

                    $stmt->execute(array(
                        ':username' => $username,
                        ':password' => $hashedpassword,
                        ':State_ID' => intVal($state),
                        ':District_ID' => intVal($district),
                        ':email' => $email,
                        ':status' => $status,
                        ':role' => $role
                    ));

//redirect to index page
                    status_message('User add  Successfully!');
                    $responseArray = array('status' => 'success', 'status_msg' => 'User add  Successfully!', 'return_url' => '');
                        } catch (PDOException $e) {
                    echo $e->getMessage();
                }
            }
        } else {
            $error[] = "Duplicate Submission!";
        }
    }

    if (count($error) > 0) {
        $errors = error_format($error);
        $responseArray = array('status' => 'error', 'status_msg' => $errors, 'token' => generatetoken());
    }
    } else {
        $responseArray = array('status' => 'error', 'status_msg' => 'Permission Error..! <br>You are not allowed to perform this operation.', 'token' => generatetoken());
    }
}
//EDIT USER
elseif (isset($_GET['action']) && $_GET['action'] == 'EDIT_USER') {
//if form has been submitted process it
        global $USER_ROLES;
        if ($user->hasPermission('EDIT_USER')) {
            if (count($_POST) > 0) {

//        require_once '../includes/sqAES.php';
//        require_once '../includes/JCryption.php';
//if (isset($_SESSION[JCryption::SESSION_KEY])) {
        if (1) {

//            $postBefore = print_r($_POST, true);
//
//            JCryption::decrypt();
//
//            unset($_SESSION[JCryption::SESSION_KEY]); // unset session key to restrict resubmit
//collect form data
            extract($_POST);

            if (!checkCSRF()) {
                $error[] = CSRF_ERROR;
            }


//very basic validation
            $username = trim(filter_var($username, FILTER_SANITIZE_STRING));
            if ($username == '') {
                $error['username'] = 'Please enter the username.';
            } else if (strlen($username) > 40) {
                $error[] = 'Username should not be more than 40 characters long.';
            } else if ($user->isUsernameExist($username, $memberID)) {
                $error['username'] = 'Username already exits.';
            }

            if (strlen($password) > 0) {
                if (trim($password) == '') {
                    $error[] = 'Please enter the password.';
                } else if (strlen($password) > 40) {
                    $error[] = 'Password should not be more than 40 characters long.';
                }

                if (trim($passwordConfirm) == '') {
                    $error[] = 'Please confirm the password.';
                }

                if ($password != $passwordConfirm) {
                    $error[] = 'Passwords do not match.';
                }
            }

//$email = trim(filter_var($email, FILTER_SANITIZE_EMAIL));
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $error[] = 'Invalid email format.';
            } else if ($user->isUserEmailExist($email, $memberID)) {
                $error[] = 'Email already exits.';
            }

// check if State and District of User
            if (isset($state) && $state != '0') {
                if (!isValidStateId($state)) {
                    $error[] = 'Invalid selected State.';
                }
            }

            if (isset($district) && isset($state) && $district != '0') {
                if (!isValidDistrictId($state, $district)) {
                    $error[] = 'Invalid selected District.';
                }
            }
            if (isset($status) && $status != '') {
                $status = intVal($status);
            } else {
                $status = 0;
            }


            if (count($error) == 0) {

                try {

                    $query = 'UPDATE ' . TB_T_MEMBERS . ' SET username = :username, State_ID = :State_ID, District_ID = :District_ID, email = :email , updatedOn = NOW() ';
                    $data = array(
                        ':username' => $username,
                        ':email' => $email,
                        ':State_ID' => intVal($state),
                        ':District_ID' => intVal($district),
                        ':memberID' => $memberID
                    );
//update all role except Super Admin (3)
                    if (isset($role) && $role != 3 && array_key_exists($role, $USER_ROLES) && $user->get_user_role($memberID) != 3) {
                        $query .= ', role = :role , status = :status ';
                        $data[':role'] = $role;
                        $data[':status'] = $status;
                    }

                    if (isset($password) && strlen($password) > 0) {
                        $query .= ', password = :password';
                        $hashedpassword = $user->password_hash($password, PASSWORD_BCRYPT);
                        $data[':password'] = $hashedpassword;
                    }

                    $query .= ' WHERE memberID = :memberID';

//update into database
                    $stmt = $db->prepare($query);
                    $stmt->execute($data);
                    status_message('User updated  Successfully!');
                    $responseArray = array('status' => 'success', 'status_msg' => 'User updated  Successfully!', 'return_url' => '');


//status_message("User updated  Successfully!");
//redirect to index page
                } catch (PDOException $e) {
                    $error[] = $e->getMessage();
                }
            }
        } else {
            $error[] = "Duplicate Submission!";
        }
    }
//check for any errors
    if (isset($error) && count($error) > 0) {
        $errors = error_format($error);
        $responseArray = array('status' => 'error', 'status_msg' => $errors, 'token' => generatetoken());
    }
    } else {
        $responseArray = array('status' => 'error', 'status_msg' => 'Permission Error..! <br>You are not allowed to perform this operation.', 'token' => generatetoken());
    }
}
//NIN_MAKE_CV_ACTION
elseif (isset($_GET['action']) && $_GET['action'] == 'NIN_MAKE_CV_ACTION') {
    if (isset($_GET['event'])) {

        $rowFacility = getRowByNIN($nin);

        if (!checkCSRF()) {
            $error[] = CSRF_ERROR;
        }
        switch ($_GET['event']) {
            case 'confirmNin':
                if ($user->hasPermission('NIN_MAKE_CONFIRM') && $rowFacility['confirmed_flag'] != 1 && $rowFacility['verified_flag'] != 1) {
                    $updateField = ' confirmed_flag = 1 , confirmed_by_user = ' . $_SESSION['memberID'] . ', confirmed_on = NOW() ';
                } else {
                    $error[] = 'Permission Error..! <br>You are not allowed to perform this operation.';
                }
                break;
            case 'unConfirmNin':
                if ($user->hasPermission('NIN_MAKE_NOT_CONFIRM') && $rowFacility['confirmed_flag'] == 1 && $rowFacility['verified_flag'] != 1) {
                    $updateField = ' confirmed_flag = 0, confirmed_by_user = ' . $_SESSION['memberID'] . ', confirmed_on = NOW() ';
                } else {
                    global $CURRENT_USER_ROLE;
                    $error[] = 'Permission Error..! <br>You are not allowed to perform this operation.' . $CURRENT_USER_ROLE;
                }
                break;
            case 'verifyNin':
                if ($user->hasPermission('NIN_MAKE_VERIFY') && $rowFacility['verified_flag'] != 1 && $rowFacility['confirmed_flag'] == 1) {
                    $updateField = ' verified_flag = 1 , verified_by_user = ' . $_SESSION['memberID'] . ', verified_on = NOW()';
                } else {
                    $error[] = 'Permission Error..! <br>You are not allowed to perform this operation.';
                }
                break;
        }
    }
    if (count($error) > 0) {
        $errors = error_format($error);
        $responseArray = array('status' => 'error', 'status_msg' => $errors, 'token' => generatetoken());
    } elseif (isset($updateField)) {
        $query = " update " . TB_HMIS_HEALTH_FACILITIES . "
                         set " . $updateField . "
                         where  NIN_2_HFI  =  " . $nin . "
                         limit 1";
        $stmt = $db->prepare($query);
        $stmt->execute();
        status_message('Record Updated Successfully!');
        $responseArray = array('status' => 'success', 'status_msg' => 'Record Updated Successfully!', 'return_url' => base_url('facilities/facilityView') . '?nin=' . $nin);
    } else {
        $responseArray = array('status' => 'error', 'status_msg' => 'Undefind Error',);
    }
}
//
else {
    $responseArray = array('status' => 'error', 'status_msg' => 'Invalid request. ');
}

//$responseArray = array('status' => 'success', 'status_msg' => 'Form save Successfully ' . $array);
//$responseArray = array('status' => 'error', 'status_msg' => 'Form save Successfully ');
   } else {
    $responseArray = array('status' => 'error', 'status_msg' => 'Invalid request. ');
}

if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
    $encoded = json_encode($responseArray);
    header('Content-Type: application/json');
    echo $encoded;
} else {
    echo json_encode($responseArray);
}
