<?php
   global $USER_ROLES;



if (isset($_GET['action']) && $_GET['action'] == 'DELETE_USER') {
    ?>

    <div id="DELETE_USER_RESULT">
        <span class="DELETE_USER"></span>
            <form id="DELETE_USER"   action="<?= base_url('ajax/eventProcess') ?>?action=DELETE_USER" role="form">
                <?php echo addCsrfTocken(); ?>
            <input type="hidden" name="USER_ID" value="<?= $data['USER_ID'] ?>">
            <?php
            $msg = "Do You Want to Delete User Account.";
            ?>
            <div class="box no-shadow no-border">
                <div class="box-body no-padding">
                    <h3 class="text-red text-center"> <span class="glyphicon glyphicon-trash"></span> <?= $msg ?></h3>
                </div>    

                <div class="box-footer no-border no-padding">
                    <button type="button"  class="btn btn-default pull-right" data-dismiss="modal">No</button>
                    <button type="submit" class="btn btn-danger marginright pull-right">Yes</button>
                </div> 
            </div>


        </form>
        <?php getFormHandler('DELETE_USER') ?>

        <?php
    }
    //=====================
    elseif (isset($_GET['action']) && $_GET['action'] == 'EDIT_USER') {
    require_once(APPPATH . "views/admin/user/m_user_edit.php");
}
    //=====================
    elseif (isset($_GET['action']) && $_GET['action'] == 'ADD_USER') {

 require_once(APPPATH . "views/admin/user/m_user_add.php");

}
//    ==================NIN_MAKE CV_ACTION
    elseif (isset($_GET['action']) && ( $_GET['action'] == 'NIN_MAKE_CONFIRM' || $_GET['action'] == 'NIN_MAKE_NOT_CONFIRM' || $_GET['action'] == 'NIN_MAKE_VERIFY')) {
        $evnt = 0;
        switch ($_GET['action']) {
            case 'NIN_MAKE_CONFIRM':
                //  if ($user->hasPermission('NIN_MAKE_CONFIRM')) {
                $msg = ' Do you want to make confirm.';
                $evnt = 'confirmNin';
                //   }
                break;
            case 'NIN_MAKE_NOT_CONFIRM':
                //  if ($user->hasPermission('NIN_MAKE_NOT_CONFIRM')) {
                $msg = ' Do you want to make not confirm.';
                $evnt = 'unConfirmNin';
                //  }
                break;
            case 'NIN_MAKE_VERIFY':
                // if ($user->hasPermission('NIN_MAKE_VERIFY')) {
                $msg = 'Do you want to make verify';
                $evnt = 'verifyNin';
                // }
                break;
            default :
                $msg = 'Undifind Request.';
                $evnt = 'Undifind';
                break;
        }
        ?>
        <div id="NIN_MAKE_CV_ACTION_RESULT">
            <span class="NIN_MAKE_CV_ACTION"></span>
                <form id="NIN_MAKE_CV_ACTION" action="<?= base_url('ajax/eventProcess') ?>?action=NIN_MAKE_CV_ACTION&event=<?php echo $evnt ?>" role="form">
                    <?php echo addCsrfTocken(); ?>
                <input type="hidden" name="nin" value="<?= $data['NIN'] ?>">

                <div class="box no-border no-shadow">
                    <div class="box-header text-red no-padding"><h3> <i class="fa fa-fw fa-warning"></i> Alert !</h3></div>
                    <div class="box-body no-padding">
                        <h4 class="text-red"><?php echo $msg ?> </h4>
                            <button type="submit" class="btn btn-danger marginright marginleft col-lg-2">Yes</button>
                            <button type="button" class="btn btn-default col-lg-2 pull-right" data-dismiss="modal">No</button>

                        </div>
                    </div>

            </form>


        </div>
        <?php getFormHandler('NIN_MAKE_CV_ACTION'); ?>

        <?php
    }
//    ===================
    elseif (isset($_GET['action']) && $_GET['action'] == 'CHANGE_PASSWORD') {
        ?>
            <div id="CHANGE_PASSWORD_RESULT" class="row">
                <form id="CHANGE_PASSWORD" action="<?= base_url('ajax/eventProcess') ?>?action=CHANGE_PASSWORD&event=<?php echo 1 ?>" role="form">
                        <?php echo addCsrfTocken(); ?>
                        <div class="box">
                            <div class="box-body">
                                    <span class="CHANGE_PASSWORD"></span>

                                    <div class="row">
                                <div class="col-md-4"></div>
                                <div class="form-group col-md-4">
                                    <label>Current Password</label>
                                    <input type="password" class="form-control" id="" name="current_password" placeholder="Enter Current Password">
                                </div>  
                                <div class="col-md-4"></div>
                            </div>
                            <div class="row">
                                <div class="col-md-4"></div>
                                <div class="form-group col-md-4">
                                    <label>New Password</label>
                                    <input type="password" class="form-control"  name="password" placeholder="Enter New Password">
                                </div>  
                                <div class="col-md-4"></div>
                            </div>
                            <div class="row">
                                <div class="col-md-4"></div>
                                <div class="form-group col-md-4">
                                    <label>Confirm Password</label>
                                    <input type="password" class="form-control"  name="passwordConfirm" placeholder="Enter Confirm Password">
                                </div>  
                                <div class="col-md-4"></div>
                            </div>



                        </div>
                <div class="box-footer">
                    <div class="row">
                        <div class="col-md-4"></div>
                        <div class="col-md-4">
                                <button type="submit"  class="btn btn-primary pull-right">Update New Password</button>
                            </div>
                        <div class="col-md-4"></div>
                    </div>
                </div>
                </div>

                                    </form>
                                    <!--    End here Box-->
        </div>
        <?php getFormHandler('CHANGE_PASSWORD'); ?>
        <?php
    }

       