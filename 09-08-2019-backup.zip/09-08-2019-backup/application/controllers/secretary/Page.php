<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Page extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
     
      $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
       
        $this->load->model('Dashboard_model');
		$this->load->model('secretary/Page_model');
		
		$this->load->library('mybreadcrumb');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        //$this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index() { 
	 
        //$this->mybreadcrumb->add('Home', '#');
        //$this->mybreadcrumb->add('Program List', base_url('secretary/page'));
        
        $data['page_type']='Secretary';
		
        $data['row'] = $this->Page_model->get_List();
				       
        loadLayout('secretary/page/form_list', 'secretary', $data);
    }
	
	 public function apistatus() { 
	 
        //$this->mybreadcrumb->add('Home', '#');
        //$this->mybreadcrumb->add('Program List', base_url('secretary/page'));
        
        $data['page_type']='Secretary';
		
        $data['row'] = $this->Page_model->get_List();
				       
        loadLayout('secretary/page/api_list', 'secretary', $data);
    }
	
	 public function dataentrystatus() { 
	 
        //$this->mybreadcrumb->add('Home', '#');
        //$this->mybreadcrumb->add('Program List', base_url('secretary/page'));
        
        $data['page_type']='Secretary';
		
        $data['row'] = $this->Page_model->get_List();
				       
        loadLayout('secretary/page/dataentry_list', 'secretary', $data);
    }
	
	
	
  
}
