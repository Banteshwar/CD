<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Pagea extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
     
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
       
        $this->load->model('Dashboard_model');
		$this->load->model('programmanager/Ambulance_model');
		
		 $this->load->model('hwc_model');
        $this->load->model('Report_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index() { 
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Infrastructure', base_url('ambulance/index'));
        
        $data['page_type']='Ambulance';
        $data['row'] = $this->Ambulance_model->get_Ambulances();
				       
        loadLayout('programmanager/ambulance/form_list', 'program_manager', $data);
    }
	
	public function add_form() { 
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Health Infrastructure', base_url('ambulance/index'));
		
		$data['state']=$this->hwc_model->get_state();
        
        $data['page_type']='Ambulance';
      
       
        loadLayout('programmanager/ambulance/form_add', 'program_manager', $data);
    }
	
	public function form_save()
	{ 
       if (isset($_POST['submit']))
		  {
			     
          $this->form_validation->set_rules('state_name', 'State Name', 'required');
		  $this->form_validation->set_rules('e_quarter', 'Quarter', 'required');
		  $this->form_validation->set_rules('e_year', 'Year', 'required');
		  $this->form_validation->set_rules('ALS_ambulances_operational', 'ALS Ambulances operational', 'required');
		  $this->form_validation->set_rules('ALS_ambulances_required', 'ALS ambulances required', 'required');
		  $this->form_validation->set_rules('BLS_ambulances_operational', 'BLS ambulances operational', 'required');
		  $this->form_validation->set_rules('BLS_ambulances_required', 'BLS ambulances required', 'required');
		  
		  $this->form_validation->set_rules('ALS_average_response_time', 'ALS average response time', 'required');
		  $this->form_validation->set_rules('BLS_average_response_time', 'BLS average response time', 'required');
			 
          if ($this->form_validation->run() == FALSE)
                {
                	 	//$data['state']=$this->hwc_model->get_state();
                	 	redirect('ambulance/add_form');	
                       // $this->load->view('programmanager/nvhcp/nvhcp_form_add',$data);
                }
                else
                {

           $data = array
				   (	 				
					
					'state_id'=> $this->input->post('state_name'),
					
					'e_year'=> $this->input->post('e_year'),
					'e_quarter'=> $this->input->post('e_quarter'),
					'ALS_ambulances_operational'=>$this->input->post('ALS_ambulances_operational'),
					'ALS_ambulances_required'=>$this->input->post('ALS_ambulances_required'),
					'BLS_ambulances_operational'=>$this->input->post('BLS_ambulances_operational'),
					'BLS_ambulances_required'=>$this->input->post('BLS_ambulances_required'),
					'ALS_average_response_time'=>$this->input->post('ALS_average_response_time'),
					'BLS_average_response_time'=>$this->input->post('BLS_average_response_time'),
					
					'updated_by'=>  (isset($_SESSION['memberID']))
													
			  	);
                
                /////// chk availability /////////
                 
                 $result = $this->Ambulance_model->chkAmbulances($this->input->post('state_name'),$this->input->post('e_year'),$this->input->post('e_quarter'));
                  
				 
                ///////////// end check availability ///////////
                
                if($result>0)
                {
					
					
                 $this->session->set_flashdata("already_added","Record already added.");
                 
					
				  redirect('ambulance/add_form');					
						
                }
                else
                {
				$this->Ambulance_model->insertAmbulances($data);

				$this->session->set_flashdata("success","Data has been submitted successfully.");
        
			    }
				
				//$data['states']= $this->Common_model->getState();
                      //  $this->load->view('demographic-details',$data);
               redirect('ambulance/index');     
		  
		  }

		  }
	}
	
	public function edit_form($id)
	{
	   $data['state']=$this->hwc_model->get_state();
       $data['value'] = $this->Ambulance_model->getAmbulance_byId($id);
	   
	  // echo print_r($data['value']); die;
	   
	     $data['page_type']='Ambulance';

	    loadLayout('programmanager/ambulance/form_edit', 'program_manager', $data);

	}
	
	public function form_update($id)
	{      
      if (isset($_POST['update']))
		  {
		  	 $data = array
				   (	
				   
				   'state_id'=> $this->input->post('state_name'),
					'e_year'=> $this->input->post('e_year'),
					'e_quarter'=> $this->input->post('e_quarter'),
					'ALS_ambulances_operational'=>$this->input->post('ALS_ambulances_operational'),
					'ALS_ambulances_required'=>$this->input->post('ALS_ambulances_required'),
					'BLS_ambulances_operational'=>$this->input->post('BLS_ambulances_operational'),
					'BLS_ambulances_required'=>$this->input->post('BLS_ambulances_required'),
					'ALS_average_response_time'=>$this->input->post('ALS_average_response_time'),
					'BLS_average_response_time'=>$this->input->post('BLS_average_response_time'),
					'updated_date'=> date("Y-m-d H:i:s"),
					
					'updated_by'=>  (isset($_SESSION['memberID']))

                    
													
			  	);
                
      

		$result = $this->Ambulance_model->updateAmbulance_byId($id,$data);
	

        if($result){
        $this->session->set_flashdata('success','Record Updated Successfully');
        }else{
        $this->session->set_flashdata('error','Something went wrong. Please try again later.');
			
	     }
         redirect(base_url('ambulance/edit_form/'. $id));

		  }
	}
	

public function delete($id)
     {
       $this->db->delete('ambulance_master_table', array('id' => $id));

       echo $this->session->set_flashdata('success','Record Deleted Successfully');
       redirect(base_url('ambulance/index'));
     }
  
}
