<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends MY_Controller {
    private $user;

    public function __construct() {

        parent::__construct();
       
       
      
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
       
       
       
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()) {
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->driver('cache');

    }

    public function index() { 
	 
        $this->mybreadcrumb->add('Home', base_url());
        $this->mybreadcrumb->add('Dashboard', base_url('minister/home'));
      

        $data['page_type']='Minister Dashboard';
		
        loadLayout('secretarythird/home/index', 'admin', $data);
    }


    
     

}
