<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Jsview extends MY_Controller {
    private $user;

    public function __construct() {
		
        parent::__construct();
        $this->load->helper('sync_master_helper');
        $this->load->helper('hwc_dashboard');
        $this->load->helper('nin_dashboard');
        $this->load->helper('commondata_helper');
        $this->load->helper('common_helper');
        $this->load->helper('encryptor_helper');
        $this->load->helper('dashboard');
		
      // $this->load->model('admin/Humanresource_model');
              
        $this->user = new Users();
        if (!$this->user->is_logged_in()){
            redirect('home/login', 'refresh');
        }

        $this->load->library('mybreadcrumb');
        $this->load->library('smslib');
        $this->load->driver('cache');

    }

    public function index() { 
	       
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        //$this->mybreadcrumb->add('', base_url('admin/Jsview'));
        $this->mybreadcrumb->add('JS View', base_url('admin/Jsview'));
        $data['page_type']='secretarythird';
        loadLayout('secretarythird/jsview/jsview', 'admin', $data);
        //loadLayout('admin/nuhm/nuhm', 'admin', $data);
		
    }

     public function jslaview() { 
	       
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        //$this->mybreadcrumb->add('', base_url('admin/jslaview'));
        $this->mybreadcrumb->add('JS View', base_url('admin/jslaview'));
        $data['page_type']='secretarythird';
        loadLayout('secretarythird/jsview/jslaview', 'admin', $data);
        //loadLayout('admin/nuhm/nuhm', 'admin', $data);
    }
    
    public function jsmkbview() { 
	       
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        //$this->mybreadcrumb->add('', base_url('admin/jsmkbview'));
        $this->mybreadcrumb->add('JS View', base_url('admin/jsmkbview'));
        $data['page_type']='secretarythird';
        loadLayout('secretarythird/jsview/jsmkbview', 'admin', $data);
        //loadLayout('admin/nuhm/nuhm', 'admin', $data);
    }
    
     public function jsasview() { 
	       
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
       // $this->mybreadcrumb->add('', base_url('admin/jsasview'));
        $this->mybreadcrumb->add('JS View', base_url('admin/jsasview'));
        $data['page_type']='secretarythird';
        loadLayout('secretarythird/jsview/jsasview', 'admin', $data);
        //loadLayout('admin/nuhm/nuhm', 'admin', $data);
    }
    public function jsnsview() { 
	       
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        //$this->mybreadcrumb->add('', base_url('admin/jsnsview'));
        $this->mybreadcrumb->add('JS View', base_url('admin/jsnsview'));
        $data['page_type']='secretarythird';
        loadLayout('secretarythird/jsview/jsnsview', 'admin', $data);
        //loadLayout('admin/nuhm/nuhm', 'admin', $data);
    }
    public function jsppview() { 
	       
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        //$this->mybreadcrumb->add('', base_url('admin/jsppview'));
        $this->mybreadcrumb->add('JS View', base_url('admin/jsppview'));
        $data['page_type']='secretarythird';
        loadLayout('secretarythird/jsview/jsppview', 'admin', $data);
        //loadLayout('admin/nuhm/nuhm', 'admin', $data);
    }
    public function jspsview() { 
	       
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        //$this->mybreadcrumb->add('', base_url('admin/jspsview'));
        $this->mybreadcrumb->add('JS View', base_url('admin/jspsview'));
        $data['page_type']='secretarythird';
        loadLayout('secretarythird/jsview/jspsview', 'admin', $data);
        //loadLayout('admin/nuhm/nuhm', 'admin', $data);
    }
    public function jsspview() { 
	       
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        //$this->mybreadcrumb->add('', base_url('admin/jsspview'));
        $this->mybreadcrumb->add('JS View', base_url('admin/jsspview'));
        $data['page_type']='secretarythird';
        loadLayout('secretarythird/jsview/jsspview', 'admin', $data);
        //loadLayout('admin/nuhm/nuhm', 'admin', $data);
    }
    public function jsskview() { 
	       
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        //$this->mybreadcrumb->add('', base_url('admin/jsskview'));
        $this->mybreadcrumb->add('JS View', base_url('admin/jsskview'));
        $data['page_type']='secretarythird';
        loadLayout('secretarythird/jsview/jsskview', 'admin', $data);
        //loadLayout('admin/nuhm/nuhm', 'admin', $data);
    }
    public function jsvsview() { 
	       
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        //$this->mybreadcrumb->add('', base_url('admin/jsvsview'));
        $this->mybreadcrumb->add('JS View', base_url('admin/jsvsview'));
        $data['page_type']='secretarythird';
        loadLayout('secretarythird/jsview/jsvsview', 'admin', $data);
        //loadLayout('admin/nuhm/nuhm', 'admin', $data);
    }
    public function jsssview() { 
	       
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        //$this->mybreadcrumb->add('', base_url('admin/jsssview'));
        $this->mybreadcrumb->add('JS View', base_url('admin/jsssview'));
        $data['page_type']='secretarythird';
        loadLayout('secretarythird/jsview/jsssview', 'admin', $data);
        //loadLayout('admin/nuhm/nuhm', 'admin', $data);
    }
    public function jsvgview() { 
	       
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
        //$this->mybreadcrumb->add('', base_url('admin/jsvgview'));
        $this->mybreadcrumb->add('JS View', base_url('admin/jsvgview'));
        $data['page_type']='secretarythird';
        loadLayout('secretarythird/jsview/jsvgview', 'admin', $data);
        //loadLayout('admin/nuhm/nuhm', 'admin', $data);
    }
    public function jsrsview() { 
	       
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
       // $this->mybreadcrumb->add('', base_url('admin/jsrsview'));
        $this->mybreadcrumb->add('JS View', base_url('admin/jsrsview'));
        $data['page_type']='secretarythird';
        loadLayout('secretarythird/jsview/jsrsview', 'admin', $data);
        //loadLayout('admin/nuhm/nuhm', 'admin', $data);
    }
     
    public function ddgdkview() { 
	       
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
       // $this->mybreadcrumb->add('', base_url('admin/ddgdkview'));
        $this->mybreadcrumb->add('JS View', base_url('admin/ddgdkview'));
        $data['page_type']='secretarythird';
        loadLayout('secretarythird/jsview/ddgdkview', 'admin', $data);
        //loadLayout('admin/nuhm/nuhm', 'admin', $data);
    }
    public function ccabdview() { 
	       
        $this->mybreadcrumb->add('Home', base_url('admin/home'));
       // $this->mybreadcrumb->add('', base_url('admin/ccabdview'));
        $this->mybreadcrumb->add('JS View', base_url('admin/ccabdview'));
        $data['page_type']='secretarythird';
        loadLayout('secretarythird/jsview/ccabdview', 'admin', $data);
        //loadLayout('admin/nuhm/nuhm', 'admin', $data);
    }
     

     

}
