<?php

defined('BASEPATH') OR exit('No direct script access allowed');
 

class MY_Controller extends CI_Controller {

    public function __construct() {
    parent::__construct();
//        global $db;
        //$user = new Users($db);
//        require_once APPPATH . 'third_party/jcryption/sqAES.php';
//        require_once APPPATH . 'third_party/jcryption/JCryption.php';
//        $this->formFunction();
       // my_session_start();
    }

  
}
