<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

Class MY_Model extends CI_Model {

    public function __construct() {
        global $db;
        parent::__construct();
        $DBHOST = '10.48.6.3';
        $DBNAME = 'central_dashboard';
        $DBUSER = 'root';
        $DBPASS = 'Bh@n3eswar';



        $db = new PDO("mysql:host=" . $DBHOST . ";port=3306;dbname=" . $DBNAME, $DBUSER, $DBPASS);

        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

}
