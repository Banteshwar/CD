<section> 
    <div class="breadcrumb_content">
        <div class="breadcrumb_text"><?php echo $this->mybreadcrumb->render(); ?></div>
      
        <div class="clearfix"></div>
    </div>
    <div class="right_col bg_fff" role="main">
        <div class="top_header_portal ">
            <h2>Family Planning<span>Dashboard</span></h2>
        </div>
       
            <div class="col-md-12 col-sm-12 col-xs-12">
               
                <div class="x_panel">
					<div class="x_content">

                <form action="<?php echo base_url('Childhealth/update_childhealth/'.$value[0]->id); ?>" method="POST">

                         <?php if (($this->session->flashdata('success'))) { ?>
                            <div class="alert alert-success alert-dismissible" role="alert">
                                <button type="button" class="close" data-dismiss="alert">&times;</button>
                                <div class="alert-icon">
                                    <i class="fa fa-check"></i>
                                </div>
                                <div class="alert-message">
                                    <span><strong>Success!</strong> <?php echo $this->session->flashdata('success'); ?></span>
                                </div>
                            </div>
                        <?php } ?>
                      
                        <?php if (validation_errors()) {
                            ?>
                            <div class="alert alert-danger alert-dismissible" role="alert">
                                <button type="button" class="close" data-dismiss="alert">&times;</button>
                                <div class="alert-icon">
                                    <i class="fa fa-times"></i>
                                </div>
                                <div class="alert-message">
                                    <span><strong>Error!</strong>  Required Field is Missing</span>
                                </div>
                            </div>
                        <?php }
                        ?>                    

                                      <?php                                                   
                                       $year = getFinancialYear();                          
                                    ?>

                                    <div class="form-group row">

                                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Financial Year <font color=red>*</font></label> 
                                        <div class="col-md-4 col-sm-4 col-xs-12">
                                            <select name="year" id="year"  class="form-control" value="<?php echo set_value('year'); ?>" required="" >

                                            <option value="">--Select Year--</option>
                                            <?php
                                            foreach ($year as $yearid => $yearname) 
                                            {
                                                $selected = "";
                                                if ($value[0]->year == $yearid) 
                                                {
                                                    $selected = "selected";
                                                }
                                            ?>
                                            
                                            <option value="<?php echo $yearid;?>" <?php echo $selected; ?> ><?php echo $yearname;?></option>
                                            
                                            <?php } ?>      
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <?php                                            
                                        $quarter = getQuarter();                            
                                    ?>
                            

                             <div class="form-group row">
                               
                                   <label class="control-label col-md-3 col-sm-3 col-xs-12">Quarter <font color=red>*</font></label> 
                                        <div class="col-sm-4">
                                    <select name="Quarter" id="quarter"  class="form-control" value="<?php echo set_value('quarter'); ?>" required>

                                        <option value="">--Select Quarter--</option>
                                        <?php foreach ($quarter as $quarterid => $quartername) 
                                        {
                                            $selected = "";
                                            if ($value[0]->Quarter == $quarterid) 
                                            {
                                                $selected = "selected";
                                            } ?>
                                        <option value="<?php echo $quarterid;?>" <?php echo $selected; ?> ><?php echo $quartername;?></option>   
                                        <?php } ?>                                  
                                    </select>
                                </div>
                            </div>
                                  
                                    <div class="form-group row">
                                        <label class="control-label col-md-3 col-sm-3 col-xs-12">National Deworming Day Coverage (NDD) as per round<font color=red>*</font></label> 
                                        <div class="col-sm-4">
                                            <input name="ndd" id="ndd"  type="number" class="form-control" value="<?php echo $value[0]->ndd; ?>" placeholder="Integer Value" required="">
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Intensified Diarrhoea Control Fortnight Coverage (IDCF) as per round<font color=red>*</font></label> 
                                        <div class="col-sm-4">
                                            <input name="idcf" id="idcf"  type="number" class="form-control" value="<?php echo $value[0]->idcf; ?>" placeholder="Integer Value" required="">
                                        </div>
                                    </div>

                                     <div class="form-group row">
                                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Number of Children Screened by MHT under RBSK Program<font color=red>*</font></label> 
                                        <div class="col-sm-4">
                                            <input name="no_of_children_screened" id="no_of_children_screened"  type="number" class="form-control" value="<?php echo $value[0]->no_of_children_screened; ?>" placeholder="Integer Value" required="">
                                        </div>
                                    </div>
                            

                                    <div class="form-group row">
                                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Number of Children Received Secondary/ tertiary treatment under RBSK<font color=red>*</font></label> 
                                        <div class="col-sm-4">
                                            <input name="no_of_children_received" id="no_of_children_received"  type="number" class="form-control" value="<?php echo $value[0]->no_of_children_received; ?>" placeholder="Integer Value" required="">
                                        </div>
                                    </div>


                                    <div class="form-group row">
                                        <label class="control-label col-md-3 col-sm-3 col-xs-12">No. of newborns received treatment in SNCUs<font color=red>*</font></label> 
                                        <div class="col-sm-4">
                                            <input name="no_of_newborns_received" id="no_of_newborns_received"  type="number" class="form-control"  value="<?php echo $value[0]->no_of_newborns_received; ?>" placeholder="Integer Value" required="">
                                        </div>
                                    </div>


                                    <div class="row">
                                        <div class="col-lg-10" style="text-align:center">
										<button type="button" class="btn btn-light" onclick="location.href ='<?php echo base_url("Childhealth/index"); ?>'">
                                                << Cancel & Back
                                            </button>
                                            
                                            <button type="submit" name="updatechform" class="btn btn-success m-btn m-btn--icon">
                                                <i class="la la-search"></i> Update
                                            </button>
                                            
                                        </div>
                                    </div>
                                </div>
                           
                        </div><!--End Row-->

                    </div>
                    </div>
            </div>
                <!--top tiles -->
    <!-- /page content -->


</section>
<script>
    $(document).ready(function () {
        $("#printButton").click(function () {
            var mode = 'iframe'; //popup
            var close = mode == "popup";
            var options = {mode: mode, popClose: close};
            $("div.printableArea").printArea(options);
        });
    });
</script>

