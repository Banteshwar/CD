<section> 
    <div class="breadcrumb_content">
        <div class="breadcrumb_text"><?php echo $this->mybreadcrumb->render(); ?></div>
        
           <div class="row pt-2 pb-2">
            <div class="col-sm-2 pull-right text-right">
                <div class="btn-group float-sm-right">
                    <button type="button" class="btn btn-warning waves-effect waves-light" onclick="location.href = '<?php echo base_url('Childhealth/add_form'); ?>'"><i class="fa fa-plus" aria-hidden="true"></i> Add New</button>
                </div>
            </div>
        </div>


        <div class="clearfix"></div>
    </div>
    <div class="right_col bg_fff" role="main">
        <div class="top_header_portal ">
            <h2>Child Health</h2>
        </div>
  
        <div class="row printableArea">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <?php if (($this->session->flashdata('success'))) { ?>
                    <div class="alert alert-success alert-dismissible" role="alert">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        <div class="alert-icon">
                            <i class="fa fa-check"></i>
                        </div>
                        <div class="alert-message">
                            <span><strong>Success!</strong> <?php echo $this->session->flashdata('success'); ?></span>
                        </div>
                    </div>
                <?php } ?>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="x_panel">
                            <div class="table-responsive">
                                <table class="table table-bordered example" id="datatable">
                                    <thead>
                                        <tr>
                                            <th>Sr.No.</th>                            
                                            <th>National Deworming Day Coverage (NDD) as per round</th>
                                            <th>Intensified Diarrhoea Control Fortnight Coverage (IDCF) as per round </th>
                                            <th>Number of Children Screened by MHT under RBSK Program </th>
                                            <th>Number of Children Received Secondary/ tertiary treatment under RBSK</th>
                                            <th>No. of newborns received treatment in SNCUs</th>
                                            <th>Year</th>
                                            <th>Quarter</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($row) {
                                            $no_start = 0;
                                            foreach ($row as $rows) {
                                                $no_start++;
                                                ?>
                                                <tr> 
                                                    <td><?php echo $no_start; ?></td>
                                                    
                                                    <td><?php echo $rows->ndd; ?></td>
                                                    <td><?php echo $rows->idcf; ?></td>
                                                    <td><?php echo $rows->no_of_children_screened; ?></td>
                                                    <td><?php echo $rows->no_of_children_received; ?></td>
                                                    <td><?php echo $rows->no_of_newborns_received; ?></td>
                                                    <td><?php echo $rows->year; ?></td>
                                                    <td><?php echo $rows->Quarter; ?></td>
                                   
                                                    <td>
                                                        <a title="Edit" class="btn btn-info btn-sm" href="<?php echo base_url('Childhealth/edit_childhealth/' . $rows->id); ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a> 

                                                        <a href="<?php echo base_url('Childhealth/delete/' . $rows->id); ?>" class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="bottom" title="Delete" onclick="return confirm('Are You Sure Want To Delete?')"><i class="fa fa-trash-o" aria-hidden="true"></i></a>      
                                                    </td>
                                                </tr>

                                                <?php
                                            }
                                        } else {
                                            ?>
                                         

                                        <?php } ?>                                      

                                    </tbody>
                                </table>
                            </div>
                        </div><!--End Row-->
                    </div><!--End Row-->
                </div>
            </div>
        </div>
    </div>
    <!-- /page content -->
</section>
<script>
    $(document).ready(function () {
        $("#printButton").click(function () {
            var mode = 'iframe'; //popup
            var close = mode == "popup";
            var options = {mode: mode, popClose: close};
            $("div.printableArea").printArea(options);
        });
    });
</script>