<?php

function loadLayout($page = null, $type = null, $data = null) {

    $layout = & get_instance();

    if ($type == 'admin') {
       //////////// for join secretary user //////
    
    global $db;
        $user = new Users($db);
     $user_row = $user->getUser();
      //echo $user_row[6]; die;
      
    if($user_row[6]=='62' || $user_row[6]=='64' || $user_row[6]=='64' || $user_row[6]=='65' || $user_row[6]=='66' || $user_row[6]=='67' || $user_row[6]=='68' || $user_row[6]=='69' || $user_row[6]=='70' || $user_row[6]=='71' || $user_row[6]=='72' || $user_row[6]=='73' || $user_row[6]=='74' || $user_row[6]=='75' || $user_row[6]=='76' || $user_row[6]=='77' || $user_row[6]=='78')
    {   // Js User
      
      $layout->load->view('template/t_jointsecretary_header',$data);
            $layout->load->view($page, $data);
            $layout->load->view('template/t_footer');
      
    } else if($user_row[6]=='3')
	{  // Minister

     $layout->load->view('template/t_minister_header',$data);
            $layout->load->view($page, $data);
            $layout->load->view('template/t_footer');
      
    }
	
    else{
    
    
        $layout->load->view('template/t_header',$data);
       $layout->load->view($page, $data);
        $layout->load->view('template/t_footer');
    
    }
    } 
	else if ($type == 'maindashboard') {
		$layout->load->view('template/t_header',$data);
       $layout->load->view($page, $data);
       $layout->load->view('template/t_footer');
       
	 }
	else if ($type == 'program_manager') {
	//////////// for join secretary user //////
    
    global $db;
        $user = new Users($db);
     $user_row = $user->getUser();
      //echo $user_row[6]; die;
      
    if($user_row[6]=='62' || $user_row[6]=='64' || $user_row[6]=='64' || $user_row[6]=='65' || $user_row[6]=='66' || $user_row[6]=='67' || $user_row[6]=='68' || $user_row[6]=='69' || $user_row[6]=='70' || $user_row[6]=='71' || $user_row[6]=='72' || $user_row[6]=='73' || $user_row[6]=='74' || $user_row[6]=='75' || $user_row[6]=='76' || $user_row[6]=='77' || $user_row[6]=='78')
    {
      
      $layout->load->view('template/t_jointsecretary_header',$data);
            $layout->load->view($page, $data);
            $layout->load->view('template/t_footer');
      
    }
    else{
    $layout->load->view('template/t_program_manager_header',$data);
       $layout->load->view($page, $data);
      $layout->load->view('template/t_footer');
    }
       
	 }
   else if ($type == 'secretary') {
		$layout->load->view('template/t_secretary_header',$data);
       $layout->load->view($page, $data);
      $layout->load->view('template/t_footer');
       
	 }
    else if ($type == 'jointsecretary') { 

		$layout->load->view('template/t_jointsecretary_firstpage_header',$data);
        $layout->load->view($page, $data);
        $layout->load->view('template/t_jointsecretary_firstpage_footer');
    
      
       
	 }
	else if ($type == 'public') {
        $layout->load->view('template/m_header');
        $layout->load->view($page, $data);
        $layout->load->view('template/m_footer');
    } else if ($type == 'popup') {
        $layout->load->view($page, $data);
      } else {
        $layout->load->view('template/m_header');
        $layout->load->view($page, $data);
        $layout->load->view('template/m_footer');
    }
}

function jdecrypt() {

    require_once APPPATH . 'third_party/jcryption/sqAES.php';
    require_once APPPATH . 'third_party/jcryption/JCryption.php';
    return JCryption::decrypt();
}

if(!function_exists('highFocusState')){
    function highFocusState()
    {
        $data = array(
            10 => 'Bihar',
            22 => 'Chhattisgarh',
            20 => 'Jharkhand',
            23 => 'Madhya Pradesh',
            21 => 'Odisha',
             8 => 'Rajasthan',
             9 => 'Uttar Pradesh',
             5 => 'Uttarakhand',
             2 => 'Himachal Pradesh'
        );
        return $data;
    }
}

if(!function_exists('nonHighFocusLargeState')){
function nonHighFocusLargeState()
{
    $data = array(
       28 => 'Andhra Pradesh',
       24 => 'Gujarat',
       30 => 'Goa',
        6 => 'Haryana',
        1 => 'Jammu & Kashmir',
       29 => 'Karnataka',
       32 => 'Kerala',
       27 => 'Maharashtra',
        3 => 'Punjab',
       33 => 'Tamil Nadu',
       36 => 'Telengana',
       19 => 'West Bengal'
    );
     return $data;
}
}

if(!function_exists('northEasternState')){
    function northEasternState()
    {
        $data = array(
           12 => 'Arunachal Pradesh',
           18 => 'Assam',
           14 => 'Manipur',
           17 => 'Meghalaya',
           15 => 'Mizoram',
           13 => 'Nagaland',
           11 => 'Sikkim ',
           16 => 'Tripura'
        );
        return $data;
    }
}

if(!function_exists('unionTerritories')){
    function unionTerritories()
    {
        $data = array(
           35 => 'Andman & Nicobar Islands',
            4 => 'Chandigarh',
           26 => 'Dadra & Nagar Haveli',
           25 => 'Daman & Diu',
            7 => 'Delhi',
           31 => 'Lakshadweep',
           34 => 'Puducherry '
        );
         return $data;
    }
}

if (!function_exists('generate_password')) {
    function generate_password($length = 20)
    {
       
        $chars =  'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789#'.
       

        $str = '';
        $max = strlen($chars) - 1;

        for ($i=0; $i < $length; $i++) {
            $str .= $chars[random_int(0, $max)];
        }

        return $str;
    }
}
//indian rupee format code
function moneyFormatIndia($num) {
    $explrestunits = "" ;
    if(strlen($num)>3) {
        $lastthree = substr($num, strlen($num)-3, strlen($num));
        $restunits = substr($num, 0, strlen($num)-3); // extracts the last three digits
        $restunits = (strlen($restunits)%2 == 1)?"0".$restunits:$restunits; // explodes the remaining digits in 2's formats, adds a zero in the beginning to maintain the 2's grouping.
        $expunit = str_split($restunits, 2);
        for($i=0; $i<sizeof($expunit); $i++) {
            // creates each of the 2's group and adds a comma to the end
            if($i==0) {
                $explrestunits .= (int)$expunit[$i].","; // if is first value , convert into integer
            } else {
                $explrestunits .= $expunit[$i].",";
            }
        }
        $thecash = $explrestunits.$lastthree;
    } else {
        $thecash = $num;
    }
    return $thecash; // writes the final format where $currency is the currency symbol.
}
//end indian rupee code 

?>
