<?php

if (!function_exists('getMonth_old2')) {
    function getMonth_old2()
    {
        return array(4=>'April',5=>'May',6=>'June',7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December',1=>'January',2=>'Febuary',3=>'March');
    }
}

if (!function_exists('getMonth')) {
    function getMonth()
    {
        return array('January'=>'January','Febuary'=>'Febuary','March'=>'March','April'=>'April','May'=>'May','June'=>'June','July'=>'July','August'=>'August','September'=>'September','October'=>'October','November'=>'November','December'=>'December');
    }
}

if (!function_exists('get2Month')) {
    function get2Month()
    {
        return array('Nov-Dec'=>'Nov-Dec','Sep-Oct'=>'Sep-Oct','Jul-Aug'=>'Jul-Aug','May-Jun'=>'May-Jun','Mar-Apr'=>'Mar-Apr','Jan-Feb'=>'Jan-Feb');
    }
}


if (!function_exists('get2Months')) {
    function get2Months()
    {
        return array('6'=>'Nov-Dec','5'=>'Sep-Oct','4'=>'Jul-Aug','3'=>'May-Jun','2'=>'Mar-Apr','1'=>'Jan-Feb');
    }
}


if (!function_exists('getbiannual')) {
    function getbiannual()
    {
        return array('Jan-Jun'=>'Jan-Jun','Jul-Dec'=>'Jul-Dec');
    }
}


if (!function_exists('getcurrent2Month')) {
    function getcurrent2Month()
    {
        return 'Jul-Aug';
    }
}

if (!function_exists('getcurrent2Monthnew')) {
    function getcurrent2Monthnew()
    {
        return 4;
    }
}

if (!function_exists('getMonth_old')) {
    function getMonth_old()
    {
        return array(1=>'January',2=>'Febuary',3=>'March',4=>'April',5=>'May',6=>'June',7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December');
    }
}

if (!function_exists('getYear')) {
    function getYear()
    {
        return array(2016=>'2016',2017=>'2017',2018=>'2018');
    }
}

if (!function_exists('getFromEnryYear')) {
	 function getFromEnryYear($year)
    { 
		
		return $year-2;	
	}
}



if (!function_exists('getTotalMonthView')) {
    function getTotalMonthView()
    {
	return '24'; 
	}
}

if (!function_exists('getTotalYearView')) {
    function getTotalYearView()
    {
	return '5'; 
	}
}

if (!function_exists('getMonthsOnDatediff')) {
    function getMonthsOnDatediff($slider_yeardate,$current_date)
    {
	$ts1 = strtotime($slider_yeardate);
$ts2 = strtotime($current_date);

$year1 = date('Y', $ts1);
$year2 = date('Y', $ts2);

$month1 = date('m', $ts1);
$month2 = date('m', $ts2);

return $diff = (($year2 - $year1) * 12) + ($month2 - $month1); 
	}
}



if (!function_exists('getYearFull')) {
    function getYearFull($flag='')
    {
		if($flag=='Monthly')
		{
		  $to_year = '2030';  
		
		 $from_year = '2017';
		 
        return $value= range($from_year,$to_year);	
	
		}
		else if($flag=='Yearly')
		{ 
	     $from_year='2011';
		 $to_year='2030';
		
        return $value= range($from_year,$to_year);	
		}
		else
		{
		
        return range(2050, 1950);
		}
        
        
    }
}

if (!function_exists('getCurrFinYear')) {
    function getCurrFinYear($flag='')
    {
		if($flag=='Quarterly')
		{
			
			
		if (date('m') <= 6) {//Upto March
            $currFYear = (date('Y')-1) . '-' . (date('y')); 
        } else {//After March
            $currFYear = date('Y') . '-' . (date('y')+1);
        }
		
		
        return $currFYear;	
		}
		else{
			
        if (date('m') <= 3) {//Upto March
            $currFYear = (date('Y')-1) . '-' . date('y');
        } else {//After March
            $currFYear = date('Y') . '-' . (date('y') + 1);
        }
        return $currFYear;
		}
    }
}


/*if (!function_exists('getCurrQuarter')) {
    function getCurrQuarter()
    {       
        return 'Q2';
    }
}*/



if (!function_exists('getCurrQuarter')) {
    function getCurrQuarter($flag='')
    {  
        if($flag=='Quarterly')
		{
			$n = date('n');
			if ( $n >=1 && $n <= 3 ) {   
				return 'Q3';
			}
			if ( $n >=4 && $n <= 6 ) {   
				return 'Q4';
			}
			if ( $n >=7 && $n <= 9 ) {   
				return 'Q1';
			}
			if ( $n >=10 && $n <= 12 ) {   
				return 'Q2';
			}
			
        }
        else{
			
        $n = date('n');
        if ( $n >=1 && $n <= 3 ) {   
            return 'Q4';
        }
        if ( $n >=4 && $n <= 6 ) {   
            return 'Q1';
        }
        if ( $n >=7 && $n <= 9 ) {   
            return 'Q2';
        }
        if ( $n >=10 && $n <= 12 ) {   
            return 'Q3';
        }
		
		}
    }
}


if (!function_exists('getCurrMonth')) {
    function getCurrMonth($flag='')
    {
		if($flag=='Monthly')
		{
			$currentMonth = date('F');
           return Date('n', strtotime($currentMonth . " last month")); 
			
		}
		else
		{
			return date('n');
		}
        
    }
}

if (!function_exists('getCurrYear')) {
    function getCurrYear($flag='')
    {  
	
      if($flag=='Yearly')
		{
			return date('Y')-1;
		}
		else if($flag=='Monthly')
		{
			$month = date('m');
			if($month == 1){
			return date('Y')-1;	
			
			}
			else{
				return date('Y'); 
			}
		}
        else
		{		
        return date('Y');
		}
    }
}


if (!function_exists('getFinancialYear_21-07-2019')) {
    function getFinancialYear21_07_2019()
    {
        return array('2019-20'=>'2019-20','2018-19'=>'2018-19','2017-18'=>'2017-18','2016-17'=>'2016-17','2015-16'=>'2015-16');
    }
}

if (!function_exists('getFromShowFinancialYear')) {
	 function getFromShowFinancialYear($flag='')
    {
	return '2016';	
	}
}


if (!function_exists('getFromEnryFinancialYear')) {
	 function getFromEnryFinancialYear($year)
    { 
		$q = getCurrQuarter('Quarterly');

		if($q  == 'Q4') {			
			return $year-2;	
		}
		return $year-3;	
	}
}
/*

if (!function_exists('getFromEnryFinancialYear')) {
	 function getFromEnryFinancialYear()
    { 
		$q = getCurrQuarter('Quarterly');

		if($q  == 'Q4') {			
			return date('Y')-2;	
		}
		return date('Y')-3;	
	}
}*/

if (!function_exists('getFromEntryQuarter')) {
	 function getFromEntryQuarter($flag='')
    {
		return getCurrQuarter('Quarterly');
	}
}

if (!function_exists('getFinancialYear')) {
    function getFinancialYear($flag='')
    {
		 if($flag=='Quarterly')
		{
			
			
			 $show_slide_upto = date('Y')+11; 
			
			 $entry_from=getFromShowFinancialYear();
		
					       			
			for($i=$entry_from;$i<$show_slide_upto;$i++)
        {
            $val = $i.'-'.(($i%100)+1);
            
            $fin_year[$val] = $val;
                        
        }
  
        return $fin_year;
		
		}
		else
		{
		 
        for($i=2050;$i>1950;$i--)
        {
            $val = $i.'-'.(($i%100)+1);
            
            $fin_year[$val] = $val;
                        
        }
    

        return $fin_year;
	}
	
    }
}



if (!function_exists('getQuarter')) {
    function getQuarter($flag='')
    {
       // return array('Q1'=>'Q1','Q2'=>'Q2','Q3'=>'Q3','Q4'=>'Q4');
	   
	   if($flag='Quarterly')
	   {
		return array('Q1'=>'Q1','Q2'=>'Q2','Q3'=>'Q3','Q4'=>'Q4');   
	   }
	   else{
		return array('Q4'=>'Q4','Q3'=>'Q3','Q2'=>'Q2','Q1'=>'Q1');   
	   }
	   
	   
    }
}

if (!function_exists('getQuarter_old')) {
    function getQuarter_old()
    {
        return array(1=>'First Quarter',2=>'Second Quarter',3=>'Third Quarter',4=>'Fourth Quarter');
    }
}

if (!function_exists('getSchemeType')) {
    function getSchemeType()
    {
        return  array('-1'=>'All',1 => 'Scheme - A',2=>'Scheme - B',3=>'DMHP');
    }
}

if (!function_exists('getDataItem')) {
    function getDataItem()
    {
        return  array(1=>'Capital Work',2 => 'Equipments (Technical)',3=>'Equipments (Non-Technical)',4=>'Library',5=>'Faculty & staff');
    }
}

if (!function_exists('getLanguages')) {
    function getLanguages()
    {
        return array('en'=>'English','hi'=>'हिंदी');
    }
}

if (!function_exists('getLanguagesDirectory')) {
    function getLanguagesDirectory()
    {
        return array('en'=>'english','hi'=>'hindi');
    }
}


if (!function_exists('getAssessmentList')) {
    function getAssessmentList()
    {
        return array('OB'=>'Observation(OB)', 'SI'=>'Staff Interview(SI)', 'RR'=>'Record Review(RR)', 'PI'=>'Patient Interview(PI)');
    }
}

if (!function_exists('getOccasionCategory')) {
    function getOccasionCategory()
    {
        return array('In campus'=>'In campus', 'Out campus'=>'Out campus', 'Nukkad Natak'=>'Nukkad Natak');
    }
}

// if(!function_exists('regionIndicator'))
// {
//   function getregionIndicator()
//   {
//     return array('Rural'=>'Rural', 'Urban'=>'Urban');
//   }
// }
if (!function_exists('getregionIndicator')) {
    function getregionIndicator()
    {
        return array('0'=>'Please select region', '1'=>'Rural', '2'=>'Urban');
    }
}

// if(!function_exists('ownershipAuthority'))
// {
//   function getownershipAuthority()
//   {
//     return array('State Government'=>'State Government', 'Central Government - MoHFW'=>'Central Government - MoHFW', 'Central Government - ESI'=>'Central Government - ESI', 'Central Government - CGHS'=>'Central Government - CGHS', 'Central Government - Other ministries'=>'Central Government - Other ministries', 'Central Government - Railways'=>'Central Government - Railways', 'Central Government - Military'=>'Central Government - Military', 'Private - for profit'=>'Private - for profit', 'Private - not for profit'=>'Private - not for profit', 'Hospital'=>'Hospital', 'Municipal Corporation'=>'Municipal Corporation', 'Person'=>'Person', 'Others'=>'Others');
//   }
// }

if (!function_exists('getOwnershipAuthority')) {
    function getOwnershipAuthority()
    {
        return array('0'=>'Please select Ownership Authority', '1'=>'State Government', '13'=>'Central Government - MoHFW', '2'=>'Central Government - ESI', '3'=>'Central Government - CGHS', '4'=>'Central Government - Other ministries', '5'=>'Central Government - Railways', '6'=>'Central Government - Military', '7'=>'Private - for profit', '8'=>'Private - not for profit', '9'=>'Hospital', '12'=>'Municipal Corporation', '10'=>'Person', '11'=>'Others');
    }
}

if (!function_exists('getFacilityType')) {
    function getFacilityType()
    {
        return array('0'=>'All', '1'=>'Primary Health Centre', '2'=>'Community Health Centre', '3'=>'Urban Health Centre', '4'=>'Sub-district Hospital', '5'=>'District Hospital');
        //  return array('0'=>'Select facility Type', '1'=>'Primary Health Centre', '2'=>'Community Health Centre', '3'=>'Urban Health Centre', '4'=>'sub-District Hospital', '5'=>'District Hospital', '6'=>'Civil Hospital/General Hospital', '7'=>'Referral Hospital', '8'=>'Dispensaries', '9'=>'Ayush Dispensaries', '10'=>'Maternity Home', '11'=>'Post Partum Unit', '12'=>'M&CW Centre', '13'=>'100 Bedded Hospital', '14'=>'100-500 Bedded Hospital', '15'=>'500 Bedded Hospital', '16'=>'Urban Health Post', '17'=>'Medical Colleges Hospital', '18'=>'Women Hospital', '99'=>'SubCentre', '100'=>'Others');
    }
}

if (!function_exists('getAllFacilityType')) {
    function getAllFacilityType()
    {
        return array('0'=>'Select facility Type', '1'=>'Primary Health Centre', '2'=>'Community Health Centre', '3'=>'Urban Health Centre', '4'=>'sub-District Hospital', '5'=>'District Hospital', '6'=>'Civil Hospital/General Hospital', '7'=>'Referral Hospital', '8'=>'Dispensaries', '9'=>'Ayush Dispensaries', '10'=>'Maternity Home', '11'=>'Post Partum Unit', '12'=>'M&CW Centre', '13'=>'100 Bedded Hospital', '14'=>'100-500 Bedded Hospital', '15'=>'500 Bedded Hospital', '16'=>'Urban Health Post', '17'=>'Medical Colleges Hospital', '18'=>'Women Hospital', '99'=>'SubCentre', '100'=>'Others');
    }
}

if (!function_exists('campaignType')) {
    function getcampaignType()
    {
        return array('Kayakalp'=>'Kayakalp', 'Swachhata Pakhwada'=>'Swachhata Pakhwada','VHSNC'=>'VHSNC');
    }
}

if (!function_exists('typeFacility')) {
    function gettypeFacility()
    {
        return array('DH, SDH and CHC' =>'DH, SDH and CHC', 'PHC'=>'PHC');
    }
}

if (!function_exists('getOperationalStatus')) {
    function getOperationalStatus()
    {
        return array('0' => '-- Please select Operational Status --',
   '1' => 'Functional',
   '2' => 'Closed',
   '3' => 'Non-Functional Under Maintenance / Others',
   '4' => 'Invalid - Does Not Exists',
   '5' => 'Duplicate');
    }
}

if (!function_exists('getComplianceList')) {
    function getComplianceList()
    {
        return array(''=>'None','0'=>'0','1'=>'1','2'=>'2');
    }
}

if (!function_exists('getAssessmentType')) {
    function getAssessmentType()
    {
        return array('1'=>'peer','2'=>'external');
    }
}

if (!function_exists('excelfacilityType')) {
    function excelfacilityType()
    {
        return array(1=>'CHC',2=>'PHC',3=>'DH');
    }
}

if (!function_exists('UIID_v4')) {
    function UIID_v4()
    {
        return sprintf(
        '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',

      // 32 bits for "time_low"
      mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),

      // 16 bits for "time_mid"
      mt_rand(0, 0xffff),

      // 16 bits for "time_hi_and_version",
      // four most significant bits holds version number 4
      mt_rand(0, 0x0fff) | 0x4000,

      // 16 bits, 8 bits for "clk_seq_hi_res",
      // 8 bits for "clk_seq_low",
      // two most significant bits holds zero and one for variant DCE1.1
      mt_rand(0, 0x3fff) | 0x8000,

      // 48 bits for "node"
      mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0xffff)
    );
    }
}

if (!function_exists('generate_password')) {
    function generate_password($length = 20)
    {
        // $chars =  'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-=~!@#$%^&*()_+/<>?[]{}';
        $chars =  'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789#'.
        //           '0123456789`-=~!@#$%^&*()_+,./<>?;:[]{}\|';

        $str = '';
        $max = strlen($chars) - 1;

        for ($i=0; $i < $length; $i++) {
            $str .= $chars[random_int(0, $max)];
        }

        return $str;
    }
}

if (!function_exists('bannerPosition')) {
    function bannerPosition()
    {
        return array('1'=>'Position-One','2'=>'Position-Two','3'=>'Position-Three', '4'=>'Position-Four', '5'=>'Position-Five', '6'=>'Position-Six', '7'=>'Position-Seven', '8'=>'Position-Eight', '9'=>'Position-Nine', '10'=>'Position-Ten');
    }
}

if (!function_exists('eventNotificationcri')) {
    function eventNotificationcri()
    {
        return array('0'=>'Choees Event Notification' ,'1'=>'New Announcement', '2'=>'Non Participating Villages', '3'=>'Other Notification');
    }
}

if (! function_exists('swachhataCampaign')) {
    function swachhataCampaign()
    {
        return array('1'=>'Open Defecation Free Village', '2'=>'School and Anganwadi Sanitation', '3'=>'Personal & Home Hygiene and Hand Washing' );
    }
}
////// show in kayakalp facility list section //////
if (! function_exists('facility_type_and_role')) {
    function facility_type_and_role()
    {
        return array('1'=>'10', '2'=>'11', '3'=>'10','4'=>'12', '5'=>'12', '99'=>'14' );
    }
}

if (! function_exists('kaykal_facility_list_type')) {
    function kaykal_facility_list_type()
    {
        return array('1','2','3','4','5');
    }
}

//////// end show in kayakalp facility list section //////
/* Added by Asjad on 11-07-2018 */
if (! function_exists('loginRole')) {
    function loginRole()
    {
        return array('1'=>'Administrator', '13'=>'State Login', '11'=>'CHC Login', '10'=>'PHC/UPHC Login', '12'=>'DH/SDH Login', '8'=>'NHSRC Admin','4'=>'CG Hospital Login', '6'=>'CG Hospital Admin','14'=>'VHSNC Login', '16'=>'VHSNC Admin');
        //  return array('1'=>'Administrator', '13'=>'State Login', '11'=>'CHC Login','10'=>'PHC Login','12'=>'DH Login','8'=>'NHSRC Admin','4'=>'CG Hospital Login','6'=>'CG Hospital Admin','14'=>'VHSNC Login','16'=>'VHSNC Admin' );
    }
}


if (!function_exists('showError')) {
    function showError($data)
    {
        error_reporting(0);
//
        //// Report simple running errors
        error_reporting(E_ERROR | E_WARNING | E_PARSE);
//
        //// Reporting E_NOTICE can be good too (to report uninitialized
        //// variables or catch variable name misspellings ...)
        error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
        error_reporting(E_ERROR | E_WARNING | E_PARSE);
        //// Report all errors except E_NOTICE
        error_reporting(E_ALL & ~E_NOTICE);
        //// Report all PHP errors (see changelog)
        error_reporting(E_ALL);
        //// Report all PHP errors
        error_reporting(-1);
        //Same as error_reporting(E_ALL);
        ini_set('error_reporting', E_ALL);
    }
}

if (!function_exists('showData')) {
    function showData($array)
    {
        if ($array) {
            if (is_array($array) || is_object($array)) {
                echo '</br>=====Array  Start ======</br>';
                // showArrayData($array);
                echo "<pre>" . print_r($array, true) . "</pre>";
                echo '</br>=======END======</br>';
            } else {
                echo $array;
            }
        } else {
            var_dump($array);
        }
    }
}
if (!function_exists('error_format')) {
    function error_format($error)
    {
        $output = '';
        //check for any errors
        if (isset($error) && count($error) > 0) {
            //       $output = '<div class=" error alert alert-danger"><ul style=" list-style: none " >';
            $output = '<ul>';
            foreach ($error as $error) {
                $output .= '<li >' . $error . '</li>';
            }
            $output .= '</ul>';

            //$output .= '</ul></div>';
        }
        return $output;
    }
}

/* Added by Asjad on 02-10-2018 */
if (!function_exists('check_input')) {
    function check_input($theValue)
    {
        $theValue = trim($theValue);
        $theValue = strip_tags($theValue);
        //$theValue = str_replace(array('\'', '"'), ' quote ', $theValue);

        $theValue = addslashes($theValue);
        $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
        $theValue = htmlspecialchars($theValue, ENT_QUOTES);
        //$ci=& get_instance();
        //$theValue = $ci->db->escape($theValue);
        return $theValue;
    }
}

/* Added by Asjad on 03-10-2018 */
if (!function_exists('getPercentage')) {
    function getPercentage($obtainNum = null, $total = null)
    {
        if ($total<=0) {
            return '0.00';
        } else {
            $percent = ($obtainNum / $total) * 100;
            $actual_percent = number_format((float)$percent, 2, '.', '');
            $actual_percent = ($actual_percent>100)?'100.00':$actual_percent;
            return $actual_percent;
        }
    }
}

/* Added by Asjad on 05-10-2018 */
    if (!function_exists('encryptor')) {
        function encryptor($action, $string)
        {
            $output = false;
            $encrypt_method = "AES-256-CBC";
            //pls set your unique hashing key
            $secret_key = 'swachtaasjad';
            $secret_iv = 'swachtaasjad1539';
            // hash
            $key = hash('sha256', $secret_key);
            // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
            $iv = substr(hash('sha256', $secret_iv), 0, 16);
            //do the encyption given text/string/number
            if ($action == 'encrypt') {
                $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
                $output = base64_encode($output);
            } elseif ($action == 'decrypt') {
                //decrypt the given text/string/number
                $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
            }
            return $output;
        }
    }
	
	
