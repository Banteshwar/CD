<?php



    function getPMSMAReport() {

       $CI  = &get_instance();

        // Please change db credentials as per environment
        $match_day = define("STATISTICS_DAY", "10");
        $match_day = STATISTICS_DAY; 

        $CI->db->select('ifnull(`TotalVolunteerRegistered`,0) as TotalVolunteerRegistered,ifnull(`TotalVolunteerProvideService`,0) as TotalVolunteerProvideService,
    ifnull(`TotalPWSeenByVolunteer`,0) as TotalPWSeenByVolunteer,
    ifnull(`AntenatalCare`,0) as AntenatalCare,
    ifnull(`HighRiskPregnancies`,0) as HighRiskPregnancies,
    ifnull(`PMSMAFacilitiesNumber`,0) as PMSMAFacilitiesNumber,
    ifnull(`TotalGrievance`,0) as TotalGrievance,
    ifnull(`TotalGrievanceNotAnsward`,0) as TotalGrievanceNotAnsward');
        $CI->db->from('dashboard_data_pmsma');
        $CI->db->where('EntityID',0);
        $CI->db->limit(1);

        $result=$CI->db->get()->result_array();
        return $result;
    }
    
    
     /* function getLAQSHAYReport() {

       $CI  = &get_instance();

        // Please change db credentials as per environment
        
        $CI->db->select('ifnull(`baseline_facilities`,0) as baseline_facilities,
ifnull(`soc_facilities`,0) as soc_facilities,
ifnull(`cretified_lrot`,0) as cretified_lrot,
ifnull(`dh_baseline_facilities`,0) as dh_baseline_facilities,
ifnull(`sc_lr_dh`,0) as sc_lr_dh,
ifnull(`sc_ot_dh`,0) as sc_ot_dh');
        $CI->db->from('dashboard_data_laqshya');
        $CI->db->where('1',1);
        $CI->db->limit(1);
        $result= $CI->db->get()->row_array();
        return $result;
    }*/


     /*   LAQSHYA CODE */  
   /*function getLAQSHAYReport() {

       $CI  = &get_instance();

        // Please change db credentials as per environment
        
        $CI->db->select('ifnull(`baseline_facilities`,0) as baseline_facilities,
ifnull(`soc_facilities`,0) as soc_facilities,
ifnull(`cretified_lrot`,0) as cretified_lrot,
ifnull(`dh_baseline_facilities`,0) as dh_baseline_facilities,
ifnull(`sc_lr_dh`,0) as sc_lr_dh,
ifnull(`sc_ot_dh`,0) as sc_ot_dh');
        $CI->db->from('dashboard_data_laqshya');
        $CI->db->where('1',1);
        $CI->db->limit(1);
        $result= $CI->db->get()->row_array();
        return $result;
    }*/


    function getLAQReport() {

        $CI  = &get_instance();

        $CI->db->select('field_1,field_2,field_3,field_4,field_5,field_6,field_7,field_8'); 
        $CI->db->from('dashboard_data_laqshya');
        $CI->db->where('type_data','boxtop');
        $CI->db->limit(1);
        $result= $CI->db->get()->row_array();
        return $result;
    }

    function getLAQSHYAmapInd() {

        $CI  = &get_instance();

        $CI->db->select('field_1,field_2,field_3,field_4,field_5,field_6,field_7,field_8,field_9');
        $CI->db->from('dashboard_data_laqshya');
        $CI->db->where('type_data','mapInd');
        $result= $CI->db->get()->result_array();
        return $result;
    }

    function getLAQSHYAmapBox() {

        $CI  = &get_instance();

        $CI->db->select('field_1,field_2,field_3,field_4,field_5,field_6,field_7,field_8,field_9');
        $CI->db->from('dashboard_data_laqshya');
        $CI->db->where('type_data','mapBox');
        $result= $CI->db->get()->row_array();
        return $result;
    }

    function getLAQSHYAtopstates() {

        $CI  = &get_instance();

        $CI->db->select('field_1,field_2,field_3,field_4,field_5');
        $CI->db->from('dashboard_data_laqshya');
        $CI->db->where('type_data','top5');
        $result= $CI->db->get()->row_array();
        return $result;
    }


    function getLAQSHYAmapBoxAsp() {

        $CI  = &get_instance();

        $CI->db->select('field_1,field_2,field_3,field_4,field_5,field_6,field_7,field_8,field_9,field_10,field_11');
        $CI->db->from('dashboard_data_laqshya');
        $CI->db->where('type_data','mapBox_asp');
        $result= $CI->db->get()->row_array();
        return $result;
    }

    function getLAQSHYAmapstatus() {

        $CI  = &get_instance();

        $CI->db->select('field_1,field_2,field_3,field_4,field_5,field_6,field_7,field_8,field_9,field_10');
        $CI->db->from('dashboard_data_laqshya');
        $CI->db->where('type_data','laqshya_sts');
        $result= $CI->db->get()->row_array();
        return $result;
    }
    
     function getLAQSHYApiechart() {

        $CI  = &get_instance();

        $CI->db->select('field_1,field_2,field_3,field_4,field_5,field_6');
        $CI->db->from('dashboard_data_laqshya');
        $CI->db->where('type_data','piechart_MatDeath');
        $result= $CI->db->get()->row_array();
        return $result;
    }

    function getLAQSHYANeonDeath() {

        $CI  = &get_instance();

        $CI->db->select('field_1,field_2,field_3,field_4,field_5,field_6');
        $CI->db->from('dashboard_data_laqshya');
        $CI->db->where('type_data','piechart_NeonDeath');
        $result= $CI->db->get()->row_array();
        return $result;
    }

     function getLAQSHYAStillBirth() {

        $CI  = &get_instance();

        $CI->db->select('field_1,field_2,field_3,field_4,field_5,field_6');
        $CI->db->from('dashboard_data_laqshya');
        $CI->db->where('type_data','piechart_StillBirth');
        $result= $CI->db->get()->row_array();
        return $result;
    }

    function getLAQSHYADeliveries() {

        $CI  = &get_instance();

        $CI->db->select('field_1,field_2,field_3,field_4,field_5,field_6');
        $CI->db->from('dashboard_data_laqshya');
        $CI->db->where('type_data','piechart_Deliveries');
        $result= $CI->db->get()->row_array();
        return $result;
    }

    function getLAQSHYAanexture() {

        $CI  = &get_instance();

        $CI->db->select('field_1,field_2,field_3,field_4,field_5,field_6');
        $CI->db->from('dashboard_data_laqshya');
        $CI->db->where('type_data','chart_anexture');
        $result= $CI->db->get()->row_array();
        return $result;
    }

     function getLAQSHYAindicatorsts() {

        $CI  = &get_instance();

        $CI->db->select('*');
        $CI->db->from('dashboard_data_laqshya');
        $CI->db->where('type_data','indicator_sts');
        $result= $CI->db->get()->row_array();
        return $result;
    }

     function getLAQSHYAaspdstcert() {

        $CI  = &get_instance();

        $CI->db->select('field_1,field_2,field_3,field_4');
        $CI->db->from('dashboard_data_laqshya');
        $CI->db->where('type_data','laqshya_aspd_st_cert');
        $result= $CI->db->get()->row_array();
        return $result;
    }
    

      function getLAQSHYAaspd() {

        $CI  = &get_instance();

        $CI->db->select('field_1,field_2,field_3');
        $CI->db->from('dashboard_data_laqshya');
        $CI->db->where('type_data','laqshya_aspd');
        $result= $CI->db->get()->row_array();
        return $result;
    }

     function getLAQSHYAaspdntcert() {

        $CI  = &get_instance();

        $CI->db->select('field_1,field_2,field_3,field_4');
        $CI->db->from('dashboard_data_laqshya');
        $CI->db->where('type_data','laqshya_aspd_nt_cert');
        $result= $CI->db->get()->row_array();
        return $result;
    }
    
    
   /*   end  */
    
    

?>