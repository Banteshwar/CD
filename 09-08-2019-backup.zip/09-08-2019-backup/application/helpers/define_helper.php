<?php

//database Tables Name

//switch ($_SERVER["HTTP_HOST"]) {
//    case "localhost":
//        define('DEVELOPMENT', 'true');
//        break;
//    default:
//        define('DEVELOPMENT', 'false');
//        break;
//}
define('DEVELOPMENT', 'true');
define('TB_M_CLINICAL_ESTABLISHMENT_TYPES', 'm_clinical_establishment_types');
define('TB_M_CLINICAL_SERVICES', 'm_clinical_services');
define('TB_M_DISTRICTS', 'm_district');
define('TB_M_HEALTHBLOCKS', 'm_healthblock');
define('TB_M_HEALTH_FACILITY_MEMEBER_TYPES', 'm_health_faclity_member_type');
define('TB_M_INDENTIFICIATIONS', 'm_identifications');
define('TB_M_NINCODE', 'm_nincode');
define('TB_M_OWNERSHIPS', 'm_ownership');
define('TB_M_QUALIFICAITONS', 'm_qualifications');
define('TB_M_STATES', 'm_state');
define('TB_M_ASPIRATIONAL_DISTRIC', 'm_hwc_aspirational_district');
define('TB_M_SYSTEM_OF_MEDICINE', 'm_system_of_medicine');
define('TB_M_TALUKA', 'm_taluka');

define('TB_T_HEALTH_FACILITIES', 't_health_facilities');
define('TB_T_HEALTH_FACILITY_CLINICAL_ESTABLISHMENT_TYPES', 't_health_facility_clinical_establishment_types');
define('TB_T_HEALTH_FACILITY_CLINICAL_SERVICES', 't_health_facility_clinical_services');
define('TB_T_HEALTH_FACILITY_IDENTIFICATIONS', 't_health_facility_identifications');
define('TB_T_HEALTH_FACILITY_OWNERSHIP', 't_health_facility_ownership');
define('TB_T_HEALTH_FACILITY_MEMBER_INFO', 't_health_facility_member_info');
define('TB_T_HEALTH_FACILITY_QUALIFICAITONS', 't_health_facility_qualifications');
define('TB_T_HEALTH_FACILITY_SYSTEM_OF_MEDICINE', 't_health_facility_system_of_medicine');
define('TB_T_MEMBERS', 't_members');
define('TB_T_IT_INFRASTRUCTURE', 't_it_infrastructure');
define('TB_T_IT_INITIATIVES', 'it_initiatives');

define('TB_TMP_HEALTH_FACILITIES', 'tmp_health_facilities');
define('TB_TMP_HEALTH_FACILITY_CLINICAL_ESTABLISHMENT_TYPES', 'tmp_health_facility_clinical_establishment_types');
define('TB_TMP_HEALTH_FACILITY_CLINICAL_SERVICES', 'tmp_health_facility_clinical_services');
define('TB_TMP_HEALTH_FACILITY_IDENTIFICATIONS', 'tmp_health_facility_identifications');
define('TB_TMP_HEALTH_FACILITY_OWNERSHIP', 'tmp_health_facility_ownership');
define('TB_TMP_HEALTH_FACILITY_MEMBER_INFO', 'tmp_health_facility_member_info');
define('TB_TMP_HEALTH_FACILITY_QUALIFICAITONS', 'tmp_health_facility_qualifications');
define('TB_TMP_HEALTH_FACILITY_SYSTEM_OF_MEDICINE', 'tmp_health_facility_system_of_medicine');

define('TB_HMIS_HEALTH_FACILITIES', 'hmis_healthfacilities');
define('TB_HMIS_HEALTH_FACILITIES_LOG', 'hmis_healthfacilities_log');
define('TB_PHC_CSC_MSTER', 'phc_chc_master');
define('TB_TNIN_HEALTHFACLIITIES', 'tnin_healthfacilities');
define('TB_TNIN_HEALTHFACLIITIES_LOG', 'tnin_healthfacilities_log');
define('TB_T_HWC', 't_hwc');
define('TB_T_HWC_PROPOSED', 't_hwc_proposed');
define('CSRF_ERROR', 'Invalid Token,Please try to resubmit the form.');

global $USER_ROLES, $USER_PERMISSIONS, $USER_ROLES_PERMISSIONS;
global $CURRENT_USER_ROLE; // maintain current USER ROLE
global $CURRENT_USER_STATE;  // maintain current USER Belonging State
global $CURRENT_USER_DISTRICT;  // maintain current USER Belonging District
global $LOADING_TEXT;
global $PRIVATEKEY_GOOGLE_CAPTCHA;
global $PUBLICKEY_GOOGLE_CAPTCHA;
global $FILE_UPLOAD_DIRECTORY_IT_INITIATIVES;
global $OPERATION_STATUS_LIST;
global $REGION_INDICATORS;
global $OWNERSHIP_AUTHORITY_LIST;
global $FINANCIAL_YEAR;

$FILE_UPLOAD_DIRECTORY_IT_INITIATIVES = 'uploads/it_initiatives/';

$LOADING_TEXT = 'LOADNING';
$SECRET_KEY_GOOGLE_CAPTCHA = "6LdSJRETAAAAAKMhAzrm6T7BXTSgOL8lS-dpUimN";
$SITE_KEY_GOOGLE_CAPTCHA = "6LdSJRETAAAAAD1f-nHILj9WjgWflmcVc-Th_tCB";


$USER_ROLES = array(
    0 => 'Not Assigned',
    1 => 'NIN District User',
    2 => 'NIN State User',
    3 => 'Super Admin', // allowed all
    4 => 'Demo User', // allowed all
    5 => 'HWC State User',
    6 => 'HWC District User',
);


$USER_PERMISSIONS = array(
    'CHANGE_PASSWORD' => 'Change Password',
    'VIEW_USER' => 'View User',
    'ADD_USER' => 'Add User',
    'EDIT_USER' => 'Edit User',
    'DELETE_USER' => 'Delete User',
    'VIEW_HEALTH_FACILITY' => 'View Health Facility',
    'ADD_HEALTH_FACILITY' => 'Add Health Facility',
    'EDIT_HEALTH_FACILITY' => 'Edit Health Facility',
    'DELETE_HEALTH_FACILITY' => 'Delete Health Facility',
    'VIEW_TNIN_HEALTH_FACILITY' => 'View TNIN Health Facility',
    'EDIT_TNIN_HEALTH_FACILITY' => 'Edit TNIN Health Facility',
    'TNIN_MAKE_CONFIRM' => 'TNIN Make Confirm',
    'TNIN_MAKE_NOT_CONFIRM' => 'TNIN Make Not Confirm',
    'TNIN_MAKE_VERIFY' => 'TNIN Make Verify',
    'NIN_GENERATE' => 'NIN Generate',
    'NIN_MAKE_CONFIRM' => 'NIN Make Confirm',
    'NIN_MAKE_NOT_CONFIRM' => 'NIN Make Not Confirm',
    'NIN_VERIFY' => 'NIN Verify Page Access',
    'NIN_MAKE_VERIFY' => 'NIN Make Verify',
    'REPORT_VERIFICATION_CONFIRMATION' => 'Report Verification and Confirmed Health facilities',
    'SETTING_CLINICAL_ESTABLISHMENT' => 'Setting Clinical Establishment',
    'SETTING_QUALIFICATION' => 'Setting Qualificaiton',
    'VIEW_IT_INFRASTRUCTURE' => 'View IT Infrastructure',
    'UPDATE_IT_INFRASTRUCTURE' => 'UPDATE IT Infrastructure',
    'IT_INITIATIVE_UPLOAD' => 'IT Initiative Upload',
    'IT_INITIATIVE_REPORT' => 'IT Initiative Report',
    'HWC_FORM_EDIT' => 'HWC Edit',
    'HWC_FORM_ADD' => 'HWC Entry Add', //
    'HWC_VIEW' => 'HWC Entry Add', //
    'HWC_PROPOSE' => 'Propose as HWC ', //
    'HWC_UNPROPOSED' => 'UnPropose as HWC ',
    'HWC_MAKE_VERIFY' => 'HWC Make Verify ', //
    'HWC_FORM_REJECT' => 'HWC Application Reject ',
    'HWC_PLANNING' => 'HWC Planning ',
);


$USER_ROLES_PERMISSIONS = array(
    0 => array(), // not any previlege
    1 => array(
        'CHANGE_PASSWORD',
        'VIEW_HEALTH_FACILITY',
        'ADD_HEALTH_FACILITY',
        'EDIT_HEALTH_FACILITY',
        // 'VIEW_TNIN_HEALTH_FACILITY',
        'EDIT_TNIN_HEALTH_FACILITY',
        'TNIN_MAKE_CONFIRM',
        'NIN_MAKE_CONFIRM',
        'VIEW_IT_INFRASTRUCTURE',
        'UPDATE_IT_INFRASTRUCTURE'
    ), // NIN District User
    2 => array(
        'CHANGE_PASSWORD',
        'VIEW_HEALTH_FACILITY',
        'ADD_HEALTH_FACILITY',
        'EDIT_HEALTH_FACILITY',
        // 'VIEW_TNIN_HEALTH_FACILITY',
        'EDIT_TNIN_HEALTH_FACILITY',
        'TNIN_MAKE_NOT_CONFIRM',
        'TNIN_MAKE_VERIFY',
        'NIN_MAKE_NOT_CONFIRM',
        'NIN_MAKE_VERIFY',
        'REPORT_VERIFICATION_CONFIRMATION',
        'VIEW_IT_INFRASTRUCTURE',
        'UPDATE_IT_INFRASTRUCTURE',
        'IT_INITIATIVE_UPLOAD'
    ), //NIN State User
    3 => array(), // Allowed All Super Admin
    4 => array(
        'CHANGE_PASSWORD',
        'VIEW_HEALTH_FACILITY',
        // 'VIEW_USER',
        'REPORT_VERIFICATION_CONFIRMATION',
        'IT_INITIATIVE_REPORT'
    ), //NIN Demo User
    5 => array(
        'PROPOSE_AS_HWC',
        'VIEW_HEALTH_FACILITY',
        'CHANGE_PASSWORD',
        // 'VIEW_USER',
        'HWC_FORM_EDIT',
        'HWC_FORM_ADD',
        'HWC_VIEW', 
        'HWC_PROPOSE',
        'HWC_UNPROPOSED',
        'HWC_MAKE_VERIFY', 
        'HWC_FORM_REJECT',
        'HWC_PLANNING'
    ), //HWC State User
    6 => array(
        'CHANGE_PASSWORD',
        'VIEW_HEALTH_FACILITY',
        // 'VIEW_USER',
        'HWC_FORM_EDIT',
        'HWC_FORM_ADD',
        'HWC_VIEW', 
          'HWC_PROPOSE',
    ), //HWC District User
);

$REGION_INDICATORS = array('0' => '-- Please select region --', '1' => 'Rural', '2' => 'Urban');

$STATUS_ACTIVE_INACTIVE = array('0' => 'Inactive', '1' => 'Active');

$OPERATION_STATUS_LIST = array(
    '0' => '-- Please select Operational Status --',
    '1' => 'Functional',
    '2' => 'Closed',
    '3' => 'Non-Functional Under Maintenance / Others',
    '4' => 'Invalid - Does Not Exists',
    '5' => 'Duplicate'
);

$OPERATION_STATUS_LIST_ABBR = array(
    '0' => '',
    '1' => '',
    '2' => '',
    '3' => 'Non-Fun',
    '4' => 'DNE',
    '5' => ''
);

$OPERATION_STATUS_LIST_COLOR_CLASS = array(
    '0' => '',
    '1' => 'green',
    '2' => 'red',
    '3' => 'yellow',
    '4' => 'red',
    '5' => 'red'
);


$OWNERSHIP_AUTHORITY_LIST = array(
    '0' => '-- Please select Ownership Authority --',
    '1' => 'State Government',
    '13' => 'Central Government - MoHFW',
    '2' => 'Central Government - ESI',
    '3' => 'Central Government - CGHS',
    '4' => 'Central Government - Other ministries',
    '5' => 'Central Government - Railways',
    '6' => 'Central Government - Military',
    '7' => 'Private - for profit',
    '8' => 'Private - not for profit',
    '9' => 'Hospital',
    '12' => 'Municipal Corporation',
    '10' => 'Person',
    '11' => 'Others'
);


// financial year

$FINANCIAL_YEAR = array(
    '0' => '-- Select Financial Year --',
    '1617' => '2016-2017',
    '1718' => '2017-2018',
    '1819' => '2018-2019'
);

