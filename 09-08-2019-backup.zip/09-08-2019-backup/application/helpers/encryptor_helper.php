<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
if(!function_exists('encryptor')){
	function encryptor($action, $string) {
		
		
		$output = false;

		$encrypt_method = "AES-256-CBC";
		//pls set your unique hashing key
		
		$secret_key = 'ajay';
		$secret_iv = 'ajay123';

		// hash
		$key = hash('sha256', $secret_key);

		// iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
		$iv = substr(hash('sha256', $secret_iv), 0, 16);

		//do the encyption given text/string/number
		if( $action == 'encrypt' ) {
			$output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
			$output = base64_encode($output);
		}
		else if( $action == 'decrypt' ){
			
			//decrypt the given text/string/number
			$output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
		}

		return $output;
	}
}

// for get the table name against budget_type 
function get_budget_table($year=NULL,$type=NULL, $grant_no=NULL) {
	$ci=& get_instance();
	$ci->db->select('*');
	$ci->db->from('mohfw_budget_table_mapping');
	$condition = array('btm_financial_year' => $year, 'btm_budget_type'=>$type, 'btm_grant_no'=>$grant_no);
	$ci->db->where($condition);
	$query = $ci->db->get();
	if ($query->num_rows() >= 1) {
		return $query->row_array();
	} else {
		return false;
	}
	$query->free_result();
}

function getPercentage2($number = NULL, $total = NULL){
	if($total<=0){
		return '0.00';
	}else{
		$percent = ($number / $total) * 100;
		$actual_percent = number_format((float)$percent, 2, '.', '');
		return $actual_percent;
	}
}