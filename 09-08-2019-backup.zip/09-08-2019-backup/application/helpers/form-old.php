<link rel="stylesheet" href="https://jqueryvalidation.org/files/demo/site-demos.css">
<section> 
    <div class="breadcrumb_content">
        <div class="breadcrumb_text"><?php echo $this->mybreadcrumb->render(); ?></div>
        <div class="clearfix"></div>
    </div>
    <div class="right_col bg_fff" role="main">
        <div class="top_header_portal ">
           <h2>Child Health</h2>
        </div>
        <form id="myform" action="<?php echo base_url('Childhealth2/form_save'); ?>" method="POST">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_content">
                    
                    <?php if (($this->session->flashdata('success'))) { ?>
                            <div class="alert alert-success alert-dismissible" role="alert">
                                <button type="button" class="close" data-dismiss="alert">&times;</button>
                                <div class="alert-icon">
                                    <i class="fa fa-check"></i>
                                </div>
                                <div class="alert-message">
                                    <span><strong>Success!</strong> <?php echo $this->session->flashdata('success'); ?></span>
                                </div>
                            </div>
                        <?php } ?>
                        <?php if (($this->session->flashdata('required'))) { ?>
                            <div class="alert alert-danger alert-dismissible" role="alert">
                                <button type="button" class="close" data-dismiss="alert">&times;</button>
                                <div class="alert-icon">
                                    <i class="fa fa-times"></i>
                                </div>
                                <div class="alert-message">
                                    <span><strong>Error!</strong> Financial Year / Quarter is Missing </span>
                                </div>
                            </div>
                        <?php } ?>
                        <?php if (validation_errors()) {
                            ?>
                            <div class="alert alert-danger alert-dismissible" role="alert">
                                <button type="button" class="close" data-dismiss="alert">&times;</button>
                                <div class="alert-icon">
                                    <i class="fa fa-times"></i>
                                </div>
                                <div class="alert-message">
                                    <span><strong>Error!</strong>  Required Field is Missing</span>
                                </div>
                            </div>
                        <?php }
                        ?>
                        
                    
                     
                    
                     <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_content">

                        <div class="table table-responsive program_table">
                            <table class="table table-bordered example" >
                            
                            <?php $year = getFinancialYear();  ?>
                                <thead>
                                    <tr align="center" id="year_quarter">
                                       <?php 
                                       $quarterid_active=0;
                                       foreach ($year as $yearid => $yearname) { ?>
                                        <td  colspan="3"><?php echo $yearname;?><br/>
                                        
                                        <?php $quarter = getQuarter(); 
                                        
                                        
                                        ?>
                                        
                                         <?php foreach ($quarter as $quarterid => $quartername) {
                                             
                                           $active_class = ""; 
                                           
                                           if($yearid==$fin_year && $quarterid==$fin_querter)
                                           {
                                               $active_class = "active";
                                           }
                                           ?>
                                           <span id="qutr<?php echo $quarterid_active;?>" class="btn btn-light qutr <?php echo $active_class;?>" onclick="funQ('<?php echo $yearid;?>','<?php echo $quarterid;?>','<?php echo $quarterid_active;?>');"><?php echo $quartername;?></span>
                                           
                                           
                                           <?php $quarterid_active++; } ?>  
                                       
                                        
                                        <?php } ?>  
                                        
                                    </tr>
                                  
                                </thead>
                            </table>
                        </div>


                        <table class="table table-bordered example" id="">
                            <thead>
                                <tr>

                                   <th>Sr.No.</th>
                                    <th>State</th>
                                                     
                                            <th>National Deworming Day Coverage (NDD) as per round</th>
                                            <th>Intensified Diarrhoea Control Fortnight Coverage (IDCF) as per round </th>
                                            <th>Number of Children Screened by MHT under RBSK Program </th>
                                            <th>Number of Children Received Secondary/ tertiary treatment under RBSK</th>
                                            <th>No. of newborns received treatment in SNCUs</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            
                            <input type="hidden" name="year_id" id="year_id" value="<?php echo $fin_year;?>">
                                    
                                    <input type="hidden" name="q_id" id="q_id" value="<?php echo $fin_querter;?>">
                             <?php
                                 $bs_count=0;
                                    foreach ($state as $stateid => $statename) {
                                        ?>
                                <tr>
                                    <td>
                                                                        
                                    <input type="checkbox" id="check<?php echo $bs_count;?>" name="check[]" value="<?php echo $bs_count;?>" class="check_box"> <?php echo $bs_count+1;?>.</td>

                                    <td><?php echo $statename['State_Name']; ?><input type="hidden" name="state_id[]" id="state_id" value="<?php echo $statename['State_ID']; ?>"></td>
                                    
                                     <td><input class="form-control" type="number" placeholder="" value="<?php echo $statename['ndd']; ?>" name="ndd[]" id="ndd<?php echo $bs_count;?>" readonly /></td>

                                    <td><input class="form-control" type="number" placeholder="" value="<?php echo $statename['idcf']; ?>" name="idcf[]" readonly id="idcf<?php echo $bs_count;?>" /></td>

                                   

                                    
                                     <td><input class="form-control" type="number" placeholder="" value="<?php echo $statename['no_of_children_screened']; ?>" name="no_of_children_screened[]" id="no_of_children_screened<?php echo $bs_count;?>" readonly /></td>

                                    <td><input class="form-control" type="number" placeholder="" value="<?php echo $statename['no_of_children_received']; ?>" name="no_of_children_received[]" id="no_of_children_received<?php echo $bs_count;?>" readonly /></td>
                                    
                                    
                                     
                                    <td><input class="form-control" type="number" placeholder="" value="<?php echo $statename['no_of_newborns_received']; ?>" name="no_of_newborns_received[]" id="no_of_newborns_received<?php echo $bs_count;?>" readonly /></td>
                                    
                                    <!--<td><button class="btn btn-danger">Clear</button> <button class="btn btn-info">Edit</button></td>-->
                                    <td><input type="button" value="Clear" class="btn btn-danger" onclick="funClr('<?php echo $bs_count;?>');"></td>
                                </tr>
                              
                                   <?php
                                    $bs_count++;
                                    }
                                    ?>                         
                               
                             
                              
                               
                             

                            </tbody>
                        </table>
                    </div>


                    <div class="row">
                        <div class="col-lg-10">
                            <button type="button" class="btn btn-light" onclick="location.href = '<?php echo base_url("ambulance/index"); ?>'">
                                << Cancel & Back
                            </button>
                          
                            <button type="submit" name="submit" class="btn btn-primary m-btn m-btn--icon">
                                <i class="la la-search"></i> Submit
                            </button>
                        </div>
                    </div>
                    </form>

                </div>   </div>
                       
                        
                       

                  
                    </div>
                </div><!--End Row-->
            </div>
        </form>
    </div>
    <!--top tiles -->
    <!-- /page content -->
</section>

<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
<script>

$("#myform").validate({
  rules: {
    ALS_ambulances_operational[]: {
      required: true
    }
    
  }
});
</script>
<script>
    
    

function funQ(y_val,q_val,quarterid_active){

        document.getElementById('year_id').value= y_val;            
        document.getElementById('q_id').value= q_val;

            
        $('#year_quarter td span').removeClass('active');
        
         $('#qutr'+quarterid_active).addClass('active');

        

        // $('#qutr'+quarterid_active).addClass('active').siblings().removeClass('active');

            var ID = y_val;
            var url1 = '<?php echo base_url(); ?>';
            if (ID) { 
                $.ajax({
                    url: url1 + 'Ambulance/change_val_ajax/' + y_val + '/'+ q_val,
                    type: "GET",
                    dataType: "json",
                    success: function (data) {
                      
                      for(var count = 0; count < data.length; count++)
                           {
                               
                               
                               document.getElementById('ndd'+count).value= data[count].ndd;
                               document.getElementById('idcf'+count).value= data[count].idcf;
                               document.getElementById('no_of_children_screened'+count).value= data[count].no_of_children_screened;
                               document.getElementById('no_of_children_received'+count).value= data[count].no_of_children_received;
                               document.getElementById('no_of_newborns_received'+count).value= data[count].no_of_newborns_received;
                              
                           }
                       
                    }
                });
            }

       }
        
    
  /*$(document).on('click', '.qutr', function(){ 
        
        
    if(this.id){
        alert(this.id);
        $("#qutr"+this.id).addClass("active");
    }else{
        //$("#qutr"+this.id).removeClass("active");
    }

    }); */


        
    $(document).on('click', '.check_box', function(){ 
        
         if(this.checked)
        {
            // alert(this.value);
            //alert('checked');
         $("#ndd"+this.value).removeAttr("readonly"); 
        $("#idcf"+this.value).removeAttr("readonly");
        $("#no_of_children_screened"+this.value).removeAttr("readonly");
        $("#no_of_children_received"+this.value).removeAttr("readonly");        
        $("#no_of_newborns_received"+this.value).removeAttr("readonly");
        
        
        }
        else
        {
            
        $("#ndd"+this.value).attr("readonly",true); 

         $("#idcf"+this.value).attr("readonly",true); 
        $("#no_of_children_screened"+this.value).attr("readonly",true); 
        $("#no_of_children_received"+this.value).attr("readonly",true); 
        
        $("#no_of_newborns_received"+this.value).attr("readonly",true); 
        
        }

    }); 
        
        
    $(document).ready(function () {
        

        $("#printButton").click(function () {
            var mode = 'iframe'; //popup
            var close = mode == "popup";
            var options = {mode: mode, popClose: close};
            $("div.printableArea").printArea(options);
        });
        
        
    
        
        
        
    });
</script>
