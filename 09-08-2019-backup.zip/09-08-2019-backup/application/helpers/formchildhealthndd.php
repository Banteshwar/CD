
<section> 
    <div class="breadcrumb_content">
        <div class="breadcrumb_text"><?php echo $this->mybreadcrumb->render(); ?></div>
        <div class="clearfix"></div>
    </div>
    <div class="right_col bg_fff" role="main">
        <div class="top_header_portal ">
            <h2>CHILD HEALTH </h2>
        </div>
        <form id="myform" action="<?php echo base_url('Childhealthndd/form_save'); ?>" method="POST">


            <?php if (($this->session->flashdata('success'))) { ?>
                <div class="alert alert-success alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <div class="alert-icon">
                        <i class="fa fa-check"></i>
                    </div>
                    <div class="alert-message">
                        <span><strong>Success!</strong> Data has been submitted successfully for <?php echo 'Bi-annual '. $fin_month .' '. $fin_year; ?></span>
                    </div>
                </div>
            <?php } ?>
            <?php if (($this->session->flashdata('required'))) { ?>
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <div class="alert-icon">
                        <i class="fa fa-times"></i>
                    </div>
                    <div class="alert-message">
                        <span><strong>Error!</strong> Financial Year </span>
                    </div>
                </div>
            <?php } ?>
            <?php if (validation_errors()) {
                ?>
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <div class="alert-icon">
                        <i class="fa fa-times"></i>
                    </div>
                    <div class="alert-message">
                        <span><strong>Error!</strong>  Required Field is Missing</span>
                    </div>
                </div>
            <?php }
            ?>

           <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_content">
                      
                                 <div class="row-crousel1">
                                        <div class="col-sm-12 columns">
                                            <div class="owl-carousel">
                                             <?php
                                                  
                                                  $quarterid_active = 0;
                                                  $year = getYearFull();

                                                  foreach ($year as $yearid => $yearname) {
                                                    $month = getbiannual();

                                                    $monthnum = date('m');
                                                    $yearnum = date('Y');
                                                   
                                                    foreach ($month as $monthid => $monthname) {

                                                    $active_class = "";

                                                    if ($yearid==$yearnum && $fin_month == $monthid) {
                                                         $active_class = "active";
                                                    }
                                                            
                                                ?>
                                               <div class="item">
                                                    <div class="tile-stats2 bg-white-sky quarter_button1" id="year_quarter">  
                                                        <div class="count <?php echo $active_class; ?>" onclick="funQ('<?php echo $yearname; ?>','<?php echo $monthid; ?>', '<?php echo $quarterid_active; ?>');" id="qutr<?php echo $quarterid_active; ?>">
                                                            <span ><?php echo $yearname; ?></span>
                                                            <span><?php echo $monthname; ?></span>
                                                       
                                                        </div>

                                                    </div>
                                                </div>

                                              <?php $quarterid_active++;} ?>
                                                 <?php } ?>
                                              
                                             
                                    </div>
                                </div>
                        <div class="table_form_data">
                        <table class="table table-bordered example" id="">
                            <thead>
                                <tr>

                                  <th width="80px;"><input type="checkbox" class="ckbCheckAll" />Select All<br/>Sr.No.</th>
                                    <th>State</th>
                                    <th>Number of children covered under National Deworming Day (NDD)</th>                        
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>

                            <input type="hidden" name="year_id" id="year_id" value="">
                           <input type="hidden" name="e_month" id="y_month" value="">
                            <?php
                            $bs_count = 0;
                            foreach ($state as $stateid => $statename) {
                                ?>
                                <tr>
                                    <td><input type="checkbox" id="check<?php echo $bs_count; ?>" name="check[]" value="<?php echo $bs_count; ?>" class="check_box"> <?php echo $bs_count + 1; ?>.</td>

                                    <td><?php echo $statename['State_Name']; ?><input type="hidden" name="state_id[]" id="state_id" value="<?php echo $statename['State_ID']; ?>"></td>

                                     <td><input class="form-control chckbox" type="number" placeholder="" value="<?php echo $statename['ndd']; ?>" name="ndd[]" id="ndd<?php echo $bs_count; ?>" readonly /></td>

                              
                                    <td><input type="button" value="Clear" class="btn btn-danger" onclick="funClr('<?php echo $bs_count; ?>');"></td>
                                </tr>

                                <?php
                                $bs_count++;
                            }
                            ?>                                 

                            </tbody>
                        </table>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-10"> 
                        <!--<input type="button" value="Edit" class="btn btn-info" id="checkall"> -->
                                            <div class="ck-button"> 
                                            <lable>
                                              <input type="checkbox"  class="btn btn-info ckbCheckAll" style="">
                                              <span>Edit All</span>
                                          </lable>
                                        </div>
                        
                        <button type="submit" name="submit" class="btn btn-primary m-btn m-btn--icon">
                                <i class="la la-search"></i> Submit
                            </button>
                        </div>
                    </div>
                    </form>
                </div>  
            </div>
    </div>
</div><!--End Row-->
</div>
</form>
</div>
<!--top tiles -->
<!-- /page content -->
</section>


<script>
            //////////////// change value of table according to quarter ///////////

           function funQ(y_val, y_month,quarterid_active){ 

                   document.getElementById('year_id').value = y_val;                   
                   document.getElementById('y_month').value = y_month;
                    $('#year_quarter div').removeClass('active');
                    $('#qutr' + quarterid_active).addClass('active');
                    // $('#qutr'+quarterid_active).addClass('active').siblings().removeClass('active');

                    var ID = y_val;
                    var url1 = '<?php echo base_url(); ?>';
                
                    if (ID) {
            $.ajax({
            url: url1 + 'Childhealthndd/change_val_ajax/' + y_val,
                    type: "GET",
                    dataType: "json",
                    success: function (data) {

                    for (var count = 0; count < data.length; count++)
                    {
                         document.getElementById('ndd' + count).value = data[count].idcf;             
                    }

                    }
            });
            }
        }
            
            
            //////////////// end value of table according to quarter ///////////

    /////////// remove readonly function on click checkbox //////////

    $(document).on('click', '.check_box', function(){

    if (this.checked)
    {
    // alert(this.value);
    //alert('checked');
    $("#ndd" + this.value).removeAttr("readonly");
            
    }
    else
    {

    $("#ndd" + this.value).attr("readonly", true);           
    }

   });        
            function funClr(id)
            {
                var isChecked = $('#check' + id).prop('checked');
                        if (isChecked)
                {
                     $("#ndd" + id).val('');
                }
                else{
                     alert('Please Select State');
                }

            }
            
            //////// end clear row on click clear button //////////
    

    $(document).ready(function () { 
    $('.owl-stage-outer').trigger('to.owl.carousel', 10);
        $("form").submit(function(){
       if ($('input:checkbox').filter(':checked').length < 1){
        alert("Check at least one State");
       return false;
       }
      });
            
    });   
    
</script>


<script type="text/javascript">
    $(document).ready(function () {
        $(".ckbCheckAll").click(function () {
            //$(".check_box").attr('checked', this.checked);

            if($(this).prop("checked")) {
                $(".check_box").prop("checked", true);

                $(".chckbox").removeAttr("readonly");

            $("#ndd" + this.value).removeAttr("readonly");
            
            } else {
                $(".check_box").prop("checked", false);
                 $(".chckbox").attr("readonly",true);

           $("#ndd" + this.value).attr("readonly", true);  
            } 

        });
    });
</script>

<style>
   
</style>