<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * @return boolean return TRUE if a session was successfully started
 */
function my_session_start() {
    $sn = session_name();
    if (isset($_COOKIE[$sn])) {
        $sessid = $_COOKIE[$sn];
    } else if (isset($_GET[$sn])) {
        $sessid = $_GET[$sn];
    } else {
        return session_start();
    }

    if (!preg_match('/^[a-zA-Z0-9,\-]{22,40}$/', $sessid)) {
        return false;
    }
    return @session_start();
}

//Custom session start
function session_start_custom() {
    if (!my_session_start()) {
        session_id(uniqid());
        session_start();
        session_regenerate_id();
    }
}

/**
 * Read file and return string
 * @param string $filename
 * @return string
 *  */
function file_get_string($filename) {
    $string = '';
    $file_handle = fopen($filename, "r");
    while (!feof($file_handle)) {
        $string .= fgets($file_handle);
//  echo $string;
    }
    fclose($file_handle);
    return $string;
}

/**
 * Get Current Page
 * @return type
 */
function currentPageURLAdd() {
    return 'previous=' . base64_encode($_SERVER['REQUEST_URI']);
}

function previousPageURL() {

    if (isset($_REQUEST['previous'])) {
        return base64_decode($_REQUEST['previous']);
    }
    return false;
}

function previousInput() {
    if (isset($_REQUEST['previous'])) {
        return '<input type="hidden" value="' . $_REQUEST['previous'] . '" name="previous" >';
    }
    return false;
}

function previousParam() {

    if (isset($_REQUEST['previous'])) {
        return 'previous=' . $_REQUEST['previous'];
    }
    return false;
}

/**
 * Retrun on previous url
 * @param type $url
 * @return string
 */
function redirectPreviusURL($url = '') {
    $preURL = previousPageURL();
    if ($preURL) {
        return $preURL;
    }
    if ($url != '') {
        return $url;
    }
    return "index.php";
}

/* find if hospital Id is valid */

function isValidStateId($State_ID) {
    global $db;
    $State_ID = intval($State_ID);
    $stmt = $db->prepare('SELECT * FROM ' . TB_M_STATES . ' WHERE State_ID = :State_ID');
    $stmt->execute(array(
        ':State_ID' => $State_ID
    ));
    $row = $stmt->fetch();
    if ($row) {
        return true;
    } else {
        return false;
    }
}

/**
 * get state Name based on State Id
 * @global type $db
 * @param type $stateId
 * @return type
 */
function getStatesName($stateId) {
    global $db;

    $stmt = $db->prepare('SELECT State_ID, State_Name FROM ' . TB_M_STATES . ' where State_ID = :State_ID ');
    $stmt->execute(array(
        ':State_ID' => intval($stateId)
    ));

    while ($row = $stmt->fetch()) {
        return $row['State_Name'];
    }
    return FALSE;
}

/* find if hospital Id is valid */

function isValidDistrictId($State_ID, $District_ID) {
    global $db;
    $State_ID = intval($State_ID);
    $District_ID = intval($District_ID);
    $stmt = $db->prepare('SELECT * FROM ' . TB_M_DISTRICTS . ' WHERE State_ID = :State_ID and District_ID = :District_ID ');
    $stmt->execute(array(
        ':State_ID' => $State_ID,
        ':District_ID' => $District_ID
    ));
    $row = $stmt->fetch();
    if ($row) {
        return true;
    } else {
        return false;
    }
}

/* find if hospital Id is valid */

function isValidTalukaId($State_ID, $District_ID, $Taluka_ID) {
    global $db;
    $State_ID = intval($State_ID);
    $District_ID = intval($District_ID);
    $stmt = $db->prepare('SELECT * FROM ' . TB_M_TALUKA . ' WHERE State_ID = :State_ID '
            . ' and District_ID = :District_ID and Taluka_ID = :Taluka_ID');
    $stmt->execute(array(
        ':State_ID' => $State_ID,
        ':District_ID' => $District_ID,
        ':Taluka_ID' => $Taluka_ID,
    ));
    $row = $stmt->fetch();
    if ($row) {
        return true;
    } else {
        return false;
    }
}

/* find if hospital Id is valid */

function isValidHealthBlockId($State_ID, $District_ID, $Taluka_ID, $Block_ID) {
    global $db;
    $State_ID = intval($State_ID);
    $District_ID = intval($District_ID);

    $params = array(
        ':State_ID' => $State_ID,
        ':District_ID' => $District_ID,
        ':Block_ID' => $Block_ID,
    );
    if ($Taluka_ID != '0') {
        $sql = 'SELECT * FROM ' . TB_M_HEALTHBLOCKS . ' WHERE State_ID = :State_ID '
                . ' and District_ID = :District_ID and Taluka_ID = :Taluka_ID and Block_ID = :Block_ID ';
        $params[':Taluka_ID'] = $Taluka_ID;
    } else {
        $sql = 'SELECT * FROM ' . TB_M_HEALTHBLOCKS . ' WHERE State_ID = :State_ID '
                . ' and District_ID = :District_ID and Block_ID = :Block_ID ';
    }

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $row = $stmt->fetch();
    if ($row) {
        return true;
    } else {
        return false;
    }
}

/**
 *
 * @global type $db
 * @param type $stateId
 * @param type $districtId
 * @return String District Name
 */
// get all Distric Name
function getDistrictName($stateId, $districtId) {
    global $db;
    $sql = 'SELECT District_ID, District_Name FROM  ' . TB_M_DISTRICTS
            . ' WHERE  State_ID = :State_ID and District_ID = :District_ID ';
    $stmt = $db->prepare($sql);
    $params = array(
        ':State_ID' => intval($stateId),
        ':District_ID' => intval($districtId)
    );
// print_r($params);
    $stmt->execute($params);

    while ($row = $stmt->fetch()) {

        return $row['District_Name'];
    }

    return false;
}

/**
 *  Get List of Talukas by Taluka
 * @global type $db
 * @param type $talukaId
 * @return String Taluka Name
 */
// get all Distric Name
function getTalukName($talukaId) {
    global $db;
    $sql = 'SELECT Taluka_ID, Taluka_Name FROM ' . TB_M_TALUKA
            . ' WHERE Taluka_ID = :Taluka_ID ';
    $stmt = $db->prepare($sql);
    $params = array(
        ':Taluka_ID' => intval($talukaId)
    );
// print_r($params);
    $stmt->execute($params);
    while ($row = $stmt->fetch()) {
        return $row['Taluka_Name'];
    }
    return false;
}

/**
 *
 * @global type $db
 * @param type $blockId
 * @return String Block Name
 */
// get all Distric Name
function getHealthBlockName($blockId) {
    global $db;
    $sql = 'SELECT Block_ID, Block_Name FROM  ' . TB_M_HEALTHBLOCKS
            . ' WHERE Block_ID = :Block_ID ';
    $stmt = $db->prepare($sql);
    $params = array(
        ':Block_ID' => intval($blockId)
    );
// print_r($params);
    $stmt->execute($params);
    while ($row = $stmt->fetch()) {
        return $row['Block_Name'];
    }
    return false;
}

// get all states list order by State Name
function getStatesList($emptyFirstRow = false) {
    global $db;

    $states = array();
    if ($emptyFirstRow) {
        $states['0'] = '-- Select a State --';
    }

    $stmt = $db->prepare('SELECT State_ID, State_Name FROM ' . TB_M_STATES . ' order by State_Name');
    $stmt->execute();

    while ($row = $stmt->fetch()) {
        
        $states[$row['State_ID']] = $row['State_Name'];
    }
   
    return $states;
}

/*function getStatesList($emptyFirstRow = false) {
    global $db;

    $states = array();
    if ($emptyFirstRow) {
        $states['0'] = '-- Select a State --';
    }

    $stmt = $db->prepare('SELECT state FROM ' . HWC_TOP_DASHBOARD . ' where state != "0" order by state');
    
    $stmt->execute();

    while ($row = $stmt->fetch()) {
        
        $states[] = $row['state'];
    }
   // print_r($states); die;
    return $states;
}*/

// get all district list order by Distric Name
function getDistrictList($state, $emptyFirstRow = false) {
    global $db;

    $districts = array();
    if ($emptyFirstRow) {
        $districts['0'] = '-- Select a District --';
    }
    if ($state > 0) {
        $sql = 'SELECT District_ID, District_Name FROM  ' . TB_M_DISTRICTS
                . ' WHERE  State_ID = :State_ID ORDER by District_Name';
        $stmt = $db->prepare($sql);
        $stmt->execute(array(
            ':State_ID' => intval($state)
        ));

        while ($row = $stmt->fetch()) {
            $districts[$row['District_ID']] = $row['District_Name'];
        }
    }

    return $districts;
}

// get all states list order by Taluka Name
function getTalukaList($state, $district, $emptyFirstRow = false) {
    global $db;

    $talukas = array();
    if ($emptyFirstRow) {
        $talukas['0'] = '-- Select a Taluka --';
    }
    if ($state > 0 && $district > 0) {
        $stmt = $db->prepare('SELECT Taluka_ID, Taluka_Name FROM ' . TB_M_TALUKA
                . ' WHERE  State_ID = :State_ID and District_ID = :District_ID ORDER by Taluka_Name');
        $stmt->execute(array(
            ':State_ID' => $state,
            ':District_ID' => $district
        ));


        while ($row = $stmt->fetch()) {
            $talukas[$row['Taluka_ID']] = $row['Taluka_Name'];
        }
    }
    return $talukas;
}

// get all states list order by Health Block Name
function getHealthblockList($state, $district, $taluka, $emptyFirstRow = false) {
    global $db;

    $healthBlocks = array();
    if ($emptyFirstRow) {
        $healthBlocks['0'] = '-- Select a Health Block  --';
    }

    if ($state > 0 && $district) {
        if ($taluka == '0') {
            $stmt = $db->prepare('SELECT Block_ID, Block_Name FROM  ' . TB_M_HEALTHBLOCKS
                    . ' WHERE  State_ID = :State_ID and District_ID = :District_ID ORDER by Block_Name');
            $stmt->execute(array(
                ':State_ID' => $state,
                ':District_ID' => $district
            ));
        } else {
            $stmt = $db->prepare('SELECT Block_ID, Block_Name FROM  ' . TB_M_HEALTHBLOCKS
                    . ' WHERE  State_ID = :State_ID and District_ID = :District_ID and Taluka_ID = :Taluka_ID ORDER by Block_Name');
            $stmt->execute(array(
                ':State_ID' => $state,
                ':District_ID' => $district,
                ':Taluka_ID' => $taluka,
            ));
        }

        while ($row = $stmt->fetch()) {
            $healthBlocks[$row['Block_ID']] = $row['Block_Name'];
        }
    }
    return $healthBlocks;
}

// get all Facility Type list order by Name
function getFacilityTypeList($emptyFirstRow = false) {
    global $db;

    $states = array();
    if ($emptyFirstRow) {
        $states['0'] = '-- Select a Facility Type --';
    }

    $stmt = $db->prepare('SELECT PHC_CHC_ID, PHC_CHC_Type FROM ' . TB_PHC_CSC_MSTER . ' order by PHC_CHC_ID');
    $stmt->execute();

    while ($row = $stmt->fetch()) {
        $states[$row['PHC_CHC_ID']] = $row['PHC_CHC_Type'];
    }
    return $states;
}

function isValidFacilityType($facility_type) {
    $facilityTypeList = getFacilityTypeList(true);
    $facility_type = intval($facility_type);
    return array_key_exists($facility_type, $facilityTypeList);
}

function activeLink($link, $linkclass) {
    $matchingLink = basename($_SERVER['PHP_SELF']);
    if (is_array($link)) {
        if (in_array($matchingLink, $link)) {
            return $linkclass;
        }
    } else if ($matchingLink == $link) {
        return $linkclass;
    }
    return '';
}

/**
 * get state Name based on State Id
 * @global type $db
 * @param type $stateId
 * @return type
 */
function getFacitlityName($typeId) {
    global $db;

    $stmt = $db->prepare('SELECT PHC_CHC_ID, PHC_CHC_Type from ' . TB_PHC_CSC_MSTER . ' where PHC_CHC_ID = :PHC_CHC_ID ');
    $stmt->execute(array(
        ':PHC_CHC_ID' => intval($typeId)
    ));

    while ($row = $stmt->fetch()) {
        return $row['PHC_CHC_Type'];
    }
    return FALSE;
}

/**
 *
 * @param type $inputSting
 * @param type $state
 * @param type $district
 * @param type $checkConfirmed  0 or 1
 * @return boolean false or Array with index State_ID, District_ID, HFI_Code, HFI_Type , NIN_2_HFI
 */
function verifyParamsForUpdate($inputSting, $state, $district, $checkConfirmed) {
    global $db;

    $input_str = filter_var($inputSting, FILTER_SANITIZE_STRING);
    $inputArray = explode("-", $input_str);
    if (count($inputArray) == 3) {
        $paramsUpdates['State_ID'] = intVal($inputArray[0]);
        $paramsUpdates['District_ID'] = intVal($inputArray[1]);
        $paramsUpdates['NIN_2_HFI'] = addslashes($inputArray[2]);
        if ($paramsUpdates['State_ID'] == $state && $paramsUpdates['District_ID'] == $district && trim($paramsUpdates['NIN_2_HFI']) != '') {

            $checkConfirmedCond = '';
            if ($checkConfirmed == 1) {
                $checkConfirmedCond = ' and confirmed_flag = 1 ';
            }

            $query = " select count(*) as cnt
                         FROM  " . TB_HMIS_HEALTH_FACILITIES . "
                         where
                         State_ID = :State_ID
                         and District_ID = :District_ID
                         and NIN_2_HFI  = " . $paramsUpdates['NIN_2_HFI'] . "
                         and verified_flag<>1 " . $checkConfirmedCond;
            $stmt = $db->prepare($query);
            $tmpParam = $paramsUpdates;
            unset($tmpParam['NIN_2_HFI']);  // it is larger than int size in PHP
// var_dump($tmpParam);
            $stmt->execute($tmpParam);
            $row = $stmt->fetch();
//print_r($row);
            if ($row['cnt'] == 1) {
//  echo "amit";
                return $paramsUpdates;
            }
//echo "kumar";
            return false;
        }
        error_message('Wrong input parameters or you do no have permission.');
        return false;
    }
    error_message('Wrong input parameters ');
    return false;
}

function updateConfirmOrVerify($paramsUpdates, $updateField) {
    global $db;
    $query = " update " . TB_HMIS_HEALTH_FACILITIES . "
                         set " . $updateField . "
                         where
                         State_ID = :State_ID
                         and NIN_2_HFI  =  " . $paramsUpdates['NIN_2_HFI'] . "
                         limit 1";
    $stmt = $db->prepare($query);
    $tmpParam = $paramsUpdates;
    unset($tmpParam['NIN_2_HFI']);
    unset($tmpParam['District_ID']);  // it is more than int size in PHP
// var_dump($tmpParam);
    $stmt->execute($tmpParam);

    status_message('Record Updated Successfully!');
}

/**
 *
 * @global type $CURRENT_USER_ROLE
 * @param type $user
 * @return boolean result true if state / District User
 */
function isHavingState($user) {
    global $CURRENT_USER_ROLE;
// global $CURRENT_USER_STATE;
// global $CURRENT_USER_DISTRICT;
    if ($user->is_logged_in()) {
        if (($CURRENT_USER_ROLE == 1 || $CURRENT_USER_ROLE == 2 || $CURRENT_USER_ROLE == 5 || $CURRENT_USER_ROLE == 6)) {
            return true;
        }
    }
    return false;
}

/**
 *
 * @global type $CURRENT_USER_ROLE
 * @param type $user
 * @return boolean  return true in case of state District User
 */
function isHavingDistrict($user) {
    global $CURRENT_USER_ROLE;
// global $CURRENT_USER_STATE;
//global $CURRENT_USER_DISTRICT;
    if ($user->is_logged_in()) {
        if ($CURRENT_USER_ROLE == 1 || $CURRENT_USER_ROLE == 6) {
            return true;
        }
    }
    return false;
}

/**
 *
 * @global type $CURRENT_USER_ROLE
 * @param type $user
 * @return boolean  return true in case of state District User
 */
function isDistrictUser($user) {
    global $CURRENT_USER_ROLE;
// global $CURRENT_USER_STATE;
//global $CURRENT_USER_DISTRICT;
    if ($user->is_logged_in()) {
        if ($CURRENT_USER_ROLE == 1 || $CURRENT_USER_ROLE == 6) {
            return true;
        }
    }
    return false;
}

/**
 *  Verify if Lantitude value is in range. Upto 10 dicimal places
 * @param type $latitude
 * @return boolean
 */
function isValidLatitude($latitude) {
    if (preg_match("/^-?([1-8]?[1-9]|[1-9]0)\.{1}\d{1,10}$/", $latitude)) {
        return true;
    } else {
        return false;
    }
}

/**
 * Verify if Longitude value is in range. Upto 10 dicimal places
 * @param type $longitude
 * @return boolean
 */
function isValidLongitude($longitude) {
    if (preg_match("/^-?([1]?[1-7][1-9]|[1]?[1-8][0]|[1-9]?[0-9])\.{1}\d{1,10}$/", $longitude)) {
        return true;
    } else {
        return false;
    }
}

/**
 * Verify if Altitude value is in range. Upto 4 dicimal places
 * @param type $longitude
 * @return boolean
 */
function isValidAltitude($altitude) {
    if (preg_match("/^-?([0-9]{0,4})(\.[0-9]{0,4})?$/", $altitude)) {
        return true;
    } else {
        return false;
    }
}

/**
 * check if Region Indicator is valid
 * @global type $REGION_INDICATORS
 * @param type $region_indicator
 * @return boolean
 */
function isValidRegionIndicator($region_indicator) {
    global $REGION_INDICATORS;
    if (array_key_exists($region_indicator, $REGION_INDICATORS)) {
        return true;
    } else {
        return false;
    }
}

/**
 * get Region Indicator Name
 * @global type $REGION_INDICATORS
 * @param type $region_indicator
 * @return boolean
 */
function getRegionIndicatorName($region_indicator) {
    global $REGION_INDICATORS;
    if ($region_indicator == 0) {
        return '';
    }
    if (array_key_exists($region_indicator, $REGION_INDICATORS)) {
        return $REGION_INDICATORS[$region_indicator];
    }
    return '';
}

/**
 * check if Operation status is valid
 * @global type $OPERATION_STATUS_LIST
 * @param type $region_indicator
 * @return boolean
 */
function isValidOperationStatus($operational_status) {
    global $OPERATION_STATUS_LIST;
    if (array_key_exists($operational_status, $OPERATION_STATUS_LIST)) {
        return true;
    } else {
        return false;
    }
}

/**
 * get Operation status Name
 * @global type $OPERATION_STATUS_LIST
 * @param type $region_indicator
 * @return boolean
 */
function getOperationStatusName($operational_status) {
    global $OPERATION_STATUS_LIST;
    if ($operational_status == 0) {
        return '';
    }
    if (array_key_exists($operational_status, $OPERATION_STATUS_LIST)) {
        return $OPERATION_STATUS_LIST[$operational_status];
    } else {
        return '';
    }
}

/**
 * Check if Ownership Authorityis valid
 * @global type $OWNERSHIP_AUTHORITY_LIST
 * @param type $ownership_authority
 * @return boolean
 */
function isValidOwnershipAuthority($ownership_authority) {
    global $OWNERSHIP_AUTHORITY_LIST;
    if (array_key_exists($ownership_authority, $OWNERSHIP_AUTHORITY_LIST)) {
        return true;
    } else {
        return false;
    }
}

/**
 * get OwnershipAuthority Name
 * @global type $OWNERSHIP_AUTHORITY_LIST
 * @param type $ownership_authority
 * @return boolean
 */
function getOwnershipAuthorityName($ownership_authority) {
    global $OWNERSHIP_AUTHORITY_LIST;

    if ($ownership_authority == 0) {
        return '';
    }
    if (array_key_exists($ownership_authority, $OWNERSHIP_AUTHORITY_LIST)) {
        return $OWNERSHIP_AUTHORITY_LIST[$ownership_authority];
    } else {
        return '';
    }
}

/**
 * Find if error present and return error class 'error_imput'
 * @param type $name
 * @param type $error
 * @return string
 */
function errorInputClass($name, $error) {
//echo $name; print_r($error);exit;
    if (!is_array($error)) {
        return '';
    }
    if (array_key_exists($name, $error)) {
        return 'has-error';
    }
    return '';
}

/**
 *
 * @param type $name
 * @param type $error
 */
function errorInputDisplay($name, $error) {
    if (!is_array($error)) {
        return '';
    }
    if (array_key_exists($name, $error)) {
        return '<span class="help-block">' . $error[$name] . '</span>';
    }
    return '';
}

/**
 *  Google Captcha Version 2.0
 * @param type $seckey
 * @param type $captcha
 * @return type
 */
function isValidCaptcha($seckey, $captcha) {

    try {

        $url = 'https://www.google.com/recaptcha/api/siteverify';
        $data = array('secret' => $seckey,
            'response' => $captcha,
            'remoteip' => $_SERVER['REMOTE_ADDR']);

        $options = array(
            'http' => array(
                'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                'method' => 'POST',
                'content' => http_build_query($data)
            )
        );

        $context = stream_context_create($options);
        $result = file_get_string($url, false, $context);
// echo $result;
        return json_decode($result)->success;
    } catch (Exception $e) {
        return null;
    }
}

/**
 * get Row find if NIN exists
 * @param type $nin
 * @return boolean
 */
function getRowByNIN($nin) {
    global $db;
    if (!preg_match('/^[1-9]{1}[0-9]{9}$/', $nin)) {
        return false;
    }
    $stmt = $db->prepare('SELECT * FROM ' . TB_HMIS_HEALTH_FACILITIES . ' WHERE NIN_2_HFI = :nin');
    $stmt->execute(array(':nin' => $nin));
    $rowFacility = $stmt->fetch();
    return $rowFacility;
}

function getFacilityInfo($nin) {
    global $db;
    $query = "select
                          hf.NIN_2_HFI,
                          hf.HFI_Name,
                          hf.State_ID,
                          hf.District_ID,
                          hf.HFI_Type,
                          hf.confirmed_flag,
                          hf.verified_flag,
                          hf.house_number,
                          hf.street,
                          hf.landmark,
                          hf.locality,
                          hf.pincode,
                          hf.landline_number,
                          hf.in_charge_mobile,
                          hf.email,
                          hf.latitude,
                          hf.longitude,
                          hf.altitude,
                          hf.region_indicator,
                          hf.operational_Status,
                          hf.ownership_authority,
                          hf.Created_On,
                          pcm.PHC_CHC_Type,
                          s.State_Name,
                          d.District_Name,
                          t.Taluka_Name,
                          da.aspirational,
                          b.Block_Name
                          from " . TB_HMIS_HEALTH_FACILITIES . " hf
                          Left join " . TB_PHC_CSC_MSTER . " pcm on hf.HFI_Type=pcm.PHC_CHC_ID
                          Left join " . TB_M_STATES . " s on hf.State_ID=s.State_ID

                          Left join " . TB_M_DISTRICTS . " d on hf.District_ID=d.District_ID
                                Left join " . TB_M_ASPIRATIONAL_DISTRIC . " da on d.District_ID=da.District_ID
                          Left join " . TB_M_TALUKA . " t on hf.Taluka_ID=t.Taluka_ID
                          Left join " . TB_M_HEALTHBLOCKS . " b on hf.HealthBlock_ID=b.Block_ID  WHERE hf.NIN_2_HFI=" . $nin;



    $stmt = $db->query($query);
    $row = $stmt->fetch();

    return $row;
}



function getRowByTNIN($tnin) {
    global $db;
    if (!preg_match('/^[0-9]{1,10}$/', $tnin)) {
        return false;
    }
    $stmt = $db->prepare('SELECT * FROM ' . TB_TMP_HEALTH_FACILITIES . ' WHERE TNIN = :tnin');
    $stmt->execute(array(':tnin' => $tnin));
    $rowFacility = $stmt->fetch();
    return $rowFacility;
}

/**
 * Make a Text input box
 * @param type $name
 * @param type $defaultValue
 * @param type $id
 * @return string
 */
function buildInputText($name = '', $defaultValue = '', $id = '') {
    $inputTextString = '<input type="text" ';
    if ($name != '') {
        $inputTextString .= 'name="' . $name . '" ';
    }
    if ($id != '') {
        $inputTextString .= 'id="' . $id . '" ';
    }
    if ($defaultValue != '') {
        $inputTextString .= 'value="' . $defaultValue . '" ';
    }
    $inputTextString .= '>';
    return $inputTextString;
}

/*
  function buildInputTextLabel($name ='', $defaultValue ='', $id = '', $required = false, $class = '', $error = array()) {
  $text = '<div class="form-row '. errorInputClass($name,$error).'" >
  <label class="ful_length">
  <span>Name of Health Facility: <span class="star_red">*</span></span>
  '.buildInputText($name, $defaultValue , $id ).'
  <input type="text" name="facility_name" value="<?php if(isset($facility_name)){ echo $facility_name;}?>" required>
  </label>
  errorInputDisplay('facility_name',$error);
  </div>';
  } */

/**
 * Make a select input box
 * @param type $name
 * @param type $list
 * @param type $selectValue
 * @param type $id
 * @return string
 */
function buildInputSelect($name = '', $list = array(), $selectValue = '', $id = '') {
    $inputSelectString = '<select ';
    if ($name != '') {
        $inputSelectString .= 'name="' . $name . '" ';
    }
    if ($id != '') {
        $inputSelectString .= 'id="' . $id . '" ';
    }
    $inputSelectString .= '>';

    if (count($list) > 0) {
        foreach ($list as $id => $value) {
            $inputSelectString .= '<option value="' . $id . '" ';
            if (isset($selectValue) && $selectValue == $id) {
                $inputSelectString .= 'selected ';
            }
            $inputSelectString .= '>' . $value . '</option> ';
        }
    }

    $inputSelectString .= '</select>';
    return $inputSelectString;
}

function buildInputButton($name = '', $value = '', $id = '', $attributes = array()) {
    $inputButtonString = '<button type="button" ';
    if ($name != '') {
        $inputButtonString .= 'name="' . $name . '" ';
    }
    if ($id != '') {
        $inputButtonString .= 'id="' . $id . '" ';
    }
    if (count($attributes) > 0) {
        foreach ($attributes as $attrName => $attrValue) {
            $inputButtonString .= $attrName . '="' . $attrValue . '" ';
        }
    }
    $inputButtonString .= '>';

    if ($value != '') {
        $inputButtonString .= $value;
    }


    $inputButtonString .= '</button>';
    return $inputButtonString;
}

/**
 * Display Parent child wise ol li format
 * @param type $elements
 * @param type $id
 * @param type $name
 * @return string
 */
function displayItems($elements, $id = 'id', $name = 'name', $extra = array()) {
    $branch = '';
    foreach ($elements as $element) {
        /* if ($element['status'] == 1) {
          $inActiveClass = '';
          } else {
          $inActiveClass = 'status_inactive';
          } */
        $branch .= '<li  class="dd-item" data-list_id="' . $element[$id] . '" >';
        $branch .= '<div class="dd-handle">' . $element[$name];
        if (!empty($extra)) {
            $branch .= ' <span class="hierachy_detail_help">(';
            foreach ($extra as $value) {
                if (trim($element[$value]) == '') {
                    continue;
                }
                $branch .= '<span class="' . $value . '">' . $element[$value] . '</span>, ';
            }
            $branch = trim($branch, ', ');
            $branch .= ') </span>';
        }
        $branch .= '</div>';

        if (isset($element['children'])) {
            $branch .= '<ol class="dd-list">' . displayItems($element['children'], $id, $name, $extra) . '</ol>';
        }
        $branch .= "</li>";
    }

    return $branch;
}

/**
 * Make try of array according to parent child relation
 * @param array $elements
 * @param type $parentId
 * @param type $id_name
 * @param type $parent_id_name
 * @return type  Array of parent child
 */
function buildTree(array $elements, $parentId = 0, $id_name = 'id', $parent_id_name = 'parent_id') {
    $branch = array();

    foreach ($elements as $element) {
        if ($element[$parent_id_name] == $parentId) {
            $children = buildTree($elements, $element[$id_name], $id_name, $parent_id_name);
            if ($children) {
                $element['children'] = $children;
            }
            $branch[] = $element;
        }
    }

    return $branch;
}

/*
  function printTreeOptions($elements, $id='id', $name='name', $level= 0) {
  $options  = '';
  foreach ($elements as $element) {
  if($element['status'] != 1) {
  continue;
  }
  $options .= '<option value="'.$element[$id].'" >'.str_repeat('---', $level) .$element[$name].'</option>';

  if (isset($element['children'])) {
  $options .= printTreeOptions($element['children'],$id, $name, ++$level);
  --$level;
  }

  }

  return $options;
  } */
/*
  function printTreeOptions($elements, $id='id', $name='name', $parentId = 0) {
  static $a = 0; $a++;   if($a==300) { die("Kumar"); }
  $options  = '';
  foreach ($elements as $element) {
  if($element['status'] != 1) {
  continue;
  }
  $options .= '<option value="'.$element[$id].'" class="'.$parentId.'" >'.$element[$name].'</option>';
  }
  return $options;
  } */

global $arrayChainSelect;

function printChainedSelect($elements, $default, $id = 'id', $name = 'name', $parentId = 0, $level = 0) {
    global $arrayChainSelect;

//$select  = '<select  name="'.$selectName.$parentId.'" name="'.$selectName.'[]">';
    $options = "";
//$select2 = array();
//$startLevel = $level;
    foreach ($elements as $element) {
        if ($element['status'] != 1) {
            continue;
        }
//$otpions  .= printTreeOptions($elements, $id,  $name, $element[$id]);
        $other = '';
        if ($element['isOther'] == 1) {
            $other = 'other="yes"';
        }
        $selectDefault = '';
        if (count($selectDefault) > 0) {
// print_r($selectedValue);echo $element[$id]; echo "<br>";
            if (in_array($element[$id], $default)) {
                $selectDefault = 'selected ';
            }
        }
        $options .= '<option value="' . $element[$id] . '" class="' . $parentId . '" ' . $other . ' ' . $selectDefault . ' >' . $element[$name] . '</option>';

        if (isset($element['children'])) {
            if (!isset($arrayChainSelect[$level + 1])) {
                $arrayChainSelect[$level + 1] = '';
            }
            $arrayChainSelect[$level] .= printChainedSelect($element['children'], $default, $id, $name, $element[$id], ++$level);
            --$level;
        }
    }
// echo "AMIT";
//print_r($arraySelectChildrens);
// $select  .= $options.'</select>'.implode('',$select2);

    return $options;
}

/*
  function printChainedSelect($selectName, $elements, $id='id', $name='name', $parentId = 0, $level= 0) {
  static $a = 0; $a++;   if($a==100) {       die("Amit"); }

  //$select  = '<select  name="'.$selectName.$parentId.'" name="'.$selectName.'[]">';
  $options = "";
  //$select2 = array();
  //$startLevel = $level;
  foreach ($elements as $element) {
  if($element['status'] != 1) {
  continue;
  }
  //$otpions  .= printTreeOptions($elements, $id,  $name, $element[$id]);
  $options .= '<option value="'.$element[$id].'" class="'.$parentId.'" >'.$element[$name].'</option>';

  if (isset($element['children'])) {
  $select2[$level] = printChainedSelect($selectName, $element['children'], $id,  $name, $element[$id], ++$level);
  --$level;
  }
  }
  // print_r($select2);
  // $select  .= $options.'</select>'.implode('',$select2);

  return $options;
  } */

/**
  function getMaxChildrenLevel($elements, $level = 0, $maxLevel = 0) {

  foreach ($elements as $element) {
  if($element['status'] != 1) {
  continue;
  }
  if (isset($element['children'])) {
  $maxLevel = getMaxChildrenLevel($element['children'], ++$level, $maxLevel);
  if($level > $maxLevel ) {
  $maxLevel  = $level;
  }
  --$level;
  }
  }
  return $maxLevel;
  }
 */
function getQualificationsById($qualification_id) {
    global $db;
    $qualification_id = intval($qualification_id);
    $stmt = $db->prepare('SELECT * FROM ' . TB_M_QUALIFICAITONS . ' WHERE qualification_id = :qualification_id');
    $stmt->execute(array(':qualification_id' => $qualification_id));
    $row = $stmt->fetch();
    return $row;
}

/**
 *  get Tree structrue of Qualificaiton
 * @global type $db
 * @return Tree of Qualification
 */
function getAllQualificationsSelect($qualificaiton_name, $qualification_default = array()) {
    global $db, $arrayChainSelect;
    try {
        $stmt = $db->query('SELECT * from ' . TB_M_QUALIFICAITONS . ' order by sorting_order  ');
    } catch (PDOException $e) {
        echo $e->getMessage();
        return false;
    }

    $rows = $stmt->fetchAll();
    $tree = buildTree($rows, 0, 'qualification_id');
    $arrayChainSelect = array(); // reinitialize
    $arrayChainSelect[0] = printChainedSelect($tree, $qualification_default, 'qualification_id', 'qualification_name');
    ksort($arrayChainSelect);
//print_r($arrayChainSelect);
    $selectList = '';
    $script = '';
    $total = count($arrayChainSelect);
    $i = 0;
    foreach ($arrayChainSelect as $select) {
        $i++;
        $selectList .= '<select id="' . $qualificaiton_name . '_' . $i . '" name="' . $qualificaiton_name . '_' . $i . '">';
        $selectList .= '<option value="0">--</option>';
        $selectList .= $select;
        $selectList .= '</select>';
        if ($i != $total) {
            $script .= ' $("#' . $qualificaiton_name . '_' . ($i + 1) . '").chained("#' . $qualificaiton_name . '_' . ($i) . '");';
        }
    }
    if ($script != '') {
        $script = '<script type="text/javascript"> $(function(){ ' . $script . ' }); </script>';
    }

    return $selectList . $script;
}

function isValidQualification($qualification_id, $parent_id = 0) {
    global $db;
    $qualification_id = intval($qualification_id);
    $parent_id = intval($parent_id);

    try {

        $stmt = $db->prepare('SELECT * FROM ' . TB_M_QUALIFICAITONS . ' WHERE qualification_id = :qualification_id and parent_id = :parent_id  ');
        $stmt->execute(array(
            ':qualification_id' => $qualification_id,
            ':parent_id' => $parent_id
        ));
    } catch (PDOException $e) {
        echo $e->getMessage();
        return false;
    }
    $row = $stmt->fetch();
    if ($row) {
        return true;
    } else {
        return false;
    }
}

function isValidIdentification($identificationId) {
    global $db;
    $identificationId = intval($identificationId);

    try {

        $stmt = $db->prepare('SELECT * FROM ' . TB_M_INDENTIFICIATIONS . ' WHERE identificationId = :identificationId   ');
        $stmt->execute(array(
            ':identificationId' => $identificationId
        ));
    } catch (PDOException $e) {
        echo $e->getMessage();
        return false;
    }
    $row = $stmt->fetch();
    if ($row) {
        return true;
    } else {
        return false;
    }
}

function isOtherIdentification($identificationId) {
    global $db;
    $identificationId = intval($identificationId);
    try {
        $stmt = $db->prepare('SELECT * FROM ' . TB_M_INDENTIFICIATIONS . ' WHERE identificationId = :identificationId and isOther = 1  ');
        $stmt->execute(array(
            ':identificationId' => $identificationId
        ));
    } catch (PDOException $e) {
        echo $e->getMessage();
        return false;
    }
    $row = $stmt->fetch();
    if ($row) {
        return true;
    } else {
        return false;
    }
}

function getdentificationById($identificationId) {
    global $db;
    $identificationId = intval($identificationId);
    $stmt = $db->prepare('SELECT * FROM ' . TB_M_INDENTIFICIATIONS . ' WHERE identificationId = :identificationId');
    $stmt->execute(array(':identificationId' => $identificationId));
    $row = $stmt->fetch();
    return $row;
}

function getAllIdentificationSelect($name, $selectedValue = '', $otherValue = '') {
    global $db;
    try {
        $stmt = $db->query('SELECT * from ' . TB_M_INDENTIFICIATIONS . ' order by sorting_order  ');
    } catch (PDOException $e) {
        echo $e->getMessage();
        return false;
    }

    $rows = $stmt->fetchAll();

    $selectList = '<select id="' . $name . '" name="' . $name . '">';
    $selectList .= '<option value="0">--</option>';
    $otherDiv = '';
    foreach ($rows as $row) {
        $selectList .= '<option value="' . $row['identificationId'] . '" ';
        if (isset($selectedValue) && $selectedValue == $row['identificationId']) {
            $selectList .= 'selected ';
        }
        if ($row['isOther'] == 1) {
            $selectList .= ' class="other" ';
        }
        $selectList .= '>' . $row['identificationName'] . '</option> ';

        if ($row['isOther'] == 1) {
            $otherDiv .= buildInputText($name . '_other', $otherValue, $name . '_other');
        }
    }
    $selectList .= '</select>';

    $stript = file_get_string(JS_TEMPLATE_DIR . 'indentification.js');
    $stript = str_replace('TOKEN_NAME', $name, $stript);
    $stript = '<script type="text/javascript">' . $stript . '</script>';

    $return['select'] = $selectList;
    $return['other'] = $otherDiv;
    $return['stript'] = $stript;
    return $return;
}

function isValidClinicalServices($clinicalServicesId) {
    global $db;
    $clinicalServicesId = intval($clinicalServicesId);

    try {

        $stmt = $db->prepare('SELECT * FROM ' . TB_M_CLINICAL_SERVICES . ' WHERE clinicalServicesId = :clinicalServicesId   ');
        $stmt->execute(array(
            ':clinicalServicesId' => $clinicalServicesId
        ));
    } catch (PDOException $e) {
        echo $e->getMessage();
        return false;
    }
    $row = $stmt->fetch();
    if ($row) {
        return true;
    } else {
        return false;
    }
}

function getClinicalServiceById($clinicalServicesId) {
    global $db;
    $clinicalServicesId = intval($clinicalServicesId);
    $stmt = $db->prepare('SELECT * FROM ' . TB_M_CLINICAL_SERVICES . ' WHERE clinicalServicesId = :clinicalServicesId');
    $stmt->execute(array(':clinicalServicesId' => $clinicalServicesId));
    $row = $stmt->fetch();
    return $row;
}

function isOtherClinicalService($clinicalServicesId) {
    global $db;
    $clinicalServicesId = intval($clinicalServicesId);
    try {
        $stmt = $db->prepare('SELECT * FROM ' . TB_M_CLINICAL_SERVICES . ' WHERE clinicalServicesId = :clinicalServicesId and isOther = 1  ');
        $stmt->execute(array(
            ':clinicalServicesId' => $clinicalServicesId
        ));
    } catch (PDOException $e) {
        echo $e->getMessage();
        return false;
    }
    $row = $stmt->fetch();
    if ($row) {
        return true;
    } else {
        return false;
    }
}

function getAllClinicalServicesSelect($name, $selectedValue = '', $otherValue = '') {
    global $db;
    try {
        $stmt = $db->query('SELECT * from ' . TB_M_CLINICAL_SERVICES . ' WHERE status = 1 order by sorting_order  ');
    } catch (PDOException $e) {
        echo $e->getMessage();
        return false;
    }

    $rows = $stmt->fetchAll();

    $selectList = '<select id="' . $name . '" name="' . $name . '">';
    $selectList .= '<option value="0">--</option>';
    $otherDiv = '';
    foreach ($rows as $row) {
        $selectList .= '<option value="' . $row['clinicalServicesId'] . '" ';
        if (isset($selectedValue) && $selectedValue == $row['clinicalServicesId']) {
            $selectList .= 'selected ';
        }
        if ($row['isOther'] == 1) {
            $selectList .= ' class="other" ';
        }
        $selectList .= '>' . $row['clinicalServicesName'] . '</option> ';

        if ($row['isOther'] == 1) {
            $otherDiv .= buildInputText($name . '_other', $otherValue, $name . '_other');
        }
    }
    $selectList .= '</select>';

    $stript = file_get_string(JS_TEMPLATE_DIR . 'indentification.js');
    $stript = str_replace('TOKEN_NAME', $name, $stript);
    $stript = '<script type="text/javascript">' . $stript . '</script>';

    $return['select'] = $selectList;
    $return['other'] = $otherDiv;
    $return['stript'] = $stript;
    return $return;
}

function getOwnershipById($ownership_id) {
    global $db;
    $ownership_id = intval($ownership_id);
    $stmt = $db->prepare('SELECT * FROM ' . TB_M_OWNERSHIPS . ' WHERE ownership_id = :ownership_id');
    $stmt->execute(array(':ownership_id' => $ownership_id));
    $row = $stmt->fetch();
    return $row;
}

function isValidOwnership($ownership_id, $parent_id = 0) {
    global $db;
    $ownership_id = intval($ownership_id);
    $parent_id = intval($parent_id);

    try {

        $stmt = $db->prepare('SELECT * FROM ' . TB_M_OWNERSHIPS . ' WHERE ownership_id = :ownership_id and parent_id = :parent_id  ');
        $stmt->execute(array(
            ':ownership_id' => $ownership_id,
            ':parent_id' => $parent_id
        ));
    } catch (PDOException $e) {
        echo $e->getMessage();
        return false;
    }
    $row = $stmt->fetch();
    if ($row) {
        return true;
    } else {
        return false;
    }
}

function isOtherOwnership($ownership_id) {
    global $db;
    $ownership_id = intval($ownership_id);
    try {
        $stmt = $db->prepare('SELECT * FROM ' . TB_M_OWNERSHIPS . ' WHERE ownership_id = :ownership_id and isOther = 1  ');
        $stmt->execute(array(
            ':ownership_id' => $ownership_id
        ));
    } catch (PDOException $e) {
        echo $e->getMessage();
        return false;
    }
    $row = $stmt->fetch();
    if ($row) {
        return true;
    } else {
        return false;
    }
}

global $arrayOnwershipChainSelect;

function printChainedSelect2($elements, $id = 'id', $name = 'name', $selectedValue, $parentId = 0, $level = 0) {
    global $arrayOnwershipChainSelect;

//$select  = '<select  name="'.$selectName.$parentId.'" name="'.$selectName.'[]">';
    $options = "";
//$select2 = array();
//$startLevel = $level;
    foreach ($elements as $element) {
        if ($element['status'] != 1) {
            continue;
        }
//$otpions  .= printTreeOptions($elements, $id,  $name, $element[$id]);
        $other = '';
        if ($element['isOther'] == 1) {
            $other = 'other="yes"';
        }
        $selectDefault = '';
//print_r($selectedValue);
        if (count($selectedValue) > 0) {
// print_r($selectedValue);echo $element[$id]; echo "<br>";
            if (in_array($element[$id], $selectedValue)) {
                $selectDefault = ' selected ';
            }
        }
        $options .= '<option value="' . $element[$id] . '" class="' . $parentId . '" ' . $other . ' ' . $selectDefault . ' >' . $element[$name] . '</option>';

        if (isset($element['children'])) {
            if (!isset($arrayOnwershipChainSelect[$level + 1])) {
                $arrayOnwershipChainSelect[$level + 1] = '';
            }
            $arrayOnwershipChainSelect[$level] .= printChainedSelect2($element['children'], $id, $name, $selectedValue, $element[$id], ++$level);
            --$level;
        }
    }
    return $options;
}

/**
 *  get Tree structrue of Qualificaiton
 * @global type $db
 * @return Tree of Qualification
 */
function getAllOwnershipSelect($ownership_name, $selectedValue = array(), $otherValue = '') {
    global $db, $arrayOnwershipChainSelect;
    try {
        $stmt = $db->query('SELECT * FROM ' . TB_M_OWNERSHIPS . ' order by sorting_order  ');
    } catch (PDOException $e) {
        echo $e->getMessage();
        return false;
    }

    $rows = $stmt->fetchAll();
    $tree = buildTree($rows, 0, 'ownership_id');
    $arrayOnwershipChainSelect = array(); // reinitialize
    $arrayOnwershipChainSelect[0] = printChainedSelect2($tree, 'ownership_id', 'ownership_name', $selectedValue);
    ksort($arrayOnwershipChainSelect);
//print_r($arrayChainSelect);
    $selectList = '';
    $script = '';
    $total = count($arrayOnwershipChainSelect);
    $i = 0;
    foreach ($arrayOnwershipChainSelect as $select) {
        $i++;
        $selectList .= '<select id="' . $ownership_name . '_' . $i . '" name="' . $ownership_name . '_' . $i . '">';
        $selectList .= '<option value="0">--</option>';
        $selectList .= $select;
        $selectList .= '</select>';
        if ($i != $total) {
            $script .= ' $("#' . $ownership_name . '_' . ($i + 1) . '").chained("#' . $ownership_name . '_' . ($i) . '");';
        }
    }
    if ($script != '') {
        $script = '<script type="text/javascript"> $(function(){ ' . $script . ' }); </script>';
    }

    $stript2 = file_get_string(JS_TEMPLATE_DIR . 'ownership.js');
    $stript2 = str_replace('TOKEN_NAME', $ownership_name . '_2', $stript2);
    $stript2 = '<script type="text/javascript">' . $stript2 . '</script>';
    $otherDiv = buildInputText($ownership_name . '_2_other', $otherValue, $ownership_name . '_2_other');

    $return['select'] = $selectList;
    $return['other'] = $otherDiv;
    $return['stript'] = $script . $stript2;
    return $return;
}

function getSystemsOfMedicineByIds($systemMedicineIds) {
    global $db;
    try {
        $stmt = $db->prepare('SELECT * FROM ' . TB_M_SYSTEM_OF_MEDICINE . ' WHERE systemMedicineId IN (' . implode(',', $systemMedicineIds) . ')   ');
        $stmt->execute();
    } catch (PDOException $e) {
        echo $e->getMessage();
        return false;
    }
    $rows = $stmt->fetchAll();
    return $rows;
}

function isValidSystemsOfMedicine($systemMedicineIds) {
    global $db;
    try {
        $stmt = $db->prepare('SELECT systemMedicineId FROM ' . TB_M_SYSTEM_OF_MEDICINE . ' WHERE systemMedicineId IN (' . implode(',', $systemMedicineIds) . ')   ');
        $stmt->execute();
    } catch (PDOException $e) {
        echo $e->getMessage();
        return false;
    }
    $found = array();
    while ($row = $stmt->fetch()) {
        $found[] = $row['systemMedicineId'];
    }
    $not_found = array_diff($systemMedicineIds, $found);
    if (count($not_found) == 0) {
        return true;
    } else {
        return false;
    }
}

/**
 * get All Systems Of Medicine which are active only
 * @global type $db
 * @param string $name  Name of the check box
 * @param array $defaultValues   Should be an array
 * @return string Checkbox list
 */
function getAllSystemsOfMedicineSelect($name, $defaultValues = array()) {
    global $db;
    try {
        $stmt = $db->query('SELECT * from ' . TB_M_SYSTEM_OF_MEDICINE . '  WHERE status = 1  order by sorting_order');
    } catch (PDOException $e) {
        echo $e->getMessage();
        return false;
    }

    $rows = $stmt->fetchAll();
    $checkboxs = '';

    foreach ($rows as $row) {

        $checkboxs .= '<label><input type="checkbox" name ="' . $name . '[]" value="' . $row['systemMedicineId'] . '" ';
        if (count($defaultValues) > 0) {
            if (in_array($row['systemMedicineId'], $defaultValues)) {
                $checkboxs .= 'checked="checked" ';
            }
        }
        $checkboxs .= '><span>' . $row['systemMedicineName'] . '</span></label>';
    }
    return $checkboxs;
}

function getAllClinicalEstablishment() {
    global $db;
    try {
        $stmt = $db->query('SELECT * from ' . TB_M_CLINICAL_ESTABLISHMENT_TYPES . '  WHERE status = 1  order by sorting_order');
    } catch (PDOException $e) {
        echo $e->getMessage();
        return false;
    }
    $rows = $stmt->fetchAll();
    return $rows;
}

/**
 * get All Clinical Statblishment type which are active only
 * @global type $db
 * @param string $name  Name of the check box
 * @param array $defaultValues   Should be an array
 * @return string Checkbox list
 */
function getAllClinicalEstablishmentTypesSelect($name, $defaultValues = array(), $otherValues = array(), $error = array()) {

    $rows = getAllClinicalEstablishment();

    $tree = buildTree($rows, 0, 'clinical_establishment_type_id');
    $checkboxs = '';
    $childNum = 0;
    $checkboxChild[] = array();
//print_r($otherValues);
    foreach ($tree as $row) {

        $checkboxs .= '<label><input type="checkbox" name="' . $name . '_' . $row['clinical_establishment_type_id'] . '" id="' . $name . '_' . $row['clinical_establishment_type_id'] . '" value="' . $row['clinical_establishment_type_id'] . '" ';

        if (in_array($row['clinical_establishment_type_id'], $defaultValues, true)) {
            $checkboxs .= 'checked="checked" ';
        }

        $checkboxs .= '><span>' . $row['clinical_establishment_type_name'] . '</span></label>';
// make other input box if Other Flag is one


        if (isset($row['children'])) {
            $tree2 = $row['children'];
            $checkboxChild[$childNum] = '';
            $checkboxChild[$childNum] .= '<div class="ce_subname " id="' . $name . '_' . $row['clinical_establishment_type_id'] . '_child" >';
            $checkboxChild[$childNum] .= '<fieldset  class=" ' . errorInputClass($name . '_' . $row['clinical_establishment_type_id'], $error) . '"><legend class="ce_sublabel" >' . $row['clinical_establishment_type_name'] . '</legend>';
            foreach ($tree2 as $row2) {
                $checkboxChild[$childNum] .= '<label><input type="checkbox" name ="' . $name . '_' . $row2['clinical_establishment_type_id'] . '" id="' . $name . '_' . $row2['clinical_establishment_type_id'] . '" value="' . $row2['clinical_establishment_type_id'] . '" ';

                if (in_array($row2['clinical_establishment_type_id'], $defaultValues)) {
                    $checkboxChild[$childNum] .= 'checked="checked" ';
                }

                $checkboxChild[$childNum] .= '><span>' . $row2['clinical_establishment_type_name'] . '</span></label>';
                if ($row2['isOther'] == 1) {
                    $stript = file_get_string(JS_TEMPLATE_DIR . 'clinicals_other.js');
                    $stript = str_replace('TOKEN_NAME', $name . '_' . $row2['clinical_establishment_type_id'], $stript);
                    $stript = '<script type="text/javascript">' . $stript . '</script>';
                    $otherVal = '';
// print_r($otherValues);
                    if (isset($otherValues[$row2['clinical_establishment_type_id']])) {
                        $otherVal = $otherValues[$row2['clinical_establishment_type_id']];
                    }

                    $checkboxChild[$childNum] .= '<div class="cet_other ' . errorInputClass($name . '_' . $row2['clinical_establishment_type_id'] . '_other', $error) . '" id= "' . $name . '_' . $row2['clinical_establishment_type_id'] . '_other_div">';
                    $checkboxChild[$childNum] .= '<span clalss="cet_other_span">Specify:</span>';
                    $checkboxChild[$childNum] .= buildInputText($name . '_' . $row2['clinical_establishment_type_id'] . '_other', $otherVal, $name . '_' . $row2['clinical_establishment_type_id'] . '_other');
                    $checkboxChild[$childNum] .= errorInputDisplay($name . '_' . $row2['clinical_establishment_type_id'] . '_other', $error);
                    $checkboxChild[$childNum] .= '</div>';
                    $checkboxChild[$childNum] .= $stript;
                }
            }
// In Case Inpatient (ID=1) add box of Number of Beds
            if ($row['clinical_establishment_type_id'] == 1) {
                $inpatient_num_beds = '';
                if (isset($otherValues['inpatient_num_beds'])) {
                    $inpatient_num_beds = $otherValues['inpatient_num_beds'];
                }
                $checkboxChild[$childNum] .= '<div class="inpatient_num_beds ' . errorInputClass('inpatient_num_beds', $error) . '">';
                $checkboxChild[$childNum] .= '<span clalss="">Number of Beds: <span class="star_red">*</span></span>';
                $checkboxChild[$childNum] .= buildInputText('inpatient_num_beds', $inpatient_num_beds, 'inpatient_num_beds');
                $checkboxChild[$childNum] .= errorInputDisplay('inpatient_num_beds', $error);
                $checkboxChild[$childNum] .= '</div>';
            }
            $checkboxChild[$childNum] .= '</fieldset>';
            $checkboxChild[$childNum] .= errorInputDisplay($name . '_' . $row['clinical_establishment_type_id'], $error);
            $checkboxChild[$childNum] .= '</div>';
            $childNum++;
        }

// get script for child select
        $stript = file_get_string(JS_TEMPLATE_DIR . 'clinicals_child.js');
        $stript = str_replace('TOKEN_NAME', $name . '_' . $row['clinical_establishment_type_id'], $stript);
        $stript = '<script type="text/javascript">' . $stript . '</script>';
        $checkboxs .= $stript;

        if ($row['isOther'] == 1) {
            $stript = file_get_string(JS_TEMPLATE_DIR . 'clinicals_other.js');
            $stript = str_replace('TOKEN_NAME', $name . '_' . $row['clinical_establishment_type_id'], $stript);
            $stript = '<script type="text/javascript">' . $stript . '</script>';
            $otherVal = '';
            if (isset($otherValues[$row['clinical_establishment_type_id']])) {
                $otherVal = $otherValues[$row['clinical_establishment_type_id']];
            }
            $checkboxs .= '<div class="cet_other ' . errorInputClass($name . '_' . $row['clinical_establishment_type_id'] . '_other', $error) . '" id= "' . $name . '_' . $row['clinical_establishment_type_id'] . '_other_div">';
            $checkboxs .= '<span clalss="cet_other_span">Specify:</span>';
            $checkboxs .= buildInputText($name . '_' . $row['clinical_establishment_type_id'] . '_other', $otherVal, $name . '_' . $row['clinical_establishment_type_id'] . '_other');
            $checkboxs .= errorInputDisplay($name . '_' . $row2['clinical_establishment_type_id'] . '_other', $error);
            $checkboxs .= '</div>';
            $checkboxs .= $stript;
        }
    }
    $checkboxs .= implode('', $checkboxChild);
    return $checkboxs;
}

/**
 * get All Clinical Statblishment type and display text which are active only
 * @global type $db
 * @param array $defaultValues
 * @param array $otherValues
 * @return string Checkbox list
 */
function getAllClinicalEstablishmentTypesDisplay($defaultValues = array(), $otherValues = array()) {

    $rows = getAllClinicalEstablishment();

    $tree = buildTree($rows, 0, 'clinical_establishment_type_id');
    $checkboxs = '';
    $childNum = 0;
    $checkboxChild[] = array();
//print_r($otherValues);
    foreach ($tree as $row) {
        if (!in_array($row['clinical_establishment_type_id'], $defaultValues, true)) {
            continue;  // no need to dispay which are not saved in database
        }

        if ($row['isOther'] == 1) {
            if (isset($otherValues[$row['clinical_establishment_type_id']]) && $otherValues[$row['clinical_establishment_type_id']] != '') {
                $checkboxs .= '<label><span><span class="other">' . $row['clinical_establishment_type_name'] . ':</span> ';
                $checkboxs .= '<div class="cet_other" >';
                $checkboxs .= '<span clalss="cet_other_span"></span>' . $otherValues[$row['clinical_establishment_type_id']];
                $checkboxs .= '</div></span></label>';
            }
        } else {
            $checkboxs .= '<label><span>' . $row['clinical_establishment_type_name'] . '</span></label>';
        }

        if (isset($row['children'])) {
            $tree2 = $row['children'];
            $checkboxChild[$childNum] = '';
            $checkboxChild[$childNum] .= '<div class="ce_subname " >';
            $checkboxChild[$childNum] .= '<fieldset><legend class="ce_sublabel" >' . $row['clinical_establishment_type_name'] . '</legend>';
            foreach ($tree2 as $row2) {
                if (!in_array($row2['clinical_establishment_type_id'], $defaultValues, true)) {
                    continue;
                }
                if ($row2['isOther'] == 1) {
                    if (isset($otherValues[$row2['clinical_establishment_type_id']]) && $otherValues[$row2['clinical_establishment_type_id']] != '') {
                        $checkboxChild[$childNum] .= '<label><span><span class="other">' . $row2['clinical_establishment_type_name'] . ':</span>';
                        $checkboxChild[$childNum] .= '<div class="cet_other">';
                        $checkboxChild[$childNum] .= '<span clalss="cet_other_span"></span>' . $otherValues[$row2['clinical_establishment_type_id']];
                        $checkboxChild[$childNum] .= '</div></span></label>';
                    }
                } else {
                    $checkboxChild[$childNum] .= '<label><span>' . $row2['clinical_establishment_type_name'] . '</span></label>';
                }
            }
// In Case Inpatient (ID=1) add box of Number of Beds
            if ($row['clinical_establishment_type_id'] == 1) {
                if (isset($otherValues['inpatient_num_beds']) && $otherValues['inpatient_num_beds'] != '') {
                    $inpatient_num_beds = $otherValues['inpatient_num_beds'];
                    $checkboxChild[$childNum] .= '<div class="inpatient_num_beds ">';
                    $checkboxChild[$childNum] .= '<span clalss="">Number of Beds:</span>' . $inpatient_num_beds;
                    $checkboxChild[$childNum] .= '</div>';
                }
            }
            $checkboxChild[$childNum] .= '</fieldset>';
            $checkboxChild[$childNum] .= '</div>';
            $childNum++;
        }
    }
    $checkboxs .= implode('', $checkboxChild);
    return $checkboxs;
}

//Add By Dharam Start ==============================================
//Check User entry exist in table
function userHistoryExist($memberID) {
    global $db;
    $stmt = $db->prepare('SELECT * FROM login_history WHERE memberID = :memberID');
    $stmt->execute(array('memberID' => $memberID));
    $row = $stmt->fetch();
    if ($row) {
        return true;
    } else {
        return false;
    }
}

//Return old password
function getPasswordHistory($memberID) {
    global $db;
    $stmt = $db->prepare('SELECT * FROM login_history WHERE memberID = :memberID');
    $stmt->execute(array('memberID' => $memberID));
    $row = $stmt->fetch();
    if ($row) {
        $password_history = $row['password_history'];

        return $password_history;
    } else {
        return false;
    }
}

function check_password_history($password, $memberID) {
    global $db;
    $stmt = $db->prepare('SELECT * FROM login_history WHERE memberID = :memberID');
    $stmt->execute(array('memberID' => $memberID));
    $row = $stmt->fetch();
    if ($row) {
// print_r($row);
        if ($row['password_history']) {
            $password_history = 0;
            $old_password = array();
            $old_password = explode('|||', $row['password_history']);
            ;
            if (sizeof($old_password) > 1) {
                foreach ($old_password as $old_password) {
                    $hashed = $old_password;
                    if (password_verify($password, $hashed) == 1) {
                        $password_history = 1;
                    }
                }
            } else {
                $hashed = $row['password_history'];
                if (password_verify($password, $hashed) == 1) {
                    $password_history = 1;
                }
            }
            if ($password_history == 1) {
                return true;
                exit;
            }
        }
    } else {
        return false;
        exit;
    }
}

function afterSuccessfulLogin($memberID) {
    global $db;
    $memberID = $memberID;
//update into database
    $stmt = $db->prepare('UPDATE login_history SET login_attempt = :login_attempt WHERE memberID = :memberID');
    $stmt->execute(array(
        ':login_attempt' => 0,
        ':memberID' => $memberID
    ));
}

function checkLogin($memberID) {
    global $db;
    $memberID = $memberID;

    $block_time = 20;  // Set Inactive time in minutes
    $time = time();
    $stmt = $db->prepare('SELECT login_attempt,last_attempt_time FROM login_history WHERE memberID = :memberID');
    $stmt->execute(array(
        ':memberID' => $memberID
    ));
    $row = $stmt->fetch();

    if ($row) {

        $attempts = $row["login_attempt"] + 1;

        if ($attempts <= 3) {
            $stmt = $db->prepare('UPDATE login_history SET login_attempt = :login_attempt , `last_attempt_time` = :last_attempt_time WHERE memberID = :memberID ');
            $stmt->execute(array(
                ':login_attempt' => $attempts,
                ':last_attempt_time' => $time,
                ':memberID' => $memberID
            ));
            return true;
            exit;
        } else {

            $last_attempt_time = $row['last_attempt_time'];

            $block_time_start = ($time - $last_attempt_time) / 60;
            $block_time_start = round($block_time_start);

//Check inactive/active account.
            if ($block_time_start >= $block_time) {
                $stmt = $db->prepare('UPDATE login_history SET login_attempt = :login_attempt , `last_attempt_time` = :last_attempt_time WHERE memberID = :memberID ');
                $stmt->execute(array(
                    ':login_attempt' => 0,
                    ':last_attempt_time' => $time,
                    ':memberID' => $memberID
                ));
                return true;
            } else {
                $_SESSION['block_time'] = $block_time - $block_time_start;
                return false;
            }
        }
    } else {
        $stmt = $db->prepare('INSERT INTO `login_history` (`id`, `memberID`, `login_attempt`) VALUES (NULL,:memberID,:login_attempt)');
        $stmt->execute(array(
            ':memberID' => $memberID,
            ':login_attempt' => 0,
        ));
        return true;
    }
}

/* for genrated random token in session for enctoken */

function generatetoken() {
    if (isset($_SESSION['EncTokken'])) {
        unset($_SESSION['EncTokken']);
    }
    $newVal = GetRandom();
    $_SESSION['EncTokken'] = $newVal;
    return $newVal;
}

function GetRandom() {
    $len = rand(16, 25);
    $string = "";
    $chars = "ABCD0Ehi1jkl2mnopq3NOPQ4RSZ5yza6bcdefg7FGHIJKLM8rstuvwx9TUVWXY";
    for ($i = 0; $i < $len; $i++) {
        $string .= substr($chars, rand(0, strlen($chars)), 1);
    }
    return sha1($string);
}

function checkCSRF() {
    $check = FALSE;
    if (isset($_REQUEST['EncToken']) && isset($_SESSION['EncTokken']) && ($_REQUEST['EncToken'] == $_SESSION['EncTokken'])) {
//write code here
//echo "Valid";
        $check = TRUE;
    }
    unset($_SESSION['EncTokken']);
    return $check;
}

function addCsrfTocken($urlParamFormat = false) {
    if ($urlParamFormat) {
        return 'EncToken=' . generatetoken();
    }
    return '<input type="hidden" style="display:none !important;" name="EncToken" id="EncToken" value="' . generatetoken() . '">';
}

//user Trail update
function userTrail($username, $status) {
    global $db;
    $username = $username;
    $status = $status;
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $login_ip = $_SERVER['REMOTE_ADDR'];
    $stmt = $db->prepare('INSERT INTO `user_trail` (`username`, `status`,`login_ip`,`user_agent`) VALUES (:username, :status, :login_ip, :user_agent)');

    $stmt->execute(array(
        ':username' => $username,
        ':status' => $status,
        ':login_ip' => $login_ip,
        ':user_agent' => $user_agent,
    ));
}

//Add By Dharam  End ===============================================

/**
 *
 *
 * @param type $startDate  YYYY-MM-DD
 * @param type $endDate  YYYY-MM-DD
 * @return type Array
 */
function getMonthsInRange($startDate, $endDate) {
    $start = $month = strtotime($startDate);
    $end = strtotime($endDate);
    $months = array();
    while ($month < $end) {
//echo date('F Y', $month), PHP_EOL;
        $months[] = array('year' => date('Y', $month), 'month' => date('m', strtotime($month)),);
        $month = strtotime("+1 month", $month);
    }
    return $months;
}

function isValidNIN($NIN) {
    global $db;

    $stmt = $db->prepare('SELECT * FROM ' . TB_HMIS_HEALTH_FACILITIES . ' WHERE NIN_2_HFI = :NIN_2_HFI');
    $stmt->execute(array(
        ':NIN_2_HFI' => $NIN
    ));
    $row = $stmt->fetch();
    if ($row) {
        return true;
    } else {
        return false;
    }
}

function getAspirationalDistrict($District_ID) {
    global $db;
    $stmt = $db->prepare('SELECT * FROM m_hwc_aspirational_district WHERE District_ID = :District_ID');
    $stmt->execute(array(
        ':District_ID' => $District_ID
    ));
    $row = $stmt->fetch();
    // showData($row);die();

    if ($row) {
        if ($row['aspirational'] == 1) {
            return true;
        } else {
            return FALSE;
        }
    } else {
        return false;
    }
}


function updateCriteria($NIN_2_HFI, $HFI_Type) {
    global $db;

    $criteria = 0;
    $query = "SELECT * FROM `t_hwc` WHERE  `NIN_2_HFI`='$NIN_2_HFI'";
    $stmt = $db->query($query);
    $row = $stmt->fetch();
    if ($HFI_Type == 1 || $HFI_Type == 3) {

        //  hr_mpw
        //  hr_asha
        //  hr_staff_nurses
//        PHC/UPHC
        
        $criteria += ($row['hr_mo_mbbs'] > 0) ? 1 : 0;
        $criteria += ($row['training_mos'] == 1 || $row['traning_hr_mos_staff_nurses']) ? 1 : 0;
        $criteria += ($row['population_enumeration'] == 1) ? 1 : 0;
        $criteria += ($row['service_hypertension'] == 1 && $row['service_diabetes'] == 1 && $row['service_oral_cancer'] == 1 && $row['service_breast_cancer'] == 1) ? 1 : 0;
        $criteria += ($row['medicines_available'] == 1) ? 1 : 0;
        $criteria += ($row['diagnostics_available'] == 1) ? 1 : 0;
        $criteria += ($row['it_equipment_desktop'] == 1 && $row['it_internet_connectivity'] == 1 && $row['it_phc_ncd_application']) ? 1 : 0;
        $criteria += ($row['infra_branding'] == 1) ? 1 : 0;
    } elseif ($HFI_Type == 99) {
        //  SC
        $criteria += ($row['mlhp_posted'] == 1) ? 1 : 0;
        $criteria += ($row['training_mpwf'] == 1 && $row['traning_ashas']) ? 1 : 0;
        $criteria += ($row['population_enumeration'] == 1) ? 1 : 0;
        $criteria += ($row['service_hypertension'] == 1 && $row['service_diabetes'] == 1 && $row['service_oral_cancer'] == 1 && $row['service_breast_cancer'] == 1) ? 1 : 0;
        $criteria += ($row['medicines_available'] == 1) ? 1 : 0;
        $criteria += ($row['diagnostics_available'] == 1) ? 1 : 0;
        $criteria += ($row['it_equipment_tablet'] == 1 && $row['it_internet_connectivity'] == 1 && $row['it_phc_ncd_application']) ? 1 : 0;
        $criteria += ($row['infra_branding'] == 1) ? 1 : 0;
    }

    if ($row) {
        $query = "UPDATE `t_hwc` SET `criteria`= $criteria  WHERE NIN_2_HFI= '$NIN_2_HFI'";
    $stmt = $db->query($query);
    }
    return true;
}



/**
 * get current financial year 
 */
//function getCurrentYear($current = null)
//{
//    try {
//        if($current == 'Y'){
//       $getcurrent =  date('Y') .'-'.date('Y', strtotime('+1 year')); // 2018-2019
//
//       return $getcurrent;
//    }elseif ($current == 'y') {
//
//         $getcurrent = date('y') .date('y', strtotime('+1 year')); //1819
//        return $getcurrent;
//    }else{
//        echo 'something error in current value';
//    }
//    } catch (Exception $e) {
//        return $e;
//    }
//}
/**
 * get current financial quarter 
 */



//===========================================

function getCurrentQuarterFYear($value) {

    $c_month = date('m');
    $date = date('d');
    $year = date('y');
    $next_year = $year + 1;

    switch ($value) {

        case 'Q':
            $month = 0;
            if ($c_month >= 4 && $c_month <= 6) {
                //$month = '1Q' . $year . $next_year;
                $month = 'Q1';
            } elseif ($c_month >= 7 && $c_month <= 9) {
                $month = 'Q2';
            } elseif ($c_month >= 10 && $c_month <= 12) {
                $month = 'Q3';
            } elseif ($c_month >= 1 && $c_month <= 3) {
                $month = 'Q4';
            }
            $result = $month;
            break;

        case 'Y':
            $result = $year . $next_year;
            break;
    }

   return $result;
    //  return $month;
}

//function getMonthsBYMQHY() {
//    $arrayMQHY = array();
//    $c_month = date('m');
//    $date = date('d');
//    $year = date('y');
//    $next_year = $year + 1;
//    if ($c_month >= 1 && $c_month <= 3) {
//        $year = date('y') - 1;
//        $next_year = date('y');
//    }
//
//
//    $arrayMQHY['M'] = $c_month . $year . $next_year;
//
//    if ($c_month >= 4 && $c_month <= 6) {
//        $arrayMQHY['Q'] = '1Q' . $year . $next_year;
//    } elseif ($c_month >= 7 && $c_month <= 9) {
//        $arrayMQHY['Q'] = '2Q' . $year . $next_year;
//    } elseif ($c_month >= 10 && $c_month <= 12) {
//        $arrayMQHY['Q'] = '3Q' . $year . $next_year;
//    } elseif ($c_month >= 1 && $c_month <= 3) {
//        $arrayMQHY['Q'] = '4Q' . $year . $next_year;
//    }
//
//
//    if ($c_month >= 4 && $c_month <= 9) {
//        $arrayMQHY['H'] = '1H' . $year . $next_year;
//    } else {
//        $arrayMQHY['H'] = '2H' . $year . $next_year;
//    }
//
//    $arrayMQHY['Y'] = 'Y-' . $year . $next_year;
//    return $arrayMQHY;
//}

 function getLoginUserName() {
     global $db;
    $user = new Users();
    global $CURRENT_USER_ROLE, $CURRENT_USER_STATE, $CURRENT_USER_DISTRICT;


  echo $STATE_NAME = getStatesName($CURRENT_USER_STATE);
    echo $DISTRCT_NAME = getDistrictName($CURRENT_USER_STATE, $CURRENT_USER_DISTRICT);
    if ($CURRENT_USER_ROLE == 0 || $CURRENT_USER_ROLE == 3) {
        $_SESSION['UESR_NAME'] = 'ADMIN';
    } else if (isDistrictUser($user)) {
        $_SESSION['UESR_NAME'] = getStatesName($CURRENT_USER_STATE);
    } elseif (isHavingDistrict($user)) {
        $_SESSION['UESR_NAME'] = getDistrictName($CURRENT_USER_STATE, $CURRENT_USER_DISTRICT);
    }
}

function getInputFieldDisabled($FYQ, $value) {
    $result = null;
    switch ($value) {
        case 'Y':
            if (getCurrentQuarterFYear('Y') != $FYQ) {
                   $result = true;
                break;
            }
        case 'Q':
            if (getCurrentQuarterFYear('Q') != $FYQ) {
                $result = true;
                break;
            } else {
              //  $result = 'disabled="" ';
            }
        default :
               $result = false;
            break;
    }


    // echo 'disabled="" ';

    return $result;
}

//getPla

//     if ($this->is_logged_in()) {
//                    $STATE_NAME = getStatesName($CURRENT_USER_STATE);
//                    $DISTRCT_NAME = getDistrictName($CURRENT_USER_STATE, $CURRENT_USER_DISTRICT);
//                    if ($CURRENT_USER_ROLE == 0 || $CURRENT_USER_ROLE == 3) {
//                        $_SESSION['UESR_NAME'] = 'ADMIN';
//                    } else if (isDistrictUser($user)) {
//                        $_SESSION['UESR_NAME'] = getStatesName($CURRENT_USER_STATE);
//                    } elseif (isHavingDistrict($user)) {
//                        $_SESSION['UESR_NAME'] = getDistrictName($CURRENT_USER_STATE, $CURRENT_USER_DISTRICT);
//                    } else {
//                        $_SESSION['UESR_NAME'] = 'User';
//                    }
//                }