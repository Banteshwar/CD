<?php
include_once 'Dashboard_function.php';

function getHWCCAReport($TYPE, $ID) {
    global $db;


    $query3 = "select

            sum(case when hf.HFI_Type = 1 then 1  else 0 end) AS phc_operational,
           sum(case when hf.HFI_Type = 3 then 1  else 0 end) AS uphc_operational,
           sum(case when hf.HFI_Type = 99 then 1  else 0 end) AS subcenter_operational,

           sum(case when HFI_Type = 1 AND criteria = 8  then 1 else 0 end) as phc_criteria_8,
           sum(case when HFI_Type = 3  AND criteria = 8  then 1 else 0 end) as uphc_criteria_8,
           sum(case when HFI_Type = 99  AND criteria = 8  then 1 else 0 end) as subcenter_criteria_8,

sum(case when HFI_Type = 1 AND criteria = 7  then 1 else 0 end) as phc_criteria_7,
           sum(case when HFI_Type = 3  AND criteria = 7  then 1 else 0 end) as uphc_criteria_7,
           sum(case when HFI_Type = 99  AND criteria = 7  then 1 else 0 end) as subcenter_criteria_7,

sum(case when HFI_Type = 1 AND criteria = 6  then 1 else 0 end) as phc_criteria_6,
           sum(case when HFI_Type = 3  AND criteria = 6  then 1 else 0 end) as uphc_criteria_6,
           sum(case when HFI_Type = 99  AND criteria = 6  then 1 else 0 end) as subcenter_criteria_6,

        sum(case when HFI_Type = 1 AND criteria =5  then 1 else 0 end) as phc_criteria_5,
           sum(case when HFI_Type = 3  AND criteria = 5  then 1 else 0 end) as uphc_criteria_5,
           sum(case when HFI_Type = 99  AND criteria = 5  then 1 else 0 end) as subcenter_criteria_5,

            sum(case when HFI_Type = 1 AND criteria =4  then 1 else 0 end) as phc_criteria_4,
           sum(case when HFI_Type = 3  AND criteria = 4  then 1 else 0 end) as uphc_criteria_4,
           sum(case when HFI_Type = 99  AND criteria = 4  then 1 else 0 end) as subcenter_criteria_4,

          sum(case when HFI_Type = 1 AND criteria <= 3  then 1 else 0 end) as phc_criteria_3,
           sum(case when HFI_Type = 3  AND criteria <= 3  then 1 else 0 end) as uphc_criteria_3,
           sum(case when HFI_Type = 99  AND criteria <= 3  then 1 else 0 end) as subcenter_criteria_3,


                          s.State_Name,
                          d.District_Name,
                          t.Taluka_Name
                          from " . TB_HMIS_HEALTH_FACILITIES . " hf
                          Left join " . TB_PHC_CSC_MSTER . " pcm on hf.HFI_Type=pcm.PHC_CHC_ID
                          Left join " . TB_M_STATES . " s on hf.State_ID=s.State_ID
                          Left join " . TB_M_DISTRICTS . " d on hf.District_ID=d.District_ID
                          Left join " . TB_M_TALUKA . " t on hf.Taluka_ID=t.Taluka_ID
                          Left join " . TB_M_HEALTHBLOCKS . " b on hf.HealthBlock_ID=b.Block_ID
                         Left join " . TB_T_MEMBERS . " m on hf.added_by_user=m.memberID
                         left join " . TB_T_HWC . " hwc on hf.NIN_2_HFI =hwc.NIN_2_HFI
                         left join " . TB_T_HWC_PROPOSED . " hwcp on hf.NIN_2_HFI =hwcp.NIN_2_HFI

                          ";

    $query3 .= 'WHERE hwcp.proposed_status=1 ';



    if ($TYPE == 0) {
        $query3 .= " GROUP BY hf.State_ID ";
    } elseif ($TYPE == 1) {
        $query3 .= " AND hf.State_ID=" . $ID;
        $query3 .= " GROUP BY d.District_Name ";
    } elseif ($TYPE == 2) {
        $query3 .= " AND hf.District_ID=" . $ID;
        $query3 .= " GROUP BY d.District_Name ";
    }


    $stmt3 = $db->query($query3);
    $row3 = $stmt3->fetchAll();

    return $row3;
}

function getHWCGraphCAReport($TYPE, $ID) {
    global $db;
    
    $query3 = "SELECT 
 SUM(CASE WHEN HFI_Type = 1 AND hr_mo_mbbs = 1  THEN 1 ELSE 0 END) AS c1_phc,
 SUM(CASE WHEN HFI_Type = 3 AND hr_mo_mbbs = 1  THEN 1 ELSE 0 END) AS c1_uphc,
 SUM(CASE WHEN HFI_Type = 99 AND mlhp_posted = 1 THEN 1 ELSE 0 END) AS c1_subcenter,

 SUM(CASE WHEN HFI_Type = 1 AND (training_mos = 1 OR traning_hr_mos_staff_nurses=1) THEN 1 ELSE 0 END) AS c2_phc,
 SUM(CASE WHEN HFI_Type = 3 AND (training_mos = 1 OR traning_hr_mos_staff_nurses=1) THEN 1 ELSE 0 END) AS c2_uphc,
 SUM(CASE WHEN HFI_Type = 99 AND (training_mpwf = 1 OR traning_ashas=1) THEN 1 ELSE 0 END) AS c2_subcenter,

 SUM(CASE WHEN HFI_Type = 1 AND  population_enumeration = 1   THEN 1 ELSE 0 END) AS c3_phc,
 SUM(CASE WHEN HFI_Type = 3 AND  population_enumeration = 1   THEN 1 ELSE 0 END) AS c3_uphc,
 SUM(CASE WHEN HFI_Type = 99 AND  population_enumeration = 1   THEN 1 ELSE 0 END) AS c3_subcenter,

 SUM(CASE WHEN HFI_Type = 1 AND (service_hypertension = 1 AND service_diabetes=1 AND service_oral_cancer=1 AND service_breast_cancer=1  ) THEN 1 ELSE 0 END) AS c4_phc,
 SUM(CASE WHEN HFI_Type = 3 AND  (service_hypertension = 1 AND service_diabetes=1 AND service_oral_cancer=1 AND service_breast_cancer=1  ) THEN 1 ELSE 0 END) AS c4_uphc,
 SUM(CASE WHEN HFI_Type = 99 AND (service_hypertension = 1 AND service_diabetes=1 AND service_oral_cancer=1 AND service_breast_cancer=1  ) THEN 1 ELSE 0 END) AS c4_subcenter,

 SUM(CASE WHEN HFI_Type = 1 AND medicines_available=1 THEN 1 ELSE 0 END) AS c5_phc,
 SUM(CASE WHEN HFI_Type = 3 AND  medicines_available=1 THEN 1 ELSE 0 END) AS c5_uphc,
 SUM(CASE WHEN HFI_Type = 99 AND  medicines_available=1 THEN 1 ELSE 0 END) AS c5_subcenter,

 SUM(CASE WHEN HFI_Type = 1 AND diagnostics_available=1 THEN 1 ELSE 0 END) AS c6_phc,
 SUM(CASE WHEN HFI_Type = 3 AND  diagnostics_available=1 THEN 1 ELSE 0 END) AS c6_uphc,
 SUM(CASE WHEN HFI_Type = 99 AND  diagnostics_available=1 THEN 1 ELSE 0 END) AS c6_subcenter,

 SUM(CASE WHEN HFI_Type = 1 AND (it_equipment_desktop=1 AND it_internet_connectivity=1 AND it_phc_ncd_application=1 ) THEN 1 ELSE 0 END) AS c7_phc,
 SUM(CASE WHEN HFI_Type = 3 AND  (it_equipment_desktop=1 AND it_internet_connectivity=1 AND it_phc_ncd_application=1 ) THEN 1 ELSE 0 END) AS c7_uphc,
 SUM(CASE WHEN HFI_Type = 99 AND  (it_equipment_tablet=1 AND it_internet_connectivity=1 AND it_phc_ncd_application=1) THEN 1 ELSE 0 END) AS c7_subcenter,

 SUM(CASE WHEN HFI_Type = 1 AND (it_equipment_desktop=1 AND it_internet_connectivity=1 AND it_phc_ncd_application=1 ) THEN 1 ELSE 0 END) AS c7_phc,
 SUM(CASE WHEN HFI_Type = 3 AND  (it_equipment_desktop=1 AND it_internet_connectivity=1 AND it_phc_ncd_application=1 ) THEN 1 ELSE 0 END) AS c7_uphc,
 SUM(CASE WHEN HFI_Type = 99 AND  (it_equipment_tablet=1 AND it_internet_connectivity=1 AND it_phc_ncd_application=1) THEN 1 ELSE 0 END) AS c7_subcenter,

  SUM(CASE WHEN HFI_Type = 1 AND infra_branding=1 THEN 1 ELSE 0 END) AS c8_phc,
 SUM(CASE WHEN HFI_Type = 3 AND  infra_branding=1 THEN 1 ELSE 0 END) AS c8_uphc,
 SUM(CASE WHEN HFI_Type = 99 AND infra_branding=1 THEN 1 ELSE 0 END) AS c8_subcenter,

                          s.State_Name,
                          d.District_Name,
                          t.Taluka_Name
                          from " . TB_HMIS_HEALTH_FACILITIES . " hf
                          Left join " . TB_PHC_CSC_MSTER . " pcm on hf.HFI_Type=pcm.PHC_CHC_ID
                          Left join " . TB_M_STATES . " s on hf.State_ID=s.State_ID
                          Left join " . TB_M_DISTRICTS . " d on hf.District_ID=d.District_ID
                          Left join " . TB_M_TALUKA . " t on hf.Taluka_ID=t.Taluka_ID
                          Left join " . TB_M_HEALTHBLOCKS . " b on hf.HealthBlock_ID=b.Block_ID
                         Left join " . TB_T_MEMBERS . " m on hf.added_by_user=m.memberID
                         left join " . TB_T_HWC . " hwc on hf.NIN_2_HFI =hwc.NIN_2_HFI
                         left join " . TB_T_HWC_PROPOSED . " hwcp on hf.NIN_2_HFI =hwcp.NIN_2_HFI

                          ";

    $query3 .= 'WHERE hwcp.proposed_status=1 ';

    if ($TYPE == 0) {
      //  $query3 .= " GROUP BY hf.State_ID ";
    } elseif ($TYPE == 1) {
        $query3 .= " AND hf.State_ID=" . $ID;
      //  $query3 .= " GROUP BY d.District_Name ";
    } elseif ($TYPE == 2) {
        $query3 .= " AND hf.District_ID=" . $ID;
     //   $query3 .= " GROUP BY d.District_Name ";
    }


    $stmt3 = $db->query($query3);
    $row3 = $stmt3->fetch();

    return $row3;
}

function dashboardDetail($stateID = null) {
    global $db;

    $query = "SELECT
        SUM(IF(hhf.HFI_Type = 1 AND thw.hr_mo_mbbs = 1 AND mhad.aspirational = 0, 1, 0)) AS phc_operational,
         SUM(IF(hhf.HFI_Type = 1 AND thw.hr_mo_mbbs = 1 AND mhad.aspirational = 1, 1, 0)) AS phc_aspirational_operational,
         SUM(IF(hhf.HFI_Type = 3 AND thw.hr_mo_mbbs = 1 AND mhad.aspirational = 0, 1, 0)) AS uphc_operational,
         SUM(IF(hhf.HFI_Type = 3 AND thw.hr_mo_mbbs = 1 AND mhad.aspirational = 1, 1, 0)) AS uphc_aspirational_operational,
         SUM(IF(hhf.HFI_Type = 99 AND thw.mlhp_posted = 1 AND mhad.aspirational = 0, 1, 0)) AS subcenter_operational,
         SUM(IF(hhf.HFI_Type = 99 AND thw.mlhp_posted = 1 AND mhad.aspirational = 1, 1, 0)) AS subcenter_aspirational_operational,
         SUM(IF(hhf.HFI_Type = 1 AND mhad.aspirational = 0, 1, 0)) AS phc_approved,
         SUM(IF(hhf.HFI_Type = 1 AND mhad.aspirational = 1, 1, 0)) AS phc_aspirational_approved,
         SUM(IF(hhf.HFI_Type = 3 AND mhad.aspirational = 0, 1, 0)) AS uphc_approved,
         SUM(IF(hhf.HFI_Type = 3 AND mhad.aspirational = 1, 1, 0)) AS uphc_aspirational_approved,
         SUM(IF(hhf.HFI_Type = 99 AND mhad.aspirational = 0, 1, 0)) AS subcenter_approved,
         SUM(IF(hhf.HFI_Type = 99 AND mhad.aspirational = 1, 1, 0)) AS subcenter_aspirational_approved
        FROM t_hwc as thw INNER JOIN hmis_healthfacilities as hhf ON thw.NIN_2_HFI = hhf.NIN_2_HFI INNER JOIN m_hwc_aspirational_district mhad ON hhf.District_ID = mhad.District_ID WHERE hhf.HFI_Type IN(1, 3, 99)";
    if (!empty($stateID)) {
        $query .= " AND hhf.State_ID =" . $stateID;
    }

    $query .= " GROUP BY hhf.State_ID ";
    $stmt = $db->query($query);
    $row = $stmt->fetch();
// echo $stateID."======".$query;

    $query2 = "select  count(*) as total_proposed
                          from " . TB_HMIS_HEALTH_FACILITIES . " hf
                          Left join " . TB_PHC_CSC_MSTER . " pcm on hf.HFI_Type=pcm.PHC_CHC_ID
                          Left join " . TB_M_STATES . " s on hf.State_ID=s.State_ID
                          Left join " . TB_M_DISTRICTS . " d on hf.District_ID=d.District_ID
                          Left join " . TB_M_TALUKA . " t on hf.Taluka_ID=t.Taluka_ID
                          Left join " . TB_M_HEALTHBLOCKS . " b on hf.HealthBlock_ID=b.Block_ID
                        Left join " . TB_T_MEMBERS . " m on hf.added_by_user=m.memberID
                         left join " . TB_T_HWC . " hwc on hf.NIN_2_HFI =hwc.NIN_2_HFI
                         left join " . TB_T_HWC_PROPOSED . " hwcp on hf.NIN_2_HFI =hwcp.NIN_2_HFI
                          ";

    $query2 .= 'WHERE hwcp.proposed_status=1 ';
    if (!empty($stateID)) {

        $query2 .= " AND hf.State_ID=" . $stateID;
    }


    $stmt2 = $db->query($query2);
    $row2 = $stmt2->fetch();
// showData($row2);
    $row['total_approved'] = $row2['total_proposed'];

// showData($row);
    $query4 = "select    sum(case when  criteria = 8  then 1 else 0 end) as total_operational
                          from " . TB_HMIS_HEALTH_FACILITIES . " hf
                          Left join " . TB_PHC_CSC_MSTER . " pcm on hf.HFI_Type=pcm.PHC_CHC_ID
                          Left join " . TB_M_STATES . " s on hf.State_ID=s.State_ID
                          Left join " . TB_M_DISTRICTS . " d on hf.District_ID=d.District_ID
                          Left join " . TB_M_TALUKA . " t on hf.Taluka_ID=t.Taluka_ID
                          Left join " . TB_M_HEALTHBLOCKS . " b on hf.HealthBlock_ID=b.Block_ID
                        Left join " . TB_T_MEMBERS . " m on hf.added_by_user=m.memberID
                         left join " . TB_T_HWC . " hwc on hf.NIN_2_HFI =hwc.NIN_2_HFI
                         left join " . TB_T_HWC_PROPOSED . " hwcp on hf.NIN_2_HFI =hwcp.NIN_2_HFI
                          ";

    $query4 .= 'WHERE hwcp.proposed_status=1  AND hwc.verify_status=1 ';
    if (!empty($stateID)) {

        $query4 .= " AND hf.State_ID=" . $stateID;
    }


    $stmt4 = $db->query($query4);
    $row4 = $stmt4->fetch();
// showData($row2);
    $row['total_operational'] = $row4['total_operational'];



    if (!empty($stateID)) {
        $query3 = "select
            
            sum(case when hf.HFI_Type = 1 then 1  else 0 end) AS phc_operational,
           sum(case when hf.HFI_Type = 3 then 1  else 0 end) AS uphc_operational,
           sum(case when hf.HFI_Type = 99 then 1  else 0 end) AS subcenter_operational,

           sum(case when HFI_Type = 1 AND criteria = 8  then 1 else 0 end) as phc_criteria_8,
           sum(case when HFI_Type = 3  AND criteria = 8  then 1 else 0 end) as uphc_criteria_8,
           sum(case when HFI_Type = 99  AND criteria = 8  then 1 else 0 end) as subcenter_criteria_8,

sum(case when HFI_Type = 1 AND criteria = 7  then 1 else 0 end) as phc_criteria_7,
           sum(case when HFI_Type = 3  AND criteria = 7  then 1 else 0 end) as uphc_criteria_7,
           sum(case when HFI_Type = 99  AND criteria = 7  then 1 else 0 end) as subcenter_criteria_7,

sum(case when HFI_Type = 1 AND criteria = 6  then 1 else 0 end) as phc_criteria_6,
           sum(case when HFI_Type = 3  AND criteria = 6  then 1 else 0 end) as uphc_criteria_6,
           sum(case when HFI_Type = 99  AND criteria = 6  then 1 else 0 end) as subcenter_criteria_6,

        sum(case when HFI_Type = 1 AND criteria =5  then 1 else 0 end) as phc_criteria_5,
           sum(case when HFI_Type = 3  AND criteria = 5  then 1 else 0 end) as uphc_criteria_5,
           sum(case when HFI_Type = 99  AND criteria = 5  then 1 else 0 end) as subcenter_criteria_5,

            sum(case when HFI_Type = 1 AND criteria =4  then 1 else 0 end) as phc_criteria_4,
           sum(case when HFI_Type = 3  AND criteria = 4  then 1 else 0 end) as uphc_criteria_4,
           sum(case when HFI_Type = 99  AND criteria = 4  then 1 else 0 end) as subcenter_criteria_4,

          sum(case when HFI_Type = 1 AND criteria <= 3  then 1 else 0 end) as phc_criteria_3,
           sum(case when HFI_Type = 3  AND criteria <= 3  then 1 else 0 end) as uphc_criteria_3,
           sum(case when HFI_Type = 99  AND criteria <= 3  then 1 else 0 end) as subcenter_criteria_3,


                          s.State_Name,
                          d.District_Name,
                          t.Taluka_Name
                          from " . TB_HMIS_HEALTH_FACILITIES . " hf
                          Left join " . TB_PHC_CSC_MSTER . " pcm on hf.HFI_Type=pcm.PHC_CHC_ID
                          Left join " . TB_M_STATES . " s on hf.State_ID=s.State_ID
                          Left join " . TB_M_DISTRICTS . " d on hf.District_ID=d.District_ID
                          Left join " . TB_M_TALUKA . " t on hf.Taluka_ID=t.Taluka_ID
                          Left join " . TB_M_HEALTHBLOCKS . " b on hf.HealthBlock_ID=b.Block_ID
                         Left join " . TB_T_MEMBERS . " m on hf.added_by_user=m.memberID
                         left join " . TB_T_HWC . " hwc on hf.NIN_2_HFI =hwc.NIN_2_HFI
                         left join " . TB_T_HWC_PROPOSED . " hwcp on hf.NIN_2_HFI =hwcp.NIN_2_HFI
                 
                          ";

        $query3 .= 'WHERE hwcp.proposed_status=1 ';
        $query3 .= " AND hf.State_ID=" . $stateID;
        $query3 .= " GROUP BY d.District_Name ";

//$query3 .= limit();
//echo $query3;

        $stmt3 = $db->query($query3);
        $row3 = $stmt3->fetchAll();

        $row['tabledata'] = $row3;
    }
//  ==============================
// showData($row2);
    $row['total_approved'] = $row2['total_proposed'];
//showData($row);
    return $row;
}

function getHWCReport($TYPE = null, $ID = null) {
    global $db;
    // $TYPE=1=Sata, 2= District;
    // showData($row);
    $query = "";
    $where = "";
    $group = '';
    $where .= ' WHERE hwcp.proposed_status=1  AND hwc.verify_status=1 ';

    if ($TYPE == 1 && $ID != null) {
        $where .= " AND hf.State_ID=" . $ID;
        $group = "GROUP BY hf.State_ID";
    } elseif ($TYPE == 2 && $ID != null) {
        $where .= " AND hf.District_ID=" . $ID;
        $group = " GROUP BY hf.District_ID ";
    }

    $sql = " SELECT


SUM(IF(hwc.criteria = 8,1,0)) AS total_operational,
SUM(IF(hf.HFI_Type = 1 AND hwc.criteria = 8,1,0)) AS phc_operational,
SUM(IF(hf.HFI_Type = 3 AND hwc.criteria = 8,1,0)) AS uphc_operational,
SUM(IF(hf.HFI_Type = 99 AND hwc.criteria = 8,1,0)) AS subcenter_operational,

SUM(IF(hwcp.proposed_status=1,1,0)) AS total_approved,
SUM(IF(hf.HFI_Type = 1 AND hwcp.proposed_status=1,1,0)) AS phc_approved,
SUM(IF(hf.HFI_Type = 3 AND hwcp.proposed_status=1,1,0)) AS uphc_approved,
SUM(IF(hf.HFI_Type = 99 AND hwcp.proposed_status=1,1,0)) AS subcenter_approved,

SUM(IF(hwcp.proposed_status=1 AND aspd.aspirational=1 ,1,0)) AS total_aspirational_approved,
SUM(IF(hf.HFI_Type = 1 AND hwcp.proposed_status=1 AND aspd.aspirational=1,1,0)) AS phc_aspirational_approved,
SUM(IF(hf.HFI_Type = 3 AND hwcp.proposed_status=1 AND aspd.aspirational=1,1,0)) AS uphc_aspirational_approved,
SUM(IF(hf.HFI_Type = 99 AND hwcp.proposed_status=1 AND aspd.aspirational=1,1,0)) AS subcenter_aspirational_approved,

SUM(IF(hwc.criteria = 8 AND aspd.aspirational=1, 1,0)) AS total_aspirational_operational,
SUM(IF(hf.HFI_Type = 1  AND aspd.aspirational=1 AND hwc.criteria = 8,1,0)) AS phc_aspirational_operational,
SUM(IF(hf.HFI_Type = 3  AND aspd.aspirational=1 AND hwc.criteria = 8,1,0)) AS uphc_aspirational_operational,
SUM(IF(hf.HFI_Type = 99  AND aspd.aspirational=1 AND hwc.criteria = 8,1,0)) AS subcenter_aspirational_operational

                          from " . TB_HMIS_HEALTH_FACILITIES . " hf
                          Left join " . TB_PHC_CSC_MSTER . " pcm on hf.HFI_Type=pcm.PHC_CHC_ID
                          Left join " . TB_M_STATES . " s on hf.State_ID=s.State_ID
                          Left join " . TB_M_DISTRICTS . " d on hf.District_ID=d.District_ID
                          Left join " . TB_M_TALUKA . " t on hf.Taluka_ID=t.Taluka_ID
                          Left join " . TB_M_HEALTHBLOCKS . " b on hf.HealthBlock_ID=b.Block_ID
                         left join " . TB_T_HWC . " hwc on hf.NIN_2_HFI =hwc.NIN_2_HFI
                         left join " . TB_T_HWC_PROPOSED . " hwcp on hf.NIN_2_HFI =hwcp.NIN_2_HFI
                         left join  m_hwc_aspirational_district aspd on hf.District_ID =aspd.District_ID
                          ";

    $query = $sql . ' ' . $where . ' ' . $group;
    $stmt = $db->query($query);
    $row = $stmt->fetch();
    $result = array(
        'total_approved' => array('TOTAL' => intval($row['total_approved']), 'PHC' => intval($row['phc_approved']), 'UPHC' => intval($row['uphc_approved']), 'SHC' => intval($row['subcenter_approved'])),
        'total_operational' => array('TOTAL' => intval($row['total_operational']), 'PHC' => intval($row['phc_operational']), 'UPHC' => intval($row['uphc_operational']), 'SHC' => intval($row['subcenter_operational'])),
        'total_aspirational_approved' => array('TOTAL' => intval($row['total_aspirational_approved']), 'PHC' => intval($row['phc_aspirational_approved']), 'UPHC' => intval($row['uphc_aspirational_approved']), 'SHC' => intval($row['subcenter_aspirational_approved'])),
        'total_aspirational_operational' => array('TOTAL' => intval($row['phc_aspirational_operational']), 'PHC' => intval($row['phc_aspirational_operational']), 'UPHC' => intval($row['uphc_aspirational_operational']), 'SHC' => intval($row['subcenter_aspirational_operational']))
    );

    return $result;
}




function getHWCGraphReport($TYPE = null, $ID = null) {
    global $db;
    // $TYPE=1=Sata, 2= District;
    // showData($row);
    $query = "";
    $where = "";
    $where2 = "";

    $group = '';
    $where .= ' WHERE hwcp.proposed_status=1  ';

    if ($TYPE == 1 && $ID != null) {
        $where .= " AND hf.State_ID=" . $ID;
        $group = "GROUP BY hf.State_ID";
    } elseif ($TYPE == 2 && $ID != null) {
        $where .= " AND hf.District_ID=" . $ID;
        $group = " GROUP BY hf.District_ID ";
    }

    $sql = " SELECT

SUM(IF(hwcp.proposed_status=1,1,0)) AS total_proposed,
SUM(IF(hf.HFI_Type = 1 AND hwcp.proposed_status=1,1,0)) AS phc_proposed,
SUM(IF(hf.HFI_Type = 3 AND hwcp.proposed_status=1,1,0)) AS uphc_proposed,
SUM(IF(hf.HFI_Type = 99 AND hwcp.proposed_status=1,1,0)) AS subcenter_proposed,

SUM(CASE WHEN HFI_Type = 1 AND hr_mo_mbbs = 1 AND (training_mos = 1 OR traning_hr_mos_staff_nurses = 1) AND medicines_available=1 AND diagnostics_available=1 AND  infra_branding=1 THEN 1 ELSE 0 END) AS dashboard_mc_phc,
SUM(CASE WHEN HFI_Type = 3 AND hr_mo_mbbs = 1 AND (training_mos = 1 OR traning_hr_mos_staff_nurses = 1) AND medicines_available=1 AND diagnostics_available=1   AND  infra_branding=1 THEN 1 ELSE 0 END) AS dashboard_mc_uphc,
SUM(CASE WHEN HFI_Type = 99 AND mlhp_posted = 1 AND (training_mpwf = 1 OR traning_ashas = 1) AND medicines_available=1 AND diagnostics_available=1  AND  infra_branding=1 THEN 1 ELSE 0 END) AS dashboard_mc_subcenter,

SUM(CASE WHEN HFI_Type = 1  AND hr_mo_mbbs = 1 AND (training_mos = 1 OR traning_hr_mos_staff_nurses = 1) AND medicines_available=1 AND diagnostics_available=1 AND (service_hypertension=1 AND service_diabetes=1 AND service_oral_cancer=1 AND service_breast_cancer=1)   AND  infra_branding=1 THEN 1 ELSE 0 END) AS dashboard_mca_phc,
SUM(CASE WHEN HFI_Type = 3  AND hr_mo_mbbs = 1 AND (training_mos = 1 OR traning_hr_mos_staff_nurses = 1) AND medicines_available=1 AND diagnostics_available=1 AND (service_hypertension=1 AND service_diabetes=1 AND service_oral_cancer=1 AND service_breast_cancer=1)   AND  infra_branding=1 THEN 1 ELSE 0 END) AS dashboard_mca_uphc,
SUM(CASE WHEN HFI_Type = 99  AND mlhp_posted = 1 AND (training_mpwf = 1 OR traning_ashas = 1) AND medicines_available=1 AND diagnostics_available=1 AND (service_hypertension=1 AND service_diabetes=1 AND service_oral_cancer=1 AND service_breast_cancer=1)   AND  infra_branding=1 THEN 1 ELSE 0 END) AS dashboard_mca_subcenter,


SUM(IF(hwcp.proposed_status=1 AND aspd.aspirational=1 ,1,0)) AS total_aspirational_approved,
SUM(IF(hf.HFI_Type = 1 AND hwcp.proposed_status=1 AND aspd.aspirational=1,1,0)) AS phc_aspirational_approved,
SUM(IF(hf.HFI_Type = 3 AND hwcp.proposed_status=1 AND aspd.aspirational=1,1,0)) AS uphc_aspirational_approved,
SUM(IF(hf.HFI_Type = 99 AND hwcp.proposed_status=1 AND aspd.aspirational=1,1,0)) AS subcenter_aspirational_approved,

SUM(CASE WHEN HFI_Type = 1 AND hwcp.proposed_status=1 AND aspd.aspirational=1   AND  hr_mo_mbbs = 1 AND (training_mos = 1 OR traning_hr_mos_staff_nurses = 1) AND medicines_available=1 AND diagnostics_available=1 THEN 1 ELSE 0 END) AS dashboard_mc_subcenter_aspirational,
SUM(CASE WHEN HFI_Type = 3 AND hwcp.proposed_status=1 AND aspd.aspirational=1 AND hr_mo_mbbs = 1 AND (training_mos = 1 OR traning_hr_mos_staff_nurses = 1) AND medicines_available=1 AND diagnostics_available=1 THEN 1 ELSE 0 END) AS dashboard_mc_uphc_aspirational,
SUM(CASE WHEN HFI_Type = 99  AND hwcp.proposed_status=1 AND aspd.aspirational=1 AND mlhp_posted = 1 AND (training_mpwf = 1 OR traning_ashas = 1) AND medicines_available=1 AND diagnostics_available=1 THEN 1 ELSE 0 END) AS dashboard_mc_subcenter_aspirational,


SUM(CASE WHEN HFI_Type = 1 AND criteria = 8 THEN 1 ELSE 0 END) AS phc_criteria_8,
SUM(CASE WHEN HFI_Type = 3 AND criteria = 8 THEN 1 ELSE 0 END) AS uphc_criteria_8,
SUM(CASE WHEN HFI_Type = 99 AND criteria = 8 THEN 1 ELSE 0 END) AS subcenter_criteria_8

from " . TB_HMIS_HEALTH_FACILITIES . " hf
Left join " . TB_PHC_CSC_MSTER . " pcm on hf.HFI_Type=pcm.PHC_CHC_ID
Left join " . TB_M_STATES . " s on hf.State_ID=s.State_ID
Left join " . TB_M_DISTRICTS . " d on hf.District_ID=d.District_ID
Left join " . TB_M_TALUKA . " t on hf.Taluka_ID=t.Taluka_ID
Left join " . TB_M_HEALTHBLOCKS . " b on hf.HealthBlock_ID=b.Block_ID
left join " . TB_T_HWC . " hwc on hf.NIN_2_HFI =hwc.NIN_2_HFI
left join " . TB_T_HWC_PROPOSED . " hwcp on hf.NIN_2_HFI =hwcp.NIN_2_HFI
left join  m_hwc_aspirational_district aspd on hf.District_ID =aspd.District_ID
";

$query = $sql . ' ' . $where . ' ' . $group;
$stmt = $db->query($query);
$row = $stmt->fetch();
return $row;

}

function getApprovedData($TYPE = null, $ID = null) {
    global $db, $CURRENT_USER_ROLE;


    $where = '';

    if ($TYPE == 1 && $ID != null) {
        $where .= " WHERE State_ID=" . $ID;
    } elseif ($TYPE == 2 && $ID != null) {
        $where .= " WHERE State_ID=" . $CURRENT_USER_ROLE;
    }


    $query2 = "SELECT SUM(y_uphc)AS total_uphc,
    SUM(y_phc)AS total_phc,
    SUM(y_shc) AS total_shc
    FROM `hwc_planing_years` " . $where;



    $stmt2 = $db->query($query2);
    $row2 = $stmt2->fetch();
   // print_r($row2); die;
    return $row2;
}

function fetchsyncdata($TYPE = null, $ID = null) {
    global $db;
    if ($TYPE == 1 && $ID != null) {
        
        $query = " SELECT getApprovedState,hwcGraphReport,hwcGraphCAReport,entry_status_graph_data,hwcCAreport FROM `hwc_top_dashboard` where state_id ='".$ID."'  GROUP BY state_id ";
    }else{
        
        $query = " SELECT getApprovedState,hwcGraphReport,hwcGraphCAReport,entry_status_graph_data,hwcCAreport FROM `hwc_top_dashboard` where state_id ='0' ";
    }
    $stmt = $db->query($query);
   //echo $query; die;
    $row = $stmt->fetch();
    $result = $row;
   
    return $result;
} 


/*function fetchsyncdata($TYPE = null, $ID = null) {
    global $db;
    if ($TYPE == 1 && $ID != null) {
        
        $query = " SELECT getApprovedState,hwcGraphReport,hwcGraphCAReport,entry_status_graph_data,hwcCAreport FROM `hwc_top_dashboard` where state_id ='".$ID."'  GROUP BY state_id ";
    }else{
        
        $query = " SELECT getApprovedState,hwcGraphReport,hwcGraphCAReport,entry_status_graph_data,hwcCAreport FROM `hwc_top_dashboard` where state_id ='0' ";
    }
    $stmt = $this->db->query($query);
   //echo $query; die;
   
    $row = $stmt->fetch();
    $result = $row;
    echo "<pre>";
        print_r($result); die;
    return $result;
}  */     


function getGraphData($TYPE = null, $ID = null) {

    global $db;
    $query = "";
    $where = "";
    $group = '';
    $where .= ' WHERE hwcp.proposed_status=1   ';
    if ($TYPE == 1 && $ID != null) {
        $where .= " AND hf.State_ID=" . $ID;
        $group = "GROUP BY hf.State_ID";
    } elseif ($TYPE == 2 && $ID != null) {
        $where .= " AND hf.District_ID=" . $ID;
        $group = " GROUP BY hf.District_ID ";
    }

    $sql = " SELECT

SUM(IF(hwcp.proposed_status=1 AND hwc.status=1,1,0)) AS total_filled ,
SUM(IF(hf.HFI_Type = 1 AND hwcp.proposed_status=1 AND hwc.status=1,1,0)) AS phc_filled,
SUM(IF(hf.HFI_Type = 3 AND hwcp.proposed_status=1 AND hwc.status=1,1,0)) AS uphc_filled,
SUM(IF(hf.HFI_Type = 99 AND hwcp.proposed_status=1 AND hwc.status=1,1,0)) AS subcenter_filled,


    SUM(IF(hwcp.proposed_status=1 AND hwc.criteria = 8,1,0)) AS total_operational,
SUM(IF(hf.HFI_Type = 1 AND hwcp.proposed_status=1  AND hwc.status=1  AND hwc.criteria = 8,1,0)) AS phc_operational,
SUM(IF(hf.HFI_Type = 3 AND hwcp.proposed_status=1  AND hwc.status=1  AND hwc.criteria = 8,1,0)) AS uphc_operational,
SUM(IF(hf.HFI_Type = 99 AND hwcp.proposed_status=1  AND hwc.status=1  AND hwc.criteria = 8,1,0)) AS subcenter_operational,



SUM(IF(hwcp.proposed_status=1,1,0)) AS total_proposed,
SUM(IF(hf.HFI_Type = 1 AND hwcp.proposed_status=1  ,1,0)) AS phc_proposed,
SUM(IF(hf.HFI_Type = 3 AND hwcp.proposed_status=1  ,1,0)) AS uphc_proposed,
SUM(IF(hf.HFI_Type = 99 AND hwcp.proposed_status=1  ,1,0)) AS subcenter_proposed,

SUM(IF(hwc.verify_status = 1, 1,0)) AS total_verify,
SUM(IF(hf.HFI_Type = 1 AND hwcp.proposed_status=1 AND hwc.verify_status = 1,1,0)) AS phc_verify,
SUM(IF(hf.HFI_Type = 3 AND hwcp.proposed_status=1 AND hwc.verify_status = 1,1,0)) AS uphc_verify,
SUM(IF(hf.HFI_Type = 99 AND hwcp.proposed_status=1 AND hwc.verify_status = 1,1,0)) AS subcenter_verify


                          from " . TB_HMIS_HEALTH_FACILITIES . " hf
                          Left join " . TB_PHC_CSC_MSTER . " pcm on hf.HFI_Type=pcm.PHC_CHC_ID
                          Left join " . TB_M_STATES . " s on hf.State_ID=s.State_ID
                          Left join " . TB_M_DISTRICTS . " d on hf.District_ID=d.District_ID
                          Left join " . TB_M_TALUKA . " t on hf.Taluka_ID=t.Taluka_ID
                          Left join " . TB_M_HEALTHBLOCKS . " b on hf.HealthBlock_ID=b.Block_ID
                         left join " . TB_T_HWC . " hwc on hf.NIN_2_HFI =hwc.NIN_2_HFI
                         left join " . TB_T_HWC_PROPOSED . " hwcp on hf.NIN_2_HFI =hwcp.NIN_2_HFI
                         left join  m_hwc_aspirational_district aspd on hf.District_ID =aspd.District_ID
                          ";

    $query = $sql . ' ' . $where . ' ' . $group;
    $stmt = $db->query($query);
    $row = $stmt->fetch();


    $result = $row;
    return $result;
}

function percentage($total, $value) {
    if ($total > 0) {
        $percentCal = ($value / $total) * 100;
        ;
        $percent = round($percentCal, 2);
    } else {
        $percent = 0;
    }
    return intval($percent);
}






?>