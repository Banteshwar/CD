<?php

function getStateDistrictSelectJS($user) {
    global $USER_ROLES, $USER_PERMISSIONS, $USER_ROLES_PERMISSIONS;
    global $CURRENT_USER_ROLE; // maintain current USER ROLE
    global $CURRENT_USER_STATE;  // maintain current USER Belonging State
    global $CURRENT_USER_DISTRICT;  // maintain current USER Belonging District
    global $LOADING_TEXT;
?>
    <script type = "text/javascript">

<?php if (!isHavingState($user)) {
    ?>
            $('select[name=\'state\']').on('change', function() {
            $.ajax({
                                    url: '<?= base_url('ajax/getSelectSDTH') ?>',
                                            type: 'post',
                    data: 'action=getDistricts&State_ID=' + encodeURIComponent(this.value),
                    dataType: 'json',
                    beforeSend: function() {
                    $('.alert').remove();
                    var district = $('select[name=\'district\']');
                    $('option[value!="0"]', district).remove();
                    var taluka = $('select[name=\'taluka\']');
                    $('option[value!="0"]', taluka).remove();
                    var healthBlock = $('select[name=\'healthBlock\']');
                    $('option[value!="0"]', healthBlock).remove();
                    $('select[name=\'state\']').after('<span class="loading alert">&nbsp;</span>');
                    },
                    complete: function() {

                    },
                    success: function(json) {
                    $('.alert').remove();
                    if (json['error']) {
                    $('select[name=\'state\']').after('<div class="alert error">' + json['error'] + '</div>');
                    }
                    if (json['data'] && json['data']['district']) {
                    var district = $('select[name=\'district\']');
                    $('option[value!="0"]', district).remove();
                    var taluka = $('select[name=\'taluka\']');
                    $('option[value!="0"]', taluka).remove();
                    var healthBlock = $('select[name=\'healthBlock\']');
                    $('option[value!="0"]', healthBlock).remove();
                    $.each(json['data']['district'], function(index, item) {
                    // console.log(index +' '+item);
                    district.append(new Option(item + '(' + index + ')', index));
                    });
                    }
                    if (json['redirect']) {
                    location = json['redirect'];
                    }
                    },
                    error: function(xhr, ajaxOptions, thrownError) {
                    alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
                    }
            });
            });
        <?php } ?>
<?php if (!isHavingDistrict($user)) { ?>
            $('select[name=\'district\']').on('change', function() {
            $.ajax({
                   url: '<?= base_url('ajax/getSelectSDTH') ?>',
                            type: 'post',
                <?php if (!isHavingState($user)) { ?>
                    data: 'action=getTalukas&State_ID=' + $('select[name=\'state\']').val() + '&District_ID=' + $('select[name=\'district\']').val(),
                <?php } else { ?>
                    data: 'action=getTalukas&State_ID=<?php echo $CURRENT_USER_STATE; ?>&District_ID=' + $('select[name=\'district\']').val(),
    <?php } ?>
            dataType: 'json',
                    beforeSend: function() {
                    $('.alert').remove();
                    var taluka = $('select[name=\'taluka\']');
                    $('option[value!="0"]', taluka).remove();
                    var healthBlock = $('select[name=\'healthBlock\']');
                    $('option[value!="0"]', healthBlock).remove();
                    $('select[name=\'district\']').after('<span class="loading alert">&nbsp;</span>');
                    },
                    complete: function() {

                    },
                    success: function(json) {
                    $('.alert').remove();
                    if (json['error']) {
                    $('select[name=\'district\']').after('<div class="alert error">' + json['error'] + '</div>');
                    }
                    if (json['data']) {

                    var taluka = $('select[name=\'taluka\']');
                    $('option[value!="0"]', taluka).remove();
                    var healthBlock = $('select[name=\'healthBlock\']');
                    $('option[value!="0"]', healthBlock).remove();
                    if (json['data']['talukas']){
                    $.each(json['data']['talukas'], function(index, item) {
                    taluka.append(new Option(item + '(' + index + ')', index));
                    });
                    }

                    if (json['data']['healthBlocks']) {
                    $.each(json['data']['healthBlocks'], function(index, item) {
                    healthBlock.append(new Option(item + '(' + index + ')', index));
                    });
                    }
                    }
                    if (json['redirect']) {
                    location = json['redirect'];
                    }
                    },
                    error: function(xhr, ajaxOptions, thrownError) {
                    alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
                    }
            });
            });
<?php } ?>
    $('select[name=\'taluka\']').on('change', function() {
    $.ajax({
       url: '<?= base_url('ajax/getSelectSDTH') ?>',
                type: 'post',
        <?php if (!isHavingState($user) && !isHavingDistrict($user)) { ?>
            data: 'action=getHealthBlocks&State_ID=' + $('select[name=\'state\']').val() + '&District_ID=' + $('select[name=\'district\']').val() + '&Taluka_ID=' + $('select[name=\'taluka\']').val(),
        <?php } else if (isHavingState($user) && !isHavingDistrict($user)) { ?>
            data: 'action=getHealthBlocks&State_ID=<?php echo $CURRENT_USER_STATE; ?>&District_ID=' + $('select[name=\'district\']').val() + '&Taluka_ID=' + $('select[name=\'taluka\']').val(),
        <?php } else { ?>
            data: 'action=getHealthBlocks&State_ID=<?php echo $CURRENT_USER_STATE; ?>&District_ID=<?php echo $CURRENT_USER_DISTRICT; ?>&Taluka_ID=' + $('select[name=\'taluka\']').val(),
<?php } ?>
    dataType: 'json',
            beforeSend: function() {
            $('.alert').remove();
            var healthBlock = $('select[name=\'healthBlock\']');
            $('option[value!="0"]', healthBlock).remove();
            $('select[name=\'taluka\']').after('<span class="loading alert">&nbsp;</span>');
            },
            complete: function() {

            },
            success: function(json) {
            $('.alert').remove();
            if (json['error']) {
            $('select[name=\'taluka\']').after('<div class="alert error">' + json['error'] + '</div>');
            }
            if (json['data']) {
            var healthBlock = $('select[name=\'healthBlock\']');
            $('option[value!="0"]', healthBlock).remove();
            if (json['data']['healthBlocks']) {
            $.each(json['data']['healthBlocks'], function(index, item) {
            healthBlock.append(new Option(item + '(' + index + ')', index));
            });
            }
            }
            if (json['redirect']) {
            location = json['redirect'];
            }
            },
            error: function(xhr, ajaxOptions, thrownError) {
            alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
            }
    });
    });
</script>
<?php
}

function getModalPopUp() {
?>
        <script>
            //$('.get_modal_data_click').click(function () {
            $(document).on('click', '.get_modal_data_click', function () {
                var title = $(this).attr('data-TITLE');
                var URL = $(this).attr('data-URL');
                var DATA = $(this).attr('data-DATA');

                $('#getModal').modal();
                $('#ModalTitle').html(title);
                    $('#modal_body_data').html('<div class="row">  <center>Please Wait....<br><img src="<?= base_url('/assets/img/input-spinner.gif') ?>" id="LoadingImage" /></center></div>');

                $.ajax({
                    url: URL,
                    method: "POST",
                    data: {DATA: DATA},
                    success: function (data)
                    {
                        $('#modal_body_data').html(data);


                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
                    }
                });

                // return true;


                // $("REQUST_ID").val('1');
                // alert(requestID);
            });


        </script>
    <?php
}

function getFormHandler($FORM_ID) {
    ?>

    <!--            <script type="text/javascript">
                        $(function () {
                            $("# $FORM_ID ?>").jCryption();
                        });
            </script>-->


        <script>
            $(function () {
                //$('#contact-form').validator();
                    $('#<?= $FORM_ID ?>').on('submit', function (e) {
    //                         var val = $("input[type=submit][clicked=true]").val()
                                if (!e.isDefaultPrevented()) {
                                    var url = $(this).attr('action');
                                            
                //                                   var data = $('input[name=jCryption]', this).serialize();
                                                         var data = $('#<?= $FORM_ID ?>').serialize();
                                   // alert(url);
                                    $('.<?= $FORM_ID ?>').html('<div class="row">  <center>Please Wait....<br><img src="<?= base_url('/assets/img/input-spinner.gif') ?>" id="LoadingImage" /></center></div>');
                                $.ajax({
                                 type: "POST",
                                 url: url,
                                                data: data,
                                            success: function (data)
                            {
                                if (data.status == 'success')
                                {
                                    //   alert(data.message);
                                    $('#<?= $FORM_ID . '_RESULT' ?>').html('<div class="box"> <div class="box-body"> <h1 class="text-green text-center"> <i class="fa fa-fw fa-check-square-o"></i> Success! </h1><h4 class="text-green text-center">' + data.status_msg + '</h4> </div> <div class="box-footer"> <button type="submit" class="btn btn-default marginright pull-right" data-dismiss="modal">Close</button> </div></div>');

                                    if (data.hasOwnProperty('return_url')) {
                                        //  alert (data.return_url);
                                        //  Redirect(data.return_url;
                                        //  window.location=data.return_url;
                                        location.reload();
                                    }


                                } else {
                                    var token = data.token;
                                    document.getElementById('EncToken').value = token;
                                    $('.<?= $FORM_ID ?>').html('<div class="alert alert-block alert-danger fade in"> <button data-dismiss="alert" class="close close-sm" type="button"><i class="fa fa-times"></i></button> <h4> <i class="fa fa-fw fa-warning"></i> Error !</h4><p>' + data.status_msg + '</p>  </div>');
                                }

                            },
                            error: function (xhr, ajaxOptions, thrownError) {
                                alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
                            }
                        });
                        return false;
                    }
                })
            });

        </script>

    <?php
}

//=================================== Error Formate And Display ============================================
function error_format($error) {
    $output = '';
    //check for any errors
    if (isset($error) && count($error) > 0) {
        $output = '<div class=" error alert alert-danger"><ul style=" list-style: none " >';
        foreach ($error as $error) {
            $output .= '<li ><i class="fa fa-times-circle-o"></i>  ' . $error . '</li>';
        }
        $output .= '</ul></div>';
    }
    return $output;
}

/** Set Global Message * */
function status_message($message) {
    $_SESSION['status_message'] = $message;
}

function error_message($message) {
    $_SESSION['error_message'] = $message;
}

function warning_message($message) {
    $_SESSION['warning_message'] = $message;
}

function info_message($message) {
    $_SESSION['info_message'] = $message;
}

function display_message() {
    if (isset($_SESSION['status_message']) && $_SESSION['status_message'] != '') {

 
        echo '<div class="success alert alert-success"><h4> <i class="fa fa-fw fa-check-square-o"></i> Success !</h4>' . $_SESSION['status_message'] . '</div>';
        unset($_SESSION['status_message']);
    }

    if (isset($_SESSION['error_message'])) {
        echo '<div class=" error alert alert-danger"><h4> <i class="fa fa-fw fa-warning"></i> Error !</h4>' . $_SESSION['error_message'] . '</div>';
        unset($_SESSION['error_message']);
    }

    if (isset($_SESSION['warning_message'])) {
        echo '<div class="error alert alert-warning"><h4> <i class="fa fa-fw fa-warning"></i> Warning !</h4>' . $_SESSION['warning_message'] . '</div>';
        unset($_SESSION['warning_message']);
    }
}

//= === === === === === === === === === === = Pagination === === === === === === === === === === === === === /**
// *
// * @param type $rpp   Number of Record per page
// */
function record_per_page($rpp = 0) {
if ($rpp == 0) {
    $record_per_page = 50;
    }
if (isset($_GET['record_per_page'])) {
$tmp_rpp = (int) $_GET['record_per_page'];
if ($tmp_rpp > 0) {
    $record_per_page = $tmp_rpp;
}
}
return $record_per_page;
}

function serial_number_start($rpp = 0) {
if ($rpp == 0) {
$record_per_page = record_per_page();
}
$page = 1;
if (isset($_GET['page'])) {
$page = (int) $_GET['page'];
if ($page < 1) {
    $page = 1;
}
}
$starting = ($page - 1) * record_per_page();

return $starting;
}

/**
 *
 * @param type $total  Total number of page exists
 * @param type $rpp    Number of Record per page
 */
function limit($rpp = 0) {
$record_per_page = record_per_page($rpp);

$page = 1;
if (isset($_GET['page'])) {
$page = (int) $_GET['page'];
if ($page < 1) {
    $page = 1;
}
}

$startPage = ($page - 1) * $record_per_page;
if ($startPage < 0)
$startPage = 0;

$limit = " limit " . $startPage . "," . $record_per_page;
return $limit;
}

function pagination($total, $pageUrl = '', $rpp = 0) {

$record_per_page = record_per_page($rpp);
$totalPages = ceil($total / $record_per_page);
$adjacents = 4;
$prevlabel = "&lsaquo; Prev";
$nextlabel = "Next &rsaquo;";
$out = "";

if ($totalPages > 1) {

$page = 1;
$outli = array();
if (isset($_GET['page'])) {
    $page = (int) $_GET['page'];
    if ($page < 1) {
        $page = 1;
    }
}
if ($pageUrl == '') {
    $pageUrl = basename($_SERVER['PHP_SELF']);
}

// previous
if ($page == 1) {
    // $outli[] = "<span class='page prevpage'>".$prevlabel."</span>";
} else {
    $outli[] = sprintf('<li><a href="%s?%s" class=\'page prevpage\'>' . $prevlabel . '</a></li>', $pageUrl, http_build_query(array('page' => $page - 1) + $_GET));
}

$pmin = ($page > $adjacents) ? ($page - $adjacents) : 1;
$pmax = ($page < ($totalPages - $adjacents)) ? ($page + $adjacents) : $totalPages;

if ($page > $adjacents + 1) {
    $outli[] = sprintf('<li><a href="%s?%s" class="page">1</a></li>', $pageUrl, http_build_query(array('page' => 1) + $_GET));
}
for ($i = $pmin; $i <= $pmax; $i++) {
    if ($i == $page) {
        $outli[] = "<li><span class=\"page active\">" . $i . "</span></li>";
    } else {
        $outli[] = sprintf('<li><a href="%s?%s" class="page">' . $i . '</a></li>', $pageUrl, http_build_query(array('page' => $i) + $_GET));
    }
}

if ($page < ($totalPages - $adjacents)) {
    //$out.= "<a  href=\"" . $pageUrl."&amp;page=".$totalPages."\">" .$totalPages."</a>\n";
    $outli[] = sprintf('<li><a href="%s?%s" class="page ">' . $totalPages . '</a></li>', $pageUrl, http_build_query(array('page' => $totalPages) + $_GET));
}
// next
if ($page < $totalPages) {
    $outli[] = sprintf('<li><a href="%s?%s" class="page " >' . $nextlabel . '</a></li>', $pageUrl, http_build_query(array('page' => $page + 1) + $_GET));
    //$out.= "<li><a href=\"".$pageUrl."&amp;page=".($page + 1)."\">".$nextlabel."</a>\n</li>";
} else {
    // $outli[]= "<span class=\"page nextpage\">".$nextlabel."</span>\n";
}
$out = implode('', $outli);
$startNumber = ($page - 1) * $record_per_page;
$toNumber = $startNumber + $record_per_page;
if ($toNumber > $total) {
    $toNumber = $total;
}

return '
                                <div class="boxtools">
                                <div class="row">
                                <div class="col-md-6">
                                    <label class="shorting_numbar"> Showing  ' . ($startNumber + 1) . ' to ' . $toNumber . ' of Total: ' . $total . '</label>
                                        </div>
<div class="col-md-6 pull-right">
<ul class="pagination pagination-sm no-margin pull-right">' . $out . '
                                            </ul>
                                        </div></div></div>';
}
return $out;
}

function paginate($pageUrl, $page, $tpages) {
$adjacents = 2;
$prevlabel = "&lsaquo; Prev";
$nextlabel = "Next &rsaquo;";
$out = "";
// previous
if ($page == 1) {
$out .= "<span>" . $prevlabel . "</span>\n";
} elseif ($page == 2) {
$out .= "<li><a href=\"" . $pageUrl . "\">" . $prevlabel . "</a>\n</li>";
} else {
$out .= "<li><a href=\"" . $pageUrl . "&amp;page=" . ($page - 1) . "\">" . $prevlabel . "</a>\n</li>";
}
$pmin = ($page > $adjacents) ? ($page - $adjacents) : 1;
$pmax = ($page < ($tpages - $adjacents)) ? ($page + $adjacents) : $tpages;
for ($i = $pmin; $i <= $pmax; $i++) {
if ($i == $page) {
    $out .= "<li class=\"active\">" . $i . "</li>\n";
} elseif ($i == 1) {
    $out .= "<li><a href=\"" . $pageUrl . "\">" . $i . "</a>\n</li>";
} else {
    $out .= "<li><a href=\"" . $pageUrl . "&amp;page=" . $i . "\">" . $i . "</a>\n</li>";
}
}

if ($page < ($tpages - $adjacents)) {
$out .= "<li><a style='font-size:11px' href=\"" . $pageUrl . "&amp;page=" . $tpages . "\">" . $tpages . "</a><li>";
}
// next
if ($page < $tpages) {
$out .= "<li><a href=\"" . $pageUrl . "&amp;page=" . ($page + 1) . "\">" . $nextlabel . "</a>\n</li>";
} else {
$out .= "<li><span style='font-size:11px'>" . $nextlabel . "</span><li>";
}
$out .= "";
return $out;
}

//================================Pagination End=======================================
function showError() {// Turn off all error reporting
    error_reporting(0);
//
//// Report simple running errors
error_reporting(E_ERROR | E_WARNING | E_PARSE);
//
//// Reporting E_NOTICE can be good too (to report uninitialized
//// variables or catch variable name misspellings ...)
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
error_reporting(E_ERROR | E_WARNING | E_PARSE);

//// Report all errors except E_NOTICE
error_reporting(E_ALL & ~E_NOTICE);
//
//// Report all PHP errors (see changelog)
error_reporting(E_ALL);
//
//// Report all PHP errors
error_reporting(-1);
//Same as error_reporting(E_ALL);
ini_set('error_reporting', E_ALL);
}



    function showData($array) {
    if ($array) {
            if (is_array($array) || is_object($array)) {
                echo '</br>=====Array  Start ======</br>';
                // showArrayData($array);
                echo "<pre>" . print_r($array, true) . "</pre>";
                echo '</br>=======END======</br>';
            } else {
                echo $array;
            }
        } else {
            var_dump($array);
        }
    }

function JSONArrayResponse($responseArray) {
    $encoded = json_encode($responseArray);
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
                    header('Content-Type: application/json');
            echo $encoded;
            exit;
    } else {
            echo $encoded;
       exit;
    }
    }



