<?php
include_once 'Dashboard_function.php';


function getNINFunctionalFacilities($groupBy = false, $search_state_id='') { 

        $DBHOST = 'localhost';
        $DBNAME = 'ninlive';
        $DBUSER = 'root';
        $DBPASS = 'DC^_^ami98';
   

        $db = new PDO("mysql:host=" . $DBHOST . ";port=3306;dbname=" . $DBNAME, $DBUSER, $DBPASS);

   // global $db;
	
	$group_query = '';
	$join = '';
	$select_filds = '';
	
	if($groupBy == TRUE) {
	  $select_filds = ' s.State_Name,
					s.State_ID,
					s.state_char_code,';		
	  $join = " Left join " . TB_M_STATES . " s on hf.State_ID=s.State_ID ";
	  $group_query = 'GROUP BY s.State_ID' ;
	}
	
    $where = ' WHERE hf.verified_flag = 1  AND ( hf.operational_Status = 1 OR hf.operational_Status = 3 )  ';

    if($search_state_id)
    { 
    $where =  $where.' AND hf.State_ID='.$search_state_id. ' ';	
    }
    
   
    $sql = "SELECT
		".$select_filds."
        COUNT(*) AS Total_Facility,
        sum(case when HFI_Type = 1 then 1 else 0 end) as Primary_Health_Centre,
        sum(case when HFI_Type = 2 then 1 else 0 end) as Community_Health_Center,
        sum(case when HFI_Type = 3 then 1 else 0 end) as Urban_Health_Centre,
        sum(case when HFI_Type = 4 then 1 else 0 end) as Sub_District_Hospital,
        sum(case when HFI_Type = 5 then 1 else 0 end) as District_Hospital,
        sum(case when HFI_Type = 6 then 1 else 0 end) as Civil_Hospital_or_General_Hospital,
        sum(case when HFI_Type = 7 then 1 else 0 end) as Referral_Hospital,
        sum(case when HFI_Type = 8 then 1 else 0 end) as Dispensaries,
        sum(case when HFI_Type = 9 then 1 else 0 end) as Ayush_Dispensaries,
        sum(case when HFI_Type = 10 then 1 else 0 end) as Maternity_Home,
        sum(case when HFI_Type = 11 then 1 else 0 end) as Post_Partum_Unit,
        sum(case when HFI_Type = 12 then 1 else 0 end) as 'M&CW_Center',
        sum(case when HFI_Type = 13 then 1 else 0 end) as '<100_Bedded_Hospital',
        sum(case when HFI_Type = 14 then 1 else 0 end) as '100-500_Bedded_Hospital',
        sum(case when HFI_Type = 15 then 1 else 0 end) as '>500_Bedded_Hospital',
        sum(case when HFI_Type = 16 then 1 else 0 end) as Urban_Health_Posts,
        sum(case when HFI_Type = 17 then 1 else 0 end) as Medical_Colleges_Hospital,
        sum(case when HFI_Type = 18 then 1 else 0 end) as Women_Hospital,
        sum(case when HFI_Type = 99 then 1 else 0 end) as SubCentre,
        sum(case when HFI_Type = 100 then 1 else 0 end) as Others
        FROM " . TB_HMIS_HEALTH_FACILITIES . " hf ". $join;

  $query = $sql . ' ' . $where . $group_query; 
 //echo $query; die();
 

    $stmt = $db->query($query);

	if($groupBy == TRUE) {
		return $stmt->fetchAll();
	}
	return $stmt->fetch(); 
}



function getNINFunctionalStateWiseFacilities() {


        $DBHOST = 'localhost';
        $DBNAME = 'ninlive';
        $DBUSER = 'root';
        $DBPASS = 'DC^_^ami98';
   

        $db = new PDO("mysql:host=" . $DBHOST . ";port=3306;dbname=" . $DBNAME, $DBUSER, $DBPASS);

   // global $db;
    $where = 'WHERE hf.verified_flag = 1  AND ( hf.operational_Status = 1 OR hf.operational_Status = 3 )  ';
   
    $sql = "SELECT
        COUNT(NIN_2_HFI) AS Total_Facility,
		s.State_Name,
		s.State_ID,
		s.state_char_code,
        sum(case when HFI_Type = 1 then 1 else 0 end) as Primary_Health_Centre,
        sum(case when HFI_Type = 2 then 1 else 0 end) as Community_Health_Center,
        sum(case when HFI_Type = 3 then 1 else 0 end) as Urban_Health_Centre,
        sum(case when HFI_Type = 4 then 1 else 0 end) as Sub_District_Hospital,
        sum(case when HFI_Type = 5 then 1 else 0 end) as District_Hospital,
        sum(case when HFI_Type = 6 then 1 else 0 end) as Civil_Hospital_or_General_Hospital,
        sum(case when HFI_Type = 7 then 1 else 0 end) as Referral_Hospital,
        sum(case when HFI_Type = 8 then 1 else 0 end) as Dispensaries,
        sum(case when HFI_Type = 9 then 1 else 0 end) as Ayush_Dispensaries,
        sum(case when HFI_Type = 10 then 1 else 0 end) as Maternity_Home,
        sum(case when HFI_Type = 11 then 1 else 0 end) as Post_Partum_Unit,
        sum(case when HFI_Type = 12 then 1 else 0 end) as 'M&CW_Center',
        sum(case when HFI_Type = 13 then 1 else 0 end) as '<100_Bedded_Hospital',
        sum(case when HFI_Type = 14 then 1 else 0 end) as '100-500_Bedded_Hospital',
        sum(case when HFI_Type = 15 then 1 else 0 end) as '>500_Bedded_Hospital',
        sum(case when HFI_Type = 16 then 1 else 0 end) as Urban_Health_Posts,
        sum(case when HFI_Type = 17 then 1 else 0 end) as Medical_Colleges_Hospital,
        sum(case when HFI_Type = 18 then 1 else 0 end) as Women_Hospital,
        sum(case when HFI_Type = 99 then 1 else 0 end) as SubCentre,
        sum(case when HFI_Type = 100 then 1 else 0 end) as Others
        FROM " . TB_HMIS_HEALTH_FACILITIES . " hf 		
		Left join " . TB_M_STATES . " s on hf.State_ID=s.State_ID ";

    $query = $sql . ' ' . $where ;
	
	 $query .= ' GROUP BY State_ID  
		      ORDER BY State_Name ' ;
	
    $stmt = $db->query($query);
    return $stmt->fetchAll ();
}






function getNINTotalConfirmedVerified($groupBy = false) {


        $DBHOST = 'localhost';
        $DBNAME = 'ninlive';
        $DBUSER = 'root';
        $DBPASS = 'DC^_^ami98';
   

        $db = new PDO("mysql:host=" . $DBHOST . ";port=3306;dbname=" . $DBNAME, $DBUSER, $DBPASS);

   // global $db;
	$group_query = '';
	$join = '';
	$select_filds = '';
	
	if($groupBy == TRUE) {
	  $select_filds = ' s.State_Name,
					s.State_ID,
					s.state_char_code,';		
	  $join = " Left join " . TB_M_STATES . " s on hf.State_ID=s.State_ID ";
	  $group_query = ' GROUP BY s.State_ID' ;

	}
	
    $query = "SELECT
		".$select_filds."
        COUNT(*) AS Total_Facility,
        COUNT(verified_flag) AS total_verified_flag,  
		COUNT(confirmed_flag) AS total_confirmed_flag  
        FROM " . TB_HMIS_HEALTH_FACILITIES . " hf ". $join.$group_query;

    $stmt = $db->query($query);
	
	if($groupBy == TRUE) {
		return $stmt->fetchAll();
	}
	return $stmt->fetch(); 
}



function getNINTotalRuralUrbanVerified($groupBy = false) {


        $DBHOST = 'localhost';
        $DBNAME = 'ninlive';
        $DBUSER = 'root';
        $DBPASS = 'DC^_^ami98';
   

        $db = new PDO("mysql:host=" . $DBHOST . ";port=3306;dbname=" . $DBNAME, $DBUSER, $DBPASS);

   // global $db;
    $group_query = '';
	$join = '';
	$select_filds = '';
	
	if($groupBy == TRUE) {
	  $select_filds = ' s.State_Name,
					s.State_ID,
					s.state_char_code,';		
	  $join = " Left join " . TB_M_STATES . " s on hf.State_ID=s.State_ID ";
	  $group_query = 'GROUP BY s.State_ID' ;
	}
	
    $query = "SELECT
        COUNT(*) AS Total_Facility,
		".$select_filds."
		sum(case when region_indicator = 2 then 1 else 0 end) as total_urban,
        sum(case when region_indicator = 1 then 1 else 0 end) as total_rural,
		sum(case when region_indicator = 2 then 1 else 0 end) as total_urban
        FROM " . TB_HMIS_HEALTH_FACILITIES . " hf ". $join;
		
	$where = ' WHERE hf.verified_flag = 1  AND ( hf.operational_Status = 1 OR hf.operational_Status = 3 )  ';
    $query .= $where.$group_query;	
	
    $stmt = $db->query($query);
	
	if($groupBy == TRUE) {
		return $stmt->fetchAll();
	}
	return $stmt->fetch(); 
}



function getFacilitiesOperationalStatus($groupBy = false) {


        $DBHOST = 'localhost';
        $DBNAME = 'ninlive';
        $DBUSER = 'root';
        $DBPASS = 'DC^_^ami98';
   

        $db = new PDO("mysql:host=" . $DBHOST . ";port=3306;dbname=" . $DBNAME, $DBUSER, $DBPASS);

   // global $db;
	$group_query = '';
	$join = '';
	$select_filds = '';
	
    if($groupBy == TRUE) {
	  $select_filds = ' s.State_Name,
					s.State_ID,
					s.state_char_code,';		
	  $join = " Left join " . TB_M_STATES . " s on hf.State_ID=s.State_ID ";
	  $group_query = 'GROUP BY s.State_ID' ;
	}
	
	
    $query = "SELECT
        COUNT(*) AS Total_Facility, 
		".$select_filds."
		sum(case when operational_Status = 0 then 1 else 0 end) as not_selected_operational_Status,
        sum(case when operational_Status = 1 then 1 else 0 end) as Functional_operational_Status,
		sum(case when operational_Status = 2 then 1 else 0 end) as Closed_operational_Status,
		sum(case when operational_Status = 3 then 1 else 0 end) as Non_Functional_Under_Maintenance_operational_Status,
		sum(case when operational_Status = 4 then 1 else 0 end) as Invalid_operational_Status,
		sum(case when operational_Status = 5 then 1 else 0 end) as Duplicate_operational_Status
        FROM " . TB_HMIS_HEALTH_FACILITIES . " hf ". $join;
		
	$where = ' WHERE hf.verified_flag = 1 ';
	
    $query .= $where.$group_query;	
	
    $stmt = $db->query($query);
	
	if($groupBy == TRUE) {
		return $stmt->fetchAll();
	}
	return $stmt->fetch(); 
}


function fetchNINsyncdata($search_state_id='') {
    global $db;
    if ($search_state_id) {
        
        $query = " SELECT * FROM `nin_top_dashboard` where state_id ='".$search_state_id."'  GROUP BY state_id ";
    }else{
         
        $query = " SELECT * FROM `nin_top_dashboard` where state_id ='0' ";
    }
    $stmt = $db->query($query);
   //echo $query; die;
    $row = $stmt->fetch();
    $result = $row;
    return $result;
}




