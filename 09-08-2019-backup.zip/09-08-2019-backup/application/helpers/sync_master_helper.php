<?php
// ------------ function for HWC database syncronization ------------ //

function syncHWCdatabase() {
   
   
    $post_data    =   array("request_for"=>'dump_table');
    $ch = curl_init(HWC_SYNC_URL);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
    $response = curl_exec($ch);
    curl_close($ch);
    
   
    
    $output_object  =  json_decode($response);
    //echo "<pre>";
    //print_r($output_object); die;
    /////////request hit for dump sql file
    
     // check Checksum if different or not 
        if($output_object->status == 1)
        {
       
            $table      = table_name;
            $servername = hwc_host_name;
            $username   = hwc_username;
            $password   = hwc_password;
            $dbname     = hwc_db;
            
            exec('mysqldump --opt -u"'.$username.'" -p"'.$password.'" "'.$dbname.'" --compact --tables "'.$table.'" > sync_master_tables/"'.$table.'".sql', $output);
            if($output_object->checksum != md5_file('sync_master_tables/"'.$table.'".sql'))	
            {
             
                $post_data  = array("request_for"=>'diff_table',"Header"=>"","Footer"=>"","Options"=>array(2,2),"Export"=>"return","key"=>md5_file('sync_master_tables/"'.$table.'".sql'));

                $ch = curl_init(HWC_SYNC_URL); 

                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
                $response = curl_exec($ch);

                curl_close($ch);
                $response=  json_decode($response);
                if(count($response)>2)
                {
                    /*$servername = hwc_host_name;
                    $username   = hwc_username;
                    $password   = hwc_password;
                    $dbname     = hwc_db;*/

                    // Create connection
                    $conn = mysqli_connect($servername, $username, $password, $dbname);
                    // Check connection
                    if($conn){
                        ///////////
                        $str = $response[1];
                        $word1 = 'UPDATES=';
                        $word2 = 'DELETES';
                        preg_match('/'.preg_quote($word1).'(.*?)'.preg_quote($word2).'/is', $str, $match);

                        $update_rows=trim($match[1]);

                        /////////////
                        $start_v=3;
                        $update_val=$update_rows;

                        if($update_val>0)
                        {
                            $loop_offset=$start_v+$update_val+1; 
                        }
                        else
                        {
                            $loop_offset=$start_v+$update_val;
                        }

                        for($i=$start_v;$i<$start_v+$update_val;$i++ )
                        {
                            $q_var=  mysqli_query($conn,$response[$i]);
                        }
                        
                        ///////// update last update timestamp /////
						if($start_v<$start_v+$update_val)
						{
						
						// $conn_update = mysqli_connect('localhost', 'root', '', 'hwc_dashboard_optimize');
						//$conn_update =  mysqli_connect($servername, $username, $password, $dbname);
						
						date_default_timezone_set("Asia/Calcutta"); 
		                $updated_date = date("Y-m-d H:i:s");
						
						$sql = 'UPDATE last_update_sync_master SET updated_date="'.$updated_date.'" WHERE program="HWC"';
						$bs_var = mysqli_query($conn, $sql);
						
						}
						
						//////////////// end last update timestamp /////////
                                 
                    }else{
                        die('database connection failed!');
                    }
                }

            }

        }
    //}  
}


// ---------- end code ---------- //

// ------------ function for Mera Aspataal database syncronization ------------ //

function syncMeraAspataaldatabase(){
       
    $post_data    =   array("request_for"=>'dump_table');
        
    $ch = curl_init(MERAASPATAAL_SYNC_URL);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
    $response = curl_exec($ch);
    curl_close($ch);  
    return $output_object  =  json_decode($response,true);	
}


// ---------- end code ---------- //


// ------------ function for NIN database syncronization ------------ //

function syncNINdatabase() {
    $post_data    =   array("request_for"=>'dump_table');

    $ch = curl_init(NIN_SYNC_URL);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
    $response = curl_exec($ch);
    curl_close($ch);
    
    $output_object  =  json_decode($response);
    
    /////////request hit for dump sql file

     // check Checksum if different or not 
        if($output_object->status == 1)
        {
            $table      = table_name1;
            $servername = hwc_host_name;
            $username   = hwc_username;
            $password   = hwc_password;
            $dbname     = hwc_db;
            
            exec('mysqldump --opt -u"'.$username.'" -p"'.$password.'" "'.$dbname.'" --compact --tables "'.$table.'" > sync_master_tables/"'.$table.'".sql', $output);
            if($output_object->checksum != md5_file('sync_master_tables/"'.$table.'".sql'))	
            {
                
               // echo 'not matched'; die;
                $post_data  = array("request_for"=>'diff_table',"Header"=>"","Footer"=>"","Options"=>array(2,2),"Export"=>"return","key"=>md5_file('sync_master_tables/"'.$table.'".sql'));

                $ch = curl_init(NIN_SYNC_URL);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
                $response = curl_exec($ch);
                curl_close($ch);
                $response=  json_decode($response);
                
                if(count($response)>2)
                {
                    // Create connection
                    $conn = mysqli_connect($servername, $username, $password, $dbname);
                    // Check connection
                    if($conn){
                        ///////////
                        $str = $response[1];
                        $word1 = 'UPDATES=';
                        $word2 = 'DELETES';
                        preg_match('/'.preg_quote($word1).'(.*?)'.preg_quote($word2).'/is', $str, $match);

                        $update_rows=trim($match[1]);

                        /////////////
                        $start_v=3;
                        $update_val=$update_rows;

                        if($update_val>0)
                        {
                            $loop_offset=$start_v+$update_val+1; 
                        }
                        else
                        {
                            $loop_offset=$start_v+$update_val;
                        }

                        for($i=$start_v;$i<$start_v+$update_val;$i++ )
                        {
                            $q_var=  mysqli_query($conn,$response[$i]);
                        }
                        
                        ///////// update last update timestamp /////
						
						if($start_v<$start_v+$update_val)
						{
						
						// $conn_update = mysqli_connect('localhost', 'root', '', 'hwc_dashboard_optimize');
						//$conn_update =  mysqli_connect($servername, $username, $password, $dbname);
						
						date_default_timezone_set("Asia/Calcutta"); 
		                $updated_date = date("Y-m-d H:i:s");
						
						$sql = 'UPDATE last_update_sync_master SET updated_date="'.$updated_date.'" WHERE program="NIN"';
						$bs_var = mysqli_query($conn, $sql);
						
						}
						
						//////////////// end last update timestamp /////////
                                 
                    }else{
                        die('database connection failed!');
                    }
                }

            }

        }
    //}  
}


// ---------- end code ---------- //


// ------------ function for PMSMA database syncronization ------------ //
function syncPMSMAdatabase() {
    $post_data    =   array("request_for"=>'dump_table');

    $ch = curl_init(PMSMA_SYNC_URL);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
    $response = curl_exec($ch);
    curl_close($ch);
    
    $output_object  =  json_decode($response);
    
    /////////request hit for dump sql file

     // check Checksum if different or not 
        if($output_object->status == 1)
        {
            $table      = table_name2;
            $servername = hwc_host_name;
            $username   = hwc_username;
            $password   = hwc_password;
            $dbname     = hwc_db;
            
            exec('mysqldump --opt -u"'.$username.'" -p"'.$password.'" "'.$dbname.'" --compact --tables "'.$table.'" > sync_master_tables/"'.$table.'".sql', $output);
            
            if($output_object->checksum != md5_file('sync_master_tables/"'.$table.'".sql'))	
            {
                
               // echo 'not matched'; die;
                $post_data  = array("request_for"=>'diff_table',"Header"=>"","Footer"=>"","Options"=>array(2,2),"Export"=>"return","key"=>md5_file('sync_master_tables/"'.$table.'".sql'));

                $ch = curl_init(PMSMA_SYNC_URL);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
                $response = curl_exec($ch);
                curl_close($ch);
                $response=  json_decode($response);
                
                if(count($response)>2)
                {
                    // Create connection
                    $conn = mysqli_connect($servername, $username, $password, $dbname);
                    // Check connection
                    if($conn){
                        ///////////
                        $str = $response[1];
                        $word1 = 'UPDATES=';
                        $word2 = 'DELETES';
                        preg_match('/'.preg_quote($word1).'(.*?)'.preg_quote($word2).'/is', $str, $match);

                        $update_rows=trim($match[1]);

                        /////////////
                        $start_v=3;
                        $update_val=$update_rows;

                        if($update_val>0)
                        {
                            $loop_offset=$start_v+$update_val+1; 
                        }
                        else
                        {
                            $loop_offset=$start_v+$update_val;
                        }

                        for($i=$start_v;$i<$start_v+$update_val;$i++ )
                        {
                            $q_var=  mysqli_query($conn,$response[$i]);
                        }
                        
                        ///////// update last update timestamp /////
						if($start_v<$start_v+$update_val)
						{
						
						// $conn_update = mysqli_connect('localhost', 'root', '', 'hwc_dashboard_optimize');
						//$conn_update =  mysqli_connect($servername, $username, $password, $dbname);
						
						date_default_timezone_set("Asia/Calcutta"); 
		                $updated_date = date("Y-m-d H:i:s");
						
						$sql = 'UPDATE last_update_sync_master SET updated_date="'.$updated_date.'" WHERE program="PMSMA"';
						$bs_var = mysqli_query($conn, $sql);
						
						}
						
						//////////////// end last update timestamp /////////
                                 
                    }else{
                        die('database connection failed!');
                    }
                }

            }

        }
    //}  
}


// ---------- end code ---------- //



// ------------ function for FVMS database syncronization ------------ //
function syncFVMSdatabase() {
    $post_data    =   array("request_for"=>'dump_table');

    $ch = curl_init(FVMS_SYNC_URL);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
    $response = curl_exec($ch);
    curl_close($ch);
    
    $output_object  =  json_decode($response);
    
    /////////request hit for dump sql file

     // check Checksum if different or not 
        if($output_object->status == 1)
        {
            $table      = table_name3;
            $servername = hwc_host_name;
            $username   = hwc_username;
            $password   = hwc_password;
            $dbname     = hwc_db;
            
            exec('mysqldump --opt -u"'.$username.'" -p"'.$password.'" "'.$dbname.'" --compact --tables "'.$table.'" > sync_master_tables/"'.$table.'".sql', $output);
            
            if($output_object->checksum != md5_file('sync_master_tables/"'.$table.'".sql'))	
            {
                
               // echo 'not matched'; die;
                $post_data  = array("request_for"=>'diff_table',"Header"=>"","Footer"=>"","Options"=>array(2,2),"Export"=>"return","key"=>md5_file('sync_master_tables/"'.$table.'".sql'));

                $ch = curl_init(FVMS_SYNC_URL);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
                $response = curl_exec($ch);
                curl_close($ch);
                $response=  json_decode($response);
                
                if(count($response)>2)
                {
                    // Create connection
                    $conn = mysqli_connect($servername, $username, $password, $dbname);
                    // Check connection
                    if($conn){
                        ///////////
                        $str = $response[1];
                        $word1 = 'UPDATES=';
                        $word2 = 'DELETES';
                        preg_match('/'.preg_quote($word1).'(.*?)'.preg_quote($word2).'/is', $str, $match);

                        $update_rows=trim($match[1]);

                        /////////////
                        $start_v=3;
                        $update_val=$update_rows;

                        if($update_val>0)
                        {
                            $loop_offset=$start_v+$update_val+1; 
                        }
                        else
                        {
                            $loop_offset=$start_v+$update_val;
                        }

                        for($i=$start_v;$i<$start_v+$update_val;$i++ )
                        {
                            $q_var=  mysqli_query($conn,$response[$i]);
                        }
                        
                        ///////// update last update timestamp /////
						if($start_v<$start_v+$update_val)
						{
						
						// $conn_update = mysqli_connect('localhost', 'root', '', 'hwc_dashboard_optimize');
						//$conn_update =  mysqli_connect($servername, $username, $password, $dbname);
						
						date_default_timezone_set("Asia/Calcutta"); 
		                $updated_date = date("Y-m-d H:i:s");
						
						$sql = 'UPDATE last_update_sync_master SET updated_date="'.$updated_date.'" WHERE program="FVMS"';
						$bs_var = mysqli_query($conn, $sql);
						
						}
						
						//////////////// end last update timestamp /////////
                                 
                    }else{
                        die('database connection failed!');
                    }
                }

            }

        }
    //}  
}


// ---------- end code ---------- //

// ------------ function for MOU database syncronization ------------ //
function syncMOUdatabase() {
    $post_data    =   array("request_for"=>'dump_table');

    $ch = curl_init(MOU_SYNC_URL);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
    $response = curl_exec($ch);
    curl_close($ch);
    
    $output_object  =  json_decode($response);
  
    /////////request hit for dump sql file

     // check Checksum if different or not 
        if($output_object->status == 1)
        {
            $table      = table_name4;
            $servername = hwc_host_name;
            $username   = hwc_username;
            $password   = hwc_password;
            $dbname     = hwc_db;
            
            exec('mysqldump --opt -u"'.$username.'" -p"'.$password.'" "'.$dbname.'" --compact --tables "'.$table.'" > sync_master_tables/"'.$table.'".sql', $output);
            
            if($output_object->checksum != md5_file('sync_master_tables/"'.$table.'".sql'))	
            {
                
               // echo 'not matched'; die;
                $post_data  = array("request_for"=>'diff_table',"Header"=>"","Footer"=>"","Options"=>array(2,2),"Export"=>"return","key"=>md5_file('sync_master_tables/"'.$table.'".sql'));

                $ch = curl_init(MOU_SYNC_URL);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
                $response = curl_exec($ch);
                curl_close($ch);
                $response=  json_decode($response);
                
                if(count($response)>2)
                {
                    // Create connection
                    $conn = mysqli_connect($servername, $username, $password, $dbname);
                    // Check connection
                    if($conn){
                        ///////////
                        $str = $response[1];
                        $word1 = 'UPDATES=';
                        $word2 = 'DELETES';
                        preg_match('/'.preg_quote($word1).'(.*?)'.preg_quote($word2).'/is', $str, $match);

                        $update_rows=trim($match[1]);

                        /////////////
                        $start_v=3;
                        $update_val=$update_rows;

                        if($update_val>0)
                        {
                            $loop_offset=$start_v+$update_val+1; 
                        }
                        else
                        {
                            $loop_offset=$start_v+$update_val;
                        }

                        for($i=$start_v;$i<$start_v+$update_val;$i++ )
                        {
                            $q_var=  mysqli_query($conn,$response[$i]);
                        }
                        
                        ///////// update last update timestamp /////
						
						if($start_v<$start_v+$update_val)
						{
						
						// $conn_update = mysqli_connect('localhost', 'root', '', 'hwc_dashboard_optimize');
						//$conn_update =  mysqli_connect($servername, $username, $password, $dbname);
						
						date_default_timezone_set("Asia/Calcutta"); 
		                $updated_date = date("Y-m-d H:i:s");
						
						$sql = 'UPDATE last_update_sync_master SET updated_date="'.$updated_date.'" WHERE program="MOU"';
						$bs_var = mysqli_query($conn, $sql);
						
						}
						
						//////////////// end last update timestamp /////////
                                 
                    }else{
                        die('database connection failed!');
                    }
                }

            }

        }
    //}  
}


// ---------- end code ---------- //

// ------------ function for ELDERLY database syncronization ------------ //
function syncELDERLYdatabase() {  
    $post_data    =   array("request_for"=>'dump_table');

    $ch = curl_init(ELDERLY_SYNC_URL);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
    $response = curl_exec($ch);
    curl_close($ch);
    
    $output_object  =  json_decode($response);
    
    /////////request hit for dump sql file

     // check Checksum if different or not 
        if($output_object->status == 1)
        {
            $table      = table_name5;
            $servername = hwc_host_name;
            $username   = hwc_username;
            $password   = hwc_password;
            $dbname     = hwc_db;
            
            exec('mysqldump --opt -u"'.$username.'" -p"'.$password.'" "'.$dbname.'" --compact --tables "'.$table.'" > sync_master_tables/"'.$table.'".sql', $output);
            
            if($output_object->checksum != md5_file('sync_master_tables/"'.$table.'".sql'))	
            {
               
               // echo 'not matched'; die;
                $post_data  = array("request_for"=>'diff_table',"Header"=>"","Footer"=>"","Options"=>array(2,2),"Export"=>"return","key"=>md5_file('sync_master_tables/"'.$table.'".sql'));

                $ch = curl_init(ELDERLY_SYNC_URL);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
                $response = curl_exec($ch);
                curl_close($ch);
                $response =  json_decode($response);
                
                if(count($response)>2)
                {
                    // Create connection
                    $conn = mysqli_connect($servername, $username, $password, $dbname);
                    // Check connection
                    if($conn){
                        ///////////
                        $str = $response[1];
                        $word1 = 'UPDATES=';
                        $word2 = 'DELETES';
                        preg_match('/'.preg_quote($word1).'(.*?)'.preg_quote($word2).'/is', $str, $match);

                        $update_rows=trim($match[1]);

                        /////////////
                        $start_v=3;
                        $update_val=$update_rows;

                        if($update_val>0)
                        {
                            $loop_offset=$start_v+$update_val+1; 
                        }
                        else
                        {
                            $loop_offset=$start_v+$update_val;
                        }

                        for($i=$start_v;$i<$start_v+$update_val;$i++ )
                        {
							
                            $q_var=  mysqli_query($conn,$response[$i]);
                        }
                        
                        ///////// update last update timestamp /////
						
						if($start_v<$start_v+$update_val)
						{
						// $conn_update = mysqli_connect('localhost', 'root', '', 'hwc_dashboard_optimize');
						//$conn_update =  mysqli_connect($servername, $username, $password, $dbname);
						
						date_default_timezone_set("Asia/Calcutta"); 
		                $updated_date = date("Y-m-d H:i:s");
						
						$sql = 'UPDATE last_update_sync_master SET updated_date="'.$updated_date.'" WHERE program="ELDERLY"';
						$bs_var = mysqli_query($conn, $sql);
						
						}
						
						//////////////// end last update timestamp /////////
                                 
                    }else{
                        die('database connection failed!');
                    }
                }

            }

        }
    //}  
}


// ---------- end code ---------- //


// ------------ function for LAQSHYA database syncronization ------------ //
function syncLAQSHYAdatabase() { 


             
    $post_data    =   array("request_for"=>'dump_table');

    $ch = curl_init(LAQSHYA_SYNC_URL);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
    $response = curl_exec($ch);
    curl_close($ch);
    
    $output_object  =  json_decode($response);
   /* echo "<pre>";
	print_r($output_object); die;*/
    /////////request hit for dump sql file

     // check Checksum if different or not 
        if($output_object->status == 1)
        {
            $table      = table_name6;
            $servername = hwc_host_name;
            $username   = hwc_username;
            $password   = hwc_password;
            $dbname     = hwc_db;
            
            exec('mysqldump --opt -u"'.$username.'" -p"'.$password.'" "'.$dbname.'" --compact --tables "'.$table.'" > sync_master_tables/"'.$table.'".sql', $output);
            
            if($output_object->checksum != md5_file('sync_master_tables/"'.$table.'".sql'))	
            {
               
               // echo 'not matched'; die;
                $post_data  = array("request_for"=>'diff_table',"Header"=>"","Footer"=>"","Options"=>array(2,2),"Export"=>"return","key"=>md5_file('sync_master_tables/"'.$table.'".sql'));

                $ch = curl_init(LAQSHYA_SYNC_URL);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
				
                $response = curl_exec($ch);
                curl_close($ch);
                $response=  json_decode($response);
                
                if(count($response)>2)
                {
                    // Create connection
                    $conn = mysqli_connect($servername, $username, $password, $dbname);
                    // Check connection
                    if($conn){
                        ///////////
                        $str = $response[1];
                        $word1 = 'UPDATES=';
                        $word2 = 'DELETES';
                        preg_match('/'.preg_quote($word1).'(.*?)'.preg_quote($word2).'/is', $str, $match);

                        $update_rows=trim($match[1]);

                        /////////////
                        $start_v=3;
                        $update_val=$update_rows;

                        if($update_val>0)
                        {
                            $loop_offset=$start_v+$update_val+1; 
                        }
                        else
                        {
                            $loop_offset=$start_v+$update_val;
                        }

                        for($i=$start_v;$i<$start_v+$update_val;$i++ )
                        {
							
                            $q_var=  mysqli_query($conn,$response[$i]);
                        }
                        
                        ///////// update last update timestamp /////
						
						if($start_v<$start_v+$update_val)
						{
						// $conn_update = mysqli_connect('localhost', 'root', '', 'hwc_dashboard_optimize');
						//$conn_update =  mysqli_connect($servername, $username, $password, $dbname);
						
						date_default_timezone_set("Asia/Calcutta"); 
		                $updated_date = date("Y-m-d H:i:s");
						
						$sql = 'UPDATE last_update_sync_master SET updated_date="'.$updated_date.'" WHERE program="LAQSHYA"';
						$bs_var = mysqli_query($conn, $sql);
						
						}
						
						//////////////// end last update timestamp /////////
                                 
                    }else{
                        die('database connection failed!');
                    }
                }

            }

        }
    //}  
}


// ---------- end code ---------- //



?>