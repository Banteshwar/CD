<?php

function my_function($whether_proposed) {
    $ci = & get_instance();
    if ($whether_proposed == 1 || $whether_proposed == 2) {
            return true;
        } else {
            $ci->form_validation->set_message('my_function', 'Please Select Yes OR No');
        return false;
        }
    }
    function hwcFormValidation($POST_DATA) {
    $ci = & get_instance();
    $_POST = $POST_DATA;
    $validation_rules = array(
//    array(
//        'field' => 'whether_proposed',
//        'label' => 'Whether Proposed',
//        'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $_POST['whether_proposed'] . ']'
//        ),
        array(
        'field' => 'hr_total',
        'label' => 'Humen Resource',
        'rules' => 'trim|required|is_natural_no_zero'
    ),
    array(
        'field' => 'hr_mo_mbbs',
        'label' => 'MO-MBBS',
        'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $_POST['hr_mo_mbbs'] . ']'
        ),
    array(
        'field' => 'traning_hr_mos_staff_nurses',
        'label' => 'Mos, Staff Nurses training',
        'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $_POST['traning_hr_mos_staff_nurses'] . ']'
        ),
    array(
        'field' => 'population_enumeration',
        'label' => 'Population enumeration',
        'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $_POST['population_enumeration'] . ']'
        ),
    array(
        'field' => 'service_hypertension',
        'label' => 'Hypertension',
        'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $_POST['service_hypertension'] . ']'
        ),
    array(
        'field' => 'service_diabetes',
        'label' => 'Diabetes',
        'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $_POST['service_diabetes'] . ']'
        ),
    array(
        'field' => 'service_oral_cancer',
        'label' => 'Oral Cancer',
        'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $_POST['service_oral_cancer'] . ']'
        ),
    array(
        'field' => 'service_breast_cancer',
        'label' => 'Breast Cancer',
    'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $_POST['service_breast_cancer'] . ']'
        ),
    array(
        'field' => 'service_cervical_cancer',
        'label' => 'Cervical cancer',
        'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $_POST['service_cervical_cancer'] . ']'
        ),
    array(
        'field' => 'medicines_available',
        'label' => 'Medicines available',
        'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $_POST['medicines_available'] . ']'
        ),
    array(
        'field' => 'diagnostics_available',
        'label' => 'Diagnostics available',
        'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $_POST['diagnostics_available'] . ']'
        ),
    array(
        'field' => 'it_equipment_tablet',
        'label' => 'Tablets',
        'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $_POST['it_equipment_tablet'] . ']'
        ),
    array(
        'field' => 'it_equipment_desktop',
        'label' => 'Desktop/ laptop',
    'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $_POST['it_equipment_desktop'] . ']'
        ),
    array(
        'field' => 'it_internet_connectivity',
        'label' => 'Internet Connectivity',
    'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $_POST['it_internet_connectivity'] . ']'
        ),
    array(
        'field' => 'it_phc_ncd_application',
        'label' => 'CPHC- NCD application',
    'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $_POST['it_phc_ncd_application'] . ']'
        ),
    array(
        'field' => 'infra_repairing',
        'label' => 'Infrastructure Repair',
        'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $_POST['infra_repairing'] . ']'
        ),
    array(
        'field' => 'infra_branding',
        'label' => 'Branding',
        'rules' => 'trim|required|is_natural_no_zero|callback_my_function[' . $_POST['infra_branding'] . ']'
        )
     
);

  $ci->form_validation->set_rules($validation_rules);
    $ci->form_validation->run();
    $error = $ci->form_validation->error_array();

    if (count($error) > 0) {
        return $error;
    } else {
        return true;
    }
}

