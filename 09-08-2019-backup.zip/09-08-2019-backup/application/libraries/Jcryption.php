<?php
class jcryption extends MY_Controller {

    public function jdecrypt() {

        require_once APPPATH . 'third_party/jcryption/sqAES.php';
        require_once APPPATH . 'third_party/jcryption/JCryption.php';
        return JCryption::decrypt();
    }

}
