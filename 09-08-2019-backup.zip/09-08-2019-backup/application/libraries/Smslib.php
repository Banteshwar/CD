<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Smslib {
     public function sendSMS($mobile_no, $message) {
       
	
		$msg = '{"<content>":"'.$message.'"}';


		
		
		$msg = str_replace(",", "", $msg);
		//echo $msg;
		

		
		$postfield = "campaign_id=100059&cid=6728&params=$msg&mobile=$mobile_no&sender_id=5616115";
		//die;
        $url = "http://117.239.178.202/newsendsms.php?";
		//echo $msg; die;
         //$url = str_replace(" ","%20",$url);
         $ch = curl_init($url);
         curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
         curl_setopt($ch,CURLOPT_POST,1);
         curl_setopt($ch,CURLOPT_POSTFIELDS,$postfield);
         curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		// echo $postfield;
		// curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
         $data = curl_exec($ch);
         //print_r($data); die;
         return $data;
     }
}