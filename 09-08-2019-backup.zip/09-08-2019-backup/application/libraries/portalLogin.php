<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class PortalLogin{

	var $apikey  	   =  md5("HWSCENTRALDASHBOARDLOGIN2018");
	var $mainurl   	   =  "http://172.16.1.165:8080/nin_ci";
	
	function __construct(){
		date_default_timezone_set('Asia/Kolkata');
        $this->date_time=   date("Y-m-d H:i:s");
        $this->date     =   date("Y-m-d");
	}
	
	function writelog($type,$req){
        $array      =   json_encode($req, TRUE);
        $handle     =   fopen("logs-login.txt", 'a');
        fwrite($handle,date("Y-m-d H:i:s")." ".$type.": ".$array."\n\n");
        fclose($handle);
    }
	
	private function hit($reqData){
			
            $curl = curl_init();
            curl_setopt_array($curl, array(
              CURLOPT_URL => $this->mainurl,
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_SSL_VERIFYPEER=> false,
              CURLOPT_SSL_VERIFYHOST=> FALSE,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 30,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS => $reqData['parameter'],
              CURLOPT_HTTPHEADER => array(                
                "cache-control: no-cache",                
              ),
            ));
            
            $response = curl_exec($curl);
            $response = curl_exec($curl);			
            $err 	  = curl_error($curl);
            
            curl_close($curl);
             $this->writelog("Response",$response);
            if ($err) {
              return $err;
            } else {
               return $response;
			}
		}
	
	
	public function login($reqData){
		  $request    =   array(            
            "parameter" =>  array(
                "apikey"       =>  $this->apikey,
            )
        );		
        return $this->hit($request);
	}
	
}