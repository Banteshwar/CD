<?php

defined('BASEPATH') or exit('No direct script access allowed');
class Dbtest_model extends MY_Model {

    public function __construct() {
        parent::__construct();
       
    }

    function db_test() {
        // insert table name to fetch All data of table
        global $db;

        $stmt = $db->query('SELECT * FROM  m_state');
        $row = $stmt->fetchAll();
        showData($row);
        echo 'hi';
    }

}
