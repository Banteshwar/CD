<?php

defined('BASEPATH') or exit('No direct script access allowed');

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//    $stmt = $db->query('SELECT * FROM  m_state');
//        $row = $stmt->fetchAll();

class Facility_model extends MY_Model {

    public function __construct() {
        parent::__construct();
    }

    public function getFacilityList($filterArray) {
        $queryWhere = $filterArray['WHERE'];
        $query = " select
                          SQL_CALC_FOUND_ROWS
                          hf.NIN_2_HFI,
                          hf.HFI_Name,
                          hf.State_ID,
                          hf.District_ID,
                          hf.HFI_Type,
                          hf.confirmed_flag,
                          hf.verified_flag,
                          hf.house_number,
                          hf.street,
                          hf.landmark,
                          hf.locality,
                          hf.pincode,
                          hf.landline_number,
                          hf.in_charge_mobile,
                          hf.email,
                          hf.latitude,
                          hf.longitude,
                          hf.altitude,
                          hf.region_indicator,
                          hf.operational_Status,
                          hf.ownership_authority,
                          hf.Created_On,
                          pcm.PHC_CHC_Type,
                          s.State_Name,
                          d.District_Name,
                          t.Taluka_Name,
                          b.Block_Name,
                          m.memberID,
                          hwc.status,
                          hwcp.proposed_status,
                          m.username
                          from " . TB_HMIS_HEALTH_FACILITIES . " hf
                          Left join " . TB_PHC_CSC_MSTER . " pcm on hf.HFI_Type=pcm.PHC_CHC_ID
                          Left join " . TB_M_STATES . " s on hf.State_ID=s.State_ID
                          Left join " . TB_M_DISTRICTS . " d on hf.District_ID=d.District_ID
                          Left join " . TB_M_TALUKA . " t on hf.Taluka_ID=t.Taluka_ID
                          Left join " . TB_M_HEALTHBLOCKS . " b on hf.HealthBlock_ID=b.Block_ID
                          Left join " . TB_T_MEMBERS . " m on hf.added_by_user=m.memberID
                         left join " . TB_T_HWC . " hwc on hf.NIN_2_HFI =hwc.NIN_2_HFI
                         left join " . TB_T_HWC_PROPOSED . " hwcp on hf.NIN_2_HFI =hwcp.NIN_2_HFI
                         where " . implode(' AND ', $queryWhere) . " Order by s.State_Name, d.District_Name, b.Block_Name, hf.HFI_Name  LIMIT 20 ";

        $query = $this->db->query($query);
        return $query->result_array();
    }



    // insert hwc from data

    public function store($storeHwcData) {
        $this->db->insert('t_hwc', $storeHwcData);
        $data = $this->db->affected_rows();
        print_r($data);
        die();
        // return ($this->db->affected_rows() != 1) ? false : true;
    }

}
