<?php

defined('BASEPATH') or exit('No direct script access allowed');

class HwcPlaningYear_model extends MY_Model {

    public function __construct() {
        parent::__construct();
    }

    // insert palnning from data
    public function planningStore($storePlanningData) {

        $this->db->insert('hwc_planing_years', $storePlanningData);
        $data = $this->db->affected_rows();
        // print_r($data);die();
        return ($this->db->affected_rows() != 1) ? false : true;
    }

    // planning view 
    public function getPlanningView($value='')
    {
    	global $CURRENT_USER_STATE;
    	$this->db->select('hwc_planing_years.State_ID');
    	$this->db->select('hwc_planing_years.financial_year');
    	$this->db->select('hwc_planing_years.y_uphc');
    	$this->db->select('hwc_planing_years.y_phc');
    	$this->db->select('hwc_planing_years.y_shc');
    	$this->db->select('hwc_planning_quarters.quarter');
    	$this->db->select('hwc_planning_quarters.q_uphc');
    	$this->db->select('hwc_planning_quarters.q_phc');
    	$this->db->select('hwc_planning_quarters.q_shc');
	    $this->db->from('hwc_planing_years');
	    $this->db->join('hwc_planning_quarters', 'hwc_planing_years.financial_year = hwc_planning_quarters.financial_year','left'); 
	    $this->db->where('hwc_planing_years.State_ID',$CURRENT_USER_STATE);
	    $query = $this->db->get();
	    return $query->result();
    }

    // get exist state ID AND financial year
    public function StateIDFinancialYearExist($State_ID =null ,$financial_year=null)
    {
    	$this->db->select('hwc_planing_years.State_ID');
        $this->db->select('hwc_planing_years.financial_year');
        $this->db->select('hwc_planing_years.y_uphc');
        $this->db->select('hwc_planing_years.y_phc');
        $this->db->select('hwc_planing_years.y_shc');
        $this->db->select('hwc_planning_quarters.quarter');
        $this->db->select('hwc_planning_quarters.q_uphc');
        $this->db->select('hwc_planning_quarters.q_phc');
        $this->db->select('hwc_planning_quarters.q_shc');
        $this->db->from('hwc_planing_years');
        $this->db->join('hwc_planning_quarters', 'hwc_planing_years.financial_year = hwc_planning_quarters.financial_year','left');
        $this->db->where('hwc_planing_years.State_ID',$State_ID);
        $this->db->where('hwc_planing_years.financial_year',$financial_year);
        $query = $this->db->get();
        $existInfo =  $query->result();
        if($existInfo){
            return $existInfo;
        }else{
            return false;
        }
    }
}
