<?php

defined('BASEPATH') or exit('No direct script access allowed');

class HwcPlanningQuarter_model extends MY_Model {

    public function __construct() {
        parent::__construct();
    }
    public function existQuarter($financialYear,$State_ID)
    {
        // showData($financialYear);
        // showData('State_ID');
        // die();
        $this->db->select('*');
        $this->db->from('hwc_planning_quarters');
        $this->db->where('financial_year',$financialYear);
        $this->db->where('State_ID',$State_ID);
        $query = $this->db->get();
        $planningData =  $query->result();
        if($planningData){
            return $planningData;
        }else{
            return false;
        }
    }
    // insert hwc from data
    public function quarterStore($storePlanningDatas= array()) {
        // showData($storePlanningDatas);//die();
        foreach ($storePlanningDatas as $key => $values) {
         // showData($values);
        foreach ($values as $key => $value) {
            # code...
       /* showData($value['State_ID']);
        echo "<br>";
        showData($value['financial_year']);
        echo "<br>";*/

            $existQuarter = $this->existQuarter($value['financial_year'],$value['State_ID']);
            // showData($existQuarter);die();
            if($existQuarter){
                // $this->db->set($value);
                // showData($value);die();
                $this->db->update('hwc_planning_quarters',$value);
                $data = $this->db->where('financial_year',$value['financial_year']);
                // showData($data);
                // $this->db->where('quarter',$value['quarter']);
            return ($this->db->affected_rows() != 1) ? false : true;    
            }else{    
            $this->db->insert('hwc_planning_quarters', $value);
            return ($this->db->affected_rows() != 1) ? false : true;
            }
           }
        }
    }

    public function getPlanningQuarterView($financialYear)
    {
        $this->db->select('*');
        $this->db->from('hwc_planning_quarters');
        $this->db->where('financial_year',$financialYear);
        $query = $this->db->get();
        $planningData =  $query->result();
        if($planningData){
            return $planningData;
        }else{
            return false;
        }
    }

    


}
