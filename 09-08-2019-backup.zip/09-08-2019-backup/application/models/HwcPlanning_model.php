<?php

defined('BASEPATH') or exit('No direct script access allowed');

class HwcPlanning_model extends MY_Model {

    public function __construct() {
        parent::__construct();
    }

    public function getPlanningData($State_ID) {

        $this->db->select('hwc_planing_years.State_ID');
        $this->db->select('hwc_planing_years.financial_year');
        $this->db->select('hwc_planing_years.y_uphc');
        $this->db->select('hwc_planing_years.y_phc');
        $this->db->select('hwc_planing_years.y_shc');
        $this->db->select('hwc_planning_quarters.quarter');
        $this->db->select('hwc_planning_quarters.q_uphc');
        $this->db->select('hwc_planning_quarters.q_phc');
        $this->db->select('hwc_planning_quarters.q_shc');
        $this->db->select('m_state.State_Name');
        $this->db->from('hwc_planing_years');
        $this->db->join('hwc_planning_quarters', 'hwc_planing_years.financial_year = hwc_planning_quarters.financial_year AND  hwc_planing_years.State_ID= hwc_planning_quarters.State_ID', 'left');
        $this->db->join('m_state', 'hwc_planing_years.State_ID = m_state.State_ID', 'left');
        $this->db->order_by("m_state.State_Name", "asc");

        if ($State_ID != 0) {
            $this->db->where('hwc_planing_years.State_ID', $State_ID);
        }
        $query = $this->db->get();
        $result = $query->result_array();
   
        return $result;
    }

    /**
     * [planningYearDataSave year data save]
     * @param  [array] $storePlanningData [description]
     * @return [string]                    [description]
     */
    public function planningYearDataSave($storePlanningData) {

        $this->db->insert('hwc_planing_years', $storePlanningData);
        $data = $this->db->affected_rows();
        // print_r($data);die();
        return ($this->db->affected_rows() != 1) ? false : true;
    }


    public function planningYearDataUpdate($planningFormYearUpdate,$year_State_ID,$year_financial_year)
    {
        $whereCondition = array('State_ID' => $year_State_ID, 'financial_year' => $year_financial_year);
        $this->db->where($whereCondition);
        $this->db->update('hwc_planing_years',$planningFormYearUpdate);
        return ($this->db->affected_rows() != 1) ? false : true;
    }

    // get exist state ID AND financial year
    public function checkExistFinancialYear($State_ID, $financial_year) {
        $this->db->select('*');
        $this->db->from('hwc_planing_years');
        $this->db->where('hwc_planing_years.State_ID', $State_ID);
        $this->db->where('hwc_planing_years.financial_year', $financial_year);
        $query = $this->db->get();
        $existInfo = $query->num_rows();
        // showData($existInfo);die();
        // $existInfo =  $query->result();
        if ($existInfo > 0) {
            return true;
        } else {
            // showData('sutea');
            return false;
        }
    }

    /**
     * [checkExistQuarter description]
     * @param  [type] $State_ID       [28]
     * @param  [type] $financial_year [1819]
     * @param  [type] $quarter        [Q1]
     * @return [type]                 [true]
     */
    public function checkExistQuarter($State_ID, $financial_year, $quarter) {
        $this->db->select('*');
        $this->db->from('hwc_planning_quarters');
        $this->db->where('State_ID', $State_ID);
        $this->db->where('financial_year', $financial_year);
        $query = $this->db->get();
        $existQuarter = $query->num_rows();
        if ($existQuarter > 0) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * [getEditInfoYear get information]
     * @param  [type] $State_ID       [int]
     * @param  [type] $financial_year [int]
     * @return [type]                 [array(information) or false]
     */
    public function getEditInfoYear($State_ID,$financial_year)
    {
        /*
            
             // table hwc_planing_years
        $this->db->select('hwc_planing_years.financial_year');
        $this->db->select('hwc_planing_years.State_ID');
        $this->db->select('hwc_planing_years.y_uphc');
        $this->db->select('hwc_planing_years.y_phc');
        $this->db->select('hwc_planing_years.y_shc');
        $this->db->select('hwc_planing_years.status');
        // table hwc_planning_quarters
        $this->db->select('hwc_planning_quarters.quarter');
        $this->db->select('hwc_planning_quarters.q_uphc');
        $this->db->select('hwc_planning_quarters.q_phc');
        $this->db->select('hwc_planning_quarters.q_shc');
        $this->db->from('hwc_planing_years');
        $this->db->join('hwc_planning_quarters','hwc_planing_years.financial_year = hwc_planning_quarters.financial_year','left');
        $this->db->where('hwc_planing_years.State_ID',$State_ID);
        $this->db->where('hwc_planing_years.financial_year',$financial_year);
        $query = $this->db->get();
        $result = $query->result_array();
        $existEditYear = $query->num_rows();
        if($existEditYear > 0){
            return $result;
        }else{
            return false;
        }

         */
        $this->db->select('*');
        $this->db->from('hwc_planing_years');
        $this->db->where('State_ID',$State_ID);
        $this->db->where('financial_year',$financial_year);
        $query = $this->db->get();
        $result = $query->row_array();
        $existEditYear = $query->num_rows();
        if($existEditYear > 0){
            return $result;
        }else{
            return false;
        }
    }

    /**
     *  
     * @param  [type] $State_ID       [description]
     * @param  [type] $financial_year [description]
     * @return [type]                 [description]
     */
    public function getEditInfoQuarter($State_ID,$financial_year)
    {

        $quarter_result = array();
        $quarter_array = array('Q1', 'Q2', 'Q3', 'Q4');

        $this->db->select('*');
        $this->db->from('hwc_planning_quarters');
        $this->db->where('State_ID',$State_ID);
        $this->db->where('financial_year',$financial_year);
        $query = $this->db->get();
        $result = $query->result_array();
        $existEditQuarter = $query->num_rows();


        if ($existEditQuarter > 0) {
                } else {
            $result = array(1, 2, 3, 4);
        }


        foreach ($quarter_array as $value) {
 
            $quarter_result[$value] = array();

            foreach ($result as $row) {
                if (isset($row['quarter']) && $row['quarter'] == $value) {
                    $quarter_result[$row['quarter']] = $row;
                }
            }


        }



        return $quarter_result;
    }

    /**
     *  
     * @param  [type] $financialYear [description]
     * @param  [type] $State_ID      [description]
     * @return [type]                [description]
     */
    public function checkExistFinancialQuarter($State_ID,$financialYear)
    {
        // showData($financialYear);
        // showData($State_ID);
        // die();
        $this->db->select('*');
        $this->db->from('hwc_planning_quarters');
        $this->db->where('financial_year',$financialYear);
        $this->db->where('State_ID',$State_ID);
        $query = $this->db->get();
        $planningData =  $query->result_array();
        $existEditQuarter = $query->num_rows();
        // return $existEditQuarter;
        if($existEditQuarter){
            return true;
        }else{
            return false;
        }
    }


    public function financialQuarterStore($storePlanningData) {
        $checkExistFinancialQuarter = $this->checkExistFinancialQuarter($storePlanningData['State_ID'],$storePlanningData['financial_year']);
        if($checkExistFinancialQuarter){
        // $this->db->set($storePlanningData);
        $whereCondition = array('State_ID' => $storePlanningData['State_ID'], 'financial_year' => $storePlanningData['financial_year']);
        $this->db->where($whereCondition);
        $this->db->update('hwc_planning_quarters',$storePlanningData);
        return ($this->db->affected_rows() != 1) ? true : true;

        }else{
        $this->db->insert('hwc_planning_quarters', $storePlanningData);
        return ($this->db->affected_rows() != 1) ? false : true; 
        }
        
    }

}
