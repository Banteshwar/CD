<?php

defined('BASEPATH') or exit('No direct script access allowed');

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//    $stmt = $db->query('SELECT * FROM  m_state');
//        $row = $stmt->fetchAll();

class Hwc_model extends MY_Model {

    public function __construct() {
       global $db;
       
     
        parent::__construct();
    }

    // get info for already edit
    public function getHWCInfo($ninID) {
        $this->db->select('t_hwc.*');
        $this->db->select('t_hwc_proposed.proposed_status');
        $this->db->select('t_hwc_proposed.population_coverage');
        $this->db->from('t_hwc');
        $this->db->join('t_hwc_proposed', 't_hwc_proposed.NIN_2_HFI = t_hwc.NIN_2_HFI', 'left');
        $this->db->where('t_hwc.NIN_2_HFI', $ninID);
        $hwc_info = $this->db->get()->row_array();


        // showData($hwc_info);die();

        if ($hwc_info)
            {
            return $hwc_info;
            }
        else
            {
            return FALSE;
            }
    }
  //////// bs function for show Program Study Centre

    public function getProgramInfo($CURRENT_USER_STATE,$financial_year) {

        $this->db->select('*');

        $this->db->from('hwc_program_study');

        $this->db->where('financial_year', $financial_year);

        $this->db->where('state_id', $CURRENT_USER_STATE);

        $p_info = $this->db->get()->row_array();


        // showData($hwc_info);die();

        if ($p_info)
            {
            return $p_info;
            }
        else
            { 
            return 0;
            }
    }

  //////// bs function for show State of MLHP

    public function getStatusMlhp($CURRENT_USER_STATE,$financial_year) {

        $this->db->select('*');

        $this->db->from('hwc_status_mlhp');

        $this->db->where('financial_year', $financial_year);

        $this->db->where('state_id', $CURRENT_USER_STATE);

        $p_info = $this->db->get()->row_array();


        // showData($hwc_info);die();

        if ($p_info)
            {
            return $p_info;
            }
        else
            { 
            return 0;
            }
    }

    // insert hwc from data
    public function store($storeHwcData, $NIN_2_HFI = null, $popCovData = null) {
        if ($storeHwcData)
            {
            $this->db->insert('t_hwc', $storeHwcData);
            }
        if ($popCovData)
            {
            //$this->db->set($popCovData);
            $this->db->where('NIN_2_HFI', $NIN_2_HFI);
            $this->db->update('t_hwc_proposed', $popCovData);
            }
        $data = $this->db->affected_rows();
        // print_r($data);die();
        // return ($this->db->affected_rows() != 1) ? false : true;
    }

    // Update hwc from data
    public function updateHwc($updateHwcData, $NIN_2_HFI = null, $popCovData = null) {
        /* $this->db->where('NIN_2_HFI', $NIN_2_HFI);
          $this->db->update('t_hwc', $updateHwcData); */
        if ($updateHwcData)
            {
            $this->db->where('NIN_2_HFI', $NIN_2_HFI);
            $this->db->update('t_hwc', $updateHwcData);
            }
        if ($popCovData)
            {
            //$this->db->set($popCovData);
            $this->db->where('NIN_2_HFI', $NIN_2_HFI);
            $this->db->update('t_hwc_proposed', $popCovData);
            }

        return $this->db->affected_rows();
        // print_r($data);die();
        // return ($this->db->affected_rows() != 1) ? false : true;
    }

  public function updateProgram($FormData, $CURRENT_USER_STATE,$financial_year) {

            $this->db->where('financial_year', $financial_year);
             $this->db->where('state_id', $CURRENT_USER_STATE);
            $this->db->update('hwc_program_study', $FormData);

  }

   public function updateStatusMlhp($FormData, $CURRENT_USER_STATE,$financial_year) {

            $this->db->where('financial_year', $financial_year);
             $this->db->where('state_id', $CURRENT_USER_STATE);
            $this->db->update('hwc_status_mlhp', $FormData);

  }
    

    public function getProposedExist($ninID = '') {
        $this->db->select('*');
        $this->db->from('t_hwc_proposed');
        $this->db->where('NIN_2_HFI', $ninID);
        $row = $this->db->get()->row_array();
        if ($row)
            {
            return $row;
            }
        else
            {
            return false;
            }
    }

     public function get_state($cid=null)
       { 
            global $db;
            $query = "Select * from m_state order by State_Name" ;

             $stmt = $db->query($query);
  
  
            return $stmt->fetchAll(); 


       }

       public function get_statenameid($get_stateid='')
       { 
         //var_dump($get_stateid); die;
            global $db;
            if($get_stateid)
            {
                if($get_stateid!='undefined'){
            $query = "Select State_Name,State_ID from m_state where State_ID=$get_stateid limit 1" ;
//echo $query; die;
             $stmt = $db->query($query);
  
  
            $val= $stmt->fetchAll(); 
            //var_dump($val[0]['State_Name']); die;
            return $val[0]['State_ID'];
                }
          }
          else
          {
            return '';
          }


       }
       
       
    public function get_statename($get_stateid='')
       { 
         //var_dump($get_stateid); die;
            global $db;
            if($get_stateid)
            {
            if($get_stateid!='undefined'){
            $query = "Select State_Name,State_ID from m_state where State_ID=$get_stateid limit 1" ;
//echo $query; die;
             $stmt = $db->query($query);
  
  
            $val= $stmt->fetchAll(); 
            //var_dump($val[0]['State_Name']); die;
            return $val[0]['State_Name'];
                }
          }
          else
          {
            return '';
          }


       }
       
       
       
       
       
    

    public function insertPropose($data) {

        $this->db->insert('t_hwc_proposed', $data);
        $data = $this->db->affected_rows();
    }

    public function updateProposed($data, $ninID) {
        $this->db->where('NIN_2_HFI', $ninID);
        $this->db->update('t_hwc_proposed', $data);
        $data = $this->db->affected_rows();
    }

    public function InsertUpdateProposed($data) {
        $ninID = $data['NIN_2_HFI'];

        if ($ninID)
            {
            // $existNinID = $this->getProposedExist($ninID);
            // showData($existNinID);//die();
            // showData($data);die();
            if ($row = $this->getProposedExist($ninID))
                {
                $this->db->where('NIN_2_HFI', $ninID);
//            if(isset($row['proposed_status']) &&proposed_status ){
//                
//            }
                $this->db->update('t_hwc_proposed', $data);
                $data = $this->db->affected_rows();
                }
            else
                {
                $this->db->insert('t_hwc_proposed', $data);
                $data = $this->db->affected_rows();
                }
            }
    }

     public function InsertProgram($data) {



       $this->db->insert('hwc_program_study', $data);


      // echo $this->db->last_query();

      

       

     }

         //////// bs function for insert State of MLHP
      public function InsertStatusMlhp($data) {



       $this->db->insert('hwc_status_mlhp', $data);


     }

    public function removeProposed($data, $ninID) {
        $this->db->where('NIN_2_HFI', $ninID);
        $this->db->update('t_hwc_proposed', $data);
        $data = $this->db->affected_rows();
    }

    public function verifyProposed($verifyProposed, $ninID) {
        $this->db->where('NIN_2_HFI', $ninID);
        $this->db->update('t_hwc', $verifyProposed);
        $data = $this->db->affected_rows();
        return $data;
    }

    public function rejectHwc($rejectData, $ninID) {
        $this->db->where('NIN_2_HFI', $ninID);
        $this->db->update('t_hwc', $rejectData);
        $data = $this->db->affected_rows();
        return $data;
    }

    // unproposed data...
    public function updateUnproposed($updateproposed, $ninID) {
        echo "test";
        return;
        $ninID = $data['NIN_2_HFI'];
        if ($ninID)
            {
            if ($this->getProposedExist($ninID))
                {
                $this->db->where('NIN_2_HFI', $ninID);
                $this->db->update('t_hwc_proposed', $data);
                $data = $this->db->affected_rows();
                }
            }
        else
            {
            $this->db->insert('t_hwc_proposed', $data);
            $data = $this->db->affected_rows();
            }
    }

//        public function insertUpdatePropose($data) {
//$sql='NSERT INTO t_hwc_proposed VALUES (3,'Example') ON DUPLICATE KEY UPDATE name='Example';
//'
//        $this->db->insert('t_hwc_proposed', $data);
//        $data = $this->db->affected_rows();
//    }
//    INSERT INTO table_name VALUES (3,'Example') ON DUPLICATE KEY UPDATE name='Example';

      public function getHWCReport($filterArray) {
        $queryWhere = $filterArray['WHERE'];

        $queryWhere[] = 'hwcp.proposed_status=1';


      
        $query = "select
                          SQL_CALC_FOUND_ROWS

  SUM(CASE WHEN HFI_Type = 1 AND hr_mo_mbbs = 1 AND (training_mos = 1 OR traning_hr_mos_staff_nurses = 1) AND medicines_available=1 AND diagnostics_available=1 AND  infra_branding=1 THEN 1 ELSE 0 END) AS dashboard_mc_phc,
  SUM(CASE WHEN HFI_Type = 3 AND hr_mo_mbbs = 1 AND (training_mos = 1 OR traning_hr_mos_staff_nurses = 1) AND medicines_available=1 AND diagnostics_available=1   AND  infra_branding=1 THEN 1 ELSE 0 END) AS dashboard_mc_uphc,
  SUM(CASE WHEN HFI_Type = 99 AND mlhp_posted = 1 AND (training_mpwf = 1 OR traning_ashas = 1) AND medicines_available=1 AND diagnostics_available=1  AND  infra_branding=1 THEN 1 ELSE 0 END) AS dashboard_mc_subcenter,


  SUM(CASE WHEN HFI_Type = 1  AND hr_mo_mbbs = 1 AND (training_mos = 1 OR traning_hr_mos_staff_nurses = 1) AND medicines_available=1 AND diagnostics_available=1 AND (service_hypertension=1 AND service_diabetes=1 AND service_oral_cancer=1 AND service_breast_cancer=1)   AND  infra_branding=1 THEN 1 ELSE 0 END) AS dashboard_mca_phc,
  SUM(CASE WHEN HFI_Type = 3  AND hr_mo_mbbs = 1 AND (training_mos = 1 OR traning_hr_mos_staff_nurses = 1) AND medicines_available=1 AND diagnostics_available=1 AND (service_hypertension=1 AND service_diabetes=1 AND service_oral_cancer=1 AND service_breast_cancer=1)   AND  infra_branding=1 THEN 1 ELSE 0 END) AS dashboard_mca_uphc,
  SUM(CASE WHEN HFI_Type = 99  AND mlhp_posted = 1 AND (training_mpwf = 1 OR traning_ashas = 1) AND medicines_available=1 AND diagnostics_available=1 AND (service_hypertension=1 AND service_diabetes=1 AND service_oral_cancer=1 AND service_breast_cancer=1)   AND  infra_branding=1 THEN 1 ELSE 0 END) AS dashboard_mca_subcenter,


                         sum(case when hf.HFI_Type = 1 then 1  else 0 end) AS phc_approved,
                        sum(case when hf.HFI_Type = 3 then 1  else 0 end) AS uphc_approved,
                         sum(case when hf.HFI_Type = 99 then 1  else 0 end) AS subcenter_approved,
                        
                      sum( case when   hf.HFI_Type =  1 AND  (hwc.hr_mo_mbbs = 1 OR hwc.hr_staff_nurses = 1) then 1  else 0 end) AS phc_hr,
                      sum( case when   hf.HFI_Type = 3 AND (hwc.hr_mo_mbbs = 1 OR hwc.hr_staff_nurses = 1) then 1  else 0 end) AS uphc_hr,
                      sum( case when   hf.HFI_Type = 99 AND hwc.mlhp_posted = 1 AND hwc.hr_asha = 1  then 1  else 0 end) AS subcenter_hr,

                      sum( case when   hf.HFI_Type =  1 AND  hwc.traning_hr_mos_staff_nurses = 1 then 1  else 0 end) AS phc_traning_staff_nurses,
                      sum( case when   hf.HFI_Type = 3 AND hwc.traning_hr_mos_staff_nurses= 1  then 1  else 0 end) AS uphc_traning_staff_nurses,
                      sum( case when   hf.HFI_Type = 99 AND hwc.traning_hr_mpw_ashas = 1  then 1  else 0 end) AS subcenter_traning_mpw_ashas,

                      sum( case when   hf.HFI_Type =  1 AND  hwc.population_enumeration = 1 then 1  else 0 end) AS phc_community_outreach,
                      sum( case when   hf.HFI_Type = 3 AND hwc.population_enumeration= 1  then 1  else 0 end) AS uphc_community_outreach,
                      sum( case when   hf.HFI_Type = 99 AND hwc.population_enumeration = 1  then 1  else 0 end) AS subcenter_community_outreach,

                      sum( case when   hf.HFI_Type =  1 AND  hwc.service_hypertension = 1 then 1  else 0 end) AS phc_service_hypertension,
                      sum( case when   hf.HFI_Type = 3 AND hwc.service_hypertension= 1  then 1  else 0 end) AS uphc_service_hypertension,
                      sum( case when   hf.HFI_Type = 99 AND hwc.service_hypertension = 1  then 1  else 0 end) AS subcenter_service_hypertension,

                     sum( case when   hf.HFI_Type =  1 AND  hwc.service_diabetes = 1 then 1  else 0 end) AS phc_service_diabetes,
                      sum( case when   hf.HFI_Type = 3 AND hwc.service_diabetes= 1  then 1  else 0 end) AS uphc_service_diabetes,
                      sum( case when   hf.HFI_Type = 99 AND hwc.service_diabetes = 1  then 1  else 0 end) AS subcenter_service_diabetes,

                     sum( case when   hf.HFI_Type =  1 AND  hwc.service_oral_cancer = 1 then 1  else 0 end) AS phc_service_service_oral_cancer,
                      sum( case when   hf.HFI_Type = 3 AND hwc.service_oral_cancer= 1  then 1  else 0 end) AS uphc_service_oral_cancer,
                      sum( case when   hf.HFI_Type = 99 AND hwc.service_oral_cancer = 1  then 1  else 0 end) AS subcenter_service_oral_cancer,

                     sum( case when   hf.HFI_Type =  1 AND  hwc.service_breast_cancer = 1 then 1  else 0 end) AS phc_service_breast_cancer,
                      sum( case when   hf.HFI_Type = 3 AND hwc.service_breast_cancer= 1  then 1  else 0 end) AS uphc_service_breast_cancer,
                      sum( case when   hf.HFI_Type = 99 AND hwc.service_breast_cancer = 1  then 1  else 0 end) AS subcenter_service_breast_cancer,

                      sum( case when   hf.HFI_Type =  1 AND  hwc.service_cervical_cancer = 1 then 1  else 0 end) AS phc_service_cervical_cancer,
                      sum( case when   hf.HFI_Type = 3 AND hwc.service_cervical_cancer= 1  then 1  else 0 end) AS uphc_service_cervical_cancer,
                      sum( case when   hf.HFI_Type = 99 AND hwc.service_cervical_cancer = 1  then 1  else 0 end) AS subcenter_service_cervical_cancer,

                     sum( case when   hf.HFI_Type =  1 AND  hwc.medicines_available = 1 then 1  else 0 end) AS phc_medicines_available,
                      sum( case when   hf.HFI_Type = 3 AND hwc.medicines_available= 1  then 1  else 0 end) AS uphc_medicines_available,
                      sum( case when   hf.HFI_Type = 99 AND hwc.medicines_available = 1  then 1  else 0 end) AS subcenter_medicines_available,

                     sum( case when   hf.HFI_Type =  1 AND  hwc.diagnostics_available = 1 then 1  else 0 end) AS phc_diagnostics_available,
                      sum( case when   hf.HFI_Type = 3 AND hwc.diagnostics_available= 1  then 1  else 0 end) AS uphc_diagnostics_available,
                      sum( case when   hf.HFI_Type = 99 AND hwc.diagnostics_available = 1  then 1  else 0 end) AS subcenter_diagnostics_available,

                      sum( case when   hf.HFI_Type =  1 AND  hwc.it_internet_connectivity = 1 then 1  else 0 end) AS phc_it_internet_connectivity,
                      sum( case when   hf.HFI_Type = 3 AND hwc.it_internet_connectivity= 1  then 1  else 0 end) AS uphc_it_internet_connectivity,
                      sum( case when   hf.HFI_Type = 99 AND hwc.it_internet_connectivity= 1  then 1  else 0 end) AS subcenter_it_internet_connectivity,

                      sum( case when   hf.HFI_Type =  1 AND  hwc.infra_branding = 1 then 1  else 0 end) AS phc_infra_branding,
                      sum( case when   hf.HFI_Type = 3 AND hwc.infra_branding= 1  then 1  else 0 end) AS uphc_infra_branding,
                      sum( case when   hf.HFI_Type = 99 AND hwc.infra_branding= 1  then 1  else 0 end) AS subcenter_infra_branding,

                          s.State_Name,
                          d.District_Name,
                          t.Taluka_Name,
                          b.Block_Name
                          from " . TB_HMIS_HEALTH_FACILITIES . " hf
                          Left join " . TB_PHC_CSC_MSTER . " pcm on hf.HFI_Type=pcm.PHC_CHC_ID
                          Left join " . TB_M_STATES . " s on hf.State_ID=s.State_ID
                          Left join " . TB_M_DISTRICTS . " d on hf.District_ID=d.District_ID
                          Left join " . TB_M_TALUKA . " t on hf.Taluka_ID=t.Taluka_ID
                          Left join " . TB_M_HEALTHBLOCKS . " b on hf.HealthBlock_ID=b.Block_ID

                         left join " . TB_T_HWC . " hwc on hf.NIN_2_HFI =hwc.NIN_2_HFI
                         left join " . TB_T_HWC_PROPOSED . " hwcp on hf.NIN_2_HFI =hwcp.NIN_2_HFI
                         where " . implode(' AND ', $queryWhere);

        $query .= " GROUP BY s.State_Name ";
        $query .= limit();


 
        $query = $this->db->query($query);
        $result_array_row = $query->result_array();
        $query = $this->db->query('SELECT FOUND_ROWS() AS `Count`');
        $fondRow = $query->row()->Count;

        //$fondRow = $query->num_rows();
        $result_array = array('result' => $result_array_row, 'total' => $fondRow);
        return $result_array;
    }

    public function getHWCFacilityList($filterArray) {
        $queryWhere = $filterArray['WHERE'];


                 $queryWhere[] = ' ( hf.operational_Status = 1 OR hf.operational_Status = 3) AND hf.confirmed_flag = 1 AND hf.verified_flag = 1 ';
        $query = "select
                          SQL_CALC_FOUND_ROWS
                          hf.NIN_2_HFI,
                          hf.HFI_Name,
                          hf.State_ID,
                          hf.District_ID,
                          hf.HFI_Type,
                          hf.confirmed_flag,
                          hf.verified_flag,
                          hf.operational_Status,
                          pcm.PHC_CHC_Type,
                          s.State_Name,
                          d.District_Name,
                          t.Taluka_Name,
                          b.Block_Name,
                          hwc.status,
                          hwc.verify_status,
                           hwc.remarks,
                            hwcp.p_remark,
                          hwcp.proposed_status,
                          hwcp.population_coverage
                          from " . TB_HMIS_HEALTH_FACILITIES . " hf
                          Left join " . TB_PHC_CSC_MSTER . " pcm on hf.HFI_Type=pcm.PHC_CHC_ID
                          Left join " . TB_M_STATES . " s on hf.State_ID=s.State_ID
                          Left join " . TB_M_DISTRICTS . " d on hf.District_ID=d.District_ID
                          Left join " . TB_M_TALUKA . " t on hf.Taluka_ID=t.Taluka_ID
                          Left join " . TB_M_HEALTHBLOCKS . " b on hf.HealthBlock_ID=b.Block_ID
                        Left join " . TB_T_MEMBERS . " m on hf.added_by_user=m.memberID
                         left join " . TB_T_HWC . " hwc on hf.NIN_2_HFI =hwc.NIN_2_HFI
                         left join " . TB_T_HWC_PROPOSED . " hwcp on hf.NIN_2_HFI =hwcp.NIN_2_HFI
                         where       " . implode(' AND ', $queryWhere) . "

                    Order by s.State_Name, d.District_Name, b.Block_Name, hf.HFI_Name " . limit();
        $query = $this->db->query($query);
        $result_array_row = $query->result_array();
        $query = $this->db->query('SELECT FOUND_ROWS() AS `Count`');
        $fondRow = $query->row()->Count;

        //$fondRow = $query->num_rows();
        $result_array = array('result' => $result_array_row, 'total' => $fondRow);
        return $result_array;
    }



    public function getFocusWiseStateDetails() {
        global $db;
        $stmt = 'SELECT
                    hhf.State_ID,
                    SUM(IF(hhf.HFI_Type = 1 AND thw.verify_status = 1 AND thw.status = 1 AND (thw.hr_mo_mbbs = 1 AND thw.traning_hr_mos_staff_nurses = 1 AND thw.population_enumeration = 1 AND thw.service_hypertension = 1 AND thw.service_diabetes = 1 AND thw.service_oral_cancer = 1 AND thw.service_breast_cancer = 1 AND thw.medicines_available = 1 AND thw.diagnostics_available = 1 AND thw.it_equipment_desktop = 1 AND thw.it_internet_connectivity = 1 AND thw.it_phc_ncd_application = 1 AND thw.infra_branding = 1), 1, 0)) AS phc_operational,
                    SUM(IF(hhf.HFI_Type = 3 AND thw.verify_status = 1 AND thw.status = 1 AND (thw.hr_mo_mbbs = 1 AND thw.traning_hr_mos_staff_nurses = 1 AND thw.population_enumeration = 1 AND thw.service_hypertension = 1 AND thw.service_diabetes = 1 AND thw.service_oral_cancer = 1 AND thw.service_breast_cancer = 1 AND thw.medicines_available = 1 AND thw.diagnostics_available = 1 AND thw.it_equipment_desktop = 1 AND thw.it_internet_connectivity = 1 AND thw.it_phc_ncd_application = 1 AND thw.infra_branding = 1), 1, 0)) AS uphc_operational,
                    SUM(IF(hhf.HFI_Type = 99 AND thw.verify_status = 1 AND thw.status = 1 AND (thw.mlhp_posted = 1 AND thw.traning_hr_mpw_ashas = 1 AND thw.population_enumeration = 1 AND thw.service_hypertension = 1 AND thw.service_diabetes = 1 AND thw.service_oral_cancer = 1 AND thw.service_breast_cancer = 1 AND thw.medicines_available = 1 AND thw.diagnostics_available = 1 AND thw.it_equipment_tablet = 1 AND thw.it_internet_connectivity = 1 AND thw.it_phc_ncd_application = 1 AND thw.infra_branding = 1), 1, 0)) AS subcenter_operational,
                    SUM(IF(hhf.HFI_Type = 1 AND thp.proposed_status=1, 1, 0)) AS phc_approved,
                    SUM(IF(hhf.HFI_Type = 3 AND thp.proposed_status=1, 1, 0)) AS uphc_approved,
                    SUM(IF(hhf.HFI_Type = 99 AND thp.proposed_status=1, 1, 0)) AS subcenter_approved
                  FROM t_hwc_proposed AS thp
                    LEFT JOIN t_hwc AS thw
                      ON thp.NIN_2_HFI = thw.NIN_2_HFI
                    INNER JOIN hmis_healthfacilities AS hhf
                      ON thp.NIN_2_HFI = hhf.NIN_2_HFI';
        $stmt .= '  WHERE hhf.HFI_Type IN(1, 3, 99) ';
        $stmt .= '  GROUP BY hhf.State_ID';
    
        $query = $db->query($stmt);
        $row = $query->fetchAll();
        return $row;
    }



    public function specialCriteria($value='')
    {
      $this->db->select('*');
      $this->db->from('t_hwc');
      $query = $this->db->get();
      $query->result_array();
    }

}
