<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Ihd_model extends CI_Model {

    public function __construct() {
      
    
        parent::__construct();
    }  
    public function son_list(){

     $this->db->select('son_master_tbl.*');
     $this->db->from('son_master_tbl');
     $this->db->order_by("son_master_tbl.id", "desc");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
    /*global $db;
    $stmt = $db->query('select n.* , s.* from notto_master_tbl as n inner join m_state as s on  n.state_id = s.state_id order by n.id desc'); 
        return $stmt->fetchAll(); 
*/
   } 
    
    public function insertson($data)
    {
        return $this->db->insert('son_master_tbl',$data);
    }
    public function son_edit_show($id){

    return $result = $this->db->select('son_master_tbl.*')->where("son_master_tbl.id",$id)->get("son_master_tbl",1)->result();
}
public function son_update_data($id,$data)
  {
    $where = array('id ' => $id);
    $this->db->where($where);
    return $this->db->update('son_master_tbl',$data);
  }
   
   public function fvms_list(){

     $this->db->select('fvms_master_tbl.*,Year (fvms_master_tbl.fromdate) as year1, Month(fvms_master_tbl.fromdate) as month1,Date(fvms_master_tbl.fromdate) as date1');
     $this->db->from('fvms_master_tbl');
     $this->db->order_by("fvms_master_tbl.id", "desc");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
    /*global $db;
    $stmt = $db->query('select n.* , s.* from notto_master_tbl as n inner join m_state as s on  n.state_id = s.state_id order by n.id desc'); 
        return $stmt->fetchAll(); 
*/
   } 
    
    public function insertfvms($data)
    {
        return $this->db->insert('fvms_master_tbl',$data);
    }
    public function fvms_edit_show($id){

    return $result = $this->db->select('fvms_master_tbl.*')->where("fvms_master_tbl.id",$id)->get("fvms_master_tbl",1)->result();
}
public function fvms_update_data($id,$data)
  {
    $where = array('id ' => $id);
    $this->db->where($where);
    return $this->db->update('fvms_master_tbl',$data);
  }

  

  /* ==================== twinkle code for mou ================ */
  public function insertdata($tbl_name,$value){
        if($this->db->insert($tbl_name, $value)){
            return true;
        }else{
            return false;
        }
    }
    //Update
    public function updatedata($tbl_name,$values,$condition=""){
        if($condition!=''){
            foreach($condition as $key=>$value){
                $this->db->where($key, $value);
            }
        }
        $this->db->update($tbl_name ,$values);
        return true;
    }
    //Delete
    public function deletedata($tbl_name,$condition=""){
        if($condition!=''){
            foreach($condition as $key=>$value){
                $this->db->where($key, $value);
            }
        }
        $this->db->delete($tbl_name);
        return true;
    }
    //Fetch Where
    public function fetchwhere($tbl_name,$andwherecondition="",$orwherecondition="",$type=""){

        $this->db->select('*');
        $this->db->from($tbl_name);
        $this->db->order_by('id','DESC');
        //echo $this->db->last_query();;die;
        if($andwherecondition!=''){
            foreach($andwherecondition as $key=>$value){
                $this->db->where($key, $value);
            }
        }
        if($orwherecondition!=''){
            foreach($orwherecondition as $key=>$value){
                $this->db->or_where($key, $value);
            }
        }
        $query = $this->db->get();
        if($query->num_rows()>0){
            if($type!=''){
                return $query->row_array();
            }else{
                return $query->result_array();
            }
        }else{
            return false;
        }
    }
    

  
    
    public function get_country($cid=null){ 
            global $db;
            $query = "Select * from tbl_country order by country" ;
            $stmt = $db->query($query); 
            return $stmt->fetchAll(); 
    }
    
    
    public function get_mouform(){
       
        $sql     =  "select mou.*,c.country from tbl_mou as mou 
        left join tbl_country as c on c.country=mou.country order by mou.id desc";
    
        $stmt = $this->db->query($sql); 
        if($stmt->num_rows()>0){
            return $stmt->result_array(); 
        }else{
            return false;
        }
        
    }


  /* ==================== end =========================== */






}

    
   