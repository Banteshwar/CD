
<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Meraaspataal_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function updateData($data){
        $this->db->where('id',1);
        return  $this->db->update("tbl_meraaspataal", $data);
    }

     public function fetchdata(){
        $this->db->select('*');
        $this->db->from('tbl_meraaspataal');
        $query  =  $this->db->get();
        return $query->row_array();
    }
    


}