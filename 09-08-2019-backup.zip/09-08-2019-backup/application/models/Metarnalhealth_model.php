<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Metarnalhealth_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    

public function getFru(){ 
    $this->db->select('*');
    $this->db->from('fru_master_table');
    $query = $this->db->get();

	if ($query->num_rows() > 0) {
		foreach ($query->result() as $row) {
			$data[] = $row;
		}
		return $data;
	}
	return false;
}

public function get_total_header(){
    $qry="SELECT sum(fru)  as header_count,'Total First Referral Unit' as header_title FROM `fru_master_table`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_table_data(){
     $subqry="(SELECT State_Name FROM `m_state` where m_state.State_ID =state_id  limit 1) as state_name";
    $qry="SELECT  year, chc as 'No. of fully operational FRUs (5 C-section/month for CHC and SDH) against months', phc as 'No. of fully operational FRUs (10 C-section/month for DH) against required no. of FRUs' FROM fru_master_table group by fru_master_table.state_id order by fru_master_table.date_added desc    ";
    return $this->db->query($qry)->result_array();   
}



public function get_total_kpi(){
     $data_val=$this->get_total_kpi_val();
    $qry="SELECT concat('Percentage of First trimester registration during Antenatal Care (ANC) : ',sum(firsttrimester),' , No. Percentage of Institutional delivery : ', sum(institutedelivery),' ,No. Percentage of 4 or more ANC checkup : ' , sum(anccheckup),' ,Number ANCs conducted under Pradhan Mantri Surakshit Matritva Abhiyan (PMSMA) : ' , sum(noofanc)) as total_kpi FROM `maternal_master_table` where financial_year='".$data_val['financial_year']."' and quarter='".$data_val['quarter']."'  ";
    return $this->db->query($qry)->row_array();
}
public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `maternal_master_table` GROUP by state_id  order by financial_year desc,quarter desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}


public function get_array_kpi(){
    $qry =  array("firsttrimester as 'Percentage of First trimester registration during ANC',institutedelivery as 'Percentage of Institutional delivery'","anccheckup as 'Percentage - 4 or more ANC checkup',noofanc as 'Number ANCs conducted under Pradhan Mantri Surakshit Matritva Abhiyan (PMSMA)'");
    return $qry;
}

public function get_table_kpi_data($id)
{  
   
    $data_val=$this->get_total_kpi_val();

    $qry="SELECT State_Name, ".$id." FROM maternal_master_table inner join m_state on m_state.State_ID=
    maternal_master_table.state_id where  financial_year='".$data_val['financial_year']."' and quarter ='".$data_val['quarter']."' GROUP by maternal_master_table.state_id  ";
   
    return $this->db->query($qry)->result_array();  
}
}

