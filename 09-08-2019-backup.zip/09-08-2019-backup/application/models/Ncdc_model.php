<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Ncdc_model extends CI_Model 
{

    public function __construct() {
        parent::__construct();
		ini_set('display_errors', 0);
    }
    public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `ncdc_money_table` GROUP by state  order by year desc,e_quarter desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}
/*public function get_total_kpi()
{
    $qry="SELECT concat('Name of Section/Division :',(SELECT (Name_Of_Section) FROM atr_master_tbl),',Pending ATR on PMO References :',SELECT (sum(atrpending_pmoreference) FROM atr_master_tbl),',Pending VIP References :',(SELECT count(devesion) FROM atr2_master_tbl),',Parliament Assurances : ',(SELECT count(Name_Section) FROM atr3_master_tbl)) as total_kpi" ;
    return $this->db->query($qry)->row_array();
}*/

public function get_total_kpi()
{
	$data_val=$this->get_total_kpi_val();
    $qry="SELECT concat('MoU SIGNED BETWEEN GOVT. OF INDIA AND STATE GOVT :',(SELECT count(date) FROM  ncdc_master_table),',SIGNING OF LEASE DEED/LAND REGISTERED:',(SELECT count(date) FROM ncdc_leased_table),',FOUNDATION STONE LAID:',(SELECT count(date) FROM ncdc_stone_table),',MONEY RELEASED DURING THE QUARTER:',(SELECT sum(amount) FROM ncdc_money_table where year='".$data_val['year']."' and e_quarter='".$data_val['e_quarter']."')) as total_kpi" ;
    return $this->db->query($qry)->row_array();
}

public function get_total_header()
{
    $qry="SELECT sum(atrpending_pmoreference) as header_count,
    'Pending ATR on PMO References' as header_title FROM `art_master_tbl`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_array_kpi()
{
    return array("date","type", "ncdc_stone_table.date", "amount" );
}

public function get_table_kpi_data($id)
{
$data_val=$this->get_total_kpi_val();
$qry2 = array("date"=>"Date","ncdc_stone_table.date"=>"Date",
    "amount"=>"Amount", "type"=>"Land Status"
     
); 
                  
        $alias_val=$qry2[$id];  

    switch($id){
        case "date":

         $qry="SELECT DATE(date) as DATE, State_Name,".$id." FROM ncdc_master_table inner join m_state on m_state.State_ID=
    ncdc_master_table.state   order by ncdc_master_table.state ";
    return $this->db->query($qry)->result_array(); 
        break;
		
		

        case "type":

         $qry="SELECT   State_Name,".$id." FROM ncdc_leased_table inner join m_state on m_state.State_ID=
    ncdc_leased_table.state   order by ncdc_leased_table.state ";
         return $this->db->query($qry)->result_array(); 
        break;
		
		  case "ncdc_stone_table.date":

         $qry="SELECT DATE(date) as DATE, State_Name,".$id." FROM ncdc_stone_table inner join m_state on m_state.State_ID=
    ncdc_stone_table.state   order by ncdc_stone_table.state ";
    return $this->db->query($qry)->result_array(); 
        break;
        
        case "amount":

        $qry="SELECT State_Name,".$id." FROM ncdc_money_table inner join m_state on m_state.State_ID=
    ncdc_money_table.state  where year='".$data_val['year']."' and e_quarter='".$data_val['e_quarter']."'  order by ncdc_money_table.state ";
         return $this->db->query($qry)->result_array(); 
        break;
              
    } 
}

}

