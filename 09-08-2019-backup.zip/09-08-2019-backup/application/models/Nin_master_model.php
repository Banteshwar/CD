
<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Nin_master_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        
    }
function getNINFunctionalFacilities($groupBy = false, $search_state_id='') { 

    global $db;
	
	$group_query = '';
	$join = '';
	$select_filds = '';
	
	if($groupBy == TRUE) {
	  $select_filds = ' s.State_Name,
					s.State_ID,
					s.state_char_code,';		
	  $join = " Left join " . TB_M_STATES . " s on hf.State_ID=s.State_ID ";
	  $group_query = 'GROUP BY s.State_ID' ;
	}
	
    $where = ' WHERE hf.verified_flag = 1  AND ( hf.operational_Status = 1 OR hf.operational_Status = 3 )  ';

    if($search_state_id)
    { 
    $where =  $where.' AND hf.State_ID='.$search_state_id. ' ';	
    }
    
   
    $sql = "SELECT
		".$select_filds."
        COUNT(*) AS Total_Facility,
        sum(case when HFI_Type = 1 then 1 else 0 end) as Primary_Health_Centre,
        sum(case when HFI_Type = 2 then 1 else 0 end) as Community_Health_Center,
        sum(case when HFI_Type = 3 then 1 else 0 end) as Urban_Health_Centre,
        sum(case when HFI_Type = 4 then 1 else 0 end) as Sub_District_Hospital,
        sum(case when HFI_Type = 5 then 1 else 0 end) as District_Hospital,
        sum(case when HFI_Type = 6 then 1 else 0 end) as Civil_Hospital_or_General_Hospital,
        sum(case when HFI_Type = 7 then 1 else 0 end) as Referral_Hospital,
        sum(case when HFI_Type = 8 then 1 else 0 end) as Dispensaries,
        sum(case when HFI_Type = 9 then 1 else 0 end) as Ayush_Dispensaries,
        sum(case when HFI_Type = 10 then 1 else 0 end) as Maternity_Home,
        sum(case when HFI_Type = 11 then 1 else 0 end) as Post_Partum_Unit,
        sum(case when HFI_Type = 12 then 1 else 0 end) as 'M&CW_Center',
        sum(case when HFI_Type = 13 then 1 else 0 end) as '<100_Bedded_Hospital',
        sum(case when HFI_Type = 14 then 1 else 0 end) as '100-500_Bedded_Hospital',
        sum(case when HFI_Type = 15 then 1 else 0 end) as '>500_Bedded_Hospital',
        sum(case when HFI_Type = 16 then 1 else 0 end) as Urban_Health_Posts,
        sum(case when HFI_Type = 17 then 1 else 0 end) as Medical_Colleges_Hospital,
        sum(case when HFI_Type = 18 then 1 else 0 end) as Women_Hospital,
        sum(case when HFI_Type = 99 then 1 else 0 end) as SubCentre,
        sum(case when HFI_Type = 100 then 1 else 0 end) as Others
        FROM " . TB_HMIS_HEALTH_FACILITIES . " hf ". $join;

  $query = $sql . ' ' . $where . $group_query; 

    $stmt = $db->query($query);

	if($groupBy == TRUE) {
		return $stmt->fetchAll();
	}
	return $stmt->fetch(); 
}



}