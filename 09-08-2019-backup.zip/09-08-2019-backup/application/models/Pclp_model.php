<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Pclp_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `maternal_master_table` GROUP by state_id  order by financial_year desc,quarter desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}


public function get_total_kpi(){

  
	$qry="SELECT concat('Total Number of Animal Bite Cases Reported : ',sum(Animal_Bite_cases_reported),' ,Total Number of Human Rabies Cases Reported : ', sum(Human_rabies_cases_reported),' ,Total Vaccine Availability Status : ', sum(Vaccine_availability_status) ) as total_kpi FROM `nrcp_master_table`  ";
    return $this->db->query($qry)->row_array();
	
	
	
	
	//echo $this->db->last_query();
	
	
}

public function get_total_header(){
   $qry="SELECT sum(Animal_Bite_cases_reported)  as header_count,'Total Ambulances Operational' as header_title FROM `nrcp_master_table`  ";
    return $this->db->query($qry)->row_array();  
}

public function get_table_data(){
   
    $subqry="(SELECT State_Name FROM `m_state` where m_state.State_ID =state_id  limit 1) as state_name";
    $qry="SELECT State_Name, Animal_Bite_cases_reported as a,Human_rabies_cases_reported as b,Vaccine_availability_status as c FROM nrcp_master_table inner join m_state on m_state.State_ID=
    nrcp_master_table.state_id order by nrcp_master_table.state_id ";
    return $this->db->query($qry)->result_array();   
	
	//echo $this->db->last_query(); die;
}


public function get_array_kpi(){

    return array("Animal_Bite_cases_reported","Human_rabies_cases_reported","Vaccine_availability_status");
}

public function get_table_kpi_data($id){
   
    
    $qry="SELECT State_Name,".$id." FROM nrcp_master_table inner join m_state on m_state.State_ID=
    nrcp_master_table.state_id  order by nrcp_master_table.state_id ";
    return $this->db->query($qry)->result_array(); 
	
}

}