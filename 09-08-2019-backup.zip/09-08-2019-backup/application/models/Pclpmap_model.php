<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Pclpmap_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
public function get_PMSSYs(){ 
    $this->db->select('nohp_master_table.*');
    $this->db->from('nohp_master_table');
	// $this->db->join('m_state','m_state.State_ID=nohp_master_table.state_id','inner');
    
 
   $this->db->order_by("nohp_master_table.id", "desc");


        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
}
public function get_mdiabetesform(){
		
		$sql     =  "select * from tbl_mdiabetes";
	
		$stmt = $this->db->query($sql); 
        if($stmt->num_rows()>0){
            return $stmt->result_array(); 
        }else{
            return false;
        }
        
	}
public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `pclp_master_table` GROUP by state_id  order by e_year desc,e_quarter desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}

public function get_map_data(){

    $qry="SELECT concat('Laboratory confirmed Leptospirosis cases reported	 : ',Laboratory_confirmed_Leptospirosis_cases_reported	,',Number of Leptospirosis outbreaks reported : ',Number_of_Leptospirosis_outbreaks_reported) AS hover, state_id FROM `pclp_master_table` order by state_id";
    return $this->db->query($qry)->result_array();

}


public function get_total_kpi(){
    $data_val=$this->get_total_kpi_val();
    $qry="SELECT concat('Total Laboratory confirmed Leptospirosis cases reported : ',sum(Laboratory_confirmed_Leptospirosis_cases_reported),' ,Total Number of Leptospirosis outbreaks reported : ', sum(Number_of_Leptospirosis_outbreaks_reported)) as total_kpi FROM `pclp_master_table` where e_year='".$data_val['e_year']."' and e_quarter='".$data_val['e_quarter']."'  ";
    return $this->db->query($qry)->row_array();

}

public function get_array_kpi(){

    $qry =  array("Laboratory_confirmed_Leptospirosis_cases_reported","Number_of_Leptospirosis_outbreaks_reported");
   
    return $qry;
}
public function get_total_header(){
    $qry="SELECT sum(Laboratory_confirmed_Leptospirosis_cases_reported)  as header_count,'Total Laboratory confirmed Leptospirosis cases reported' as header_title FROM `pclp_master_table`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_table_data(){
    $subqry="(SELECT State_Name FROM `m_state` where m_state.State_ID =state_id  limit 1) as state_name";
    $qry="SELECT State_Name,  Laboratory_confirmed_Leptospirosis_cases_reported,Number_of_Leptospirosis_outbreaks_reported FROM pclp_master_table inner join m_state on m_state.State_ID=
    pclp_master_table.state_id group by pclp_master_table.state_id order by pclp_master_table.state_id ";
    return $this->db->query($qry)->result_array();   
}

public function get_table_data_map(){
    
    $qry="SELECT State_Name,Laboratory_confirmed_Leptospirosis_cases_reported,Number_of_Leptospirosis_outbreaks_reported FROM pclp_master_table inner join m_state on m_state.State_ID=
    pclp_master_table.state_id  order by pclp_master_table.state_id ";
    return $this->db->query($qry)->result_array();   
}


public function get_table_kpi_data($id){
   
    $data_val=$this->get_total_kpi_val();
    $qry="SELECT State_Name,".$id." FROM pclp_master_table inner join m_state on m_state.State_ID=
    pclp_master_table.state_id  where e_year='".$data_val['e_year']."' and e_quarter='".$data_val['e_quarter']."' order by pclp_master_table.state_id ";
    return $this->db->query($qry)->result_array(); 
	
}
public function get_table_header($table){
    $qry="describe $table  ";
    return $this->db->query($qry)->result_array();   
}
}