<?php

defined('BASEPATH') or exit('No direct script access allowed');

   class Ambulance_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    } 
   
public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `ambulance_master_table` where e_year <= '".getCurrFinYear('Quarterly')."' and e_quarter <= '".getCurrQuarter('Quarterly')."' order by e_year desc,e_quarter desc LIMIT 1"; 

    $row = $this->db->query($qry)->row_array();
    
    if(empty($row)) {

      $qry="SELECT * FROM `ambulance_master_table` where e_year < '".getCurrFinYear('Quarterly')."' order by e_year desc,e_quarter desc LIMIT 1"; 

       $row = $this->db->query($qry)->row_array();        
    }
    return $row;
}

public function  getSumFieldValue($field, $table, $where =''){    
    
     $qry="SELECT sum(". $field.") as sum_". $field.", 
          SUM(IF(". $field."='', 1,0)) as count_". $field.",
        count(*) as total_count
      FROM ".$table." " . $where; 
      
      
     $val= $this->db->query($qry)->row_array();  
     
     if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
        return 'N/E';
     }
     else if($val['total_count']==0)
     {
        return 'N/E'; 
     }
     else {
        return $val["sum_".$field]; 
     }     
}


public function get_total_kpi(){ 
      $data_val=$this->get_total_kpi_val();

      $als  = "SELECT CONCAT(FLOOR((SUBQUERY.tt/SUBQUERY.cnt)/60), '.', LPAD((SUBQUERY.tt/SUBQUERY.cnt)%60, 2, 0)) as alss from (SELECT SUM(ALS_average_response_time_minute)*60 + SUM(ALS_average_response_time_second) as tt, COUNT( if(ALS_average_response_time_minute = '' AND ALS_average_response_time_second = '' , NULL, 1) ) as cnt  FROM `ambulance_master_table` where e_year = '".$data_val['e_year']."' order by e_year desc,e_quarter desc) AS SUBQUERY";

      $als1 =  $this->db->query($als)->row_array();
      
      if($als1['alss']!=0) {      
        $als1['alss']  =  $als1['alss'];;
      }else{
        $als1['alss']  = 'N/E'; 
      }

      $bls  = "SELECT CONCAT(FLOOR((SUBQUERY.tt/SUBQUERY.cnt)/60), '.', LPAD((SUBQUERY.tt/SUBQUERY.cnt)%60, 2, 0)) as blss from (SELECT SUM(BLS_average_response_minute)*60 + SUM(BLS_average_response_second) as tt, COUNT( if(BLS_average_response_minute = '' AND BLS_average_response_second = '' , NULL, 1) ) as cnt  FROM `ambulance_master_table` where e_year = '".$data_val['e_year']."' order by e_year desc,e_quarter desc) AS SUBQUERY";

      $bls1 =  $this->db->query($bls)->row_array();
      
     if($bls1['blss']!=0) {      
        $bls1['blss']  =  $bls1['blss'];;
      }else{
        $bls1['blss']  = 'N/E'; 
      }
  
     $table = 'ambulance_master_table';
     $where = "where e_year='".$data_val['e_year']."' and e_quarter='".$data_val['e_quarter']."' ";
      
  	 $value1 = $this->getSumFieldValue('ALS_ambulances_operational', $table, $where);
         
     $value2 = $this->getSumFieldValue('ALS_ambulances_required', $table, $where);     
          
     if($value1=='N/E' || $value2=='N/E'){        
         $als_kpi  = 'N/E';
     }else{
         $als_kpi   = $value1.'/'.$value2;
     }

     $value3 = $this->getSumFieldValue('BLS_ambulances_operational', $table, $where);
         
     $value4 = $this->getSumFieldValue('BLS_ambulances_required', $table, $where);     
          
     if($value3=='N/E' || $value4=='N/E'){        
         $bls_kpi  = 'N/E';
     }else{
         $bls_kpi   = $value3.'/'.$value4;
     }


  	  $qry="SELECT concat('Total Advanced Life Support(ALS) Ambulances Operational against Required: ','".$als_kpi."',',Total Basic life support(BLS) Ambulances Operational against Required : ','".$bls_kpi."',',Average response time (call to scene) ALS (min.sec) : ' , '".$als1['alss']."',', Average response time (call to scene) BLS (min.sec) : ','".$bls1['blss']."') as total_kpi FROM `ambulance_master_table` where e_year='".$data_val['e_year']."' and e_quarter='".$data_val['e_quarter']."' ";
  	
      return $this->db->query($qry)->row_array();
    }

    public function get_array_kpi(){
    
    //array("ALS_ambulances_operational as 'opr',ALS_ambulances_required as 'requ'","")

      $qry =  array("IF(ALS_ambulances_operational ='' AND ALS_ambulances_required ='','',CONCAT(ALS_ambulances_operational, '/',(ALS_ambulances_required))) as 'No. of Advanced Life Support(ALS) Ambulances Operational against Required'","IF(BLS_ambulances_operational ='' AND BLS_ambulances_required ='','',CONCAT(BLS_ambulances_operational, '/',(BLS_ambulances_required))) as 'No. of Basic life support(BLS) Ambulances Operational against Required'","IF(ALS_average_response_time_minute = '' AND ALS_average_response_time_second = '', '', CONCAT(IF(ALS_average_response_time_minute='',0,ALS_average_response_time_minute), ':', LPAD(ALS_average_response_time_second, 2, 0))) as 'Average response time (call to scene) ALS (min:sec)'","IF(BLS_average_response_minute = '' AND BLS_average_response_second = '', '', CONCAT(IF(BLS_average_response_minute = '' , 0,BLS_average_response_minute) , ':', LPAD(BLS_average_response_second, 2, 0)))  as 'Average response time (call to scene) BLS (min:sec)'");
       
        return $qry;
    }

   /* public function get_table_kpi_data($id){ 
      
         $data_val=$this->get_total_kpi_val();

         $qry="SELECT State_Name, ".$id." FROM ambulance_master_table inner join m_state on m_state.State_ID=
        ambulance_master_table.state_id where  e_year='".$data_val['e_year']."' and e_quarter ='".$data_val['e_quarter']."' GROUP by ambulance_master_table.state_id  ";
       
        return $this->db->query($qry)->result_array();  
    }*/

   public function get_table_kpi_data($id){ 

    $data_val=$this->get_total_kpi_val();
     
    $idWithoutAs = substr($id, 0, stripos($id, "as "));
    
    $qry="SELECT State_Name,".$id." FROM ambulance_master_table inner join m_state on m_state.State_ID=
    ambulance_master_table.state_id  where e_year='".$data_val['e_year']."' and e_quarter='".$data_val['e_quarter']."' AND ".$idWithoutAs." !='' AND ".$idWithoutAs." !='0' order by m_state.State_Name ";
    
    return $this->db->query($qry)->result_array();     
  }
  
}