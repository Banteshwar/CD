<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Amrcpmap_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
public function get_PMSSYs(){ 
    $this->db->select('nohp_master_table.*');
    $this->db->from('nohp_master_table');
	// $this->db->join('m_state','m_state.State_ID=nohp_master_table.state_id','inner');
    
 
   $this->db->order_by("nohp_master_table.id", "desc");


        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
}
public function get_mdiabetesform(){
		
		$sql     =  "select * from tbl_mdiabetes";
	
		$stmt = $this->db->query($sql); 
        if($stmt->num_rows()>0){
            return $stmt->result_array(); 
        }else{
            return false;
        }
        
	}

public function get_map_data(){

    $qry="SELECT concat('LABS ENROLLED UNDER THE AMR PROGRAMME	 : ',Labs_enrolled_under_the_AMR_Programme) AS hover, state_id FROM `amrcp_master_table` order by state_id";
    return $this->db->query($qry)->result_array();

}
/* public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `amrcp_master_table` order by e_year desc,e_quarter desc LIMIT 1";
    return $this->db->query($qry)->row_array();
} */


public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `amrcp_master_table` where e_year <= '".getCurrFinYear()."' and e_quarter <= '".getCurrQuarter('Quarterly')."' order by e_year desc,e_quarter desc LIMIT 1"; 

    $row = $this->db->query($qry)->row_array();
    
    if(empty($row)) {

      $qry="SELECT * FROM `amrcp_master_table` where e_year < '".getCurrFinYear()."' order by e_year desc,e_quarter desc LIMIT 1"; 

       $row = $this->db->query($qry)->row_array();        
    }

    return $row;
}


public function  getCountFieldValue($field, $table, $where =''){    
    
     $qry="SELECT count(". $field.") as sum_". $field.", 
          count(IF(". $field."='' || ". $field."='0', 1,0)) as count_". $field.",
        count(*) as total_count
      FROM ".$table." " . $where; 
      
      
     $val= $this->db->query($qry)->row_array();  
     
     if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
        return 'N/E';
     }
     else if($val['total_count']==0)
     {
        return 'N/E'; 
     }
     else {
        return $val["sum_".$field]; 
     }     
}


public function  getSumFieldValue2($field, $table, $where =''){    
    
	
     $qry="select sum(IF(Labs_reporting_AMR_surveillance_data = 'Yes', 1, 0)) as Labs_reporting_AMR_surveillance_data FROM ".$table." " . $where; 
    
     $val= $this->db->query($qry)->row_array();  
     
	
     if($val['Labs_reporting_AMR_surveillance_data'] == 0 ) {
       $val['Labs_reporting_AMR_surveillance_data']= 'N/E';
     }
    
     else {
        $val['Labs_reporting_AMR_surveillance_data']; 
     } 

return $val['Labs_reporting_AMR_surveillance_data'];
 
	 
}


public function get_total_kpi()
{ 
     $data_val=$this->get_total_kpi_val(); 

    
     $table = 'amrcp_master_table';
     $where = "where e_year='".$data_val['e_year']."' and e_quarter='".$data_val['e_quarter']."' ";
     
     $total_kpi = array(); 
      
     $value = $this->getCountFieldValue('Labs_enrolled_under_the_AMR_Programme', $table, $where);
     $total_kpi[] = 'Total Labs enrolled under the AMR Programme : '.$value ;  
	 
	 $value = $this->getSumFieldValue2('Labs_reporting_AMR_surveillance_data', $table, $where);     
     $total_kpi[] = 'Total Labs reporting AMR surveillance data: '.$value ; 
     
     $data['total_kpi'] = implode(',',$total_kpi);
    
    //echo print_r($data); die;
    return $data;
}

/* public function get_total_kpi(){
 $data_val=$this->get_total_kpi_val();
    $qry="SELECT concat('Total Labs enrolled under the AMR Programme : ',count(Labs_enrolled_under_the_AMR_Programme),' ,Total Labs reporting AMR surveillance data : ', SUM(IF(Labs_reporting_AMR_surveillance_data='Yes',1,0))) as total_kpi FROM `amrcp_master_table` where e_year='".$data_val['e_year']."' and e_quarter='".$data_val['e_quarter']."'  ";
    return $this->db->query($qry)->row_array();

} */

public function get_total_header(){
    $qry="SELECT sum(Labs_enrolled_under_the_AMR_Programme)  as header_count,'Total Labs enrolled under the AMR Programme' as header_title FROM `amrcp_master_table`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_table_data(){
    $subqry="(SELECT State_Name FROM `m_state` where m_state.State_ID =state_id  limit 1) as state_name";
    $qry="SELECT State_Name,  Labs_enrolled_under_the_AMR_Programme,Labs_reporting_AMR_surveillance_data FROM amrcp_master_table inner join m_state on m_state.State_ID=
    amrcp_master_table.state_id  order by amrcp_master_table.state_id ";
    return $this->db->query($qry)->result_array();   
}

public function get_table_data_map(){
    
    $qry="SELECT State_Name,Labs_enrolled_under_the_AMR_Programme,Labs_reporting_AMR_surveillance_data FROM amrcp_master_table inner join m_state on m_state.State_ID=
    amrcp_master_table.state_id  order by amrcp_master_table.state_id ";
    return $this->db->query($qry)->result_array();   
}

public function get_table_header($table){
    $qry="describe $table  ";
    return $this->db->query($qry)->result_array();   
}


public function get_array_kpi(){
    return array("Labs_enrolled_under_the_AMR_Programme as 'Labs enrolled under the AMR Programme'","Labs_reporting_AMR_surveillance_data as 'Total Labs reporting AMR surveillance data'");
}


 public function get_table_kpi_data($id){

    $data_val=$this->get_total_kpi_val();
	//echo $id;
    if($id == "Labs_reporting_AMR_surveillance_data as 'Total Labs reporting AMR surveillance data'"){
		 $qry="SELECT State_Name, Labs_enrolled_under_the_AMR_Programme as 'Labs reporting AMR surveillance data' FROM amrcp_master_table inner join m_state on m_state.State_ID=
    amrcp_master_table.state_id where  e_year='".$data_val['e_year']."' and e_quarter ='".$data_val['e_quarter']."' AND Labs_reporting_AMR_surveillance_data='Yes' Order by m_state.State_Name asc";
	}else {
		 $qry="SELECT State_Name, ".$id." FROM amrcp_master_table inner join m_state on m_state.State_ID=
    amrcp_master_table.state_id where  e_year='".$data_val['e_year']."' and e_quarter ='".$data_val['e_quarter']."' Order by m_state.State_Name asc";
	}
   
   
    return $this->db->query($qry)->result_array();  
} 

/* public function get_table_kpi_data($id){

    $data_val=$this->get_total_kpi_val();
    
    $qry="SELECT State_Name, ".$id." FROM amrcp_master_table inner join m_state on m_state.State_ID=
    amrcp_master_table.state_id where  e_year='".$data_val['e_year']."' and e_quarter ='".$data_val['e_quarter']."' GROUP by amrcp_master_table.state_id  ";
   
    return $this->db->query($qry)->result_array();  
} */


}