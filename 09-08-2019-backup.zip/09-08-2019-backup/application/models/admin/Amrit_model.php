<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Amrit_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
     
public function get_total_kpi_val(){
       
$qry="SELECT * FROM `amrit_master_tbl` order by year desc,month desc LIMIT 1";

    $row = $this->db->query($qry)->row_array();
   /* 
    if(empty($row)) {

      $qry="SELECT * FROM `amrit_master_tbl` where year < '".getCurrYear()."' order by year desc,month desc LIMIT 1"; 
       $row = $this->db->query($qry)->row_array();        
    }*/
    return $row;
}



public function  getSumFieldValue($field, $table, $where =''){    
    
     $qry="SELECT sum(". $field.") as sum_". $field.", 
          SUM(IF(". $field."='', 1,0)) as count_". $field.",
        count(*) as total_count
      FROM ".$table." " . $where; 
      
      
     $val= $this->db->query($qry)->row_array();  
     
     
     if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
        return 'N/E';
     }
     else if(empty($val['total_count']))
	 {
		return 'N/E'; 
	 }
     else {
        return $val["sum_".$field]; 
     }     
}


public function get_total_kpi()
{ 
     $data_val=$this->get_total_kpi_val();
    
     $table = 'amrit_master_tbl';
     $where = "where year='".$data_val['year']."' and month='".$data_val['month']."' ";
     
     $total_kpi = array(); 
      


     $value1 = $this->getSumFieldValue('Total_number_of_pharmacies', $table, $where);
    
     if($value1=='N/E'){
        $total_kpi[]= 'Total number of pharmacies: N/E';

     }else{
        $total_kpi[]= 'Total number of pharmacies: '.$value1;

     }
	 
	 $value1 = $this->getSumFieldValue('Number_of_patients_served', $table, $where);
    
     if($value1=='N/E'){
        $total_kpi[]= 'Total number of patients served: N/E';

     }else{
        $total_kpi[]= 'Total number of patients served: '.$value1;

     }

     $value1 = $this->getSumFieldValue('Value_of_drugs_dispensed', $table, $where);
    
     if($value1=='N/E'){
        $total_kpi[]= 'Value of drugs dispensed (at MRP): N/E';

     }else{
        $total_kpi[]= 'Value of drugs dispensed (at MRP): '.$value1;

     }
	 
	 $value1 = $this->getSumFieldValue('Savings_to_the_patients', $table, $where);
    
     if($value1=='N/E'){
        $total_kpi[]= 'Savings to the patients: N/E';

     }else{
        $total_kpi[]= 'Savings to the patients: '.$value1;

     }

     
     $data['total_kpi'] = implode(',',$total_kpi);
        
     return $data;
}




public function get_array_kpi(){

    $qry =  array("Total_number_of_pharmacies as 'Number of Pharmacies'","Number_of_patients_served as 'Number of Patients Served'","Value_of_drugs_dispensed as 'Value of drugs dispensed (in Crore)'","Savings_to_the_patients as 'Savings to the patients (in Crore)'");
   
    return $qry;
}

public function get_table_kpi_data($id){
    

	$data_val=$this->get_total_kpi_val();
	
    $idWithoutAs = substr($id, 0, stripos($id, "as "));
    
    $qry="SELECT State_Name,".$id." FROM amrit_master_tbl inner join m_state on m_state.State_ID=
    amrit_master_tbl.state_id  where year='".$data_val['year']."' and month='".$data_val['month']."' AND ".$idWithoutAs." !='' AND ".$idWithoutAs." !='0' order by m_state.State_Name ";
    
    return $this->db->query($qry)->result_array();    	
}

}