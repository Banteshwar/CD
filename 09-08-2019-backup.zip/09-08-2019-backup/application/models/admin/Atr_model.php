<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Atr_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
  

/* public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `ntcp_master_table`  order by year desc,Quarterly desc LIMIT 1";
    return $this->db->query($qry)->row_array();
} */

public function get_total_kpi_val(){
    
    $qry  = "SELECT * FROM `art_master_tbl`";
    $row  = $this->db->query($qry)->row_array();

    if(empty($row)) {

      $qry="SELECT * FROM `art_master_tbl` order by art_master_tbl.id"; 

       $row = $this->db->query($qry)->row_array();
        //echo "Inner condition"; print_r($row);
    }

    return $row;

}

public function get_total_kpi_val2(){
    
    $qry  = "SELECT * FROM `atr2_master_tbl`";
    $row  = $this->db->query($qry)->row_array();

    if(empty($row)) {

      $qry="SELECT * FROM `atr2_master_tbl` order by atr2_master_tbl.id"; 

       $row = $this->db->query($qry)->row_array();
        //echo "Inner condition"; print_r($row);
    }

    return $row;

}
public function get_total_kpi_val3(){
    
    $qry  = "SELECT * FROM `atr3_master_tbl`";
    $row  = $this->db->query($qry)->row_array();

    if(empty($row)) {

      $qry="SELECT * FROM `atr3_master_tbl` order by atr3_master_tbl.id"; 

       $row = $this->db->query($qry)->row_array();
        //echo "Inner condition"; print_r($row);
    }

    return $row;

}

public function  getCountFieldValue($field, $table, $where =''){
    
    
     $qry="SELECT count(". $field.") as sum_". $field.", 
          SUM(IF(". $field."='' || ". $field."='0', 1,0)) as count_". $field.",
        count(*) as total_count
      FROM ".$table." " . $where; 
      
      
     $val= $this->db->query($qry)->row_array();  
     
     if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
        return 'N/E';
     }
     else if($val['total_count']==0)
     {
        return 'N/E'; 
     }
     else {
        return $val["sum_".$field]; 
     }
     
}

public function  getSumFieldValue2($field, $table, $where =''){
    
    
     $qry="SELECT sum(". $field.") as sum_". $field.", 
      SUM(IF(". $field." = '', 1,0)) as count_". $field.",
      count(*) as total_count
    FROM ".$table." " . $where; 
    
    
   $val= $this->db->query($qry)->row_array();  
   if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
    return 'N/E';
   }
   else if(empty($val['total_count']))
   {
    return 'N/E'; 
   }
   else {
    return $val["sum_".$field]; 
   }
   
}
public function get_total_kpi()
{ 
     $data_val=$this->get_total_kpi_val();
    $data_val2=$this->get_total_kpi_val2();  
        $data_val2=$this->get_total_kpi_val3();  


    
     $table = 'art_master_tbl';
      $table1 = 'atr2_master_tbl';
    $table2 = 'atr3_master_tbl';

    

     
      $total_kpi = array(); 
      
      $value1 = $this->getSumFieldValue2('atrpending_pmoreference', $table);
      $total_kpi[] = 'No.of Pending ATR on PMO References : '.$value1 ; 
      
      $value1 = $this->getCountFieldValue('name', $table1);
      $total_kpi[] = 'Name of VIP : '.$value1 ; 
      
      $value1 = $this->getSumFieldValue2('pacount', $table2);
      $total_kpi[] = 'No.of Parliament Assurances: '.$value1 ; 
      
      
    
      
    $data['total_kpi'] = implode(',',$total_kpi);
    return str_replace("N/E/N/E","N/E",$data);
    
}




public function get_array_kpi()
{
    return array("atrpending_pmoreference", "name", "pacount");
}

public function get_table_kpi_data($id){
    $data_val=$this->get_total_kpi_val();
     $data_val1=$this->get_total_kpi_val2();
          $data_val2=$this->get_total_kpi_val3();

    
    if($id=="atrpending_pmoreference"){

         $qry="SELECT Name_Of_Section as 'Name of Section/Division' ,atrpending_pmoreference as 'No.of Pending ATR on PMO References', date1 as 'Date' FROM art_master_tbl where atrpending_pmoreference != 0 order by art_master_tbl.id ";
    return $this->db->query($qry)->result_array(); 
    }
    if($id=="name"){
      
         $qry="SELECT devesion as 'Name of Section/Division' ,name as 'Name of VIP', date as 'Date' FROM atr2_master_tbl order by atr2_master_tbl.id ";
    return $this->db->query($qry)->result_array(); 
    }
    if($id=="pacount"){
        
       
         $qry="SELECT Name_Section as 'Name of Section/Division' ,pacount as 'No.of Parliament Assurances', date1 as 'Date' FROM atr3_master_tbl where pacount != 0 order by atr3_master_tbl.id ";
    return $this->db->query($qry)->result_array(); 
    }
    
    
}

}