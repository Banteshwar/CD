<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Block_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
    public function selectSmsmaster(){

     $this->db->select('tbl_sms_master.*');
     $this->db->from('tbl_sms_master');
     $this->db->where("tbl_sms_master.is_active", "1");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   

   }
  
public function get_PMSSY_api($url)
	{
//$url="https://dashboard.nhp.gov.in/pmssy/pms/api/centraldashboard";
//$url="https://dashboard.nhp.gov.in/pmssy/pms/api/project_status";
$username="nhp";
$password="Pq@mk82ky#Z";
$ch = curl_init($url);
$ch_post_data = array();
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, TRUE);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
$rc = curl_exec($ch);
if ($rc) {
$rc= json_decode($rc,true);
//print_r($rc);
};
curl_close($ch);
return $rc;
}
 public function get_PMSSY_table($cond = NULL){
  $url="https://dashboard.nhp.gov.in/pmssy/pms/api/centraldashboard";
  $tbl_show=array("state","location","phase","emergencybeds","privatebeds","project_status","opd_status","mc_status","phy_progress","fin_progress");
  $result_tbl=$this->get_PMSSY_api($url);
  $final=array();
  $i=0;
  foreach($result_tbl as $result)
	   {
	  $final[$i]=array();

			foreach($result as $key=>$value)
		   {
						
		   if(in_array($key,$tbl_show))
			   {
			if($key=="state")
				$key="State_Name";
			   $final[$i][$key]=$value;
				
				}
	     }
   $i++;
   }
   return $final;
   }
public function get_PMSSYs(){ 
    $this->db->select('nohp_master_table.*');
    $this->db->from('nohp_master_table');
	// $this->db->join('m_state','m_state.State_ID=nohp_master_table.state_id','inner');
    
 
   $this->db->order_by("nohp_master_table.id", "desc");


        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
}

public function get_map_data(){

    $qry="SELECT concat('ALS Operational : ',ALS_ambulances_operational,',ALS Required : ',ALS_ambulances_required,'BLS Operational : ',BLS_ambulances_operational,',BLS Required : ',BLS_ambulances_required) AS hover, state_id FROM `ambulance_master_table` order by state_id";
    return $this->db->query($qry)->result_array();

}

public function TypeA(){
	 $qry="SELECT count(*) as sum_amount_due  FROM `pmssy_api_table` where type='A'";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount_due']; 
}

public function TypeM(){
	 $qry="SELECT count(*) as sum_amount_due  FROM `pmssy_api_table` where type='M'";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount_due']; 
}


public function get_total_kpi($tb){
$data_val=$this->get_total_kpi_val();
$data_nac=$this->get_total_kpi_val_naco();
switch($tb){
	case "ambulance":
    $qry="SELECT concat('No of ALS Ambulances Operational/Required : ',sum(ALS_ambulances_operational),'/',sum(ALS_ambulances_required),' ,No of BLS Ambulances Operational/Required : ', sum(BLS_ambulances_operational),'/',sum(BLS_ambulances_required),' ,Average response time (call to scene) ALS : ' , sum(ALS_average_response_time) ,', Average response time (call to scene) BLS  : ',sum(BLS_average_response_time)) as total_kpi FROM `ambulance_master_table`  ";
	return $this->db->query($qry)->row_array();
	break;
case "mera_aspataal":
    $qry="SELECT concat(name,':',score) as total_kpi FROM `merasptaal_master_table` WHERE `merasptaal_master_table`.`id` < 7   ORDER BY FIELD(id,2,3,4,5,6,1); ";
	return $this->db->query($qry)->result_array();
	break;
	
	
	case "pmssy":

	/* $count1="select * from tbl_pmssy_form_b";
	$c1=$this->db->query($count1)->num_rows();
	$count2="select * from tbl_pmssy_form_b_other";
	$c2=$this->db->query($count2)->num_rows();
	$c3=$c1+$c2;

    $qry="SELECT concat('New AIIMS Announced  : ',new_aiims,' ,New AIIMS approved by Cabinet : ', $c3,' ,Remaining AIIMS  : ' , new_aiims - $c3  ,', Government Medical College(GMC) appointed  : ',pmc,', Turnkey  Tender awarded  : ',turnkey) as total_kpi FROM `pmssyiims` join tbl_pmssy_form_b as tblb join tbl_pmssy_form_b_other as tblboth  ";
	return $this->db->query($qry)->row_array();
	break; */
	
	$row  = array();
     $row['total_kpi'] = 'New AIIMS Announced : '.$this->TypeA().' , Medical College Upgradation: '.$this->TypeM();	 
	 return $row;
	 break;
	
case "qa":

    $qry="SELECT State_Name,sum(nqas_facilities_count) as count FROM qa_master_table inner join m_state on m_state.State_ID= qa_master_table.state_id group by qa_master_table.state_id order by qa_master_table.state_id ";
	return $this->db->query($qry)->result_array();
	break;


case "elderly":
    //$qry="SELECT concat('Financial Outlay 2019-20 for Tertiary Care Component : ',fa_total,' ,Fund Utilization: ', fu_total,' ,District count : ' , no_of_district ,', RGC Count : ',no_of_rgc,' ,DH Operational: ', dh_operational,' ,RGC Operational: ', rgc_operational,' ,NCA operational: ', nca_operational,' ,Trainings Conducted: ', trainings_conducted,' ,Persons Trained: ', persons_trained,' ,OPD Provided: ', provide_service_opd,' ,IPD Services: ', provide_service_ipd) as total_kpi FROM `elderly_master_table_new` order by id DESC LIMIT 1 ";
	
	$qry = "SELECT concat('No. of District Hospitals sanctioned for Geriatric Unit : ',no_of_district,' ,No. of geriatric units in District Hospitals Operational: ', dh_operational,' ,Number of Regional Geriatric Centres (RGCs) sanctioned : ' , no_of_rgc ,', No of Regional Geriatric Centres (RGCs) Operational : ',rgc_operational,' ,No. of National Centre of Ageing (NCAs) sanctioned for establishment: ', nca_count,' ,No of National Centre of Ageing (NCAs) operational: ', nca_operational,' ,Financial Outlay 2019-20 for Tertiary Care Component: ', ROUND(fa_total,0),' ,Fund Utilization: ', ROUND(fu_total,0),' ,No. of staff Trained at Health Facilities: ', persons_trained,' ,No. of elderly provided service at OPD: ', ROUND(provide_service_opd,0),' ,No. of elderly provided service at IPD: ',ROUND(provide_service_ipd,0)) as total_kpi FROM `elderly_master_table_new` order by id DESC LIMIT 1";
	
	
	return $this->db->query($qry)->row_array();
	break;

case "son":
    $qry="SELECT concat('Application SON : ',noof_application_son,' ,Issued SON: ', issued_son,' ,Pending SON : ' , pending_son ,', ENC Application : ',noof_application_enc,' ,Issued ENC: ', issued_enc,' ,Pending ENC: ', pending_enc) as total_kpi FROM `son_master_tbl` order by id DESC LIMIT 1 ";
	return $this->db->query($qry)->row_array();
	break;

case "ehospital":
   /* $qry="SELECT concat(kpi_desc,':',kpi_value) as total_kpi FROM `ors_master_table` ";
	return $this->db->query($qry)->result_array();*/
 $qry="SELECT concat('No of Hospitals Onboarded : ',No_of_Hospitals_On_boarded,' ,No of Total Registration: ', No_of_Total_Registration,' ,No of Registration done Today : ' , No_of_Registration_done_Today) as total_kpi FROM `ehospital_master_table` where id =1 ";
	return $this->db->query($qry)->row_array();
	break;

	case "ors":
$qry="SELECT concat('No of Hospitals Onboarded : ',sum(No_of_Hospitals_On_boarded),' ,No of Total Appointments: ', sum(No_of_Total_Appointments),' ,No Of Appointments Taken Today: ', sum(No_of_Appointments_Taken_Today)) as total_kpi FROM ors_master_table where id =1";

	return $this->db->query($qry)->result_array();
	break;

	case "cghs":
    $qry="SELECT concat(kpi_desc,':',kpi_value) as total_kpi FROM `cghs_master_table`  ";
	return $this->db->query($qry)->result_array();
	break;

	case "rch":
    $qry="SELECT concat(kpi_desc,':',kpi_value) as total_kpi FROM `rch_master_table`  ";
	return $this->db->query($qry)->result_array();
	break;

	case "tobacco":
    $qry="SELECT concat('No of Users Registered : ',(SELECT NUM FROM `tbl_mhealth` WHERE id=1),' ,No of Users Quit Tobacco : ', sum(no_users_quit_tobacco)) as total_kpi FROM `tbl_tobacco`  ";
	return $this->db->query($qry)->row_array();
	break;

	case "mdiabetes":
    $qry="SELECT concat('No of Users Registered : ',num) as total_kpi FROM `tbl_mhealth` WHERE id=2 ";
	return $this->db->query($qry)->row_array();
	break;

	case "notto":
    $qry="SELECT concat('List of Hospitals for Organ and Tissue retreival/Transplantation and Eye Banks : ',listoff_hospitals,' ,No of Organ/Tissue Donors who have pledged for Organ and Tissue Donation after Death: ', numberoff_organ_tissue,' ,Transplants trends in the country: ' , transplant_trends_inthe_countery ,', No of Organ Allocation on central Registry : ',noof_organ_allocation_on_central,' , No of Wait Listed Patients Organ Wise : ', noof_wait_list_patient) as total_kpi FROM `notto_master_tbl` order by id DESC LIMIT 1 ";
	return $this->db->query($qry)->row_array();
	break;

	case "nvhcp":

	$qry="SELECT concat('Numbet of Districts with at least 1 Treatment centre : ',sum(Number_of_Districts),' ,Number of Model Treatment Centres Target: ', sum(Model_Treatment_Center_Target),' ,Model Treatment Centre Acheived : ' , SUM(Model_Treatment_Center_Achieved) ,', Number of Treatment Centre : ',sum(Districts_with_TC),' ,Number of Treatment Centre: ', sum(Total_No_of_TC),', Number of patients Put on treatment for Hepatitis C : ',sum(Patient_on_treatment),' ,Number of Hepatitis C patients successfully treated: ', sum(Patient_Successfully_Treated),', Number of Institutional Deliveries : ',sum(Institutional_Deliveries),' ,New Borns receiving Birth Dose of Hepatitis B vaccine: ', sum(Newborns_Receiving_birth_dose_of_Hepatitis_B_vaccine)) as total_kpi FROM `nvhcp_master_table`  where e_year='".$data_val['e_year']."' and e_month='".$data_val['e_month']."' ";
	
    /* $qry="SELECT concat('Model Treatment Centre Target : ',sum(Model_Treatment_Center_Target),' ,Model Treatment Centre Acheived: ', sum(Model_Treatment_Center_Achieved),' ,Total Districts : ' , SUM(Number_of_Districts) ,', District with Treatment Centre : ',sum(Districts_with_TC),' ,Total Treatment Centre: ', sum(Total_No_of_TC),', Patients on Treatment : ',sum(Patient_on_treatment),' ,Treated Ones: ', sum(Patient_Successfully_Treated),', Institutional Deliveries : ',sum(Institutional_Deliveries),' ,New Borns receiving Birth Dose of Hepatitis B vaccine: ', sum(Newborns_Receiving_birth_dose_of_Hepatitis_B_vaccine)) as total_kpi FROM `nvhcp_master_table` "; */
	
	
	  //$qry="SELECT concat('No of districts with functional dialysis units/Total districts : ',sum(No_of_districts_with_functional_dialysis_units), ' / ',sum(units_against_the_total_districts),',No of patients receiving treatment sessions held under PMNDP : ' , sum(No_of_patients_receiving_treatment)) as total_kpi FROM `hidialysis_master_tbl`  ";
	  
	/*$qry="SELECT
    CONCAT(
        'No. of Districts with at least one Treatment Center : ',
        SUM(Districts_with_TC),
        ' ,No. of Treatment Centers: ',
        SUM(Total_No_of_TC),
        ' ,No. of Model Treatment Centers made functional/Target : ',
            SUM(Model_Treatment_Center_Target),
            '/',
            SUM(
                Model_Treatment_Center_Achieved),
        ',No. of patients put on treatment for Hepatitis C: ',
        SUM(Patient_on_treatment),
        ' ,No. of Patients Successfully Treated: ',
        SUM(Patient_Successfully_Treated),
        ', Percentage of Newborns receiving birth dose of Hepatitis B/Institutional Deliveries : ',
            SUM(
                Newborns_Receiving_birth_dose_of_Hepatitis_B_vaccine
            ),
            '/',
            SUM(Institutional_Deliveries)
        ) AS total_kpi
    FROM
        `nvhcp_master_table`;"; */
	
	return $this->db->query($qry)->row_array();
	break;

	/*case "naco":
    $qry="SELECT concat('HIV Testing Done : ',sum(Number_of_HIV_testing_done),' ,People with HIV: ', sum(People_Living_with_HIV),' ,People Treated : ' , SUM(PLHIV_undergone)) as total_kpi FROM `naconew_master_table`  where e_year='".$data_nac['e_year']."' and e_month='".$data_nac['e_month']."'";*/

    case "naco":
    $qry="SELECT concat('Number of HIV Testing Done : ',sum(Number_of_HIV_testing_done),' ,b. Number of People Living with HIV (PLHIV) who are on treatment(Cumulative): ', sum(People_Living_with_HIV),' ,Number of PLHIV undergone viral load testing : ' , SUM(PLHIV_undergone)) as total_kpi FROM `naconew_master_table`  where e_year='".$data_nac['e_year']."' and e_month='".$data_nac['e_month']."'";
	return $this->db->query($qry)->row_array();
	break;

	case "mou":
    $qry="SELECT COUNT(subject) as 'Total MOUs', SUM(CASE WHEN status=1 THEN 1 ELSE 0 END) as 'Total Active', SUM(CASE WHEN status=2 THEN 1 ELSE 0 END) as 'Total Inactive', SUM(CASE WHEN status=3 THEN 1 ELSE 0 END) as 'Total Expired' FROM tbl_mou ";
	return $this->db->query($qry)->row_array();
	break;

	case "fvms":
    $qry="SELECT COUNT(subject) as 'Total Meetings', SUM(noof_delegates) as 'Total Delegates Visited' FROM fvms_master_tbl ";
	return $this->db->query($qry)->row_array();
	break;
}
	
	
}

public function get_total_header(){
    $qry="SELECT sum(ALS_ambulances_operational)  as header_count,'Total Ambulances Operational' as header_title FROM `ambulance_master_table`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_table_data($slug){
    switch($slug){
	
	case "ambulance":
	$subqry="(SELECT State_Name FROM `m_state` where m_state.State_ID =state_id  limit 1) as state_name";
    $qry="SELECT State_Name,  ALS_ambulances_operational,ALS_ambulances_required,BLS_ambulances_operational,BLS_ambulances_required,ALS_average_response_time,BLS_average_response_time FROM ambulance_master_table inner join m_state on m_state.State_ID=
    ambulance_master_table.state_id  order by ambulance_master_table.state_id ";
    break;

case "pmssy":
	$qry="SELECT State_Name, District_name, avg_daily_opd,monthly_ipd,pg_seats,mbbs_seats,speciality_functional,super_speciality_functional,faculty_in_position,non_faculty_in_position,remarks FROM tbl_pmssy_form_b inner join m_state on m_state.State_ID= tbl_pmssy_form_b.statename inner join m_district on m_district.District_ID= tbl_pmssy_form_b.aiims_district order by tbl_pmssy_form_b.statename ";
    break;

    case "ehospital":
		$qry-"SELECT m_state.State_Name,No_of_Hospitals_On_boarded,No_of_Total_Registration,No_of_Registration_done_Today FROM `ehospital_master_table` inner JOIN `tbl_state_ors_ehospital` USING(State_code) inner JOIN m_state ON State_Id=cd_state_id";

		break;


    case "ors":
		$qry-"SELECT m_state.State_Name,No_of_Hospitals_On_boarded,No_of_Total_Appointments,No_of_Appointments_Taken_Today FROM `ors_master_table` inner JOIN `tbl_state_ors_ehospital` USING(State_code) inner JOIN m_state ON State_Id=cd_state_id";

		break;
	case "qa":
	
	$qry="SELECT State_Name,nqas_facilities_count,financial_year,quarter FROM qa_master_table inner join m_state on m_state.State_ID= qa_master_table.state_id order by qa_master_table.state_id ";
    break;

	case "nvhcp":
		$subqry="(SELECT State_Name FROM `m_state` where m_state.State_ID =state_id  limit 1) as state_name";
    $qry="SELECT State_Name,e_year as Year,e_month as Month,  Model_Treatment_Center_Target,Model_Treatment_Center_Achieved,Number_of_Districts,Districts_with_TC,Total_No_of_TC,Patient_on_treatment,Patient_Successfully_Treated,Institutional_Deliveries,Newborns_Receiving_birth_dose_of_Hepatitis_B_vaccine FROM nvhcp_master_table inner join m_state on m_state.State_ID=
    nvhcp_master_table.state_id  order by nvhcp_master_table.state_id ";
		break;
		case "naco":
		    $qry="SELECT  e_year as Year,e_month as Month,  Number_of_HIV_testing_done,People_Living_with_HIV,PLHIV_undergone FROM  naconew_master_table";
		break;
		case "mou":
		    $qry="SELECT  id,subject,type,country,date_of_signing,date_of_ratification,cabinet_approval,date_of_cabinet_approval,sunset_clause,auto_renewal,select_cycle,date_next_level,status FROM  tbl_mou";
		break;
		case "fvms":
		    $qry="SELECT subject,meeting_venues,fromdate,todate,noof_delegates FROM  fvms_master_tbl";
		break;
	}
	$result=$this->db->query($qry)->result_array();
	if(empty($result))
		$result[0]="No records to display";
	return  $result;   
}
public function get_array_kpi($slug){
    switch($slug){
	case "ambulance":
	return array("ALS_ambulances_operational,ALS_ambulances_required","BLS_ambulances_operational,BLS_ambulances_required","ALS_average_response_time","BLS_average_response_time");
	break;
	
	case "pmssy":
	//return array("1","1","1","1","1");
	$qry =  array("New AIIMS","Medical College");
   
    return $qry;
	break;

	case "qa":
		$qry="SELECT DISTINCT state_id FROM qa_master_table ORDER BY state_id";
	return $this->db->query($qry)->result_array();	
	break;

	case "nvhcp":
	return array("Number_of_Districts as 'Total Districts'","Model_Treatment_Center_Target as 'Model Treatment Centre Target'","Model_Treatment_Center_Achieved as 'Model Treatment Centre Acheived'","Districts_with_TC as 'District with Treatment Centre'","Total_No_of_TC as 'Total Treatment Centre'","Patient_on_treatment as 'Patients on Treatment'","Patient_Successfully_Treated as 'Treated Ones'","Institutional_Deliveries as 'Institutional Deliveries'","Newborns_Receiving_birth_dose_of_Hepatitis_B_vaccine as 'New Borns receiving Birth Dose of Hepatitis B vaccine'");
	break;
	case "naco":
	return array("Number_of_HIV_testing_done","People_Living_with_HIV","PLHIV_undergone");
	break;
   case "mou":
	return array("1","status=1","status=2","status=3");
	break;
	case "fvms":
	return array("subject","noof_delegates");
	break;
case "ehospital":
	return array("No_of_Hospitals_On_boarded","No_of_Total_Registration","No_of_Registration_done_Today");
	break;
case "ors":
	return array("No_of_Hospitals_On_boarded","No_of_Total_Appointments","No_of_Appointments_Taken_Today");
	break;

	}
}

public function get_table_kpi_data($slug,$id){
	$data_val=$this->get_total_kpi_val();
	$data_nac=$this->get_total_kpi_val_naco();
   switch($slug){
	case "ambulance":
	
	$qry="SELECT State_Name,".$id." FROM ambulance_master_table inner join m_state on m_state.State_ID=
    ambulance_master_table.state_id  order by ambulance_master_table.state_id ";
    break;
   
   case "qa":
	
	$qry="SELECT State_Name,nqas_facilities_count,financial_year,quarter FROM qa_master_table inner join m_state on m_state.State_ID= qa_master_table.state_id WHERE qa_master_table.state_id=".$id;
    break;

case "pmssy":
	
	/* $qry="SELECT State_Name, District_name, avg_daily_opd,monthly_ipd,pg_seats,mbbs_seats,speciality_functional,super_speciality_functional,faculty_in_position,non_faculty_in_position,remarks FROM tbl_pmssy_form_b inner join m_state on m_state.State_ID= tbl_pmssy_form_b.statename inner join m_district on m_district.District_ID= tbl_pmssy_form_b.aiims_district  WHERE ".$id." order by tbl_pmssy_form_b.statename";
    break; */
	
	if($id == 'New AIIMS') {
	   return $this->newaiimslisting();
   }
   
   if($id == 'Medical College') {
	   return $this->MedicalCollegeListing();
   }
   

	return array();

    break;

   case "nvhcp":
		$subqry="(SELECT State_Name FROM `m_state` where m_state.State_ID =state_id  limit 1) as state_name";
    /*$qry="SELECT e_year as year, State_Name, ".$id." FROM nvhcp_master_table inner join m_state on m_state.State_ID= nvhcp_master_table.state_id group by nvhcp_master_table.e_year  order by nvhcp_master_table.state_id ";
		break;*/
		$qry="SELECT e_year as year, State_Name, ".$id." FROM nvhcp_master_table inner join m_state on m_state.State_ID= nvhcp_master_table.state_id where  e_year='".$data_val['e_year']."' and e_month ='".$data_val['e_month']."'    order by nvhcp_master_table.state_id ";
		break;


   case "naco":
		
    //$qry="SELECT e_year as year,e_month as month,  ".$id." FROM naconew_master_table";
		//break;
		$subqry="(SELECT State_Name FROM `m_state` where m_state.State_ID =state_id  limit 1) as state_name";
    $qry="SELECT e_year as year, State_Name, ".$id." FROM naconew_master_table inner join m_state on m_state.State_ID= naconew_master_table.state_id where  e_year='".$data_nac['e_year']."' and e_month ='".$data_nac['e_month']."'    order by naconew_master_table.state_id ";
		break;

    case "mou":
		
    $qry="SELECT  subject,type,country,date_of_signing,date_of_ratification,cabinet_approval,date_of_cabinet_approval,sunset_clause,auto_renewal,select_cycle,date_next_level,status FROM  tbl_mou WHERE ".$id;
		break;
	case "fvms":
	$qry="SELECT  meeting_venues,fromdate,todate,".$id." FROM  fvms_master_tbl";
   break;
case "ehospital":
	$qry="SELECT m_state.State_Name,".$id." FROM  ehospital_master_table inner JOIN  tbl_state_ors_ehospital  USING(State_code) inner JOIN m_state ON State_Id=cd_state_id";
	break;
case "ors":
	$qry="SELECT m_state.State_Name,".$id." FROM  ors_master_table inner JOIN  tbl_state_ors_ehospital  USING(State_code) inner JOIN m_state ON State_Id=cd_state_id";
	break;
   }
   $result=$this->db->query($qry)->result_array();
   if(empty($result))
	   $result[0]="No records to display";
	return $result;   
}

public function newaiimslisting(){
	
	 $qry="SELECT project,state, location, phase,project_status,opd_status,mc_status,phy_progress  FROM `pmssy_api_table` where type='A'";	
	 return $this->db->query($qry)->result_array();
	
}

public function MedicalCollegeListing(){
	
	 $qry="SELECT project,state, location, phase,approvedcost,project_status,phy_progress  FROM `pmssy_api_table` where type='M'";	
	 return $this->db->query($qry)->result_array();
	
}

public function get_table_data_map(){
    
    $qry="SELECT State_Name,ALS_ambulances_operational,ALS_ambulances_required,BLS_ambulances_operational,BLS_ambulances_required,ALS_average_response_time,BLS_average_response_time FROM ambulance_master_table inner join m_state on m_state.State_ID=
    ambulance_master_table.state_id  order by ambulance_master_table.state_id ";
    return $this->db->query($qry)->result_array();   
}

public function get_table_header($table){
    $qry="describe $table  ";
    return $this->db->query($qry)->result_array();   
}


public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `nvhcp_master_table` GROUP by state_id  order by e_year desc,e_month desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}
 
  public function get_total_kpi_val_naco(){
    
    $qry="SELECT * FROM `naconew_master_table` GROUP by state_id  order by e_year desc,e_month desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}
   
   
}

