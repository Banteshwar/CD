<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Bloodbank_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    

public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `hibloodbank_master_tbl` where year <= '".getCurrFinYear()."' and Quarterly <= '".getCurrQuarter('Quarterly')."' order by year desc,Quarterly desc LIMIT 1"; 

    $row = $this->db->query($qry)->row_array();
    //print_r($row);
    if(empty($row)) {

      $qry="SELECT * FROM `hibloodbank_master_tbl` where year < '".getCurrFinYear()."' order by year desc,Quarterly desc LIMIT 1"; 

       $row = $this->db->query($qry)->row_array();        
    }

    return $row;
}


public function  getSumFieldValue($field, $table, $where =''){    
    
     $qry="SELECT sum(". $field.") as sum_". $field.", 
          SUM(IF(". $field."='' , 1,0)) as count_". $field.",
        count(*) as total_count
      FROM ".$table." " . $where; 
      
      
     $val= $this->db->query($qry)->row_array();  
     
     if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
        return 'N/E';
     }else if(empty($val['total_count'])){
        return 'N/E'; 
     }else {
        return $val["sum_".$field]; 
     }     
}

public function get_total_kpi(){ 

     $data_val=$this->get_total_kpi_val(); 
    
     $table = 'hibloodbank_master_tbl';
     $where = "where year='".$data_val['year']."' and Quarterly='".$data_val['Quarterly']."' ";
     
     $total_kpi = array(); 
      
     $value1 = $this->getSumFieldValue('No_of_functional_blood_banks', $table, $where);
         
     $value2 = $this->getSumFieldValue('dh_morethanhundred_beds', $table, $where);     
          
     if($value1=='N/E' || $value2=='N/E'){
        
         $total_kpi[]= 'No. of functional Blood Banks (against the target of District Hospitals having >100 beds: N/E';

     }else{
        $total_kpi[]= 'No. of functional Blood Banks (against the target of District Hospitals having >100 beds: '.$value1.'/'.$value2;
     }

     $value1 = $this->getSumFieldValue('No_of_functional_blood_banks', $table, $where);
         
     $value2 = $this->getSumFieldValue('No_of_functional_fru', $table, $where);     
          
     if($value1=='N/E' || $value2=='N/E'){
        $total_kpi[]= 'No. of functional Blood Banks/ Blood Storage Units (against no of functional FRUs): N/E';

     }else{
        $total_kpi[]= 'No. of functional Blood Banks/ Blood Storage Units (against no of functional FRUs): '.$value1.'/'.$value2;
     }     
     
     $data['total_kpi'] = implode(',',$total_kpi);
        
     return str_replace('N/E/N/E','N/E',$data);
}

public function get_array_kpi(){

    $qry =  array("No_of_functional_blood_banks as 'No of functional Blood Banks',dh_morethanhundred_beds as 'District Hospitals having >100 beds'",
      "No_of_functional_blood_banks as 'No of functional Blood Banks', 
      No_of_functional_fru as 'Number of functional FRU'");
   
    return $qry;
}

public function get_table_kpi_data($id){ 

    $data_val=$this->get_total_kpi_val();
     
    $idWithoutAs = substr($id, 0, stripos($id, "as "));
    
    $qry="SELECT State_Name,".$id." FROM hibloodbank_master_tbl inner join m_state on m_state.State_ID=
    hibloodbank_master_tbl.state_id  where year='".$data_val['year']."' and Quarterly='".$data_val['Quarterly']."' AND ".$idWithoutAs." !='' AND ".$idWithoutAs." !='0' order by m_state.State_Name "; 
    return $this->db->query($qry)->result_array();     
}

}