<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Bloodbank_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    


public function get_total_kpi(){

    $qry="SELECT concat('No. of functional Blood Banks (against the target of District Hospitals having >100 beds)  : ',sum(No_of_functional_blood_banks),'/',sum(dh_morethanhundred_beds),' ,No. of functional Blood Banks / Blood Storage Units (against no. of functional FRUs) : ', sum(No_of_functional_blood_banks),'/',sum(No_of_functional_bloodbanks_bsu)) as total_kpi FROM `hibloodbank_master_tbl`  ";
    return $this->db->query($qry)->row_array();

}

public function get_total_header(){
    $qry="SELECT sum(No_of_functional_blood_banks)  as header_count,'Total Blood Banks' as header_title FROM `hibloodbank_master_tbl`  ";
    return $this->db->query($qry)->row_array();   
}


public function get_array_kpi(){

    $qry =  array("No_of_functional_blood_banks,dh_morethanhundred_beds","No_of_functional_bloodbanks_bsu,dh_morethanhundred_beds");
   
    return $qry;
}

public function get_table_kpi_data($id){
   
    
    /*$qry="SELECT State_Name, year, SUM(".$id.") AS ".$id." FROM hibloodbank_master_tbl inner join m_state on m_state.State_ID=
    hibloodbank_master_tbl.state_id  group by hibloodbank_master_tbl.year ";*/

    
    $qry2 = array("No_of_functional_blood_banks,dh_morethanhundred_beds"=>"No. of fully operational FRUs (5 C-section/month for CHC and SDH) against required no. of FRUs", 
        "No_of_functional_bloodbanks_bsu,dh_morethanhundred_beds"=>"No. of fully operational FRUs (10 C-section/month for DH) against required no. of FRUs");

   $alias_val=$qry2[$id];


   $lst = explode(",", $id);

   if(count($lst) > 1)
   {
        $id1 = $lst[0];
        $id2 = $lst[1];
        $id3 = $id1.'/'.$id2;
        
        $qry="SELECT State_Name, year as 'Financial Year', concat(SUM(".$id1."),'/',SUM(".$id2.")) AS '".$alias_val."' FROM hibloodbank_master_tbl  inner join m_state on m_state.State_ID=
    hibloodbank_master_tbl.state_id group by hibloodbank_master_tbl.year ";
   
   }
    else{
    $qry="SELECT State_Name, year as 'Financial Year', SUM(".$id.") AS '".$alias_val."' FROM hibloodbank_master_tbl group by hibloodbank_master_tbl.year ";
   }
   
   
    return $this->db->query($qry)->result_array();   
}
  
}

