<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Cghs_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
public function get_CGHS(){ 
    $this->db->select('cghs_master_table.*');
    $this->db->from('cghs_master_table');
	// $this->db->join('m_state','m_state.State_ID=nohp_master_table.state_id','inner');
    
 
   $this->db->order_by("cghs_master_table.id", "desc");

        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
}

/*public function cghs_kpis() {
        $this->db->select("*"); 
        $this->db->from('cghs_master_table');
        $query=$this->db->get();
        if($query){ 
            return $query->result_array();
        }else{
            return false;
        }
        
    }*/


public function get_array_kpi(){

   return Array("No. of empanelled Health Care Organisations","MRC Claims Pending > 30 days");   
    
}


public function get_total_kpi(){

    $qry="SELECT concat('KPI Description : ',sum(kpi_desc),'KPI Value : ',sum(kpi_value)) as total_kpi FROM `cghs_master_table`  ";
    return $this->db->query($qry)->row_array();

}

public function get_table_data(){
    $qry="SELECT cghs_master_table.id,  cghs_master_table.kpi_desc  as 'KPI Description' FROM cghs_master_table order by cghs_master_table.id";
    return $this->db->query($qry)->result_array();   
}

/*public function get_table_data_map(){
    
    $qry="SELECT * FROM cghs_master_table order by cghs_master_table.id ";
    return $this->db->query($qry)->result_array();   
}*/

public function get_table_header($table){
    $qry="describe $table  ";
    return $this->db->query($qry)->result_array();   
}

 
    
   
}

