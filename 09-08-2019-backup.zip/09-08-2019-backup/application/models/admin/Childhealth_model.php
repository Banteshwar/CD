<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Childhealth_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }


   
public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `childhealthndd_master_table` order by year desc,e_month desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}

public function get_total_kpi_val1(){
    
    $qry="SELECT * FROM `childhealthidsp_master_table` order by year desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}

public function get_total_kpi_val2(){
    
    $qry="SELECT * FROM `childhealthmht_master_table` order by year desc,Quarter desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}
    
public function get_total_kpi(){
    $data_val=$this->get_total_kpi_val();
    $data_val1=$this->get_total_kpi_val1();
    $data_val2=$this->get_total_kpi_val2();

    $qry="SELECT concat('Number of children covered under National Deworming Day Coverage (NDD): ',(select sum(ndd) from childhealthndd_master_table where year='".$data_val['year']."' and e_month='".$data_val['e_month']."'),',Number of children covered under Intensified Diarrhoea Control Fortnight Coverage (IDCF): ', (select sum(idcf) from childhealthidsp_master_table where year='".$data_val1['year']."'),',Number of children screened by Mobile Health Team (MHT) under Rashtriya Bal Swasthya Karyakram (RBSK) : ' ,sum(no_of_children_screened) ,',Number of Newborns received complete home visits under Home Based Newborn Care (HBNC) Program: 
    ',sum(no_of_newborns_received),',Number of sick newborns received treatment in Special Newborn Care Units (SNCUs)  :',sum(no_of_children_received)) as total_kpi FROM `childhealthmht_master_table` where year='".$data_val2['year']."' and Quarter='".$data_val2['Quarter']."' ";
    return $this->db->query($qry)->row_array();

}




public function get_array_kpi(){

    /*return 
    array("ndd","idcf","no_of_children_screened","no_of_children_received","no_of_newborns_received");*/

    $qry =  array("ndd as 'Number of children covered under National Deworming Day Coverage (NDD)'","idcf as 'Number of children covered under Intensified Diarrhoea Control Fortnight Coverage (IDCF)'","no_of_children_screened as 'Number of children screened by Mobile Health Team (MHT) under Rashtriya Bal Swasthya Karyakram (RBSK)'","no_of_newborns_received as 'Number of Newborns received complete home visits under Home Based Newborn Care (HBNC) Program'","no_of_children_received as 'Number of sick newborns received treatment in Special Newborn Care Units (SNCUs)'");
    return $qry;

}

public function get_table_kpi_data($id){
    $data_val=$this->get_total_kpi_val();
    $data_val1=$this->get_total_kpi_val1();
    $data_val2=$this->get_total_kpi_val2();

   if($id == "ndd as 'Number of children covered under National Deworming Day Coverage (NDD)'"){

        $qry="SELECT State_Name,".$id." FROM childhealthndd_master_table inner join m_state on m_state.State_ID=childhealthndd_master_table.state_id where  year='".$data_val['year']."' and e_month ='".$data_val['e_month']."' order by childhealthndd_master_table.state_id asc";
    return $this->db->query($qry)->result_array(); 
   }

    if($id == "idcf as 'Number of children covered under Intensified Diarrhoea Control Fortnight Coverage (IDCF)'"){

        $qry="SELECT State_Name,".$id." FROM childhealthidsp_master_table inner join m_state on m_state.State_ID=childhealthidsp_master_table.state_id where  year='".$data_val1['year']."'  order by childhealthidsp_master_table.state_id asc";
    return $this->db->query($qry)->result_array(); 
   }


    $qry="SELECT State_Name,".$id." FROM childhealthmht_master_table inner join m_state on m_state.State_ID=childhealthmht_master_table.state_id where  year='".$data_val2['year']."' and Quarter ='".$data_val2['Quarter']."' order by m_state.State_Name ";
    return $this->db->query($qry)->result_array();  
 
    
    
}

 public function chkDemographic($collegeID,$stateID)
    {
       
        $this->db->where('collegename',$collegeID);
        $this->db->where('statename',$stateID);
        
        $this->db->from("utilization_certificate");
        return $this->db->count_all_results();
    }

}