<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Childhealth_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   


public function get_total_kpi(){

    $qry="SELECT concat('Number of children covered under National Deworming Day Coverage (NDD): ',sum(ndd),',Number of children covered under Intensified Diarrhoea Control Fortnight Coverage (IDCF): ', sum(idcf),' ,Number of Children Screened by Mobile Health Team (MHT) under RBSK Program : ' ,sum(no_of_children_screened) ,',Number of Newborns received complete home visits under Home Based Newborn Care (HBNC) Program: 
    ',sum(no_of_children_received),',Number of sick newborns received treatment in Special Newborn Care Units (SNCUs) :',sum(no_of_newborns_received)) as total_kpi FROM `childhealth_master_table` ";
    return $this->db->query($qry)->row_array();

}

public function get_total_header(){
    $qry="SELECT sum(ndd)  as header_count,'National Deworming Day Coverage (NDD) as per round' as header_title FROM `childhealth_master_table`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_table_data(){
    $qry="SELECT ndd,idcf,no_of_children_screened,no_of_children_received,no_of_newborns_received FROM childhealth_master_table order by id desc ";
    return $this->db->query($qry)->result_array();   
}


public function get_array_kpi(){

    /*return 
    array("ndd","idcf","no_of_children_screened","no_of_children_received","no_of_newborns_received");*/

    $qry =  array("ndd","idcf","no_of_children_screened","no_of_children_received","no_of_newborns_received");
    return $qry;
}

public function get_table_kpi_data($id){
   $qry2 = array("ndd"=>"Number of children covered under National Deworming Day Coverage (NDD)", 
    "idcf"=>"Number of children covered under Intensified Diarrhoea Control Fortnight Coverage (IDCF)",   
                  "no_of_children_screened"=>"Number of Children Screened by Mobile Health Team (MHT) under RBSK Program",
                  "no_of_children_received"=>"Number of Newborns received complete home visits under Home Based Newborn Care (HBNC) Program", 
                  "no_of_newborns_received"=>"Number of sick newborns received treatment in Special Newborn Care Units (SNCUs)"); 
   
    $alias_val=$qry2[$id];
   $qry="SELECT State_Name,".$id." FROM childhealth_master_table inner join m_state on m_state.State_ID=
    childhealth_master_table.state_id  order by childhealth_master_table.state_id ";
    return $this->db->query($qry)->result_array(); 
    
}

 public function chkDemographic($collegeID,$stateID)
    {
       
        $this->db->where('collegename',$collegeID);
        $this->db->where('statename',$stateID);
        
        $this->db->from("utilization_certificate");
        return $this->db->count_all_results();
    }

}