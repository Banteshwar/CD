<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Cmha_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    


public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `tbl_cmha`  order by year desc,month desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}

public function get_total_kpi(){
    $data_val=$this->get_total_kpi_val();

    $qry="SELECT concat('Number of Patients treated in OPD : ',sum(patient_treated_opd),' ,Number of Patients treated in IPD : ', sum(patient_treated_ipd),
    ' ,Number of Professionals trained under Digital Academy : ' ,sum(medical_officers+psychologists+social_workers+nurses)) as total_kpi FROM `tbl_cmha` where year='".$data_val['year']."' and month='".$data_val['month']."'  ";
    return $this->db->query($qry)->row_array();

}

public function get_array_kpi(){

    $qry =  array("hospital_name as 'Hospital Name' , patient_treated_opd as 'Number of Patients treated in OPD'","hospital_name as 'Hospital Name',patient_treated_ipd as 'Number of Patients treated in IPD'","hospital_name as 'Hospital Name' , medical_officers as 'Medical Officers under Digital Academy', psychologists as 'Psychologists under Digital Academy', social_workers as 'Social Workers under Digital Academy', nurses as 'Nurses under Digital Academy'");
   
    return $qry;
}


public function get_table_kpi_data($id){
   
    $data_val=$this->get_total_kpi_val();
    
    $qry="SELECT State_Name, ".$id." FROM tbl_cmha inner join m_state on m_state.State_ID=
    tbl_cmha.statename where  year='".$data_val['year']."' and month ='".$data_val['month']."' GROUP by tbl_cmha.statename  ";
   
    return $this->db->query($qry)->result_array();  


    
}
   
}

