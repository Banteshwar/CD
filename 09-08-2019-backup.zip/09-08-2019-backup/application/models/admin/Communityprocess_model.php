<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Communityprocess_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `community_process` where year <= '".getCurrFinYear()."' and Quarter <= '".getCurrQuarter('Quarterly')."' order by year desc,Quarter desc LIMIT 1"; 

    $row = $this->db->query($qry)->row_array();
    
    if(empty($row)) {

      $qry="SELECT * FROM `community_process` where year < '".getCurrFinYear()."' order by year desc,Quarterly desc LIMIT 1"; 
       $row = $this->db->query($qry)->row_array();        
    }
    return $row;
}


public function  getSumFieldValue($field, $table, $where =''){    
    
     $qry="SELECT sum(". $field.") as sum_". $field.", 
          SUM(IF(". $field."='', 1,0)) as count_". $field.",
        count(*) as total_count
      FROM ".$table." " . $where; 
      
      
     $val= $this->db->query($qry)->row_array();  
     
     if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
        return 'N/E';
    }else if(empty($val['total_count'])){
        return 'N/E'; 
     }else {
        return $val["sum_".$field]; 
     }     
}

public function  getSumPercentFieldValue($table, $field1 ='',$field2 ='' ,$where){    
    
     $qry  =  "SELECT floor(sum(".$field1.")/sum(".$field2.")*100) as percentage FROM ".$table." " . $where;
     
     $val  =  $this->db->query($qry)->row_array();
     
     if($val==0){
        return 0;
     }else{
        return $val;
     }     
}

public function get_total_kpi()
{ 
     $data_val=$this->get_total_kpi_val();
    
     $table = 'community_process';
     $where = "where year='".$data_val['year']."' and Quarter='".$data_val['Quarter']."' ";
     
     $total_kpi = array(); 
      

     $value1 = $this->getSumFieldValue('Number_of_VHNSCs_formed', $table, $where);
         
     $value2 = $this->getSumFieldValue('number_of_villages', $table, $where);     
          
     if($value1=='N/E' || $value2=='N/E'){
        
         $total_kpi[]= 'Number of VHNSCs formed against number of revenue villages: N/E';

     }else{
        $total_kpi[]= 'Number of VHNSCs formed against number of revenue villages: '.$value1.'/'.$value2;

     }

     $value1 = $this->getSumFieldValue('Number_of_RKSs', $table, $where);
         
     $value2 = $this->getSumFieldValue('total_number_of_PHC_CHC_SDH_DH', $table, $where);     
          
     if($value1=='N/E' || $value2=='N/E'){
        $total_kpi[]= 'Vacancies of Rogi Kalyan Samiti(RKSs) against total number of PHCs+CHCs+SDHs+DHs: N/E';

     }else{
        $total_kpi[]= 'Vacancies of Rogi Kalyan Samiti(RKSs) against total number of PHCs+CHCs+SDHs+DHs: '.$value1.'/'.$value2;

     }

   
     $value1 = $this->getSumFieldValue('No_of_ASHAs_in_position', $table, $where);
         
     $value2 = $this->getSumFieldValue('approved', $table, $where);     
          
     if($value1=='N/E' || $value2=='N/E'){
        $total_kpi[]= 'Number of ASHAs in position against approved strength(Both in rural and urban areas): N/E';

     }else{
        $total_kpi[]= 'Number of ASHAs in position against approved strength(Both in rural and urban areas): '.$value1.'/'.$value2;

     }

     $value1 = $this->getSumFieldValue('ASha_As_whose_honorarium', $table, $where);
         
     $value2 = $this->getSumFieldValue('No_of_ASHAs_in_position', $table, $where);     
          
     $cal1 = ROUND((($value1/$value2)*100),2);
     if($value1=='N/E' || $value2=='N/E'){
        $total_kpi[]= 'Percentage of ASHAs whose Honorarium is Paid through DBT: N/E';

     }else{
        $total_kpi[]= 'Percentage of ASHAs whose Honorarium is Paid through DBT: '.$cal1;

     }

     $value1 = $this->getSumFieldValue('number_of_MAS_created', $table, $where);
         
     $value2 = $this->getSumFieldValue('number_of_MAS_approved', $table, $where);     
          
     $cal2 = ROUND((($value1/$value2)*100),2);

     if($value1=='N/E' || $value2=='N/E'){
        $total_kpi[]= 'Percentage of MAS created against approved: N/E';

     }else{
        $total_kpi[]= 'Percentage of MAS created against approved: '.$cal2;

     }

     
     
     $data['total_kpi'] = implode(',',$total_kpi);
        
     return str_replace('N/E/N/E','N/E',$data);
}

public function get_array_kpi(){

    $qry =  array("Number_of_VHNSCs_formed as 'Number of VHNSC formed',number_of_villages as 'Number of Villages'","Number_of_RKSs as 'Number of RKS',total_number_of_PHC_CHC_SDH_DH as 'total number of PHC+CHC+SDH+DH'","No_of_ASHAs_in_position as 'No. of ASHA in position',approved as 'approved'","ASha_As_whose_honorarium as 'Number of ASHA Honorarium who Paid through DBT ',No_of_ASHAs_in_position as 'Number of ASHA Position'","number_of_MAS_created as 'Number of MAS created',number_of_MAS_approved as 'Number of MAS Approved'");   
    return $qry;
}

public function get_table_kpi_data($id){ 

    $data_val=$this->get_total_kpi_val();
     
    $idWithoutAs = substr($id, 0, stripos($id, "as "));
    
    $qry="SELECT State_Name,".$id." FROM community_process inner join m_state on m_state.State_ID=
    community_process.state_id  where year='".$data_val['year']."' and Quarter='".$data_val['Quarter']."' AND ".$idWithoutAs." !='' AND ".$idWithoutAs." !='0' order by m_state.State_Name ";
    
    return $this->db->query($qry)->result_array();     
}

}