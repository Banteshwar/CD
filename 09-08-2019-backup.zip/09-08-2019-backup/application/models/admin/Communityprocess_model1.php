<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Communityprocess_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    

public function get_total_kpi(){

 $qry="SELECT
   CONCAT(
        'Number of Villages : ',
        SUM(number_of_villages),
        ' ,Number of VHNSCs Formed : ',
        SUM(Number_of_VHNSCs_formed),
        ' ,Number of Rogi Kalyan Samiti : ',
        SUM(Number_of_RKSs),
        ', Number of PHC+CHC+SDH+DH : ',
        SUM(total_number_of_PHC_CHC_SDH_DH),
        ', Number of ASHAs in Position : ',
        SUM(No_of_ASHAs_in_position),
        ', Approved Strength (both Rural Andurban Areas): ',
        SUM(approved), ', Percentage of ASHAs who Honorarium is Paid through DBT : ',
        SUM(ASha_As_whose_honorarium)/count(id)
    ) AS total_kpi
FROM community_process";
        return $this->db->query($qry)->row_array();

}

public function get_total_header(){
    $qry="SELECT sum(number_of_villages)  as header_count,'  Number of Villages' as header_title FROM `community_process`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_array_kpi(){

    $qry =  array("number_of_villages","Number_of_VHNSCs_formed","Number_of_RKSs","total_number_of_PHC_CHC_SDH_DH","No_of_ASHAs_in_position","approved","ASha_As_whose_honorarium");   
    return $qry;
}

public function get_table_kpi_data($id){   
        
     /*   $qry="SELECT year,State_Name,".$id." AS ".$id." FROM community_process inner join m_state on m_state.State_ID=
        community_process.state_id group by community_process.year";   
    return $this->db->query($qry)->result_array();   */

    $qry2 = array("number_of_villages"=>"Number of Villages","Number_of_VHNSCs_formed"=>"Number of VHNSCs Formed","Number_of_RKSs"=>"Number of Rogi Kalyan Samiti","total_number_of_PHC_CHC_SDH_DH"=>"Number of PHC+CHC+SDH+DH","No_of_ASHAs_in_position"=>"Number of ASHAs in Position","approved"=>"Approved Strength (both Rural Andurban Areas)","ASha_As_whose_honorarium"=>"Percentage of ASHAs who Honorarium is Paid through DBT"); 
   
    $alias_val = $qry2[$id];
    
    $qry="SELECT State_Name,year,sum(".$id.") AS '".$alias_val."' FROM community_process inner join m_state on m_state.State_ID=
        community_process.state_id group by community_process.year,community_process.state_id";
        return $this->db->query($qry)->result_array();   
   
}

 
    
   
}

