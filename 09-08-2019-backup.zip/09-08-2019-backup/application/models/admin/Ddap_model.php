<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Ddap_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    


public function get_total_kpi(){

    $qry="SELECT concat('No. of persons who availed Drug Deaddiction OPD services from Deaddiction Treatment Clinics
 : ',sum(deaddiction_treatment),' ,No. of persons who availed inpatient treatment services from Drug Dependence Treatment Centers
 : ', sum(dependence_treatment)) as total_kpi FROM `tbl_ddap`  ";
    return $this->db->query($qry)->row_array();

}

public function get_total_header(){
    $qry="SELECT sum(deaddiction_treatment)  as header_count,'No of persons who availed Drug Deaddiction OPD services from Deaddiction Treatment Clinics' as header_title FROM `tbl_ddap`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_array_kpi(){

    $qry =  array("deaddiction_treatment","dependence_treatment");
   
    return $qry;
}

public function get_table_kpi_data($id){
	
	$qry2 = array("deaddiction_treatment"=>"No. of persons who availed Drug Deaddiction OPD services from Deaddiction Treatment Clinics", "dependence_treatment"=>"No. of persons who availed inpatient treatment services from Drug Dependence Treatment Centers"); 
   
    $alias_val=$qry2[$id];
	
	
    $qry="SELECT State_Name,sum(".$id.") as '".$alias_val."' FROM tbl_center inner join m_state on m_state.State_ID=
        tbl_center.statename inner join tbl_ddap on tbl_center.name = tbl_ddap.center_name order by tbl_center.statename ";
    
    
   
    return $this->db->query($qry)->result_array();   
}

 
    
   
}

