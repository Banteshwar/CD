<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Dialysis_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
public function  getSumFieldValue($field, $table, $where =''){
  
   $qry="SELECT sum(". $field.") as sum_". $field.", 
      SUM(IF(". $field."='', 1,0)) as count_". $field.",
      count(*) as total_count
    FROM ".$table." " . $where; 
    
    
   $val= $this->db->query($qry)->row_array();  
   
   if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
    return 'N/E';
   }
   else if(empty($val['total_count']))
   {
    return 'N/E'; 
   }
   else {
    return $val["sum_".$field]; 
   }
   
}
  

public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `hidialysis_master_tbl`  order by year desc,Quarterly desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}

public function get_total_kpi(){
    $data_val=$this->get_total_kpi_val();
 
    $table = 'hidialysis_master_tbl';
   $where = "where year='".$data_val['year']."' and Quarterly='".$data_val['Quarterly']."' ";
   
    $total_kpi = array(); 
    
    $value1 = $this->getSumFieldValue('No_of_districts_with_functional_dialysis_units', $table, $where);
    
    $value2 = $this->getSumFieldValue('units_against_the_total_districts', $table, $where);

    $total_kpi[]= 'No. of districts with functional dialysis units against the total districts : '.$value1.'/'.$value2;


    $value = $this->getSumFieldValue('No_of_patients_receiving_treatment', $table, $where);   
    $total_kpi[] = 'No of patients receiving treatment sessions held under PMNDP: '.$value ; 
  
    $data['total_kpi'] = implode(',',$total_kpi);
   
     return str_replace('N/E/N/E','N/E',$data);
}


public function get_array_kpi(){
    $qry =  array("No_of_districts_with_functional_dialysis_units as 'No. of districts with functional dialysis',units_against_the_total_districts as 'Total districts with over 2 lakh population'","No_of_patients_receiving_treatment as 'No. of patients receiving treatment sessions held under PMNDP'");
    return $qry;
}


/*public function get_table_kpi_data($id){ 

  $data_val=$this->get_total_kpi_val();
 $qry="SELECT State_Name,".$id." FROM hidialysis_master_tbl inner join m_state on m_state.State_ID=
    hidialysis_master_tbl.state_id  where year='".$data_val['year']."' and Quarterly='".$data_val['Quarterly']."'  order by m_state.State_Name "; 
    return $this->db->query($qry)->result_array(); 
}*/

public function get_table_kpi_data($id){ 

    $data_val=$this->get_total_kpi_val();
     
    $idWithoutAs = substr($id, 0, stripos($id, "as "));
 
    $qry="SELECT State_Name,".$id." FROM hidialysis_master_tbl inner join m_state on m_state.State_ID=
    hidialysis_master_tbl.state_id  where year='".$data_val['year']."' and Quarterly='".$data_val['Quarterly']."' AND ".$idWithoutAs." !='' AND ".$idWithoutAs." !='0' order by m_state.State_Name "; 
    return $this->db->query($qry)->result_array(); 
}

 
    
   
}

