<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Dialysis_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   



/*public function get_total_kpi(){

    $qry="SELECT concat('No of districts with functional dialysis units : ',sum(No_of_districts_with_functional_dialysis_units),' ,Total districts with over 2 lakh population (State Wise) : ', sum(units_against_the_total_districts),' ,No of patients receiving treatment sessions held under PMNDP : ' , sum(No_of_patients_receiving_treatment)) as total_kpi FROM `hidialysis_master_tbl`  ";
    return $this->db->query($qry)->row_array();

}*/



public function get_total_kpi(){




   // $qry="SELECT concat('No of districts with functional dialysis units/Total districts  : ',sum(No_of_districts_with_functional_dialysis_units) /  sum(units_against_the_total_districts),',No of patients receiving treatment sessions held under PMNDP : ' , sum(No_of_patients_receiving_treatment)) as total_kpi FROM `hidialysis_master_tbl`  ";
   
   $qry="SELECT concat('No. of districts with functional dialysis units against the total districts : ',sum(No_of_districts_with_functional_dialysis_units), ' / ',sum(units_against_the_total_districts),',No. of patients receiving treatment sessions held under PMNDP : ' , sum(No_of_patients_receiving_treatment)) as total_kpi FROM `hidialysis_master_tbl`  ";
   
  return $this->db->query($qry)->row_array();
	
	//echo $this->db->last_query(); die;



}

public function get_total_header(){
    $qry="SELECT sum(No_of_districts_with_functional_dialysis_units)  as header_count,'No. of districts with functional dialysis units against the total districts' as header_title FROM `hidialysis_master_tbl`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_table_data(){
    
    $qry="SELECT SUM(No_of_districts_with_functional_dialysis_units),SUM(units_against_the_total_districts),SUM(No_of_patients_receiving_treatment) FROM hidialysis_master_tbl  ";
    return $this->db->query($qry)->result_array();   
}




/*public function get_array_kpi(){

    $qry =  array("No_of_districts_with_functional_dialysis_units","units_against_the_total_districts","No_of_patients_receiving_treatment");
   
    return $qry;
}

public function get_table_kpi_data($id){
   
    
    $qry="SELECT year, SUM(".$id.") AS ".$id." FROM hidialysis_master_tbl group by hidialysis_master_tbl.year ";
   
    return $this->db->query($qry)->result_array();   
}*/




public function get_array_kpi(){

    $qry =  array("No_of_districts_with_functional_dialysis_units,units_against_the_total_districts",
      "No_of_patients_receiving_treatment");
   
    return $qry;
}

public function get_table_kpi_data($id){
   
   $lst = explode(",", $id);


   if(count($lst) > 1)
   {
    $id1 = $lst[0];
    $id2 = $lst[1];
   // $id3 = $id1.'/'.$id2;
    
    $qry="SELECT State_Name,year, concat(SUM(".$id1."),'/',SUM(".$id2.")) AS 'No. of districts with functional dialysis units against the Total Districts' FROM hidialysis_master_tbl inner join m_state ON m_state.State_ID=hidialysis_master_tbl.State_ID
    group by hidialysis_master_tbl.year,hidialysis_master_tbl.State_ID ";
   
   }
    else{
    $qry="SELECT State_Name,year, SUM(".$id.") AS ".$lst[0]." FROM hidialysis_master_tbl inner join m_state ON m_state.State_ID=hidialysis_master_tbl.State_ID group by hidialysis_master_tbl.year,hidialysis_master_tbl.State_ID ";
   }
    return $this->db->query($qry)->result_array();
    
}

 
    
   
}

