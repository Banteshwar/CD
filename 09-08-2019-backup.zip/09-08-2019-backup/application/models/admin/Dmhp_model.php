<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Dmhp_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    


public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `tbl_dmhp`  order by e_year desc,e_quarter desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}

public function get_total_kpi(){
    $data_val=$this->get_total_kpi_val();

    $qry="SELECT concat('Number of Districts Covered under DMHP up to the year ".$data_val['e_year']." : ',sum(num_district_cover),' ,Funds sanctioned under ROP for the year ".$data_val['e_year']." : ', sum(fund),
    ' ,Expenditure incurred up to ".$data_val['e_quarter']." quarter of ".$data_val['e_year']." : ' ,sum(expenditure)) as total_kpi FROM `tbl_dmhp` where e_year='".$data_val['e_year']."' and e_quarter='".$data_val['e_quarter']."'  ";
    return $this->db->query($qry)->row_array();

}

public function get_array_kpi(){
    $data_val=$this->get_total_kpi_val();

    $qry =  array("num_district_cover as 'Number of Districts Covered under DMHP up to the year ".$data_val['e_year']."' " , "fund as 'Funds sanctioned under ROP for the year ".$data_val['e_year']."'","expenditure as 'Expenditure incurred up to ".$data_val['e_quarter']." quarter of ".$data_val['e_year']."' ");
   
    return $qry;
}


public function get_table_kpi_data($id){
   
    $data_val=$this->get_total_kpi_val();
    
    $qry="SELECT State_Name, ".$id." FROM tbl_dmhp inner join m_state on m_state.State_ID=
    tbl_dmhp.statename where  e_year='".$data_val['e_year']."' and e_quarter ='".$data_val['e_quarter']."' GROUP by tbl_dmhp.statename  ";
   
    return $this->db->query($qry)->result_array();  


    
}
   
}

