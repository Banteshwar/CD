<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Drugsdiagnostics_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   


public function get_Healthdata(){ 
    $this->db->select('nohp_master_table.*');
    $this->db->from('nohp_master_table');
	// $this->db->join('m_state','m_state.State_ID=nohp_master_table.state_id','inner');
    
 
   $this->db->order_by("nohp_master_table.id", "desc");


        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
}

  public function get_totalRecordfdsi(){ 
    $this->db->select('SUM( Number_of_States ) as st ,  updated_by   ');
    $this->db->from('free_diagnosticssi_master_tbl');
    
    $this->db->order_by("free_diagnosticssi_master_tbl.id", "desc");

    $query = $this->db->get();

    return $query->row_array();  
}


  public function get_totaldrugdata(){ 
    $this->db->select('SUM(	Total_number_of_pharmacies) as pharmatotal ,SUM(	Number_of_patients_served	) as drugtotal,SUM(	Value_of_drugs_dispensed	) as pateintstotal,SUM(	Savings_to_the_patients	) as savetotal');
    $this->db->from('amrit_master_tbl');
    
    

    $query = $this->db->get();

    return $query->row_array();  
}

 public function getDiagnosticServiecs(){ 
    $this->db->select('SUM(Number_of_States) as stateTotal ,SUM(Free_Laboratory_services) as freeLab,SUM( Radiology_services    ) as radio,SUM( services_in_DHs ) as dhs, year');
    $this->db->from('free_diagnosticssi_master_tbl');
    
    

    $query = $this->db->get();

    return $query->row_array();  
}

public function getDiagnosticServiecsTotal(){ 
    $this->db->select('*');
    $this->db->from('free_diagnosticssi_master_tbl');
    $query = $this->db->get();

    return $query->result_array();  
}

/*---------------Start drugs & Services------------------------*/

 public function get_drug(){
        global $db;
        $sql     =  "select sum(rank) as rank,sum(active_user) as active from freedrugservice_master_table";
        
        $stmt = $db->query($sql); 
        return $stmt->fetchAll(); 
    }

    public function get_table_data(){
    $qry="SELECT id,statename,rank,active_user FROM freedrugservice_master_table";
    return $this->db->query($qry)->result_array();   
    }
   
 public function get_total_kpi(){

    $qry="SELECT concat('Total States Rank : ',sum(rank),' ,Total Active User : ', sum(active_user)) as active FROM `freedrugservice_master_table`  ";
    return $this->db->query($qry)->row_array();

}

    public function get_map_data(){

    $qry="SELECT concat('Rank : ',rank,',State Name : ',statename ,',Active User : ',active_user) AS hover FROM `freedrugservice_master_table`";
    return $this->db->query($qry)->result_array();

}

public function get_total_header(){
    $qry="SELECT sum(rank) as header_count,'Active User' as header_title FROM `freedrugservice_master_table`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_table_header($table){
    $qry="describe $table  ";
    return $this->db->query($qry)->result_array();   
}

/*---------------End Drugs & Services--------------------------*/
    
   
}

