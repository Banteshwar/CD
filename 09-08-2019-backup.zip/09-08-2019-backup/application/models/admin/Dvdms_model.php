<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Dvdms_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    


public function get_total_kpi(){

    //$qry="SELECT concat('Hightest Average  : ',avg_score,' ,Lower : ', avg_score,' ,Active PHC User : ', phc_active_user) as total_kpi FROM `dvdms_master_table`, dvdms_master_table_active ";

$qry="SELECT concat('Hightest Average/Lowest : ',max(avg_score), ' / ',min(avg_score),' ,Active PHC User : ', phc_active_user) as total_kpi FROM `dvdms_master_table`, dvdms_master_table_active  ";

    return $this->db->query($qry)->row_array();

}


/* $qry="SELECT concat('New AIIMS Announced  : ',new_aiims,' ,New AIIMS approved by Cabinet : ', count(tbl_pmssy_form_b.id),' ,Remaining AIIMS  : ' , new_aiims - count(tbl_pmssy_form_b.id)  ,', PMC appointed  : ',pmc,', Turnkey  Tender awarded  : ',turnkey) as total_kpi FROM `pmssyiims`,tbl_pmssy_form_b  "; */

public function get_total_header(){
    $qry="SELECT sum(No_of_functional_blood_banks)  as header_count,'Total Blood Banks' as header_title FROM `hibloodbank_master_tbl`  ";
    return $this->db->query($qry)->row_array();   
}


public function get_array_kpi(){

    $qry =  array("No_of_functional_blood_banks,dh_morethanhundred_beds","No_of_functional_bloodbanks_bsu,dh_morethanhundred_beds");
   
    return $qry;
}

public function get_table_kpi_data($id){
   
    
    /*$qry="SELECT State_Name, year, SUM(".$id.") AS ".$id." FROM hibloodbank_master_tbl inner join m_state on m_state.State_ID=
    hibloodbank_master_tbl.state_id  group by hibloodbank_master_tbl.year ";*/

 


        $qry="SELECT State_Name, concat(SUM(new_aiims)) AS '".$alias_val."' FROM pmssyiims  inner join m_state on m_state.State_ID=
    pmssyiims.statename";


   
   
    return $this->db->query($qry)->result_array();   
}
  
}

