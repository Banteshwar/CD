<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Emr_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
public function getFru(){ 
    $this->db->select('*');
    $this->db->from('fru_master_table');
    $query = $this->db->get();

	if ($query->num_rows() > 0) {
		foreach ($query->result() as $row) {
			$data[] = $row;
		}
		return $data;
	}
	return false;
}
/*

public function skillNumerbs(){
	
	 $qry="SELECT sum(no_of_skillcentre) as cnt  FROM `emr_nels_skillcentre_master_table`  ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['cnt'];   
	
	
}


public function skilllisting(){
	$data_val = $this->get_total_kpi_val5();
	 $qry="SELECT State_name,no_of_skillcentre, medical_college_name, amount_released  FROM `emr_nels_skillcentre_master_table` inner join `m_state` on m_state.State_ID=emr_nels_skillcentre_master_table.state_id where year='".$data_val['year']."'";	
	 return $this->db->query($qry)->result_array();
	
}



public function PersonnelNumbers(){
	
	 $qry="SELECT sum(doctors+nurses+paramedics) as sum_amount_due  FROM `emr_nels_personneltrained_master_table`  ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount_due']; 
}

public function MedicalPersonNumbers(){
	
	$qry="SELECT sum(doctorstrained_in_phe+doctorstrained_in_he) as sum_amount_due  FROM `emr_dhm_personneltrained_master_table`   ";	
	$row = $this->db->query($qry)->row_array();
    return $row['sum_amount_due']; 
}

public function MedicalPersonListing(){
	$data_val=$this->get_total_kpi_val3();
	$qry="SELECT State_name,doctorstrained_in_phe, doctorstrained_in_he FROM `emr_dhm_personneltrained_master_table` inner join `m_state` on m_state.State_ID=emr_dhm_personneltrained_master_table.state_id where year='".$data_val['year']."'";	
	return $this->db->query($qry)->result_array();
}

public function CbrnMedicalCentre(){
	
	 $qry="SELECT count(*) as sum_amount_due  FROM `emr_dhm_cbrn_master_table`   ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount_due']; 
}



public function CbrnListing(){
	$data_val=$this->get_total_kpi_val1();
	$qry="SELECT State_name,centre_name, (case 
when (status = 1) 
 THEN
      'Planned'
when (status = 2)
THEN
      'Under Construction'
when (status = 3)
THEN
      'Functional'	  
 ELSE
      '--' 
 END)
 as status FROM `emr_dhm_cbrn_master_table` inner join `m_state` on m_state.State_ID= emr_dhm_cbrn_master_table.state_id where year='".$data_val['year']."'";	
	return $this->db->query($qry)->result_array();
}


public function HeocListing(){
	$data_val=$this->get_total_kpi_val2();
	$qry="SELECT State_name,location, (case 
when (status = 1) 
 THEN
      'Planned'
when (status = 2)
THEN
      'Under Construction'
when (status = 3)
THEN
      'Functional'	  
 ELSE
      '--' 
 END)
 as status FROM `emr_dhm_heoc_master_table` inner join `m_state` on m_state.State_ID=emr_dhm_heoc_master_table.state_id  where year='".$data_val['year']."' ";	
	return $this->db->query($qry)->result_array();
}



public function HeocCentre(){
	
	 $qry="SELECT count(*) as sum_amount_due  FROM `emr_dhm_heoc_master_table` ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount_due']; 
}


public function TrainerListing(){
	$data_val=$this->get_total_kpi_val4();
	$qry="SELECT State_name,doctors, nurses, paramedics FROM `emr_nels_personneltrained_master_table` inner join `m_state` on m_state.State_ID=emr_nels_personneltrained_master_table.state_id where year='".$data_val['year']."'";	
	return $this->db->query($qry)->result_array();
}*/


/*public function get_total_kpi(){
	//$data_val=$this->get_total_kpi_val();
	 $row  = array();
     $row['total_kpi'] = 'No. of Skill Centre : '.$this->skillNumerbs().' , No. Of Personnel Trained: '.$this->PersonnelNumbers().' , No. Of Medical Persons Trained: '.$this->MedicalPersonNumbers().' , No. Of CBRN Medical Centres: '.$this->CbrnMedicalCentre().' , No. Of Health Emergency Operation Centre: '.$this->HeocCentre();	 
	 return $row;
 
}*/


public function get_total_kpi(){
    $data_val1=$this->get_total_kpi_val1();
    $data_val2=$this->get_total_kpi_val2();
    $data_val3=$this->get_total_kpi_val3();
    $data_val4=$this->get_total_kpi_val4();
    $data_val5=$this->get_total_kpi_val5();
    
    
    
    $qry="SELECT concat('No. of Skill Centres on National Emergency Life Support : ',(SELECT sum(medical_college_name) FROM emr_nels_skillcentre_master_table where year='".$data_val5['year']."'),',Number of personnel trained in  Emergency Life Support  : ',(SELECT sum(doctors+nurses+paramedics) FROM emr_nels_personneltrained_master_table where year='".$data_val4['year']."'),',Number of Medical Personnel trained : ' , (SELECT sum(doctorstrained_in_phe+doctorstrained_in_he) FROM emr_dhm_personneltrained_master_table where year='".$data_val3['year']."'),',Number of CBRN Medical Management Centres : ' ,(SELECT  count(centre_name) FROM emr_dhm_cbrn_master_table where year='".$data_val1['year']."'),',Number of Health Emergency Operation Centres  : ' , (SELECT count(location) FROM emr_dhm_heoc_master_table where year='".$data_val2['year']."')) as total_kpi  ";
    return $this->db->query($qry)->row_array();

}


public function get_array_kpi(){

	$qry =  array("sum(medical_college_name) as 'Number of Skill Centre', sum(amount_released) as 'Grant Released in Rupees (INR)'",
    "doctors as 'No. of Doctors Trained',nurses as 'No. of Nurses Trained',paramedics as 'No. of Paramedics Trained'",

    "doctorstrained_in_phe as 'Doctors trained in Public Health Emergencies',doctorstrained_in_he as 'Doctors trained in Hospital Emergencies'","count(centre_name) as 'Number of Centers'","count(location) as 'Number of Location'");
   
    return $qry;
}

  public function get_table_kpi_data($id){
   
 
    $data_val5=$this->get_total_kpi_val5();
    $data_val1=$this->get_total_kpi_val1();
    $data_val2=$this->get_total_kpi_val2();
    $data_val3=$this->get_total_kpi_val3();
    $data_val4=$this->get_total_kpi_val4();
    
    
    if($id == "sum(medical_college_name) as 'Number of Skill Centre', sum(amount_released) as 'Grant Released in Rupees (INR)'"){

        $qry="SELECT State_Name, ".$id." FROM emr_nels_skillcentre_master_table inner join m_state on m_state.State_ID=
    emr_nels_skillcentre_master_table.state_id where  year='".$data_val5['year']."' GROUP by emr_nels_skillcentre_master_table.state_id order by m_state.State_Name ASC ";
            return $this->db->query($qry)->result_array();  
    }

   if($id == "doctors as 'No. of Doctors Trained',nurses as 'No. of Nurses Trained',paramedics as 'No. of Paramedics Trained'"){

        $qry="SELECT State_Name, ".$id." FROM emr_nels_personneltrained_master_table inner join m_state on m_state.State_ID=
    emr_nels_personneltrained_master_table.state_id where  year='".$data_val4['year']."' GROUP by emr_nels_personneltrained_master_table.state_id  ";
            return $this->db->query($qry)->result_array();  
    }

    if($id == "doctorstrained_in_phe as 'Doctors trained in Public Health Emergencies',doctorstrained_in_he as 'Doctors trained in Hospital Emergencies'"){

        $qry="SELECT State_Name, ".$id." FROM emr_dhm_personneltrained_master_table inner join m_state on m_state.State_ID=
    emr_dhm_personneltrained_master_table.state_id where  year='".$data_val3['year']."' GROUP by emr_dhm_personneltrained_master_table.state_id  ";
            return $this->db->query($qry)->result_array();  
    }

    if($id == "count(centre_name) as 'Number of Centers'"){

        $qry="SELECT State_Name, ".$id." FROM emr_dhm_cbrn_master_table inner join m_state on m_state.State_ID=
    emr_dhm_cbrn_master_table.state_id where  year='".$data_val1['year']."' GROUP by emr_dhm_cbrn_master_table.state_id  ";
            return $this->db->query($qry)->result_array();  
    }

    if($id == "count(location) as 'Number of Location'"){

        $qry="SELECT State_Name, ".$id." FROM emr_dhm_heoc_master_table inner join m_state on m_state.State_ID=
          emr_dhm_heoc_master_table.state_id where  year='".$data_val2['year']."' GROUP by emr_dhm_heoc_master_table.state_id  ";
            return $this->db->query($qry)->result_array();  
    }
}


public function get_total_kpi_val1(){
    
    $qry="SELECT * FROM `emr_dhm_cbrn_master_table` order by year desc LIMIT 1";
    return $this->db->query($qry)->row_array();
} 

public function get_total_kpi_val2(){
    
    $qry="SELECT * FROM `emr_dhm_heoc_master_table` order by year desc LIMIT 1";
    return $this->db->query($qry)->row_array();
} 

public function get_total_kpi_val3(){
    
    $qry="SELECT * FROM `emr_dhm_personneltrained_master_table` order by year desc LIMIT 1";
    return $this->db->query($qry)->row_array();
} 

public function get_total_kpi_val4(){
    
    $qry="SELECT * FROM `emr_nels_personneltrained_master_table` order by year desc LIMIT 1";
    return $this->db->query($qry)->row_array();
} 

public function get_total_kpi_val5(){
    
    $qry="SELECT * FROM `emr_nels_skillcentre_master_table` order by year desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}  

}