<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Emr_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
/*public function get_map_data(){

    $qry="SELECT concat('Financial Year : ',Completeness_of_Syndromic, 'Month : ',Completeness_of_Presumptive,', Number of Cataract Surgery Performed : ',Completeness_of_Lab_Confirmed,',Number of Free Spectacles distributed to Elderly Population  : ',human_samples_in_disease_outbreaks) AS hover FROM `tbl_npcb_hsd` order by id";
    return $this->db->query($qry)->result_array();

}*/

public function get_totalRecordEMR(){ 
    $this->db->select('SUM( no_of_skillcentre ) as no_skillcentre_emr,SUM( amount_released ) as amt_released_emr');
    $this->db->from('emr_nels_skillcentre_master_table');
    //$this->db->order_by("tbl_npcb_hsd.id", "desc");

    $query = $this->db->get();

    return $query->row_array();  
}

public function get_total_header(){
    $qry="SELECT sum(cataract_surgery)  as header_count,'Cataract Sursgery' as header_title FROM `tbl_npcb_hsd`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_total_kpi(){

    $qry="SELECT concat('Completeness of ‘Syndromic (S)’ form reporting <br/> (to be monitored quarterly) : ',sum(Completeness_of_Syndromic),',Completeness of ‘Presumptive (P)’ form reporting <br/> (to be monitored quarterly): ',sum(Completeness_of_Presumptive),',Completeness of ‘Lab Confirmed (L)’ form reporting (to be monitored quarterly): ',sum(Completeness_of_Lab_Confirmed),',Quarterly Laboratory Access For Human Samples In Disease Outbreaks: ',sum(Completeness_of_Lab_Confirmed)) as total_kpi FROM `idsp_master_tbl`  ";
    return $this->db->query($qry)->row_array();

}


public function get_table_data(){
    $subqry="(SELECT State_Name FROM 'm_state' where m_state.State_ID =state_id  limit 1) as state_name";
    
    $qry="SELECT State_Name as 'State Name', date as 'Date',  Completeness_of_Syndromic as 'Completeness of Syndromic (S) form reporting (to be monitored quarterly)',  Completeness_of_Presumptive  as 'Completeness of Presumptive (P) form reporting (to be monitored quarterly)',
     Completeness_of_Lab_Confirmed as 'Completeness of Lab Confirmed (L) form reporting (to be monitored quarterly)',human_samples_in_disease_outbreaks as 'Quarterly laboratory access for human samples in disease outbreaks' FROM idsp_master_tbl inner join m_state on
     m_state.State_ID=idsp_master_tbl.state_id  
    order by idsp_master_tbl.id ";
    return $this->db->query($qry)->result_array();   
}

public function get_table_header($table){
    $qry="describe $table  ";
    return $this->db->query($qry)->result_array();   
}


}

