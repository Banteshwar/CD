<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Family_planning_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `familyplanning_master_table` where e_year <= '".getCurrFinYear()."' and e_quarter <= '".getCurrQuarter('Quarterly')."' order by e_year desc,e_quarter desc LIMIT 1"; 

    $row = $this->db->query($qry)->row_array();
    
    if(empty($row)) {

      $qry="SELECT * FROM `familyplanning_master_table` where e_year < '".getCurrFinYear()."' order by e_year desc,e_quarter desc LIMIT 1"; 
       $row = $this->db->query($qry)->row_array();        
    }
    return $row;
}

public function  getSumFieldValue($field, $table, $where =''){    
    
     $qry="SELECT sum(". $field.") as sum_". $field.", 
          SUM(IF(". $field."='', 1,0)) as count_". $field.",
        count(*) as total_count
      FROM ".$table." " . $where; 
      
      
     $val= $this->db->query($qry)->row_array();  
     
     if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
        return 'N/E';
     }
     else if(empty($val['total_count']))
	 {
		return 'N/E'; 
	 }
     else {
        return $val["sum_".$field]; 
     }     
} 


public function  getSumPercentFieldValue($table, $field1 ='',$field2 ='' ,$where){    
    
     $qry  =  "SELECT floor(sum(".$field1.")/sum(".$field2.")*100) as percentage FROM ".$table." " . $where;
     
     $val  =  $this->db->query($qry)->row_array();
     
     if($val==0){
        return 0;
     }else{
        return $val;
     }     
}



public function get_total_kpi()
{ 
     $data_val=$this->get_total_kpi_val();
    
     $table = 'familyplanning_master_table';
     $where = "where e_year='".$data_val['e_year']."' and e_quarter='".$data_val['e_quarter']."' ";
     
     $total_kpi = array(); 
      



     $value1 = $this->getSumFieldValue('ppiucd_insertion_no', $table, $where);
         
     $value2 = $this->getSumFieldValue('total_institution_delivery', $table, $where);     
          
     $cal1 = ROUND((($value1/$value2)*100),2);
	 
     if($value1=='N/E' || $value2=='N/E'){
        $total_kpi[]= 'Post Partum Intrauterine Copper Device (PPIUCD) Acceptance rate(%) - Public: N/E';

     }else{
        $total_kpi[]= 'Post Partum Intrauterine Copper Device (PPIUCD) Acceptance rate(%) - Public: '.$cal1;

     }

     $value1 = $this->getSumFieldValue('injectable_doses', $table, $where);
    
    

     if($value1=='N/E'){
        $total_kpi[]= 'Number of Injectable doses given: N/E';

     }else{
        $total_kpi[]= 'Number of Injectable doses given: '.$value1;

     }

     
     
     $data['total_kpi'] = implode(',',$total_kpi);
        
     return $data;
}




public function get_array_kpi(){

    return array("ppiucd_insertion_no as 'Number of PPIUCD insertions - Public' , total_institution_delivery as 'Total institutional deliveries - Public', acceptance_rate as 'Post Partum Intrauterine Copper Device (PPIUCD) Acceptance rate(%) - Public'","injectable_doses as 'Number of Injectable doses given'");
}

public function get_table_kpi_data($id){

    $data_val=$this->get_total_kpi_val();
	
    $idWithoutAs = substr($id, 0, stripos($id, "as "));
    
    $qry="SELECT State_Name,".$id." FROM familyplanning_master_table inner join m_state on m_state.State_ID=
    familyplanning_master_table.state_id  where e_year='".$data_val['e_year']."' and e_quarter='".$data_val['e_quarter']."' AND ".$idWithoutAs." !='' AND ".$idWithoutAs." !='0' order by m_state.State_Name ";
    
    return $this->db->query($qry)->result_array();     
    
} 



}