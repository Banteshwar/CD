<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Family_planning_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   


public function get_total_kpi(){

    $qry="SELECT concat('Number of PPIUCD insertions : ',sum(ppiucd_insertion_no),' ,Total institutional deliveries : ', sum(total_institution_delivery),' ,PPIUCD acceptance rate : ' ,sum(acceptance_rate) ,', Number of Injectable doses given : ',sum(injectable_doses)) as total_kpi FROM `familyplanning_master_table` ";
    return $this->db->query($qry)->row_array();

}

public function get_total_header(){
    $qry="SELECT sum(ppiucd_insertion_no)  as header_count,'Number of PPIUCD insertions' as header_title FROM `familyplanning_master_table`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_table_data(){
    $qry="SELECT ppiucd_insertion_no,total_institution_delivery,acceptance_rate,injectable_doses FROM familyplanning_master_table order by id desc ";
    return $this->db->query($qry)->result_array();   
}


public function get_array_kpi(){

    return array("ppiucd_insertion_no","total_institution_delivery","acceptance_rate","injectable_doses");
}

public function get_table_kpi_data($id){
	
	
    $arr2=  array("ppiucd_insertion_no"=>"Number of PPIUCD insertions", "total_institution_delivery"=>"Total institutional deliveries",   
                  "acceptance_rate"=>"PPIUCD acceptance rate", "injectable_doses"=>"Number of Injectable doses given");
    
    $qry="SELECT  Year(entry_date) as 'Year',SUM(".$id.") AS '".$arr2[$id]."' FROM familyplanning_master_table group by Year";
    return $this->db->query($qry)->result_array(); 
    
}

}