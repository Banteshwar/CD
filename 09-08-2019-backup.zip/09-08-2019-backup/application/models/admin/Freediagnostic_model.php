<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Freediagnostic_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }    

public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `free_diagnosticssi_master_tbl` where year <= '".getCurrFinYear()."' and Quarterly <= '".getCurrQuarter()."' order by year desc,Quarterly desc LIMIT 1"; 

    $row = $this->db->query($qry)->row_array();
    
    if(empty($row)) {

      $qry="SELECT * FROM `free_diagnosticssi_master_tbl` where year < '".getCurrFinYear()."' order by year desc,Quarterly desc LIMIT 1"; 

       $row = $this->db->query($qry)->row_array();        
    }

    return $row;
}

/*public function  getSumFieldValue($field, $table, $where =''){    
    
     $qry="SELECT count(". $field.") as sum_". $field.", 
          COUNT(IF(". $field."='' , 1,0)) as count_". $field.",
        count(*) as total_count
      FROM ".$table." " . $where; 
      
      
     $val= $this->db->query($qry)->row_array();  
     
     if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
        return 'N/E';
     
     }else if(empty($val['total_count'])){
        return 'N/E'; 
     }else {
        return $val["sum_".$field]; 
     }     
}*/

public function  getSumFieldValue2($field, $table, $where =''){  
    
    $qry="SELECT SUM(IF(".$field."  = 'Yes', 1,0)) AS `total_count` FROM ".$table." " . $where;

     $val= $this->db->query($qry)->row_array();  
     
    
    if($val['total_count'] == 0) {
        return 0;
    }else if(empty($val['total_count'])){
        return 'N/E'; 
    }else {
        return $val['total_count']; 
    }

     
}

public function get_total_kpi()
{ 
     $data_val=$this->get_total_kpi_val(); 

    
     $table = 'free_diagnosticssi_master_tbl';
     $where = "where year='".$data_val['year']."' and Quarterly='".$data_val['Quarterly']."' ";
     
     $total_kpi = array(); 
      
     $value = $this->getSumFieldValue2('Number_of_States', $table, $where);     
     $total_kpi[] = 'Number of States/UTs implemented Free Diagnostic Services: '.$value ;

     $value = $this->getSumFieldValue2('Free_Laboratory_services', $table, $where);     
     $total_kpi[] = 'Number of States/UTs implemented Free Laboratory Services: '.$value ;

     $value = $this->getSumFieldValue2('Radiology_services', $table, $where);     
     $total_kpi[] = 'Number of States/UTs implemented Free Tele Radiology Services: '.$value ;

     $value = $this->getSumFieldValue2('services_in_DHs', $table, $where);     
     $total_kpi[] = 'Number of States/UTs implemented Free CT Scan services in DHs: '.$value ; 


     $data['total_kpi'] = implode(',',$total_kpi);
        
     return str_replace('N/E/N/E','N/E',$data);
}

public function get_array_kpi(){

    $qry =  array("Number_of_States as 'Number of States/UTs implemented Free Diagnostic Services'","Free_Laboratory_services as 'Number of States/UTs implemented Free Laboratory Services'","Radiology_services as 'Number of States/UTs implemented Free Tele Radiology Services'","services_in_DHs as 'Number of States/UTs implemented Free CT Scan services in DHs'");
   
    return $qry;
}

public function get_table_kpi_data($id){ 

    $data_val=$this->get_total_kpi_val();
     
    $idWithoutAs = substr($id, 0, stripos($id, "as "));
    
    $qry="SELECT State_Name,".$id." FROM free_diagnosticssi_master_tbl inner join m_state on m_state.State_ID=
    free_diagnosticssi_master_tbl.state_id  where year='".$data_val['year']."' and Quarterly='".$data_val['Quarterly']."' AND ".$idWithoutAs." !='' AND ".$idWithoutAs." ='Yes' order by m_state.State_Name ";
    return $this->db->query($qry)->result_array();     
}

}