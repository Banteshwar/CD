<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Fru_model extends CI_Model {

    public function __construct() {
        parent::__construct();
		
    }
    

public function  getSumFieldValue($field, $table, $where =''){    
    
     $qry="SELECT sum(". $field.") as sum_". $field.", 
          SUM(IF(". $field."='', 1,0)) as count_". $field.",
        count(*) as total_count
      FROM ".$table." " . $where; 
      
      
     $val= $this->db->query($qry)->row_array();  
     
     if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
        return 'N/E';
     }
     else if(empty($val['total_count']))
	 {
		return 'N/E'; 
	 }
     else {
        return $val["sum_".$field]; 
     }     
} 

public function get_total_kpi()
{ 
     $data_val=$this->get_total_kpi_val();
    
     $table = 'fru_master_table';
     $where = "where year='".$data_val['year']."' and e_quarter='".$data_val['e_quarter']."' ";
     
     $total_kpi = array(); 
      

     $value1 = $this->getSumFieldValue('chc', $table, $where);
         
     $value2 = $this->getSumFieldValue('fru', $table, $where);     
          
     if($value1=='N/E' || $value2=='N/E'){
        
         $total_kpi[]= 'No. of fully operational FRUs (5 C-section/month for CHC and SDH) against required no. of FRUs: N/E';

     }else{
        $total_kpi[]= 'No. of fully operational FRUs (5 C-section/month for CHC and SDH) against required no. of FRUs: '.$value1.'/'.$value2;

     }

     $value1 = $this->getSumFieldValue('phc', $table, $where);
         
     $value2 = $this->getSumFieldValue('num_frus', $table, $where);     
          
     if($value1=='N/E' || $value2=='N/E'){
        $total_kpi[]= 'No. of fully operational FRUs (10 C-section/month for DH) against required no. of FRUs: N/E';

     }else{
        $total_kpi[]= 'No. of fully operational FRUs (10 C-section/month for DH) against required no. of FRUs: '.$value1.'/'.$value2;

     }
	 
     $data['total_kpi'] = implode(',',$total_kpi);
        
     return str_replace('N/E/N/E','N/E',$data);
}



public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `fru_master_table` where year <= '".getCurrFinYear()."' and e_quarter <= '".getCurrQuarter('Quarterly')."' order by year desc,e_quarter desc LIMIT 1"; 

    $row = $this->db->query($qry)->row_array();
    
    if(empty($row)) {

      $qry="SELECT * FROM `fru_master_table` where year < '".getCurrFinYear()."' order by year desc,e_quarter desc LIMIT 1"; 
       $row = $this->db->query($qry)->row_array();        
    }
    return $row;
}


public function get_array_kpi(){
    $qry =  array("chc as 'No. of fully operational FRU for CHC and SDH',fru as 'Required No. of FRUs'","phc as 'No. of fully operational FRU for DH',num_frus as 'Required No. of FRUs'");
    return $qry;
} 



public function get_table_kpi_data($id){ 

    $data_val=$this->get_total_kpi_val();
     
    $idWithoutAs = substr($id, 0, stripos($id, "as "));
    
    $qry="SELECT State_Name,".$id." FROM fru_master_table inner join m_state on m_state.State_ID=
    fru_master_table.state_id  where year='".$data_val['year']."' and e_quarter='".$data_val['e_quarter']."' AND ".$idWithoutAs." !='' AND ".$idWithoutAs." !='0' order by m_state.State_Name ";
    
    return $this->db->query($qry)->result_array();     
}











}