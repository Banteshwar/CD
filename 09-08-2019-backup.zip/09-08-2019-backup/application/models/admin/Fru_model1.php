<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Fru_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
public function getFru(){ 
    $this->db->select('*');
    $this->db->from('fru_master_table');
    $query = $this->db->get();

	if ($query->num_rows() > 0) {
		foreach ($query->result() as $row) {
			$data[] = $row;
		}
		return $data;
	}
	return false;
}

public function get_total_kpi(){

    $qry="SELECT concat('No. of fully operational FRUs (5 C-section/month for CHC and SDH) against required no. of FRUs : ',sum(chc),'/',sum(fru),' , No. of fully operational FRUs (10 C-section/month for DH) against required no. of FRUs : ', sum(phc),'/',sum(fru)) as total_kpi FROM `fru_master_table`  ";
    return $this->db->query($qry)->row_array();
}

public function get_total_header(){
    $qry="SELECT sum(fru)  as header_count,'Total First Referral Unit' as header_title FROM `fru_master_table`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_table_data(){
   
    $qry="SELECT year, fru_month, chc as 'No. of fully operational FRUs (5 C-section/month for CHC and SDH) against months', phc as 'No. of fully operational FRUs (10 C-section/month for DH) against required no. of FRUs' FROM fru_master_table order by fru_master_table.id ";
    return $this->db->query($qry)->result_array();   
}


public function get_array_kpi(){
    $qry =  array("chc,fru","phc,fru");
    return $qry;
}

public function get_table_kpi_data($id)
{  
    /*$qry="SELECT year, fru_month, SUM(".$id.") AS ".$id."  FROM fru_master_table group by fru_master_table.year ";*/

    $qry2 = array("chc,fru"=>"No. of fully operational FRUs (5 C-section/month for CHC and SDH) against required no. of FRUs", 
        "phc,fru"=>"No. of fully operational FRUs (10 C-section/month for DH) against required no. of FRUs");

   $alias_val=$qry2[$id];

   $lst = explode(",", $id);

   if(count($lst) > 1)
   {
        $id1 = $lst[0];
        $id2 = $lst[1];
        $id3 = $id1.'/'.$id2;
		
		if($id3=='phc/fru')
		{
		$lst[0]='DH';	
		}
        
        $qry="SELECT year AS `Financial Year`, concat(SUM(".$id1."),'/',SUM(".$id2.")) AS '".$alias_val."' FROM fru_master_table group by fru_master_table.year ";
   
   }
    else{
    $qry="SELECT year AS `Financial Year`, SUM(".$id.") AS '".$alias_val."' FROM fru_master_table group by fru_master_table.year ";
   }
   
    return $this->db->query($qry)->result_array();   
}

}