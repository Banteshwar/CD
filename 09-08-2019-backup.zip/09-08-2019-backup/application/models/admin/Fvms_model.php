<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Fvms_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    

/*public function get_total_kpi(){

    $qry="SELECT concat('No. of Application SON : ',sum(noof_application_son)) as total_kpi FROM `tbl_mou`  ";
    return $this->db->query($qry)->row_array();

}*/


public function get_table_data(){
 $qry = "select fvms_master_tbl.*, fvms_master_tbl.meeting_venues, fvms_master_tbl.noof_delegates,Date(fvms_master_tbl.fromdate) as date from fvms_master_tbl order by fvms_master_tbl.id desc";
     
    return $this->db->query($qry)->result_array();   
}

public function get_table_header($table){
    $qry="describe $table  ";
    return $this->db->query($qry)->result_array();   
}


}

