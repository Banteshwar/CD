<?php

defined('BASEPATH') or exit('No direct script access allowed');

class HealthcareInfrastructure_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   


public function get_Healthdata(){ 
    $this->db->select('nohp_master_table.*');
    $this->db->from('nohp_master_table');
	// $this->db->join('m_state','m_state.State_ID=nohp_master_table.state_id','inner');
    
 
   $this->db->order_by("nohp_master_table.id", "desc");


        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
}

  public function get_kiosk(){      
        $this->db->select('*');
        $this->db->from('tbl_kiosk');
        $query=$this->db->get();
        if($query){
            return $query->row_array();
        } else {
            return false;
        }
    }
    public function get_healthd(){      
        $this->db->select_sum('ALS_ambulances_operational');
		$this->db->select_sum('ALS_ambulances_required');
		$this->db->select_sum('BLS_ambulances_operational');
		$this->db->select_sum('BLS_ambulances_required');
		$this->db->select_sum('ALS_average_response_time');
		$this->db->select_sum('BLS_average_response_time');
		
        $this->db->from('ambulance_master_table');
        $query=$this->db->get();
        if($query){
            return $query->row_array();
        } else {
            return false;
        }
    }
    
    /*--------------------- Start HWC ----------------*/ 
    public function get_hwc(){
        global $db;
        $sql     =  "select sum(approve) as approve,sum(functional_target) as target from hwc_master_table";
        
        $stmt = $db->query($sql); 
        return $stmt->fetchAll(); 
    }

    public function get_table_data(){
    $qry="SELECT id,statename,approve,functional_target FROM hwc_master_table";
    return $this->db->query($qry)->result_array();   
    }
   
 public function get_total_kpi(){

    $qry="SELECT concat('Total AB-HWC Approved : ',sum(approve),' ,Total Functional Target : ', sum(functional_target)) as total_kpi FROM `hwc_master_table`  ";
    return $this->db->query($qry)->row_array();

}

    public function get_map_data(){

    $qry="SELECT concat('Approve : ',approve,',ALS Required : ',functional_target) AS hover, state_id FROM `hwc_master_table`";
    return $this->db->query($qry)->result_array();

}

public function get_total_header(){
    $qry="SELECT sum(approve)  as header_count,'Total AB-HWC Approved' as header_title FROM `hwc_master_table`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_table_header($table){
    $qry="describe $table  ";
    return $this->db->query($qry)->result_array();   
}

   /*--------------------- End HWC ----------------*/ 
   
}

