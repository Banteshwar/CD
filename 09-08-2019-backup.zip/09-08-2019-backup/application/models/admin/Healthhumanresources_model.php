<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Healthhumanresources_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   


public function get_totalRecordhr(){ 
    $this->db->select('SUM( Vacancies_of_medical_officers ) as vmo  , SUM( vacancies_of_nurses_against_sanctioned_posts ) as vnas , updated_date ');
    $this->db->from('hr_master_tbl');
    
    $this->db->order_by("hr_master_tbl.id", "desc");

    $query = $this->db->get();

    return $query->row_array();  
}
    
   
}

