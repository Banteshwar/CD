<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Healthservice_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   


 public function fetch_curr_date() {
        $this->db->select('date_update');
        $this->db->from('tbl_date');
        $this->db->where('name =', 'Elderly');
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return false;
        }
        $query->free_result();
    }

    public function hmis_curr_date() {
        $this->db->select("date_added,date_update");
        $this->db->from('tbl_date');
        $this->db->where('name =', 'HMIS');
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return false;
        }
        $query->free_result();
    }


    public function amrit_curr_date() {
        $this->db->select("date_added,date_update");
        $this->db->from('tbl_date');
        $this->db->where('name =', 'AMRIT');
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return false;
        }
        $query->free_result();
    }

     public function rch_curr_date() {
        $this->db->select("date_added,date_update");
        $this->db->from('tbl_date');
        $this->db->where('name =', 'RCH Portal');
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return false;
        }
        $query->free_result();
    }

    public function ors_curr_date() {
        $this->db->select("date_update");
        $this->db->from('tbl_date');
        $this->db->where('name =', 'ORS');
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->row_array();
        } else {
            return false;
        }
        $query->free_result();
    }

    public function fetch_notto_currdate() {
        $this->db->select("date_added,date_update");
        $this->db->from('tbl_date');
        $this->db->where('name =', 'NOTTO');
        $query = $this->db->get();
        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return false;
        }
        $query->free_result();
    }

    //Convert The Code Core Php To CI Date 04/02/2019
     public function newerinitamrit() {
        $this->db->select('*'); 
        $this->db->from('tbl_amrit');
        $query=$this->db->get();
        if($query){
            return $query->row_array();
        }else{
            return false;
        }
    }

    public function cghs_kpis() {
        $this->db->select("*"); 
        $this->db->from('cghs_master_table');
        $query=$this->db->get();
        if($query){ 
            return $query->result_array();
        }else{
            return false;
        }
        
    }

    public function immunization() {
        $this->db->select("sum(immunization_coverage) as 'immunization',sum(rotavirus_vaccine_coverage) as 'rotavirus',sum(mrone_dose_coverage) as 'mrone_dose',sum(mrsecond_dose_coverage) as 'mrsecond'"); 
        $this->db->from('immunization_master_table');
        $query=$this->db->get();
        if($query){
            return $query->row_array();
        }else{
            return false;
        }
    }
    
   public function nohp_sum_data() {
        $this->db->select("sum(units_approved) as 'units_approved',sum(units_functional) as 'units_functional',sum(against_approved_units) as 'against_approved_units'"); 
        $this->db->from('nohp_master_table');
        $query=$this->db->get();
        if($query){
            return $query->row_array();
        }else{
            return false;
        }   
    }


 



    public function familyplanning() {
        $this->db->select("sum(ppiucd_insertion_no) as 'ppiucd_insertion_no',sum(total_institution_delivery) as 'total_institution_delivery',sum(acceptance_rate) as 'acceptance_rate',sum(injectable_doses) as 'injectable_doses'"); 
        $this->db->from('familyplanning_master_table');
        $query=$this->db->get();
        if($query){
            return $query->row_array();
        }else{
            return false;
        }   
    }


    public function adolescent_Health() {
        $this->db->select("sum(coverage_of_wifs) as 'coverage_of_wifs',sum(client_load) as 'client_load'"); 
        $this->db->from('adolescenthealth_master_table');
        $query=$this->db->get();
        if($query){
            return $query->row_array();
        }else{
            return false;
        }   
    }


}

