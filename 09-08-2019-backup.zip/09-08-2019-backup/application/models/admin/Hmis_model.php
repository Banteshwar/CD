<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Hmis_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
public function  getSumFieldValue($field, $table, $where =''){    
    
      $qry="SELECT sum(". $field.") as sum_". $field.", 
          SUM(IF(". $field."='', 1,0)) as count_". $field.",
        count(*) as total_count
      FROM ".$table." " . $where; 
      
     $val= $this->db->query($qry)->row_array(); 
     
     if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
        return 'N/E';
     }
    else if($val['total_count']==0)
   {
    return 'N/E'; 
   }
     else {
        return $val["sum_".$field]; 
     }     
} 
 

public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `hmis_new_monthly` where year <= '".getCurrYear()."' and month <= '".getCurrMonth()."'  order by year desc,month desc "; 

    $row = $this->db->query($qry)->row_array();
    
    if(empty($row)) {

      $qry="SELECT * FROM `hmis_new_monthly` where year < '".getCurrYear()."' and month <= '".getCurrMonth()."'  order by year desc,month desc "; 
       $row = $this->db->query($qry)->row_array();        
    }
    return $row;
}


public function get_total_kpi()
{ 
     $data_val=$this->get_total_kpi_val();
    
     $table = 'hmis_new_monthly';
     $where = "where year='".$data_val['year']."' and month='".$data_val['month']."' ";
     
     $total_kpi = array(); 

     //Start PHC
    
     $value1 = $this->getSumFieldValue('phc_gradingzero', $table, $where);
                  
     if($value1=='N/E'){
        
        $total_kpi[]= '0/5 PHC Grading: N/E';

     }else{
        $total_kpi[]= '0/5 PHC Grading: '.$value1;

     }

     $value1 = $this->getSumFieldValue('phc_gradingone', $table, $where);
              
     if($value1=='N/E'){
        
        $total_kpi[]= '1/5 PHC Grading: N/E';

     }else{
        $total_kpi[]= '1/5 PHC Grading: '.$value1;

     }

     $value1 = $this->getSumFieldValue('phc_gradingtwo', $table, $where);
                
     if($value1=='N/E'){
        
        $total_kpi[]= '2/5 PHC Grading: N/E';

     }else{
        $total_kpi[]= '2/5 PHC Grading: '.$value1;

     }

     $value1 = $this->getSumFieldValue('phc_gradingthree', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= '3/5 PHC Grading: N/E';

     }else{
        $total_kpi[]= '3/5 PHC Grading: '.$value1;

     }


     $value1 = $this->getSumFieldValue('phc_gradingfour', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= '4/5 PHC Grading: N/E';

     }else{
        $total_kpi[]= '4/5 PHC Grading: '.$value1;

     }


     $value1 = $this->getSumFieldValue('phc_gradingfive', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= '5/5 PHC Grading: N/E';

     }else{
        $total_kpi[]= '5/5 PHC Grading: '.$value1;

     }

     $value1 = $this->getSumFieldValue('phc_gradingne', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= 'N/E PHC Grading: N/E';

     }else{
        $total_kpi[]= 'N/E PHC Grading: '.$value1;

     }

 //End PHC


     //---Start CHC---//

     $value1 = $this->getSumFieldValue('chc_gradingzero', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= '0/5 CHC Grading: N/E';

     }else{
        $total_kpi[]= '0/5 CHC Grading: '.$value1;

     }

      $value1 = $this->getSumFieldValue('chc_gradingone', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= '1/5 CHC Grading: N/E';

     }else{
        $total_kpi[]= '1/5 CHC Grading: '.$value1;

     }

         $value1 = $this->getSumFieldValue('chc_gradingtwo', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= '2/5 CHC Grading: N/E';

     }else{
        $total_kpi[]= '2/5 CHC Grading: '.$value1;

     }

           $value1 = $this->getSumFieldValue('chc_gradingthree', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= '3/5 CHC Grading: N/E';

     }else{
        $total_kpi[]= '3/5 CHC Grading: '.$value1;

     }



           $value1 = $this->getSumFieldValue('chc_gradingfour', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= '4/5 CHC Grading: N/E';

     }else{
        $total_kpi[]= '4/5 CHC Grading: '.$value1;

     }
 


           $value1 = $this->getSumFieldValue('chc_gradingfive', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= '5/5 CHC Grading: N/E';

     }else{
        $total_kpi[]= '5/5 CHC Grading: '.$value1;

     }

                $value1 = $this->getSumFieldValue('chc_gradingne', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= 'N/E CHC Grading: N/E';

     }else{
        $total_kpi[]= 'N/E CHC Grading: '.$value1;

     }
 

            $value1 = $this->getSumFieldValue('chc_gradingna', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= 'N/A CHC Grading: N/E';

     }else{
        $total_kpi[]= 'N/A CHC Grading: '.$value1;

     }

// ---End CHC---//


      //---Start OPD Per FAcility---//

      $value1 = $this->getSumFieldValue('opd_per_facility_sc', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= 'SC OPD Per Facility-Type Per Month: N/E';

     }else{
        $total_kpi[]= 'SC OPD Per Facility-Type Per Month: '.$value1;

     }

           $value1 = $this->getSumFieldValue('opd_per_facility_phc', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= 'PHC OPD Per Facility-Type Per Month: N/E';

     }else{
        $total_kpi[]= 'PHC OPD Per Facility-Type Per Month: '.$value1;

     }

           $value1 = $this->getSumFieldValue('opd_per_facility_chc', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= 'CHC OPD Per Facility-Type Per Month: N/E';

     }else{
        $total_kpi[]= 'CHC OPD Per Facility-Type Per Month: '.$value1;

     }
 

       $value1 = $this->getSumFieldValue('opd_per_facility_sdh', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= 'SDH OPD Per Facility-Type Per Month: N/E';

     }else{
        $total_kpi[]= 'SDH OPD Per Facility-Type Per Month: '.$value1;

     }
 

       $value1 = $this->getSumFieldValue('opd_per_facility_dh', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= 'DH OPD Per Facility-Type Per Month: N/E';

     }else{
        $total_kpi[]= 'DH OPD Per Facility-Type Per Month: '.$value1;

     }

     // --End OPD--//


     // --Start IPD-//

         $value1 = $this->getSumFieldValue('ipd_per_facility_phc', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= 'PHC IPD Per Facility-Type Per Month: N/E';

     }else{
        $total_kpi[]= 'PHC IPD Per Facility-Type Per Month: '.$value1;

     }

    $value1 = $this->getSumFieldValue('ipd_per_facility_chc', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= 'CHC IPD Per Facility-Type Per Month: N/E';

     }else{
        $total_kpi[]= 'CHC IPD Per Facility-Type Per Month: '.$value1;

     }

    $value1 = $this->getSumFieldValue('ipd_per_facility_sdh', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= 'SDH IPD Per Facility-Type Per Month: N/E';

     }else{
        $total_kpi[]= 'SDH IPD Per Facility-Type Per Month: '.$value1;

     }

    $value1 = $this->getSumFieldValue('ipd_per_facility_dh', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= 'DH IPD Per Facility-Type Per Month: N/E';

     }else{
        $total_kpi[]= 'DH IPD Per Facility-Type Per Month: '.$value1;

     }

     ///--- End IPD//


     ///--- Start Lab Test---//


    $value1 = $this->getSumFieldValue('labtest_per_facility_phc', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= 'PHC Lab Test: N/E';

     }else{
        $total_kpi[]= 'PHC Lab Test: '.$value1;

     }

        $value1 = $this->getSumFieldValue('labtest_per_facility_chc', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= 'CHC Lab Test: N/E';

     }else{
        $total_kpi[]= 'CHC Lab Test: '.$value1;

     }


   $value1 = $this->getSumFieldValue('labtest_per_facility_sdh', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= 'SDH Lab Test: N/E';

     }else{
        $total_kpi[]= 'SDH Lab Test: '.$value1;

     }


   $value1 = $this->getSumFieldValue('labtest_per_facility_dh', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= 'DH Lab Test: N/E';

     }else{
        $total_kpi[]= 'DH Lab Test: '.$value1;

     }

 //---End Lab Test---//


     ///---Start Major Operation---//

  $value1 = $this->getSumFieldValue('major_operation_per_phc_facility', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= 'PHC Major Operations excluding C-sections: N/E';

     }else{
        $total_kpi[]= 'PHC Major Operations excluding C-sections: '.$value1;

     }


       $value1 = $this->getSumFieldValue('major_operation_per_chc_facility', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= 'CHC Major Operations excluding C-sections: N/E';

     }else{
        $total_kpi[]= 'CHC Major Operations excluding C-sections: '.$value1;

     }

           $value1 = $this->getSumFieldValue('major_operation_per_sdh_facility', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= 'SDH Major Operations excluding C-sections: N/E';

     }else{
        $total_kpi[]= 'SDH Major Operations excluding C-sections: '.$value1;

     }

        $value1 = $this->getSumFieldValue('major_operation_per_dh_facility', $table, $where);
               
     if($value1=='N/E'){
        
        $total_kpi[]= 'DH Major Operations excluding C-sections: N/E';

     }else{
        $total_kpi[]= 'DH Major Operations excluding C-sections: '.$value1;

     }

     //---End Major Operation---//
 
 
     $data['total_kpi'] = implode(',',$total_kpi);
        
     return $data;
}


public function get_array_kpi(){

 $qry =  array("phc_gradingzero as '0/5 PHC Grading'","phc_gradingone as '1/5 PHC Grading'","phc_gradingtwo as '2/5 PHC Grading'","phc_gradingthree as '3/5 PHC Grading'","phc_gradingfour as '4/5 PHC Grading'","phc_gradingfive as '5/5 PHC Grading'","phc_gradingne as 'N/E PHC Grading'","chc_gradingzero as '0/5 CHC Grading'","chc_gradingone as '1/5 CHC Grading'","chc_gradingtwo as '2/5 CHC Grading'"
        ,"chc_gradingthree as '3/5 CHC Grading'","chc_gradingfour as '4/5 CHC Gradings'","chc_gradingfive as '5/5 CHC Grading'","chc_gradingne as 'N/E CHC Grading'","chc_gradingna as 'N/A CHC Grading'"
        ,"opd_per_facility_sc as 'SC OPD Per Facility-Type Per Month'","opd_per_facility_phc as 'PHC OPD Per Facility-Type Per Month'","opd_per_facility_chc as 'CHC OPD Per Facility-Type Per Month'","opd_per_facility_sdh as 'SDH OPD Per Facility-Type Per Month'"
        ,"opd_per_facility_dh as 'DH OPD Per Facility-Type Per Month'",
         "ipd_per_facility_phc as 'PHC IPD Per Facility-Type Per Month'","ipd_per_facility_chc as 'CHC IPD Per Facility-Type Per Month'","ipd_per_facility_sdh as 'SDH IPD Per Facility-Type Per Month'"
        ,"ipd_per_facility_dh as 'DH IPD Per Facility-Type Per Month'",

        "labtest_per_facility_phc as 'PHC Lab Test'","labtest_per_facility_chc as 'CHC Lab Test'"
        ,"labtest_per_facility_sdh as 'SDH Lab Test'","labtest_per_facility_dh as 'DH Lab Test'"
        ,"major_operation_per_phc_facility as 'PHC Major Operations excluding C-sections'"
        ,"major_operation_per_chc_facility as 'CHC Major Operations excluding C-sections'","major_operation_per_sdh_facility as 'SDH Major Operations excluding C-sections'",
        "major_operation_per_dh_facility as 'DH Major Operations excluding C-sections'");
    return $qry;
   
}

public function get_table_kpi_data($id){
  
  
  $data_val=$this->get_total_kpi_val();
     
    $idWithoutAs = substr($id, 0, stripos($id, "as "));
    
    $qry="SELECT State_Name,".$id." FROM hmis_new_monthly inner join m_state on m_state.State_ID=
    hmis_new_monthly.state_id  where year='".$data_val['year']."' and month='".$data_val['month']."' AND ".$idWithoutAs." !='' AND ".$idWithoutAs." !='0' order by m_state.State_Name ";
    
    return $this->db->query($qry)->result_array();
    
}

}