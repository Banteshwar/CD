<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Hpe_model extends CI_Model 
{

    public function __construct() {
        parent::__construct();
		ini_set('display_errors', 0);
    }
    
/*public function get_total_kpi()
{
    $qry="SELECT concat('Name of Section/Division :',(SELECT (Name_Of_Section) FROM atr_master_tbl),',Pending ATR on PMO References :',SELECT (sum(atrpending_pmoreference) FROM atr_master_tbl),',Pending VIP References :',(SELECT count(devesion) FROM atr2_master_tbl),',Parliament Assurances : ',(SELECT count(Name_Section) FROM atr3_master_tbl)) as total_kpi" ;
    return $this->db->query($qry)->row_array();
}*/

public function get_total_kpi()
{
	$data_val1=$this->get_total_kpi_val1();
	
    $qry="SELECT concat('Total Number of Products :',(SELECT count(products) FROM tbl_hpe_products where  year='".$data_val1['year']."' and month ='".$data_val1['month']."' order by tbl_hpe_products.id ),',Total Amount received during the month:',(SELECT sum(amt_receive) FROM tbl_hpe_recev),',Total Number of Pharma Retail Outlets:',(SELECT sum(amrit_outlets+other_outlets) FROM tbl_hpe_pharma),',HindLabs Diagnostic Centres: ',(SELECT sum(no_labs+no_imaging_centres) FROM tbl_hpe_hindlabs),',Total number of Hospitals:',(SELECT sum(total_hospitals) FROM tbl_hpe_hospitals),',Total No of Projects in Hand PMC:',(SELECT sum(Total_No_of_Projects_in_Hand_PMC) FROM tbl_hpe_hites )) as total_kpi" ;
    return $this->db->query($qry)->row_array();
}



public function get_array_kpi()
{
   $qry =  array("products as 'Total Number of Products'", "amt_receive as 'Total Amount received during the month'", "amrit_outlets as 'Total Number of Pharma Retail AMRIT Outlets', other_outlets as 'Total Number of Pharma Retail Other Outlets'","no_labs as 'Total No of Labs', no_imaging_centres as 'Total No of Imaging Centres'","total_hospitals as 'Total number of Hospitals'","Total_No_of_Projects_in_Hand_PMC as 'Total No of Projects in Hand PMC'");

   return $qry;
}



public function get_table_kpi_data($id)
{

	$data_val1=$this->get_total_kpi_val1();
    $data_val2=$this->get_total_kpi_val2();
    $data_val3=$this->get_total_kpi_val3();
    $data_val4=$this->get_total_kpi_val4();
    $data_val5=$this->get_total_kpi_val5();
    $data_val6=$this->get_total_kpi_val6();

	
 if($id == "products as 'Total Number of Products'")
 {
        $qry="SELECT year , ".$id." FROM tbl_hpe_products where  year='".$data_val1['year']."' and month ='".$data_val1['month']."' order by tbl_hpe_products.id  "; 
   
    return $this->db->query($qry)->result_array();  
        
 }

 if($id == "amt_receive as 'Total Amount received during the month'")
 {
        $qry="SELECT  ".$id." FROM tbl_hpe_recev where  year='".$data_val2['year']."' and month ='".$data_val2['month']."' order by tbl_hpe_recev.id desc";
        return $this->db->query($qry)->result_array(); 
        
 }

 if($id =="amrit_outlets as 'Total Number of Pharma Retail AMRIT Outlets', other_outlets as 'Total Number of Pharma Retail Other Outlets'")
 {
		$qry="SELECT State_Name, ".$id." FROM tbl_hpe_pharma inner join m_state on m_state.State_ID = tbl_hpe_pharma.state_id where  e_year='".$data_val3['e_year']."' and financial_month ='".$data_val3['financial_month']."' GROUP by tbl_hpe_pharma.state_id";
        return $this->db->query($qry)->result_array(); 

 }


if($id == "no_labs as 'Total No of Labs', no_imaging_centres as 'Total No of Imaging Centres'")
{
        $qry="SELECT State_Name, ".$id."  FROM tbl_hpe_hindlabs inner join m_state on m_state.State_ID = tbl_hpe_hindlabs.state_id where  e_year='".$data_val4['e_year']."' and financial_month ='".$data_val4['financial_month']."' GROUP by tbl_hpe_hindlabs.state_id";
        return $this->db->query($qry)->result_array(); 
        
}

if($id == "total_hospitals as 'Total number of Hospitals'")
{
        $qry="SELECT State_Name, ".$id."  FROM tbl_hpe_hospitals inner join m_state on m_state.State_ID = tbl_hpe_hospitals.state_id where  e_year='".$data_val5['e_year']."' and financial_month ='".$data_val5['financial_month']."' GROUP by tbl_hpe_hospitals.state_id";
        return $this->db->query($qry)->result_array(); 
       
}

if($id == "Total_No_of_Projects_in_Hand_PMC as 'Total No of Projects in Hand PMC'")
{
        $qry="SELECT State_Name, ".$id." FROM tbl_hpe_hites inner join m_state on m_state.State_ID = tbl_hpe_hites.state_id where  e_year='".$data_val6['e_year']."' and financial_month ='".$data_val6['financial_month']."' GROUP by tbl_hpe_hites.state_id";
        return $this->db->query($qry)->result_array(); 
     
}
}

public function get_total_kpi_val1(){
    
    $qry="SELECT * FROM `tbl_hpe_products` order by year desc , month desc  LIMIT 1";
    return $this->db->query($qry)->row_array();
} 

public function get_total_kpi_val2(){
    
    $qry="SELECT * FROM `tbl_hpe_recev` order by year desc , month desc LIMIT 1";
    return $this->db->query($qry)->row_array();
} 

public function get_total_kpi_val3(){
    
    $qry="SELECT * FROM `tbl_hpe_pharma` order by e_year desc , financial_month desc  LIMIT 1";
    return $this->db->query($qry)->row_array();
} 

public function get_total_kpi_val4(){
    
    $qry="SELECT * FROM `tbl_hpe_hindlabs` order by e_year desc , financial_month desc LIMIT 1";
    return $this->db->query($qry)->row_array();
} 

public function get_total_kpi_val5(){
    
    $qry="SELECT * FROM `tbl_hpe_hospitals` order by e_year desc , financial_month desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}  

public function get_total_kpi_val6(){
    
    $qry="SELECT * FROM `tbl_hpe_hites` order by e_year desc , financial_month desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}  


}

