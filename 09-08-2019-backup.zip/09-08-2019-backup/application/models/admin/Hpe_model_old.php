<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Hpe_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
public function getFru(){ 
    $this->db->select('*');
    $this->db->from('fru_master_table');
    $query = $this->db->get();

	if ($query->num_rows() > 0) {
		foreach ($query->result() as $row) {
			$data[] = $row;
		}
		return $data;
	}
	return false;
}


public function productsNumerbs(){
	
	 $qry="SELECT count(*) as cnt  FROM `hpe_product_category`  ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['cnt'];   
	
	
}
public function productlisting(){
	
	 $qry="SELECT year, month, products, installed_capacity, monthly_production, total_production, manpower  FROM `tbl_hpe_products`  ";	
	 return $this->db->query($qry)->result_array();
	
}

public function ReceivablesNumbers(){
	 $qry="SELECT sum(amt_due) as sum_amount_due  FROM `tbl_hpe_recev`  ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount_due']; 
}

public function ReceivablesListing(){
	$qry="SELECT year, month, category,amt_due, amt_receive, sale_services, balance_amt  FROM `tbl_hpe_recev`  ";	
	return $this->db->query($qry)->result_array();
}
public function PharmaNumbers(){
	 $qry="SELECT sum(amrit_outlets+other_outlets) as sum_amount_due  FROM `tbl_hpe_pharma`  ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount_due']; 
}

public function PharmaListing(){
	$qry="SELECT year, month, amrit_outlets,other_outlets, state_outlets, beneficiaries, quantum_saving, manpower  FROM `tbl_hpe_pharma`  ";	
	return $this->db->query($qry)->result_array();
}

public function HindNumbers(){
	 $qry="SELECT sum(no_labs + no_imaging_centres) as sum_amount_due  FROM `tbl_hpe_hindlabs`  ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount_due']; 
}

public function HindListing(){
	$qry="SELECT year, month, centres,no_labs  as `Number of Labs` , no_imaging_centres as `Number of Imaging centre`, state_covered, new_hindlabs, beneficiaries, quantum, manpower  FROM `tbl_hpe_hindlabs`  ";	
	return $this->db->query($qry)->result_array();
}

public function HosNumbers(){
	 $qry="SELECT sum(total_hospitals) as sum_amount_due  FROM `tbl_hpe_hospitals`  ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount_due']; 
}

public function HosListing(){
	$qry="SELECT year, month, total_hospitals, total_states, proposed_new_hospitals, in_patients, out_patients, quantum_savings, manpower  FROM `tbl_hpe_hospitals`  ";	
	return $this->db->query($qry)->result_array();
}
public function HiteNumbers(){
	 $qry="SELECT sum(project_hand) as sum_amount_due  FROM `tbl_hpe_hites`  ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount_due']; 
}

public function HiteListing(){
	$qry="SELECT year, month, category, project_hand,  	project_completed, project_fund_disbursed, ontime_completed, manpower  FROM `tbl_hpe_hites`  ";	
	return $this->db->query($qry)->result_array();
}












public function get_total_kpi(){
	 $row  = array();
     $row['total_kpi'] = 'Products : '.$this->productsNumerbs().' , Receivables (Amout Due): '.$this->ReceivablesNumbers().' , Pharma Retail Outlet: '.$this->PharmaNumbers().' , HindLabs Diagnostic Centers: '.$this->HindNumbers().' , HindLabs Diagnostic Centers: '.$this->HosNumbers().' , HindLabs Diagnostic Centers: '.$this->HiteNumbers();	 
	 return $row;
  
    //$qry="SELECT concat('No. of fully operational FRUs (5 C-section/month for CHC and SDH) against months : ',sum(chc),' , No. of fully operational FRUs (10 C-section/month for DH) against required no. of FRUs : ', sum(phc)) as total_kpi FROM `fru_master_table`  ";
   // return $this->db->query($qry)->row_array();
}

public function get_total_header(){
    $qry="SELECT sum(fru)  as header_count,'Total First Referral Unit' as header_title FROM `fru_master_table`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_table_data(){
   
    $qry="SELECT year, fru_month, chc as 'No. of fully operational FRUs (5 C-section/month for CHC and SDH) against months', phc as 'No. of fully operational FRUs (10 C-section/month for DH) against required no. of FRUs' FROM fru_master_table order by fru_master_table.id ";
    return $this->db->query($qry)->result_array();   
}


public function get_array_kpi(){

    $qry =  array("Products","Receivables","Pharma","Hind","Hospital","Hite");
   
    return $qry;
}

public function get_table_kpi_data($id){
   
   if($id == 'Products') {
	   return $this->productlisting();
   }
   
   if($id == 'Receivables') {
	   return $this->ReceivablesListing();
   }
    if($id == 'Pharma') {
	   return $this->PharmaListing();
   }
	if($id == 'Hind') {
	   return $this->HindListing();
   }
   if($id == 'Hospital') {
	   return $this->HosListing();
   }
   if($id == 'Hite') {
	   return $this->HiteListing();
   }
	return array();
	
    //$qry="SELECT year, fru_month, SUM(".$id.") AS ".$id."  FROM fru_master_table group by fru_master_table.year ";   
    //return $this->db->query($qry)->result_array();   
}

}