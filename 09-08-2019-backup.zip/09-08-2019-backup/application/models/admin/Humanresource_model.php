<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Humanresource_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    

public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `hr_master_tbl` where year <= '".getCurrFinYear()."' and Quarterly <= '".getCurrQuarter('Quarterly')."' order by year desc,Quarterly desc LIMIT 1"; 

    $row = $this->db->query($qry)->row_array();
    
    if(empty($row)) {

      $qry="SELECT * FROM `hr_master_tbl` where year < '".getCurrFinYear()."' order by year desc,Quarterly desc LIMIT 1"; 

       $row = $this->db->query($qry)->row_array();        
    }

    return $row;
}


public function  getSumFieldValue($field, $table, $where =''){    
    
     $qry="SELECT sum(". $field.") as sum_". $field.", 
          SUM(IF(". $field."='', 1,0)) as count_". $field.",
        count(*) as total_count
      FROM ".$table." " . $where; 
      
     $val= $this->db->query($qry)->row_array();  
     
     if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
        return 'N/E';
     }else if(empty($val['total_count'])){
        return 'N/E'; 
     }
     else {
        return $val["sum_".$field]; 
     }     
}

public function  getSumPercentFieldValue($table, $field1 ='',$field2 ='' ,$where){    
    
     $qry  =  "SELECT floor(sum(".$field1.")/sum(".$field2.")*100) as percentage FROM ".$table." " . $where;
     
     $val  =  $this->db->query($qry)->row_array();
     
     if($val==0){
        return 0;
     }else{
        return $val;
     }     
}

public function get_total_kpi()
{ 
     $data_val=$this->get_total_kpi_val(); 

    
     $table = 'hr_master_tbl';
     $where = "where year='".$data_val['year']."' and Quarterly='".$data_val['Quarterly']."' ";
     
     $total_kpi = array(); 
      
     
     $per1 = $this->getSumPercentFieldValue($table, 'Vacancies_of_medical_officers' , 'sanction_medical_post',$where);
     /*echo "<pre>";
     print_r($per['percentage']);die;*/

     $value1 = $this->getSumFieldValue('Vacancies_of_medical_officers', $table, $where);
         
     $value2 = $this->getSumFieldValue('sanction_medical_post', $table, $where);     
          
     if($value1=='N/E' || $value2=='N/E'){
        
         $total_kpi[]= 'Vacancies ('.$per1["percentage"].' %) of Medical Officers
(including specialists) against Sanctioned Posts(Both Regular & NRHM Posts: N/E';

     }else{
        $total_kpi[]= 'Vacancies ('.$per1["percentage"].' %) of Medical Officers
(including specialists) against Sanctioned Posts(Both Regular & NRHM Posts: '.$value1.'/'.$value2;

     }

     $per2 = $this->getSumPercentFieldValue($table, 'vacancies_of_nurses_against_sanctioned_posts' , 'sanction_nurses_post',$where);

     $value1 = $this->getSumFieldValue('vacancies_of_nurses_against_sanctioned_posts', $table, $where);
         
     $value2 = $this->getSumFieldValue('sanction_nurses_post', $table, $where);     
          
     if($value1=='N/E' || $value2=='N/E'){
        $total_kpi[]= 'Vacancies ('.$per2["percentage"].' %)  of Staff Nurse Against
Sanctioned Posts (Both Regular and NRHM Posts: N/E';

     }else{
        $total_kpi[]= 'Vacancies  ('.$per2["percentage"].' %) of Staff Nurse Against
Sanctioned Posts (Both Regular and NRHM Posts: '.$value1.'/'.$value2;

     }

     $per3 = $this->getSumPercentFieldValue($table, 'sanction_medical_post_nuhm' , 'Vacancies_of_medical_officers_nuhm',$where);

     $value1 = $this->getSumFieldValue('sanction_medical_post_nuhm', $table, $where);
         
     $value2 = $this->getSumFieldValue('Vacancies_of_medical_officers_nuhm', $table, $where);     
          
     if($value1=='N/E' || $value2=='N/E'){
        $total_kpi[]= 'Vacancies ('.$per3["percentage"].' %) of Medical Officer(including specialists) Against
Sanctioned Posts under NUHM: N/E';

     }else{
        $total_kpi[]= 'Vacancies ('.$per3["percentage"].' %) of Medical Officer(including specialists) Against
Sanctioned Posts under NUHM: '.$value1.'/'.$value2;

     }

     $per4 = $this->getSumPercentFieldValue($table, 'sanction_nurses_post_nuhm' , 'vacancies_of_nurses_nuhm',$where);

     $value1 = $this->getSumFieldValue('sanction_nurses_post_nuhm', $table, $where);
         
     $value2 = $this->getSumFieldValue('vacancies_of_nurses_nuhm', $table, $where);     
          
     if($value1=='N/E' || $value2=='N/E'){
        $total_kpi[]= 'Vacancies ('.$per4["percentage"].' %)  of Staff Nurse Against
Sanctioned Posts under NUHM: N/E';

     }else{
        $total_kpi[]= 'Vacancies ('.$per4["percentage"].' %)  of Staff Nurse Against
Sanctioned Posts under NUHM: '.$value1.'/'.$value2;

     }

     
     
     $data['total_kpi'] = implode(',',$total_kpi);
        
     return str_replace('N/E/N/E','N/E',$data);
}

public function get_array_kpi(){
     
   $qry =  array(
   "Vacancies_of_medical_officers as 'Vacancies Of Medical Officer NRHM',
    sanction_medical_post as 'Sanctioned Medical Post NRHM'",
   
   "vacancies_of_nurses_against_sanctioned_posts as 'Vacancies Of Nurses NRHM',
   sanction_nurses_post as 'Sanctioned Nurse Post NRHM'",
   
   "sanction_medical_post_nuhm as 'Vacancies Of Medical Officer NUHM',
   Vacancies_of_medical_officers_nuhm as 'Sanctioned Medical Post NUHM'",

   "sanction_nurses_post_nuhm as 'Vacancies Of Nurses NUHM',
   vacancies_of_nurses_nuhm as 'Sanctioned Nurse Post NUHM'"
   );   
  
  return $qry;
}

public function get_table_kpi_data($id){ 

    $data_val=$this->get_total_kpi_val();
     
    $idWithoutAs = substr($id, 0, stripos($id, "as "));
    
    $qry="SELECT State_Name,".$id." FROM hr_master_tbl inner join m_state on m_state.State_ID=
    hr_master_tbl.state_id  where year='".$data_val['year']."' and Quarterly='".$data_val['Quarterly']."' AND ".$idWithoutAs." !='' AND ".$idWithoutAs." !='0' order by m_state.State_Name ";
    
    return $this->db->query($qry)->result_array();     
}

}