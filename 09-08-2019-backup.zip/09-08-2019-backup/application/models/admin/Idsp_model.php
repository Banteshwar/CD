<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Idsp_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    

public function get_total_kpi(){

	$qry="SELECT concat('Diseases : ',count(disease),',Cases:',sum(cases),',Deaths:',sum(deaths)) as total_kpi FROM `tbl_outbreaks_hfm` ";
    return $this->db->query($qry)->row_array();
	//echo $this->db->last_query();
}

public function get_total_header(){
   $qry="SELECT sum(disease)  as header_count,'disease' as header_title FROM `tbl_outbreaks_hfm`  ";
    return $this->db->query($qry)->row_array();  
}


public function get_array_kpi(){

    /*return array("disease as 'Diseases'","cases as 'Cases'","deaths as 'Deaths'","date_of_outbreak as ' Date of Outbreak'");*/

    $qry =  array("disease","cases","deaths");
    return $qry;
}

public function get_table_kpi_data($id){
   
    $qry2 = array("disease"=>"Disease Surveillance Programme", 
        "cases" => "Cases Reported",
        "deaths"=>"Number of Deaths"
        
    ); 
if($id!="disease"){
    $alias_val=$qry2[$id];

    $qry="SELECT State_Name, SUM(".$id.") AS '".$alias_val."' FROM tbl_outbreaks_hfm inner join m_state on m_state.State_ID=
    tbl_outbreaks_hfm.cd_stateid group by tbl_outbreaks_hfm.state";
}else{

    $qry="SELECT State_Name,".$id." FROM tbl_outbreaks_hfm inner join m_state on m_state.State_ID=
    tbl_outbreaks_hfm.cd_stateid group by tbl_outbreaks_hfm.state";
    }
    return $this->db->query($qry)->result_array(); 
	
}

}