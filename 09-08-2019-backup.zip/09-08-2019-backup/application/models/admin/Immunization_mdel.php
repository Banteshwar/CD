<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Immunization_mdel extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   


public function get_total_kpi(){

    $qry="SELECT concat('Full Immunization Coverage: ',sum(immunization_coverage),' ,Rotavirus vaccine coverage : ', sum(rotavirus_vaccine_coverage),' ,Measles/MR 1st Dose Coverage: ' ,sum(mrone_dose_coverage),',Measles/MR 2nd Dose Coverage : ',sum(mrsecond_dose_coverage)) as total_kpi FROM `immunization_master_table`  ";
    return $this->db->query($qry)->row_array();

}

public function get_total_header(){
    $qry="SELECT sum(immunization_coverage)  as header_count,'Rotavirus vaccine coverage' as header_title FROM `immunization_master_table`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_table_data(){
    $qry="SELECT immunization_coverage,rotavirus_vaccine_coverage,mrone_dose_coverage,mrsecond_dose_coverage FROM immunization_master_table order by id desc ";
    return $this->db->query($qry)->result_array();   
}


public function get_array_kpi(){

    return array("immunization_coverage","rotavirus_vaccine_coverage","mrone_dose_coverage","mrsecond_dose_coverage");
}

public function get_table_kpi_data($id){
   
    
    $qry="SELECT  financial_year, SUM(".$id.") AS ".$id." FROM immunization_master_table group by immunization_master_table.financial_year";
    return $this->db->query($qry)->result_array(); 
    
}

}