<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Immunization_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
  
public function  getSumFieldValue($field, $table, $where =''){    
    
     $qry="SELECT sum(". $field.") as sum_". $field.", 
          SUM(IF(". $field."='', 1,0)) as count_". $field.",
        count(*) as total_count
      FROM ".$table." " . $where; 
      
      
     $val= $this->db->query($qry)->row_array();  
     
     if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
        return 'N/E';
     }
     else if(empty($val['total_count']))
	 {
		return 'N/E'; 
	 }
     else {
        return $val["sum_".$field]; 
     }     
} 
 

public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `immunization_master_table` where financial_year <= '".getCurrFinYear()."' and quarter <= '".getCurrQuarter('Quarterly')."' order by financial_year desc,quarter desc LIMIT 1"; 

    $row = $this->db->query($qry)->row_array();
    
    if(empty($row)) {

      $qry="SELECT * FROM `immunization_master_table` where financial_year < '".getCurrFinYear()."' order by financial_year desc,quarter desc LIMIT 1"; 
       $row = $this->db->query($qry)->row_array();        
    }
    return $row;
}




public function get_total_kpi()
{ 
     $data_val=$this->get_total_kpi_val();
    
     $table = 'immunization_master_table';
     $where = "where financial_year='".$data_val['financial_year']."' and quarter='".$data_val['quarter']."' ";
     
     $total_kpi = array(); 
      

     $value1 = $this->getSumFieldValue('immunization_coverage', $table, $where);
         
       
          
     if($value1=='N/E'){
        
        $total_kpi[]= 'Full Immunization Coverage: N/E';

     }else{
        $total_kpi[]= 'Full Immunization Coverage: '.$value1;

     }

     $value1 = $this->getSumFieldValue('rotavirus_vaccine_coverage', $table, $where);
         
       
          
     if($value1=='N/E'){
        
        $total_kpi[]= 'Rotavirus vaccine Coverage: N/E';

     }else{
        $total_kpi[]= 'Rotavirus vaccine Coverage: '.$value1;

     }

   
     $value1 = $this->getSumFieldValue('mrone_dose_coverage', $table, $where);
         
       
          
     if($value1=='N/E'){
        
        $total_kpi[]= 'Measles/MR 1st Dose Coverage: N/E';

     }else{
        $total_kpi[]= 'Measles/MR 1st Dose Coverage: '.$value1;

     }

     $value1 = $this->getSumFieldValue('mrsecond_dose_coverage', $table, $where);
         
       
          
     if($value1=='N/E'){
        
        $total_kpi[]= 'Measles/MR 2nd Dose Coverage: N/E';

     }else{
        $total_kpi[]= 'Measles/MR 2nd Dose Coverage: '.$value1;

     }

     

     
     
     $data['total_kpi'] = implode(',',$total_kpi);
        
     return $data;
}




public function get_array_kpi(){

 $qry =  array("immunization_coverage as 'Full Immunization Coverage'","rotavirus_vaccine_coverage as 'Rotavirus vaccine coverage'","mrone_dose_coverage as 'Measles/MR 1st Dose Coverage'","mrsecond_dose_coverage as 'Measles/MR 2nd Dose Coverage'");
    return $qry;
   
}

public function get_table_kpi_data($id){
	
	
	$data_val=$this->get_total_kpi_val();
     
    $idWithoutAs = substr($id, 0, stripos($id, "as "));
    
    $qry="SELECT State_Name,".$id." FROM immunization_master_table inner join m_state on m_state.State_ID=
    immunization_master_table.state_id  where financial_year='".$data_val['financial_year']."' and quarter='".$data_val['quarter']."' AND ".$idWithoutAs." !='' AND ".$idWithoutAs." !='0' order by m_state.State_Name ";
    
    return $this->db->query($qry)->result_array();
    
}

}