<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Laqshya_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
public function get_map_data(){

    $qry="SELECT concat('Total No of Medical Officers,ANMs,Staff Nurses,Lab Technician,Pharmacists: ',Medical_Officers+ANMs+Staff_Nurses+Lab_Technician+Pharmacists),' ,Number of UHCs operationalized as HWCs : ', sum(Number_of_UHCs_operationalized_as_HWCs,',Number of Mahila Arogya Samiti Constitued : ',Number_of_Mahila_Arogya_Samiti_Constitued) AS hover,'Patient Treatment Successfully : ',Patient_Successfully_Treated,'Percentage of newborns : ',Newborns_Receiv FROM `immunization_master_table`";
    return $this->db->query($qry)->result_array();

}

public function get_totalRecordNVHCPs(){ 
    $this->db->select('SUM(Medical_Officers+ANMs+Staff_Nurses+Lab_Technician+Pharmacists) as mt , SUM(Number_of_UHCs_operationalized_as_HWCs) as ma , SUM(Number_of_Mahila_Arogya_Samiti_Constitued) as nd');
    $this->db->from('nuhm_master_tbl');
    
    $this->db->order_by("nuhm_master_tbl.id", "desc");

    $query = $this->db->get();

    return $query->row_array();  
}

public function get_total_header(){
    $qry="SELECT sum(Number_of_UHCs_operationalized_as_HWCs)  as header_count,'Number of UHCs operationalized as HWCs' as header_title FROM `nuhm_master_tbl`";
    return $this->db->query($qry)->row_array();   
}

public function get_total_kpi(){

   $qry="SELECT concat('Number of Operation Theature : ',field_1,',Number of Labour Room : ',field_2,',LaQshya baseline assessment completed : ',field_3 ,', LaQshya State orientation completed  : ',field_4,',LaQshya Certified Facilities LR & OT : ', field_5,', DH in Aspirational Districts completed baseline assessment : ', field_6,',State Certification of LR of Dist Hospital in Aspirational District : ',field_7,',State Certification of OT of Dist. Hospital in Aspirational District :',field_8) as total_kpi FROM `dashboard_data_laqshya` where type_data ='summary' ";
    return $this->db->query($qry)->row_array();

}
public function get_table_data(){
    $qry ="(SELECT public_health_facilites_no FROM `maternal_laqshya_master_table`) ";
    return $this->db->query($qry)->result_array();   
}

public function get_array_kpi(){
    return array("Quarterly","Medical_Officers","ANMs","Staff_Nurses","Lab_Technician","Pharmacists","Number_of_UHCs_operationalized_as_HWCs","Number_of_Mahila_Arogya_Samiti_Constitued ");
}

public function get_table_kpi_data($id){
   
    $qry ="SELECT * FROM maternal_laqshya_master_table";
    return $this->db->query($qry)->result_array();   
}


/*public function get_table_data(){
    $qry="SELECT state_id,Medical_Officers,ANMs,Staff_Nurses,Lab_Technician,Pharmacists,Number_of_UHCs_operationalized_as_HWCs,Number_of_Mahila_Arogya_Samiti_Constitued,year FROM nuhm_master_tbl order by id desc ";
    return $this->db->query($qry)->result_array();   
}
*/
public function get_table_header($table){
    $qry="describe $table  ";
    return $this->db->query($qry)->result_array();   
}

  


   
}

