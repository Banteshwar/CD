<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Metarnalhealth_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    


public function  getSumFieldValue($field, $table, $where =''){    
    
     $qry="SELECT sum(". $field.") as sum_". $field.", 
          SUM(IF(". $field."='', 1,0)) as count_". $field.",
        count(*) as total_count
      FROM ".$table." " . $where; 
      
      
     $val= $this->db->query($qry)->row_array();  
     
     if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
        return 'N/E';
     }
     else if(empty($val['total_count']))
	 {
		return 'N/E'; 
	 }
     else {
        return $val["sum_".$field]; 
     }     
}

public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `maternal_master_table` where financial_year <= '".getCurrFinYear()."' and quarter <= '".getCurrQuarter('Quarterly')."' order by financial_year desc,quarter desc LIMIT 1"; 

    $row = $this->db->query($qry)->row_array();
    
    if(empty($row)) {

      $qry="SELECT * FROM `maternal_master_table` where financial_year < '".getCurrFinYear()."' order by financial_year desc,quarter desc LIMIT 1"; 
       $row = $this->db->query($qry)->row_array();        
    }
    return $row;
}


public function get_total_kpi_val1(){
    
    $qry="SELECT * FROM `maternal_laqshya_master_table` where financial_year <= '".getCurrFinYear()."' and quarter <= '".getCurrQuarter('Quarterly')."' order by financial_year desc,quarter desc LIMIT 1"; 

    $row = $this->db->query($qry)->row_array();
    
    if(empty($row)) {

      $qry="SELECT * FROM `maternal_laqshya_master_table` where financial_year < '".getCurrFinYear()."' order by financial_year desc,quarter desc LIMIT 1"; 
       $row = $this->db->query($qry)->row_array();        
    }
    return $row;
}




public function get_total_kpi()
{ 
     $data_val=$this->get_total_kpi_val();
	 
	 $data_val1=$this->get_total_kpi_val1();
    
     $table = 'maternal_master_table';
     $where = "where financial_year='".$data_val['financial_year']."' and quarter='".$data_val['quarter']."' ";
     
     $total_kpi = array(); 
      


     $value1 = $this->getSumFieldValue('firsttrimester', $table, $where);
         
     $value2 = $this->getSumFieldValue('estimate_pregnancy_w', $table, $where);     
          
     $cal1 = ROUND((($value1/$value2)*100),2);
     if($value1=='N/E' || $value2=='N/E'){
        $total_kpi[]= 'Percentage of First trimester registration during Antenatal Care (ANC): N/E';

     }else{
        $total_kpi[]= 'Percentage of First trimester registration during Antenatal Care (ANC): '.$cal1;

     }

     $value1 = $this->getSumFieldValue('institutedelivery', $table, $where);
         
     $value2 = $this->getSumFieldValue('estimate_pregnancy_id', $table, $where);     
          
     $cal2 = ROUND((($value1/$value2)*100),2);
     if($value1=='N/E' || $value2=='N/E'){
        $total_kpi[]= 'Percentage of Institutional delivery: N/E';

     }else{
        $total_kpi[]= 'Percentage of Institutional delivery: '.$cal2;

     }

     $value1 = $this->getSumFieldValue('anccheckup', $table, $where);
         
     $value2 = $this->getSumFieldValue('estimate_pregnancy_anc', $table, $where);     
          
     $cal3 = ROUND((($value1/$value2)*100),2);
     if($value1=='N/E' || $value2=='N/E'){
        $total_kpi[]= 'Percentage of 4 or more ANC checkup: N/E';

     }else{
        $total_kpi[]= 'Percentage of 4 or more ANC checkup: '.$cal3;

     }
	 
	 $value1 = $this->getSumFieldValue('noofanc', $table, $where);
     
     if($value1=='N/E'){
        $total_kpi[]= 'No. of ANCs conducted under Pradhan Mantri Surakshit Matritva Abhiyan (PMSMA): N/E';

     }else{
        $total_kpi[]= 'No. of ANCs conducted under Pradhan Mantri Surakshit Matritva Abhiyan (PMSMA): '.$value1;

     }
	 
	 $table1 = 'maternal_laqshya_master_table';
     $where1 = "where financial_year='".$data_val1['financial_year']."' and quarter='".$data_val1['quarter']."' ";
     
     
	 
	 $value1 = $this->getSumFieldValue('public_health_facilites_no', $table1, $where1);
     
     if($value1=='N/E'){
        $total_kpi[]= 'Total number of Public Health facilities selected under LaQshya: N/E';

     }else{
        $total_kpi[]= 'Total number of Public Health facilities selected under LaQshya: '.$value1;

     }
	 
	 $value1 = $this->getSumFieldValue('lr_and_ot_state', $table1, $where1);
     
     if($value1=='N/E'){
        $total_kpi[]= 'Total number of Labour Rooms and Operation Theatres (OT) State Certified under LaQshya: N/E';

     }else{
        $total_kpi[]= 'Total number of Labour Rooms and Operation Theatres (OT) State Certified under LaQshya: '.$value1;

     }
	 
	 $value1 = $this->getSumFieldValue('lr_and_ot_national', $table1, $where1);
     
     if($value1=='N/E'){
        $total_kpi[]= 'Total number of Labour Rooms (LR) and Operation Theatres (OT) Nationally Certified under LaQshya: N/E';

     }else{
        $total_kpi[]= 'Total number of Labour Rooms (LR) and Operation Theatres (OT) Nationally Certified under LaQshya: '.$value1;

     }
     
	 $data['total_kpi'] = implode(',',$total_kpi);
        
     return $data;
}




public function get_array_kpi(){
    $qry =  array("firsttrimester as 'Number of women registered in First trimester during ANC',estimate_pregnancy_w as 'Total estimated pregnancy for women registered in First trimester',firsttrimester_w as '% of First trimester registration during ANC'","institutedelivery as 'Number of Institutional delivery',estimate_pregnancy_id as 'Total estimated pregnancy for Institutional delivery',institutedelivery_id as '% of Institutional delivery'","anccheckup as 'Number of 4 or more ANC checkup',estimate_pregnancy_anc as 'Total estimated pregnancy for 4 or more ANC checkup',anccheckup_anc as '% 4 or more ANC checkup'","noofanc as 'Number ANCs conducted under Pradhan Mantri Surakshit Matritva Abhiyan (PMSMA)'","public_health_facilites_no as 'Number of Public Health facilities selected under LaQshya'","lr_and_ot_state as 'Number of Labour Rooms and Operation Theatres (OT) State Certified under LaQshya'","lr_and_ot_national as 'Number of Labour Rooms(LR) and Operation Theatres(OT) Nationally Certified under LaQshya'");
    return $qry;
}

public function get_table_kpi_data($id)
{  
   
    $data_val=$this->get_total_kpi_val();
	$data_val1=$this->get_total_kpi_val1();
	
	$idWithoutAs = substr($id, 0, stripos($id, "as "));
	
	if($id == "firsttrimester as 'Number of women registered in First trimester during ANC',estimate_pregnancy_w as 'Total estimated pregnancy for women registered in First trimester',firsttrimester_w as '% of First trimester registration during ANC'"){
		
		$qry="SELECT State_Name,".$id." FROM maternal_master_table inner join m_state on m_state.State_ID=
    maternal_master_table.state_id  where financial_year='".$data_val['financial_year']."' and quarter='".$data_val['quarter']."' AND ".$idWithoutAs." !='' AND ".$idWithoutAs." !='0' order by m_state.State_Name ";
	
		return $this->db->query($qry)->result_array();  
	}
	
	if($id == "institutedelivery as 'Number of Institutional delivery',estimate_pregnancy_id as 'Total estimated pregnancy for Institutional delivery',institutedelivery_id as '% of Institutional delivery'"){
		
		$qry="SELECT State_Name,".$id." FROM maternal_master_table inner join m_state on m_state.State_ID=
    maternal_master_table.state_id  where financial_year='".$data_val['financial_year']."' and quarter='".$data_val['quarter']."' AND ".$idWithoutAs." !='' AND ".$idWithoutAs." !='0' order by m_state.State_Name ";
	
		return $this->db->query($qry)->result_array();  
	}
	
	if($id == "anccheckup as 'Number of 4 or more ANC checkup',estimate_pregnancy_anc as 'Total estimated pregnancy for 4 or more ANC checkup',anccheckup_anc as '% 4 or more ANC checkup'"){
		
		$qry="SELECT State_Name,".$id." FROM maternal_master_table inner join m_state on m_state.State_ID=
    maternal_master_table.state_id  where financial_year='".$data_val['financial_year']."' and quarter='".$data_val['quarter']."' AND ".$idWithoutAs." !='' AND ".$idWithoutAs." !='0' order by m_state.State_Name ";
	
		return $this->db->query($qry)->result_array();  
	}
	
	if($id == "noofanc as 'Number ANCs conducted under Pradhan Mantri Surakshit Matritva Abhiyan (PMSMA)'"){
		
		$qry="SELECT State_Name,".$id." FROM maternal_master_table inner join m_state on m_state.State_ID=
    maternal_master_table.state_id  where financial_year='".$data_val['financial_year']."' and quarter='".$data_val['quarter']."' AND ".$idWithoutAs." !='' AND ".$idWithoutAs." !='0' order by m_state.State_Name ";
	
		return $this->db->query($qry)->result_array();  
	}
	
	if($id == "public_health_facilites_no as 'Number of Public Health facilities selected under LaQshya'" ){
	
		$qry="SELECT State_Name,".$id." FROM maternal_laqshya_master_table inner join m_state on m_state.State_ID=
    maternal_laqshya_master_table.state_id  where financial_year='".$data_val1['financial_year']."' and quarter='".$data_val1['quarter']."' AND ".$idWithoutAs." !='' AND ".$idWithoutAs." !='0' order by m_state.State_Name ";
	
		return $this->db->query($qry)->result_array();  
	}
	if($id == "lr_and_ot_state as 'Number of Labour Rooms and Operation Theatres (OT) State Certified under LaQshya'" ){
		
		$qry="SELECT State_Name,".$id." FROM maternal_laqshya_master_table inner join m_state on m_state.State_ID=
    maternal_laqshya_master_table.state_id  where financial_year='".$data_val1['financial_year']."' and quarter='".$data_val1['quarter']."' AND ".$idWithoutAs." !='' AND ".$idWithoutAs." !='0' order by m_state.State_Name ";
		
   
		return $this->db->query($qry)->result_array();  
	}
	if($id == "lr_and_ot_national as 'Number of Labour Rooms(LR) and Operation Theatres(OT) Nationally Certified under LaQshya'" ){
		
		$qry="SELECT State_Name,".$id." FROM maternal_laqshya_master_table inner join m_state on m_state.State_ID=
    maternal_laqshya_master_table.state_id  where financial_year='".$data_val1['financial_year']."' and quarter='".$data_val1['quarter']."' AND ".$idWithoutAs." !='' AND ".$idWithoutAs." !='0' order by m_state.State_Name ";
   
		return $this->db->query($qry)->result_array();  
	}
	
    
} 







}

