<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Ncdc_model extends CI_Model 
{

    public function __construct() {
        parent::__construct();
		ini_set('display_errors', 0);
    }
    public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `ncdc_leased_table`  order by year desc,e_quarter desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}
  public function get_total_kpi_val1(){
    
    $qry="SELECT * FROM `ncdc_master_table` order by year desc,e_quarter desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}
  public function get_total_kpi_val2(){
    
    $qry="SELECT * FROM `ncdc_money_table` order by year desc,e_quarter desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}
  public function get_total_kpi_val3(){
    
    $qry="SELECT * FROM `ncdc_stone_table` order by year desc,e_quarter desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}
/*public function get_total_kpi()
{
    $qry="SELECT concat('Name of Section/Division :',(SELECT (Name_Of_Section) FROM atr_master_tbl),',Pending ATR on PMO References :',SELECT (sum(atrpending_pmoreference) FROM atr_master_tbl),',Pending VIP References :',(SELECT count(devesion) FROM atr2_master_tbl),',Parliament Assurances : ',(SELECT count(Name_Section) FROM atr3_master_tbl)) as total_kpi" ;
    return $this->db->query($qry)->row_array();
}*/

public function get_total_kpi()
{
	$data_val=$this->get_total_kpi_val();
    $data_val1=$this->get_total_kpi_val1();
    $data_val2=$this->get_total_kpi_val2();
    $data_val3=$this->get_total_kpi_val3();
    $qry="SELECT concat('MOU Signed Between Govt of India And State Govt :',(SELECT count(date) FROM  ncdc_master_table where year='".$data_val1['year']."' and e_quarter='".$data_val1['e_quarter']."'),',Lease Deed Signed/Land Transfered:',(SELECT count(date) FROM ncdc_leased_table where year='".$data_val['year']."' and e_quarter='".$data_val['e_quarter']."'),',Money Released for Construction of Branch(Rupees In LAKH):',(SELECT sum(amount) FROM ncdc_money_table where year='".$data_val2['year']."' and e_quarter='".$data_val1['e_quarter']."')) as total_kpi" ;
    return $this->db->query($qry)->row_array();
}

public function get_total_header()
{
    $qry="SELECT sum(atrpending_pmoreference) as header_count,
    'Pending ATR on PMO References' as header_title FROM `art_master_tbl`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_array_kpi()
{
    return array("date as 'MOU Signed Between Govt of India And State Govt'","type as 'Lease Deed Signed/Land Transferred'", "amount as 'Money Released Ror Construnction of Branches'" );
}

public function get_table_kpi_data($id){

    $data_val=$this->get_total_kpi_val();
    $data_val1=$this->get_total_kpi_val1();
    $data_val2=$this->get_total_kpi_val2();
    $data_val3=$this->get_total_kpi_val3();

/*$qry2 = array("date"=>"Date","ncdc_stone_table.date"=>"Date",
    "amount"=>"Amount", "type"=>"Land Status"
     
);*/ 
                  
      //  $alias_val=$qry2[$id];  

    if($id=="date as 'MOU Signed Between Govt of India And State Govt'"){
        

        $qry="SELECT State_Name, DATE_FORMAT(date,'%d/%m/%Y') as 'MOU Signed Between Govt of India And State Govt' FROM ncdc_master_table inner join m_state on m_state.State_ID=ncdc_master_table.state  where year='".$data_val1['year']."' and e_quarter='".$data_val1['e_quarter']."' group by ncdc_master_table.state order by m_state.state_id desc ";
    return $this->db->query($qry)->result_array(); 
        }
		
		

        if($id=="type as 'Lease Deed Signed/Land Transferred'"){
			
         $qry="SELECT  State_Name,".$id." FROM ncdc_leased_table inner join m_state on m_state.State_ID=
    ncdc_leased_table.state where year='".$data_val['year']."' and e_quarter='".$data_val['e_quarter']."' group by ncdc_leased_table.state";
         return $this->db->query($qry)->result_array(); 
 }
		
		 if($id=="ncdc_stone_table.date as 'FOUNDATION STONE LAID'"){ 

         $qry="SELECT State_Name,".$id." FROM ncdc_stone_table inner join m_state on m_state.State_ID=
    ncdc_stone_table.state  where year='".$data_val3['year']."' and e_quarter='".$data_val3['e_quarter']."'  group by ncdc_stone_table.state";
    return $this->db->query($qry)->result_array(); 
        }
        
      
       if($id=="amount as 'Money Released Ror Construnction of Branches'"){ 

        $qry="SELECT State_Name,".$id." FROM ncdc_money_table inner join m_state on m_state.State_ID=
    ncdc_money_table.state where year='".$data_val2['year']."' and e_quarter='".$data_val2['e_quarter']."'  order by ncdc_money_table.state ";
         return $this->db->query($qry)->result_array(); 
      }
              
    } 


}

