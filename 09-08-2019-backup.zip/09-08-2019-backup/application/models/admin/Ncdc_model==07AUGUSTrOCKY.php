<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Ncdc_model extends CI_Model 
{

    public function __construct() {
        parent::__construct();
		ini_set('display_errors', 0);
    }
	
	public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `ncdc_master_table` where year <= '".getCurrFinYear()."' and e_quarter <= '".getCurrQuarter()."' order by year desc,e_quarter desc LIMIT 1"; 

    $row = $this->db->query($qry)->row_array();
    //print_r($row);
    if(empty($row)) {

      $qry="SELECT * FROM `ncdc_master_table` where year < '".getCurrFinYear()."' order by year desc,e_quarter desc LIMIT 1"; 

       $row = $this->db->query($qry)->row_array();
        //echo "Inner condition"; print_r($row);
    }

    return $row;
}


	public function get_total_kpi_val1(){
    
    $qry="SELECT * FROM `ncdc_leased_table` where year <= '".getCurrFinYear()."' and e_quarter <= '".getCurrQuarter()."' order by year desc,e_quarter desc LIMIT 1"; 

    $row = $this->db->query($qry)->row_array();
    //print_r($row);
    if(empty($row)) {

      $qry="SELECT * FROM `ncdc_leased_table` where year < '".getCurrFinYear()."' order by year desc,e_quarter desc LIMIT 1"; 

       $row = $this->db->query($qry)->row_array();
        //echo "Inner condition"; print_r($row);
    }

    return $row;
}

public function get_total_kpi_val2(){
    
    $qry="SELECT * FROM `ncdc_money_table` where year <= '".getCurrFinYear()."' and e_quarter <= '".getCurrQuarter()."' order by year desc,e_quarter desc LIMIT 1"; 

    $row = $this->db->query($qry)->row_array();
    //print_r($row);
    if(empty($row)) {

      $qry="SELECT * FROM `ncdc_money_table` where year < '".getCurrFinYear()."' order by year desc,e_quarter desc LIMIT 1"; 

       $row = $this->db->query($qry)->row_array();
        //echo "Inner condition"; print_r($row);
    }

    return $row;
}

public function  getSumFieldValue($field, $table, $where =''){    
    
     $qry="SELECT sum(". $field.") as sum_". $field.", 
          SUM(IF(". $field."='' || ". $field."='0', 1,0)) as count_". $field.",
        count(*) as total_count
      FROM ".$table." " . $where; 
      
      
     $val= $this->db->query($qry)->row_array();  
     
     if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
        return 'N/E';
     }
     else if($val['total_count']==0)
     {
        return 'N/E'; 
     }
     else {
        return $val["sum_".$field]; 
     }     
}

public function  getCountFieldValue($field, $table, $where =''){    
    
     $qry="SELECT count(". $field.") as sum_". $field.", 
          count(IF(". $field."='' || ". $field."='0', 1,0)) as count_". $field.",
        count(*) as total_count
      FROM ".$table." " . $where; 
      
      
     $val= $this->db->query($qry)->row_array();  
     
     if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
        return 'N/E';
     }
     else if($val['total_count']==0)
     {
        return 'N/E'; 
     }
     else {
        return $val["sum_".$field]; 
     }     
}


public function get_total_kpi()
{ 


     $data_val=$this->get_total_kpi_val();
    $data_val1=$this->get_total_kpi_val1();
    $data_val2=$this->get_total_kpi_val2();



     $table = 'ncdc_master_table';
     $where = "where year='".$data_val['year']."' and e_quarter='".$data_val['e_quarter']."' ";
	 
	 $table1 = 'ncdc_leased_table';
     $where1 = "where year='".$data_val1['year']."' and e_quarter='".$data_val1['e_quarter']."' ";
	 
	 $table2 = 'ncdc_money_table';
     $where2 = "where year='".$data_val2['year']."' and e_quarter='".$data_val2['e_quarter']."' ";
     
     $total_kpi = array(); 
      
     //$value1 = $this->getSumFieldValue('date', $table, $where);  
     $value1 = $this->getCountFieldValue('date', $table, $where);
     $value2 = $this->getCountFieldValue('typess', $table1, $where1);
     $value3 = $this->getSumFieldValue('amount', $table2, $where2);	 
          
     $total_kpi[]= 'MOU Signed Between Govt of India And State Govt: '.$value1;
	 
	 $total_kpi[]= 'Lease Deed Signed/Land Transfered: '.$value2;
	 
	 $total_kpi[]= 'Money Released For Construction of Branches: '.$value3;


     /* $value1 = $this->getSumFieldValue('No_of_functional_blood_banks', $table, $where);
         
     $value2 = $this->getSumFieldValue('No_of_functional_fru', $table, $where);     
          
     $total_kpi[]= 'No. of functional Blood Banks/ Blood Storage Units (against no of functional FRUs): '.$value1.'/'.$value2;
*/
     
     $data['total_kpi'] = implode(',',$total_kpi);
	 
	// print_r($data); die;
        
     return $data;
}

   /* public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `ncdc_leased_table`  order by year desc,e_quarter desc LIMIT 1";
    return $this->db->query($qry)->row_array();
} */
  /* public function get_total_kpi_val1(){
    
    $qry="SELECT * FROM `ncdc_master_table` order by year desc,e_quarter desc LIMIT 1";
    return $this->db->query($qry)->row_array();
} */
/*   public function get_total_kpi_val2(){
    
    $qry="SELECT * FROM `ncdc_money_table` order by year desc,e_quarter desc LIMIT 1";
    return $this->db->query($qry)->row_array();
} */
 /* public function get_total_kpi_val3(){
    
    $qry="SELECT * FROM `ncdc_stone_table` order by year desc,e_quarter desc LIMIT 1";
    return $this->db->query($qry)->row_array();
} */
/*public function get_total_kpi()
{
    $qry="SELECT concat('Name of Section/Division :',(SELECT (Name_Of_Section) FROM atr_master_tbl),',Pending ATR on PMO References :',SELECT (sum(atrpending_pmoreference) FROM atr_master_tbl),',Pending VIP References :',(SELECT count(devesion) FROM atr2_master_tbl),',Parliament Assurances : ',(SELECT count(Name_Section) FROM atr3_master_tbl)) as total_kpi" ;
    return $this->db->query($qry)->row_array();
}*/

/* public function get_total_kpi()
{
	$data_val=$this->get_total_kpi_val();
    $data_val1=$this->get_total_kpi_val1();
    $data_val2=$this->get_total_kpi_val2();
    $data_val3=$this->get_total_kpi_val3();
    $qry="SELECT concat('MOU Signed Between Govt of India And State Govt :',(SELECT count(date) FROM  ncdc_master_table where year='".$data_val1['year']."' and e_quarter='".$data_val1['e_quarter']."'),',Lease Deed Signed/Land Transfered:',(SELECT count(date) FROM ncdc_leased_table where year='".$data_val['year']."' and e_quarter='".$data_val['e_quarter']."'),',Money Released for Construction of Branch(Rupees In LAKH):',(SELECT sum(amount) FROM ncdc_money_table where year='".$data_val2['year']."' and e_quarter='".$data_val1['e_quarter']."')) as total_kpi" ;
    return $this->db->query($qry)->row_array();
} */

public function get_total_header()
{
    $qry="SELECT sum(atrpending_pmoreference) as header_count,
    'Pending ATR on PMO References' as header_title FROM `art_master_tbl`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_array_kpi()
{
    return array("date as 'MOU Signed Between Govt of India And State Govt'","typess as 'Lease Deed Signed/Land Transferred'","amount as 'Money Released For Construction of Branches'" );
}

public function get_table_kpi_data($id){

    $data_val=$this->get_total_kpi_val();
    $data_val1=$this->get_total_kpi_val1();
    $data_val2=$this->get_total_kpi_val2();
   // $data_val3=$this->get_total_kpi_val3();

/*$qry2 = array("date"=>"Date","ncdc_stone_table.date"=>"Date",
    "amount"=>"Amount", "type"=>"Land Status"
     
);*/ 
                  
      //  $alias_val=$qry2[$id];  

   if($id=="date as 'MOU Signed Between Govt of India And State Govt'"){
        

        $qry="SELECT State_Name, date as 'MOU Signed Between Govt of India And State Govt' FROM ncdc_master_table inner join m_state on m_state.State_ID=ncdc_master_table.state  where year='".$data_val['year']."' and e_quarter='".$data_val['e_quarter']."' group by ncdc_master_table.state order by m_state.State_Name ";
    return $this->db->query($qry)->result_array(); 
	
		 
        } 
		
		

         if($id=="typess as 'Lease Deed Signed/Land Transferred'"){
			
         $qry="SELECT  State_Name,".$id." FROM ncdc_leased_table inner join m_state on m_state.State_ID=
    ncdc_leased_table.state where year='".$data_val['year']."' and e_quarter='".$data_val['e_quarter']."' group by ncdc_leased_table.state order by m_state.State_Name";
         return $this->db->query($qry)->result_array(); 
 } 
		
		/*  if($id=="ncdc_stone_table.date as 'FOUNDATION STONE LAID'"){ 

         $qry="SELECT State_Name,".$id." FROM ncdc_stone_table inner join m_state on m_state.State_ID=
    ncdc_stone_table.state  where year='".$data_val3['year']."' and e_quarter='".$data_val3['e_quarter']."'  group by ncdc_stone_table.state";
    return $this->db->query($qry)->result_array(); 
        } */
        
      
       if($id=="amount as 'Money Released For Construction of Branches'"){ 

        $qry="SELECT State_Name,".$id." FROM ncdc_money_table inner join m_state on m_state.State_ID=
    ncdc_money_table.state where year='".$data_val2['year']."' and e_quarter='".$data_val2['e_quarter']."' group by ncdc_money_table.state order by m_state.State_Name ";
         return $this->db->query($qry)->result_array(); 
      } 
       
 
		 
    } 


}

