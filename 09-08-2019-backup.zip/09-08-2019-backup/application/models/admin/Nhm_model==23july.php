<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Nhm_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
public function get_table_data_map(){
    
    $qry="select * from nhm_master_table ";
    return $this->db->query($qry)->result_array();   
}

public function totalGrant(){
    
    $qry="select sum(grant_release) as grant_release from nhm_master_table ";
    return $this->db->query($qry)->row_array();   
}





public function get_total_kpi(){

    // $qry="SELECT concat('No of districts with functional dialysis units/Total districts : ',sum(No_of_districts_with_functional_dialysis_units), ' / ',sum(units_against_the_total_districts),',No of patients receiving treatment sessions held under PMNDP : ' , sum(No_of_patients_receiving_treatment)) as total_kpi FROM `hidialysis_master_tbl`  ";

     $qry="SELECT concat('Grants Released against Central share earmarked for the State/UTs under NHM : ',sum(grant_release), ' / ',sum(central_share)) as total_kpi FROM `nhm_master_table`  ";
    return $this->db->query($qry)->row_array();

}

public function get_total_header(){
    $qry="SELECT sum(grant_release), ' / ',sum(central_share) as header_count,'Grants Released against Central share earmarked for the State/UTs under NHM' as header_title FROM `nhm_master_table`  ";
    return $this->db->query($qry)->row_array();   
}




public function get_array_kpi(){

    $qry =  array("grant_release,central_share");
   
    return $qry;
}

public function get_table_kpi_data($id){
   
   $lst = explode(",", $id);


   if(count($lst) > 1)
   {
    $id1 = $lst[0];
    $id2 = $lst[1];
   // $id3 = $id1.'/'.$id2;
    
    $qry="SELECT State_Name,concat(SUM(".$id1."),'/',SUM(".$id2.")) AS 'Grants Released against Central share earmarked for the State/UTs under NHM'  FROM nhm_master_table inner join m_state on m_state.State_Name = nhm_master_table.statename  group by nhm_master_table.statename ";
   
   }
    else{
     $qry="SELECT State_Name,SUM(".$id.") AS 'Grants Released against Central share earmarked for the State/UTs under NHM' FROM nhm_master_table inner join m_state on m_state.State_Name = nhm_master_table.statename  group by nhm_master_table.statename ";
   }
   
   return $this->db->query($qry)->result_array();   


}



}