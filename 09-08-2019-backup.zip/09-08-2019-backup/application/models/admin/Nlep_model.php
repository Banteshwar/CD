<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Nlep_model extends CI_Model 
{

    public function __construct() 
    {
        parent::__construct();
    }
    

   

public function  getSumFieldValue($field, $table, $where =''){    
    
     $qry="SELECT sum(". $field.") as sum_". $field.", 
          SUM(IF(". $field."='', 1,0)) as count_". $field.",
        count(*) as total_count
      FROM ".$table." " . $where; 
      
      
     $val= $this->db->query($qry)->row_array();  
     
     if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
        return 'N/E';
     }
     else if(empty($val['total_count']))
	 {
		return 'N/E'; 
	 }
     else {
        return $val["sum_".$field]; 
     }     
} 



public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `nlep_master_table` where year <= '".getCurrFinYear()."' and Quarterly <= '".getCurrQuarter('Quarterly')."' order by year desc,Quarterly desc LIMIT 1"; 

    $row = $this->db->query($qry)->row_array();
    
    if(empty($row)) {

      $qry="SELECT * FROM `nlep_master_table` where year < '".getCurrFinYear()."' order by year desc,Quarterly desc LIMIT 1"; 
       $row = $this->db->query($qry)->row_array();        
    }
    return $row;
}

    

public function get_total_kpi()
{ 
     $data_val=$this->get_total_kpi_val();
    
     $table = 'nlep_master_table';
     $where = "where year='".$data_val['year']."' and Quarterly='".$data_val['Quarterly']."' ";
     
     $total_kpi = array(); 
      
	  
	 $value1 = $this->getSumFieldValue('cases_on_record', $table, $where);
    
          
     if($value1=='N/E'){
        
         $total_kpi[]= 'Cases on Record: N/E';

     }else{
        $total_kpi[]= 'Cases on Record: '.$value1;

     } 
	 
	  $value1 = $this->getSumFieldValue('new_cases', $table, $where);
    
          
     if($value1=='N/E'){
        
        $total_kpi[]= 'New Cases Detected: N/E';

     }else{
        $total_kpi[]= 'New Cases Detected: '.$value1;

     } 

     $value1 = $this->getSumFieldValue('G2D_Male_cases', $table, $where);
         
     $value2 = $this->getSumFieldValue('new_cases', $table, $where);  
	 
     $cal1 = ROUND((($value1/$value2)*100),2); 
     
     if($value1=='N/E' || $value2=='N/E'){
        
         $total_kpi[]= 'Grade II Disability (G2D) cases (Percentage in New Cases): N/E';

     }else{
        $total_kpi[]= 'Grade II Disability (G2D) cases (Percentage in New Cases): '.$cal1;

     }

      $value1 = $this->getSumFieldValue('G2D_FeMale_cases', $table, $where);
         
     $value2 = $this->getSumFieldValue('new_cases', $table, $where);  
	 
     $cal1 = ROUND((($value1/$value2)*100),2); 
     
     if($value1=='N/E' || $value2=='N/E'){
        
         $total_kpi[]= 'No. of Female Cases (Percentage in New cases): N/E';

     }else{
        $total_kpi[]= 'No. of Female Cases (Percentage in New cases): '.$cal1;

     }
	 
	   $value1 = $this->getSumFieldValue('G2D_Child_cases', $table, $where);
         
     $value2 = $this->getSumFieldValue('new_cases', $table, $where);  
	 
     $cal1 = ROUND((($value1/$value2)*100),2); 
     
     if($value1=='N/E' || $value2=='N/E'){
        
         $total_kpi[]= 'No. of Child Cases (Percentage in New cases): N/E';

     }else{
        $total_kpi[]= 'No. of Child Cases (Percentage in New cases): '.$cal1;

     }
	 
	 $value1 = $this->getSumFieldValue('Re_Constructive_Surgeries', $table, $where);
    
          
     if($value1=='N/E'){
        
         $total_kpi[]= 'Re-Constructive Surgeries (RCS) conducted: N/E';

     }else{
        $total_kpi[]= 'Re-Constructive Surgeries (RCS) conducted: '.$value1;

     } 
	 
	  $value1 = $this->getSumFieldValue('mcr_footwear', $table, $where);
    
          
     if($value1=='N/E'){
        
         $total_kpi[]= 'MCR footwear distributed: N/E';

     }else{
        $total_kpi[]= 'MCR footwear distributed: '.$value1;

     } 
	 
	  $value1 = $this->getSumFieldValue('self_kits', $table, $where);
    
          
     if($value1=='N/E'){
        
         $total_kpi[]= 'Self care kits distributed: N/E';

     }else{
        $total_kpi[]= 'Self care kits distributed: '.$value1;

     } 
	 
	 $value1 = $this->getSumFieldValue('Total_No_districts_ABSULS', $table, $where);
    
          
     if($value1=='N/E'){
        
         $total_kpi[]= 'Total No. of districts in ABSULS: N/E';

     }else{
        $total_kpi[]= 'Total No. of districts in ABSULS: '.$value1;

     } 
	 
	 $value1 = $this->getSumFieldValue('No_districts_implemented_ABSULS', $table, $where);
    
          
     if($value1=='N/E'){
        
         $total_kpi[]= 'Total No. of districts implemented ABSULS: N/E';

     }else{
        $total_kpi[]= 'Total No. of districts implemented ABSULS: '.$value1;

     } 
	 
	  $value1 = $this->getSumFieldValue('No_Suspects_identified_ABSULS', $table, $where);
    
          
     if($value1=='N/E'){
        
         $total_kpi[]= 'Total No. of Suspects identified in ABSULS: N/E';

     }else{
        $total_kpi[]= 'Total No. of Suspects identified in ABSULS: '.$value1;

     } 
	 
	  $value1 = $this->getSumFieldValue('No_Suspects_referred_ABSULS', $table, $where);
    
          
     if($value1=='N/E'){
        
         $total_kpi[]= 'Total No. of Suspects referred in ABSULS: N/E';

     }else{
        $total_kpi[]= 'Total No. of Suspects referred in ABSULS: '.$value1;

     } 
	 
	/* $value1 = $this->getSumFieldValue('Total_No_districts_ABSULS', $table, $where);
	 $value2 = $this->getSumFieldValue('No_districts_implemented_ABSULS', $table, $where);
	 $value3 = $this->getSumFieldValue('No_Suspects_identified_ABSULS', $table, $where);
	 $value4 = $this->getSumFieldValue('No_Suspects_referred_ABSULS', $table, $where);
     $val    = $value1 + $value2 + $value3 + $value4; 
          
     if($val=='N/E'){
        
         $total_kpi[]= 'ASHA based Surveillance for Leprosy Suspects (ABSULS): N/E';

     }else{
        $total_kpi[]= 'ASHA based Surveillance for Leprosy Suspects (ABSULS): '.$val;

     }*/
	 $value1 = $this->getSumFieldValue('No_G2D_cases_detected', $table, $where);
	       
     if($value1=='N/E'){
        
         $total_kpi[]= 'No. of G2D cases detected: N/E';

     }else{
        $total_kpi[]= 'No. of G2D cases detected: '.$value1;

     } 
	 
	  $value1 = $this->getSumFieldValue('No_G2D_investigations_done', $table, $where);
	       
     if($value1=='N/E'){
        
         $total_kpi[]= 'No. of G2D investigations done: N/E';

     }else{
        $total_kpi[]= 'No. of G2D investigations done: '.$value1;

     } 
	 
	  /*$value1 = $this->getSumFieldValue('No_G2D_cases_detected', $table, $where);
         
      $value2 = $this->getSumFieldValue('No_G2D_investigations_done', $table, $where);     
          
     if($value1=='N/E' || $value2=='N/E'){
        $total_kpi[]= 'Grade II Disability (G2D) case investigation: N/E';

     }else{
        $total_kpi[]= 'Grade II Disability (G2D) case investigation: '.$value1.'/'.$value2;

     }*/  
	 
     $data['total_kpi'] = implode(',',$total_kpi);
        
     return str_replace('N/E/N/E','N/E',$data);
}
   
   
   

    public function get_array_kpi()
    {
        $qry =  
        array("cases_on_record as 'Cases on Record'","new_cases as 'New Cases Detected'","G2D_Male_cases as 'No. of G2D cases',new_cases as 'New Cases Detected',G2D_Male_cases_percentage as 'Grade II Disability (G2D) cases(in Percentage)'","G2D_FeMale_cases as 'No. of Female Cases',new_cases as 'New Cases Detected',G2D_FeMale_cases_percentage as 'Female Cases (in Percentage)'", "G2D_Child_cases as 'No. of Child Cases',new_cases as 'New Cases Detected',G2D_Child_cases_percentage as 'Child Cases (in Percentage)'","Re_Constructive_Surgeries as 'Re-Constructive Surgeries (RCS) conducted'", "mcr_footwear as 'MCR footwear distributed'", "self_kits as 'Self care kits distributed'", "Total_No_districts_ABSULS as 'Total No. of districts in ABSULS'" ,"No_districts_implemented_ABSULS as 'No. of districts implemented ABSULS'","No_Suspects_identified_ABSULS as 'No. of suspects identified in ABSULS'","No_Suspects_referred_ABSULS as 'No. of suspects referred in ABSULS'", "No_G2D_cases_detected as 'No. of G2D cases detected'","No_G2D_investigations_done as 'No. of G2D investigations done'");
        return $qry;
    }

    public function get_table_kpi_data($id)
    {
    /*$data_val=$this->get_total_kpi_val();
    
    $qry="SELECT State_Name, ".$id." FROM nlep_master_table inner join m_state on m_state.State_ID=
    nlep_master_table.state_id where  year='".$data_val['year']."' and Quarterly ='".$data_val['Quarterly']."'  order by m_state.State_Name ";
   
    return $this->db->query($qry)->result_array();*/

	$data_val=$this->get_total_kpi_val();
     
    $idWithoutAs = substr($id, 0, stripos($id, "as "));
    
    $qry="SELECT State_Name,".$id." FROM nlep_master_table inner join m_state on m_state.State_ID=
    nlep_master_table.state_id  where year='".$data_val['year']."' and Quarterly='".$data_val['Quarterly']."' AND ".$idWithoutAs." !='' AND ".$idWithoutAs." !='0' order by m_state.State_Name ";
    
    return $this->db->query($qry)->result_array();


	
    }

    
   
}

