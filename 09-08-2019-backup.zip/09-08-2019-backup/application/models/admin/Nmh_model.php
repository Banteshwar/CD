<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Nmh_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    


public function get_total_kpi_val(){    
    $qry="SELECT * FROM `tbl_cmha`  order by year desc,month desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}

public function get_total_kpi_valdmhp(){
    
    $qry="SELECT * FROM `tbl_dmhp`  order by e_year desc,e_quarter desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}


public function get_total_kpi(){
    $data_val  = $this->get_total_kpi_val();
    $data_val1 = $this->get_total_kpi_valdmhp();

    $qry="SELECT concat('Number of Patients treated in OPD : ',(SELECT sum(patient_treated_opd) FROM tbl_cmha where year='".$data_val['year']."' and month='".$data_val['month']."'),' ,Number of Patients treated in IPD : ',(SELECT sum(patient_treated_ipd) FROM tbl_cmha where year='".$data_val['year']."' and month='".$data_val['month']."'),',Number of Professionals trained under Digital Academy : ' ,(SELECT sum(medical_officers+psychologists+social_workers+nurses) FROM tbl_cmha where year='".$data_val['year']."' and month='".$data_val['month']."'),',Number of Districts Covered under DMHP up to the year ".$data_val1['e_year']." :',sum(num_district_cover),' ,Funds sanctioned under ROP for the year ".$data_val1['e_year']." (In Rs. lakhs) : ', sum(fund),' ,Expenditure incurred up to ".$data_val1['e_quarter']." quarter of ".$data_val1['e_year']." (In Rs. lakhs) : ' ,sum(expenditure)) as total_kpi FROM `tbl_dmhp` where e_year='".$data_val1['e_year']."' and e_quarter='".$data_val1['e_quarter']."'  ";
    return $this->db->query($qry)->row_array();
}



public function get_array_kpi(){
    $data_val1 = $this->get_total_kpi_valdmhp();

    $qry =  array("cmha_institute_name.name as 'Hospital Name' , patient_treated_opd as 'Number of Patients treated in OPD'","patient_treated_ipd as 'Number of Patients treated in IPD'","cmha_institute_name.name as 'Hospital Name' , medical_officers as 'Medical Officers under Digital Academy', psychologists as 'Psychologists under Digital Academy', social_workers as 'Social Workers under Digital Academy', nurses as 'Nurses under Digital Academy'","num_district_cover as 'Number of Districts Covered under DMHP up to the year ".$data_val1['e_year']."' " , "fund as 'Funds sanctioned under ROP for the year ".$data_val1['e_year']." (In Rs. lakhs)'","expenditure as 'Expenditure incurred up to ".$data_val1['e_quarter']." quarter of ".$data_val1['e_year']." (In Rs. lakhs)'");
   
    return $qry;
}




public function get_table_kpi_data($id){
   
    $data_val=$this->get_total_kpi_val();
    $data_val1 = $this->get_total_kpi_valdmhp();

    if($id == "cmha_institute_name.name as 'Hospital Name' , patient_treated_opd as 'Number of Patients treated in OPD'"){

     $qry="SELECT ".$id." FROM tbl_cmha inner join cmha_institute_name on cmha_institute_name.inst_id=
        tbl_cmha.instituteid where  year='".$data_val['year']."' and month ='".$data_val['month']."' GROUP by tbl_cmha.instituteid order by cmha_institute_name.name ";
		
         return $this->db->query($qry)->result_array();  
    }
    if($id == "patient_treated_ipd as 'Number of Patients treated in IPD'"){
        
        $qry="SELECT name as `Hospital Name`, ".$id." FROM tbl_cmha inner join cmha_institute_name on cmha_institute_name.inst_id=
        tbl_cmha.instituteid where  year='".$data_val['year']."' and month ='".$data_val['month']."' GROUP by tbl_cmha.instituteid order by cmha_institute_name.name ";
         return $this->db->query($qry)->result_array();  
    }
    if($id == "cmha_institute_name.name as 'Hospital Name' , medical_officers as 'Medical Officers under Digital Academy', psychologists as 'Psychologists under Digital Academy', social_workers as 'Social Workers under Digital Academy', nurses as 'Nurses under Digital Academy'"){
        
        $qry="SELECT ".$id." FROM tbl_cmha inner join cmha_institute_name on cmha_institute_name.inst_id=
        tbl_cmha.instituteid where  year='".$data_val['year']."' and month ='".$data_val['month']."' GROUP by tbl_cmha.instituteid  order by cmha_institute_name.name";
         return $this->db->query($qry)->result_array();  
    }
    if($id == "num_district_cover as 'Number of Districts Covered under DMHP up to the year ".$data_val1['e_year']."' "){
        
         $qry="SELECT State_Name, ".$id." FROM tbl_dmhp inner join m_state on m_state.State_ID=
    tbl_dmhp.statename where  e_year='".$data_val1['e_year']."' and e_quarter ='".$data_val1['e_quarter']."' GROUP by tbl_dmhp.statename order by m_state.State_Name  ";
    return $this->db->query($qry)->result_array();  
    
    }
    if($id == "fund as 'Funds sanctioned under ROP for the year ".$data_val1['e_year']." (In Rs. lakhs)'"){
        
         $qry="SELECT State_Name, ".$id." FROM tbl_dmhp inner join m_state on m_state.State_ID=
    tbl_dmhp.statename where  e_year='".$data_val1['e_year']."' and e_quarter ='".$data_val1['e_quarter']."' GROUP by tbl_dmhp.statename order by m_state.State_Name ";
    return $this->db->query($qry)->result_array();  
    
    }
    if($id == "expenditure as 'Expenditure incurred up to ".$data_val1['e_quarter']." quarter of ".$data_val1['e_year']." (In Rs. lakhs)'"){
        
         $qry="SELECT State_Name, ".$id." FROM tbl_dmhp inner join m_state on m_state.State_ID=
    tbl_dmhp.statename where  e_year='".$data_val1['e_year']."' and e_quarter ='".$data_val1['e_quarter']."' GROUP by tbl_dmhp.statename order by m_state.State_Name ";
    return $this->db->query($qry)->result_array();  
    
    }
    
   
    
}

   
}

