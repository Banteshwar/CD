<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Nmhp_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
/*public function get_map_data(){

    $qry="SELECT concat('Model Treatment Center : ',Model_Treatment_Center_Target,',No of District : ',Number_of_Districts,',Treatment Center : ',Total_No_of_TC,',Patient Treatment : ',Patient_on_treatment) AS hover,'Patient Treatment Successfully : ',Patient_Successfully_Treated,'Percentage of newborns : ',Newborns_Received, state_id FROM `nvhcp_master_table` order by state_id";
    return $this->db->query($qry)->result_array();

}

public function get_totalRecordNVHCPs(){ 
    $this->db->select('SUM( Model_Treatment_Center_Target ) as mt , SUM(Model_Treatment_Center_Achieved) as ma , SUM(Number_of_Districts) as nd , SUM( Number_of_Districts ) as dtc , SUM(Total_No_of_TC) as tc , SUM( Patient_on_treatment ) as pt , SUM(Patient_Successfully_Treated) as pst , SUM( Institutional_Deliveries ) as id , SUM( Newborns_Received ) as nr ');
    $this->db->from('nvhcp_master_table');
    
    $this->db->order_by("nvhcp_master_table.id", "desc");

    $query = $this->db->get();

    return $query->row_array();  
}

public function get_total_header(){
    $qry="SELECT sum(Model_Treatment_Center_Target)  as header_count,'Model Treatment Centres' as header_title FROM `nvhcp_master_table`  ";
    return $this->db->query($qry)->row_array();   
}*/

public function get_total_kpi(){

    $qry="SELECT concat('Number of Model Treatment Centres made functional against target : ',sum(Model_Treatment_Center_Target),' ,Number of districts with at least 1 treatment centre & number of treatment centres : ', sum(Number_of_Districts),' / ', sum(Total_No_of_TC),' ,Number of patients put on treatment for  Hepatitis C : ' ,sum(Patient_on_treatment),' , Number of Hepatitis C patients successfully treated : ',sum(Patient_Successfully_Treated),' ,Percentage of newborns receiving birth dose of Hepatitis B vaccine /against the number of Institutional deliveries : ',sum(Newborns_Received)) as total_kpi FROM `nvhcp_master_table`  ";
    return $this->db->query($qry)->row_array();

}

public function get_table_data(){
    $qry="SELECT state_id,Model_Treatment_Center_Target,Number_of_Districts,Total_No_of_TC,Patient_on_treatment,Patient_Successfully_Treated,Newborns_Received FROM tbl_dmhp order by statename ";
    return $this->db->query($qry)->result_array();   
}

public function get_table_header($table){
    $qry="describe $table  ";
    return $this->db->query($qry)->result_array();   
}

  


   
}

