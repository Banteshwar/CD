<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Nohp_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
public function get_map_data(){

    $qry="SELECT concat('Model Treatment Center : ',Model_Treatment_Center_Target,',No of District : ',Number_of_Districts,',Treatment Center : ',Total_No_of_TC,',Patient Treatment : ',Patient_on_treatment) AS hover,'Patient Treatment Successfully : ',Patient_Successfully_Treated,'Percentage of newborns : ',Newborns_Receiving_birth_dose_of_Hepatitis_B_vaccine, state_id FROM `nvhcp_master_table` order by state_id";
    return $this->db->query($qry)->result_array();

}

public function get_totalRecordNVHCPs(){ 
    $this->db->select('SUM( units_approved ) as mt , SUM(units_functional) as ma , SUM(against_approved_units) as nd');
    $this->db->from('nohp_master_table');
    
    $this->db->order_by("nohp_master_table.id", "desc");

    $query = $this->db->get();

    return $query->row_array();  
}

public function get_total_header(){
    $qry="SELECT sum(units_approved)  as header_count,'Model Treatment Centres' as header_title FROM `nohp_master_table`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_total_kpi(){

    $qry="SELECT concat('Number of dental care units approved at level of District Hospital and below : ',sum(units_approved),' ,Number of dental care units made functional : ', sum(units_functional),' ,Number of approved units : ' ,sum(against_approved_units)) as total_kpi FROM `nohp_master_table`  ";
    return $this->db->query($qry)->row_array();

}

public function get_table_data(){
    $qry="SELECT units_approved,units_functional,against_approved_units,e_year FROM nohp_master_table order by id desc ";
    return $this->db->query($qry)->result_array();   
}

public function get_table_header($table){
    $qry="describe $table  ";
    return $this->db->query($qry)->result_array();   
}

  


   
}

