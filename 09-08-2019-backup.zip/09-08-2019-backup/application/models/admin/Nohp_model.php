<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Nohp_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    

public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `nohp_master_table` where e_year <= '".getCurrYear('Yearly')."' order by e_year desc LIMIT 1"; 

    $row = $this->db->query($qry)->row_array();
   
    return $row;
}


public function  getSumFieldValue($field, $table, $where =''){    
    
     $qry="SELECT sum(". $field.") as sum_". $field.", 
          SUM(IF(". $field."='' , 1,0)) as count_". $field.",
        count(*) as total_count
      FROM ".$table." " . $where; 
      
      
     $val= $this->db->query($qry)->row_array();  
     
     if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
        return 'N/E';
     }else if(empty($val['total_count'])){
        return 'N/E'; 
     }else {
        return $val["sum_".$field]; 
     }     
}

public function get_total_kpi(){ 

     $data_val=$this->get_total_kpi_val(); 
    
     $table = 'nohp_master_table';
     $where = "where e_year='".$data_val['e_year']."' ";
     
     $total_kpi = array(); 
      
     $value1 = $this->getSumFieldValue('units_approved', $table, $where);             
     if($value1=='N/E'){        
         $total_kpi[] = 'Number of Dental Care Units Approved at Level of District Hospital and Below: N/E';
     }else{
        $total_kpi[]  = 'Number of Dental Care Units Approved at Level of District Hospital and Below: '.$value1;
     }
  
     $value2 = $this->getSumFieldValue('units_functional', $table, $where);     
          
     if($value2=='N/E'){
        $total_kpi[]= 'Number of Dental Care Units Made Functional: N/E';
     }else{
        $total_kpi[]= 'Number of Dental Care Units Made Functional: '.$value2;
     }

     $data['total_kpi'] = implode(',',$total_kpi);
        
     return str_replace('N/E/N/E','N/E',$data);
}

public function get_array_kpi(){

    $qry =  array("units_approved as 'Number of Dental Care Units Approved at Level of District Hospital and Below'","units_functional as 'Number of Dental Care Units Made Functional'");
   
    return $qry;
}

public function get_table_kpi_data($id){ 

    $data_val=$this->get_total_kpi_val();
     
    $idWithoutAs = substr($id, 0, stripos($id, "as "));
    
    $qry="SELECT State_Name,".$id." FROM nohp_master_table inner join m_state on m_state.State_ID=
    nohp_master_table.state_id  where e_year='".$data_val['e_year']."' AND ".$idWithoutAs." !='' AND ".$idWithoutAs." !='0' order by m_state.State_Name "; 
    return $this->db->query($qry)->result_array();     
}

}