<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Notto_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
public function get_state_data(){
    $qry="select State_Name,State_ID from m_state";
    return $this->db->query($qry)->result_array();
}
public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `notto_master_tbl` GROUP by state_id  order by year desc,month desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}

public function get_total_kpi(){
    $data_val=$this->get_total_kpi_val();
    $qry="SELECT concat('Hospitals for Organ And Tissue retrieval/transplantation and Eye Banks : ',sum(listoff_hospitals),' ,Number of Organ/Tissue Donors who have pledged for Organ and/or Tissue donation after death: ', sum(numberoff_organ_tissue),' ,Transplant trends in the country : ' , sum(transplant_trends_inthe_countery) ,', No. of Organ allocation on Central Registry : ',sum(noof_organ_allocation_on_central),' ,No. of Wait List Patients organ-wise : ', sum(noof_wait_list_patient)) as total_kpi FROM `notto_master_tbl` where year='".$data_val['year']."' and month='".$data_val['month']."' ";
    return $this->db->query($qry)->row_array();

}

public function get_total_header(){
    $qry="SELECT sum(listoff_hospitals)  as header_count,'Hospital Lists' as header_title FROM `notto_master_tbl`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_table_data(){
    $subqry="(SELECT State_Name FROM `m_state` where m_state.State_ID =state_id  limit 1) as state_name";
    $qry="SELECT State_Name,  listoff_hospitals,numberoff_organ_tissue,transplant_trends_inthe_countery,noof_organ_allocation_on_central,noof_wait_list_patient FROM notto_master_tbl inner join m_state on m_state.State_ID=
    notto_master_tbl.state_id  order by notto_master_tbl.state_id ";
    return $this->db->query($qry)->result_array();   
}





public function get_array_kpi(){

    $qry =  array("listoff_hospitals as 'List of Hospitals For organ And Tissue retrieval/Transplantation and Eye Banks'","numberoff_organ_tissue as 'Number Of Organ/Tissue donors Who Have Pledged for Organ and/or Tissue donation after death'","transplant_trends_inthe_countery as 'Transplant trends in the Country'","noof_organ_allocation_on_central as 'No.of Organ Allocation on Central Registry' ","noof_wait_list_patient as 'No. of Wait List Patients Organ Wise'");
   
    return $qry;
}

public function get_table_kpi_data($id){

    $data_val=$this->get_total_kpi_val();
    
   $qry="SELECT State_Name,".$id." FROM notto_master_tbl inner join m_state on m_state.State_ID=
    notto_master_tbl.state_id where  year='".$data_val['year']."' and month ='".$data_val['month']."'  order by notto_master_tbl.state_id ";
   
    return $this->db->query($qry)->result_array();  
}

 
    
   
}

