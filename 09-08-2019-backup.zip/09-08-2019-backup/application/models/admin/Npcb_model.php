<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Npcb_model extends CI_Model 
{
    public function __construct() 
    {
        parent::__construct();
    }
    
    /*public function get_map_data()
    {
        $qry="SELECT concat('Financial Year : ',e_year, 'Month : ',e_month,', Number of Cataract Surgery Performed : ',cataract_surgery,', 
        Number of Free Spectacles distributed to Elderly Population  : ',elderly_population,',School Children : ',school_children,',Corneal Transplantation : ',corneal_transplantation) AS hover FROM `tbl_npcb_hsd` order by id";
        return $this->db->query($qry)->result_array();
    }*/

    /*public function get_totalRecordNPCBs()
    { 
        $this->db->select('SUM(cataract_surgery) as mt , SUM( elderly_population ) as dtc , 
            SUM(school_children) as tc , SUM(corneal_transplantation) as pt');
        $this->db->from('tbl_npcb_hsd');
        $this->db->order_by("tbl_npcb_hsd.id", "desc");
        $query = $this->db->get();
        return $query->row_array();  
    }*/

    public function get_total_header()
    {
        $qry="SELECT sum(cataract_surgery) as header_count,'Cataract Sursgery' as header_title FROM `tbl_npcb_hsd`  ";
        return $this->db->query($qry)->row_array();   
    }
	
	


 /* public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `tbl_npcb_hsd` GROUP by state_id  order by e_year desc,e_month desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}  */

public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `tbl_npcb_hsd` where e_year <= '".getCurrYear()."' and e_month <= '".getCurrMonth()."'  order by e_year desc,e_month desc LIMIT 1";
    return $this->db->query($qry)->row_array();
} 

/* public function get_total_kpi_val_quar(){
    
    $qry="SELECT * FROM `tbl_npcb_hhr` GROUP by state_id  order by e_year desc,e_quarter desc LIMIT 1";
    return $this->db->query($qry)->row_array();
} */

public function get_total_kpi_val_quar(){
$qry="SELECT * FROM `tbl_npcb_hhr` where e_year = '".getCurrFinYear()."' and e_quarter <= '".getCurrQuarter()."' order by e_year desc,e_quarter desc LIMIT 1"; 

    $row = $this->db->query($qry)->row_array();
    //print_r($row);
    if(empty($row)) {

      $qry="SELECT * FROM `tbl_npcb_hhr` where e_year < '".getCurrFinYear()."' order by e_year desc,e_quarter desc LIMIT 1"; 

       $row = $this->db->query($qry)->row_array();
        //echo "Inner condition"; print_r($row);
    }

    return $row;
}

public function get_totalCount_hhr()
{
	
	$qry="SELECT * FROM `tbl_npcb_hhr` GROUP by state_id  order by e_year desc,e_quarter desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}

public function get_totalCount_hsd()
{
	
	$qry="SELECT * FROM `tbl_npcb_hsd` GROUP by state_id  order by e_year desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}

public function get_total_kpi(){
    $data_val=$this->get_total_kpi_val();
    $q_val=$this->get_total_kpi_val_quar();
	
	$firstTable=$this->get_totalCount_hhr();
	$secTable=$this->get_totalCount_hsd();
	
	//echo count($secTable)."==";
	
	 if(count($firstTable)>0 && count($secTable)>0) 
	{ 
    $qry="SELECT concat('Number of Eye Surgeons trained : ',(SELECT sum(eye_surgeon) FROM tbl_npcb_hhr where e_year='".$q_val['e_year']."' and e_quarter='".$q_val['e_quarter']."'),',Number of Cataract Surgery Performed : ' , sum(cataract_surgery),',Number of Free Spectacles distributed to Elderly Population : ' , sum(elderly_population),',Number of Free Spectacles distributed to School Children : ' , sum(school_children),',Number of Donated Eyes collected for corneal transplantation : ' , sum(corneal_transplantation)) as total_kpi FROM `tbl_npcb_hsd` where e_year='".$data_val['e_year']."' and e_month='".$data_val['e_month']."'  ";
	return $this->db->query($qry)->row_array();
	} 
	
	
	if(count($firstTable)>0 && count($secTable)=='') 
	{ 

	$qry="SELECT concat('Number of Eye Surgeons trained : ',sum(eye_surgeon)) as total_kpi FROM `tbl_npcb_hhr` where e_year='".$q_val['e_year']."' and e_quarter='".$q_val['e_quarter']."'  ";
	return $this->db->query($qry)->row_array();
	
	}
	
	 if(count($firstTable)=='' && count($secTable)>0) 
	{ 
    $qry="SELECT concat('Number of Cataract Surgery Performed : ' , sum(cataract_surgery),',Number of Free Spectacles distributed to Elderly Population : ' , sum(elderly_population),',Number of Free Spectacles distributed to School Children : ' , sum(school_children),',Number of Donated Eyes collected for corneal transplantation : ' , sum(corneal_transplantation)) as total_kpi FROM `tbl_npcb_hsd` where e_year='".$data_val['e_year']."' and e_month='".$data_val['e_month']."'  ";
	return $this->db->query($qry)->row_array();
	} 
	
    

}

   

 /*   public function get_table_kpi_data($id)
    {

     
        $data_val=$this->get_total_kpi_val();

        switch($id)
        {

            case "eye_surgeon":

            $qry="SELECT State_Name, ".$id." FROM tbl_npcb_hhr inner join m_state on m_state.State_ID=
    tbl_npcb_hhr.state_id where  e_year='".$data_val['e_year']."' and e_quarter ='".$data_val['e_quarter']."' GROUP by tbl_npcb_hhr.state_id  ";
            return $this->db->query($qry)->result_array();   
            break;


            case "cataract_surgery":

         
    
            $qry="SELECT State_Name, ".$id." FROM  tbl_npcb_hsd inner join m_state on m_state.State_ID=
     tbl_npcb_hsd.state_id where  e_year='".$data_val['e_year']."' and e_month ='".$data_val['e_month']."' GROUP by tbl_npcb_hsd.state_id  ";
            return $this->db->query($qry)->result_array(); 

            break;
            
            case "elderly_population":

            $qry="SELECT State_Name, ".$id." FROM  tbl_npcb_hsd inner join m_state on m_state.State_ID=
     tbl_npcb_hsd.state_id where  e_year='".$data_val['e_year']."' and e_month ='".$data_val['e_month']."' GROUP by tbl_npcb_hsd.state_id  ";
            return $this->db->query($qry)->result_array(); 
            break;

            case "school_children":
            $qry="SELECT State_Name, ".$id." FROM  tbl_npcb_hsd inner join m_state on m_state.State_ID=
     tbl_npcb_hsd.state_id where  e_year='".$data_val['e_year']."' and e_month ='".$data_val['e_month']."' GROUP by tbl_npcb_hsd.state_id  ";
            return $this->db->query($qry)->result_array(); 
            break;

             case "corneal_transplantation":
             $qry="SELECT State_Name, ".$id." FROM  tbl_npcb_hsd inner join m_state on m_state.State_ID=
     tbl_npcb_hsd.state_id where  e_year='".$data_val['e_year']."' and e_month ='".$data_val['e_month']."' GROUP by tbl_npcb_hsd.state_id  ";
            return $this->db->query($qry)->result_array(); 
            break;

          

           
        }
    }*/


public function get_array_kpi(){
	
	$firstTable=$this->get_totalCount_hhr();
	$secTable=$this->get_totalCount_hsd();

    /* $qry =  array("eye_surgeon as 'Number of Eye Surgeons trained'","cataract_surgery as 'Number of Cataract Surgery performed'","elderly_population as 'Number of Free Spectacles distributed to Elderly Population'","school_children as 'Number of Free Spectacles distributed to School Children'","corneal_transplantation as 'Number of Donated Eyes collected for corneal transplantation'"); 
	return $qry;
	*/
	
	if(count($firstTable)>0 && count($secTable)>0) 
	{ 

$qry =  array("eye_surgeon as 'Number of Eye Surgeons trained'","cataract_surgery as 'Number of Cataract Surgery performed'","elderly_population as 'Number of Free Spectacles distributed to Elderly Population'","school_children as 'Number of Free Spectacles distributed to School Children'","corneal_transplantation as 'Number of Donated Eyes collected for corneal transplantation'"); 
	return $qry;
	}
	
	
	if(count($firstTable)>0 && count($secTable)=='') 
	{ 

  $qry =  array("eye_surgeon as 'Number of Eye Surgeons trained'");
return $qry;  
	}
	
	if(count($firstTable)=='' && count($secTable)>0)
	{
	$qry =  array("cataract_surgery as 'Number of Cataract Surgery performed'","elderly_population as 'Number of Free Spectacles distributed to Elderly Population'","school_children as 'Number of Free Spectacles distributed to School Children'","corneal_transplantation as 'Number of Donated Eyes collected for corneal transplantation'");
	return $qry;
	}
   
    
}


    public function get_table_kpi_data($id){
   
 // var_dump($id); 

    $data_val=$this->get_total_kpi_val();
    $q_val=$this->get_total_kpi_val_quar();
    
    if($id == "eye_surgeon as 'Number of Eye Surgeons trained'"){

        $qry="SELECT State_Name, ".$id." FROM tbl_npcb_hhr inner join m_state on m_state.State_ID=
    tbl_npcb_hhr.state_id where  e_year='".$q_val['e_year']."' and e_quarter ='".$q_val['e_quarter']."' GROUP by tbl_npcb_hhr.state_id order by m_state.State_Name ASC  ";
            return $this->db->query($qry)->result_array();  
    }

    $qry="SELECT State_Name, ".$id." FROM  tbl_npcb_hsd inner join m_state on m_state.State_ID=
     tbl_npcb_hsd.state_id where  e_year='".$data_val['e_year']."' and e_month ='".$data_val['e_month']."' GROUP by tbl_npcb_hsd.state_id order by m_state.State_Name ASC ";
            return $this->db->query($qry)->result_array(); 


    
}



   

    public function get_table_header($table)
    {
        $qry="describe $table  ";
        return $this->db->query($qry)->result_array();   
    }
  
}

