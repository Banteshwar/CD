<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Npcb_model extends CI_Model 
{
    public function __construct() 
    {
        parent::__construct();
    }
    
    public function get_map_data()
    {
        $qry="SELECT concat('Financial Year : ',e_year, 'Month : ',e_month,', Number of Cataract Surgery Performed : ',cataract_surgery,', 
        Number of Free Spectacles distributed to Elderly Population  : ',elderly_population,',School Children : ',school_children,',Corneal Transplantation : ',corneal_transplantation) AS hover FROM `tbl_npcb_hsd` order by id";
        return $this->db->query($qry)->result_array();
    }

    public function get_totalRecordNPCBs()
    { 
        $this->db->select('SUM(cataract_surgery) as mt , SUM( elderly_population ) as dtc , 
            SUM(school_children) as tc , SUM(corneal_transplantation) as pt');
        $this->db->from('tbl_npcb_hsd');
        $this->db->order_by("tbl_npcb_hsd.id", "desc");
        $query = $this->db->get();
        return $query->row_array();  
    }

    public function get_total_header()
    {
        $qry="SELECT sum(cataract_surgery) as header_count,'Cataract Sursgery' as header_title FROM `tbl_npcb_hsd`  ";
        return $this->db->query($qry)->row_array();   
    }

    public function get_total_kpi()
    {
        $qry="SELECT concat('Number of Cataract Surgery <br/> performed : ',sum(cataract_surgery),' ,Number of Free Spectacles distributed to Elderly Population : ', sum(elderly_population),',Number of Free Spectacles distributed to School Children : ',sum(school_children),
            ',Number of Donated Eyes collected for corneal transplantation:',sum(corneal_transplantation)) as total_kpi FROM `tbl_npcb_hsd`  ";
        return $this->db->query($qry)->row_array();
    }

    public function get_table_data()
    {
        //$subqry="(SELECT State_Name FROM `m_state` where m_state.State_ID =state_id  limit 1) as state_name";
        $qry="SELECT e_year as 'Financial Year', e_month as 'Month',  cataract_surgery as 'Number of Cataract Surgery Performed',elderly_population as 'Number of Free Spectacles distributed to Elderly Population',school_children as 'Number of Free Spectacles distributed to School Children',corneal_transplantation as 'Corneal Transplantation' FROM 
        tbl_npcb_hsd order by tbl_npcb_hsd.id ";
        return $this->db->query($qry)->result_array();   
    }

    public function get_table_kpi_data($id)
    {

        $qry2 = array("cataract_surgery"=>"Number of Cataract Surgery
                      performed ", 
        "elderly_population"=>"Number of Free Spectacles distributed to Elderly Population",
        "school_children"=>"Number of Free Spectacles distributed to School Children",
        "corneal_transplantation"=>"Number of Donated Eyes collected for corneal transplantation"
          ); 
        
        $alias_val=$qry2[$id];

        $qry="SELECT e_year as 'Financial Year', SUM(".$id.") AS '".$alias_val."' FROM tbl_npcb_hsd group by tbl_npcb_hsd.e_year ";

        return $this->db->query($qry)->result_array();   
    }

    public function get_array_kpi()
    {
        $qry =  
        array("cataract_surgery","elderly_population", "school_children", "corneal_transplantation");
        return $qry;
    }

    public function get_table_header($table)
    {
        $qry="describe $table  ";
        return $this->db->query($qry)->result_array();   
    }
  
}

