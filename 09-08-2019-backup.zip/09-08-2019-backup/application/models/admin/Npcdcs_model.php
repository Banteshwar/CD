<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Npcdcs_model extends CI_Model 
{
    public function __construct() 
    {
        parent::__construct();
    }
    
   

     

public function get_total_kpi_val(){
    
            $qry="SELECT * FROM `tbl_npcdcs` order by e_year desc,e_quarter desc LIMIT 1";
    return $this->db->query($qry)->row_array();

   
}

   /* public function get_total_kpi()
    {
        $qry="SELECT concat('District NCD Cells-Approved/Functional :', (SELECT sum(ncd_cells) FROM tbl_npcdcs),',District NCD Clinics- Approved/Functional : ',(SELECT sum(ncd_clinics) FROM tbl_npcdcs),' ,Cardiac Care Units (CCU)-Approved/Functional : ', (SELECT sum(cardiac_care_units) FROM tbl_npcdcs),',District Day Care Centres-Approved/Functional : ',(SELECT sum(day_care_centres)FROM tbl_npcdcs),
            ',CHC NCD Clinics-Approved/Functional:',(SELECT sum(chc_ncd_clinics) FROM tbl_npcdcs),',Under Opportunistic Screening(Total persons screened):',(SELECT sum(opportunistic_screening) FROM tbl_npcdcs),',Under Outreach Screening(Total persons screened): ',(SELECT sum(outreach_screening)FROM tbl_npcdcs)) as total_kpi ";
        return $this->db->query($qry)->row_array();
    }*/

 

public function get_total_kpi(){
    $data_val=$this->get_total_kpi_val();

    

    $qry="SELECT concat('District NCD Cells-Functional : ',sum(ncd_cells),',District NCD Clinics-Functional : ' , sum(ncd_clinics),',Cardiac Care Units (CCU)-Functional : ' , sum(cardiac_care_units),',District Day Care Centres-Functional : ' , sum(day_care_centres),',CHC NCD Clinics-Functional : ' , sum(chc_ncd_clinics),',Under Opportunistic Screening(Total persons screened) : ' , sum(opportunistic_screening),',Under Outreach Screening(Total persons screened) : ' , sum(outreach_screening)) as total_kpi FROM `tbl_npcdcs` where e_year='".$data_val['e_year']."' and e_quarter='".$data_val['e_quarter']."'  ";
    return $this->db->query($qry)->row_array();

}


   
public function get_array_kpi(){

    $qry = array("ncd_cells as 'District NCD Cells-Functional'",
            "ncd_clinics as 'District NCD Clinics-Functional'", 
            "cardiac_care_units as 'Cardiac Care Units (CCU)-Functional'",
        
        "day_care_centres as 'District Day Care Centres-Functional'",
        "chc_ncd_clinics as 'CHC NCD Clinics-Functional'",
        "opportunistic_screening as 'Under Opportunistic Screening(Total persons screened)'",
        "outreach_screening as 'Under Outreach Screening(Total persons screened)'"
          ); 
   
    return $qry;
}


    public function get_table_kpi_data($id)
    {

    

        $data_val=$this->get_total_kpi_val();
    
        $qry="SELECT State_Name, ".$id." FROM tbl_npcdcs inner join m_state on m_state.State_ID=
        tbl_npcdcs.state_id where  e_year='".$data_val['e_year']."' and e_quarter ='".$data_val['e_quarter']."' order by tbl_npcdcs.state_id desc ";
       
        return $this->db->query($qry)->result_array();  

    }

  

    
  
}

