<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Nppcd_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
public function get_total_kpi_val(){
    
    $qry  = "SELECT * FROM `nppcd_master_tbl` where year < '".getCurrYear()."' order by year desc LIMIT 1";
    $row  = $this->db->query($qry)->row_array();
    return $row;
}

public function get_total_kpi(){
    $data_val=$this->get_total_kpi_val();

    $qry="SELECT concat('Total Number of districts under NPPCD : ',sum(Total_Number_of_districts),' ,Total Number of district made operational under NPPCD : ',sum(Total_Number_of_district_made_operational)) as total_kpi FROM `nppcd_master_tbl` where year='".$data_val['year']."' ";
    return $this->db->query($qry)->row_array();

}

public function get_array_kpi(){

    $qry =  array("Total_Number_of_districts as 'Total Number of districts under NPPCD'","Total_Number_of_district_made_operational as 'Total Number of district made operational under NPPCD'");   
    return $qry;
}


public function get_table_kpi_data($id){   
   
    $data_val=$this->get_total_kpi_val();    
    $qry="SELECT State_Name, ".$id." FROM nppcd_master_tbl inner join m_state on m_state.State_ID=
    nppcd_master_tbl.state_id where year='".$data_val['year']."' GROUP by nppcd_master_tbl.state_id order by m_state.State_Name ";
   
    return $this->db->query($qry)->result_array();  
}
   
   
}

