<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Nrcp_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
  

/* public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `nrcp_master_table`  order by e_year desc,e_quarter desc LIMIT 1";
    return $this->db->query($qry)->row_array();
} */

/* public function get_total_kpi_val(){
    
    $qry  = "SELECT * FROM `nrcp_master_table` where e_year <= '".getCurrFinYear()."' and e_quarter <= '".getCurrQuarter()."' order by e_year desc,e_quarter DESC LIMIT 1";
    $row  = $this->db->query($qry)->row_array();

    if(empty($row)) {

      $qry="SELECT * FROM `nrcp_master_table` where e_year < '".getCurrFinYear()."' order by e_year desc,e_quarter desc LIMIT 1"; 

       $row = $this->db->query($qry)->row_array();
        //echo "Inner condition"; print_r($row);
    }

    return $row;

} */


public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `nrcp_master_table` where e_year <= '".getCurrFinYear()."' and e_quarter <= '".getCurrQuarter('Quarterly')."' order by e_year desc,e_quarter desc LIMIT 1"; 

    $row = $this->db->query($qry)->row_array();
    
    if(empty($row)) {

      $qry="SELECT * FROM `nrcp_master_table` where e_year < '".getCurrFinYear()."' order by e_year desc,e_quarter desc LIMIT 1"; 

       $row = $this->db->query($qry)->row_array();        
    }

    return $row;
}

/* public function get_total_kpi(){
$data_val=$this->get_total_kpi_val();
  
	$qry="SELECT concat('Total Number of Animal Bite Cases Reported : ',sum(animal_bites_cases),' ,Total Number of Deaths due to Human Rabies : ', sum(human_rabies_total),' ,Total number of states/UTs reported shortage of AR Vaccine : ', sum(IF(vaccine_total = 'Yes', 1, 0)) ) as total_kpi FROM `nrcp_master_table`  where e_year='".$data_val['e_year']."' and e_quarter='".$data_val['e_quarter']."'  ";
    return $this->db->query($qry)->row_array();
	
	
	
	
	//echo $this->db->last_query();
	
	
} */



public function  getSumFieldValue($field, $table, $where =''){    
    
     $qry="SELECT sum(". $field.") as sum_". $field.", 
          SUM(IF(". $field."='', 1,0)) as count_". $field.",
        count(*) as total_count
      FROM ".$table." " . $where;       
      
     $val= $this->db->query($qry)->row_array();  
     
     if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
        return 'N/E';
     }
     else {
        return $val["sum_".$field]; 
     }     
}

public function  getSumFieldValue2($field, $table, $where =''){    
    
	
     $qry="select sum(IF(vaccine_total = 'Yes', 1, 0)) as vaccine_total FROM ".$table." " . $where; 
    
     $val= $this->db->query($qry)->row_array();  
     
	
     if($val['vaccine_total'] == 0 ) {
       $val['vaccine_total']= 'N/E';
     }
    
     else {
        $val['vaccine_total']; 
     } 

return $val['vaccine_total'];
 
	 
}


public function get_total_kpi()
{ 
     $data_val=$this->get_total_kpi_val(); 

    
     $table = 'nrcp_master_table';
     $where = "where e_year='".$data_val['e_year']."' and e_quarter='".$data_val['e_quarter']."' ";
     
     $total_kpi = array(); 
      
     $value = $this->getSumFieldValue('animal_bites_cases', $table, $where);
     $total_kpi[] = 'Total Number of Animal Bite Cases Reported : '.$value ; 
     
         
     $value = $this->getSumFieldValue('human_rabies_total', $table, $where);     
     $total_kpi[] = 'Total Number of Deaths due to Human Rabies: '.$value ; 
	 
	 $value = $this->getSumFieldValue2('vaccine_total', $table, $where);     
     $total_kpi[] = 'Total number of states/UTs reported shortage of AR Vaccine: '.$value ; 
     
     $data['total_kpi'] = implode(',',$total_kpi);
    
    //echo print_r($data); die;
    return $data;
}

public function get_total_header(){
   $qry="SELECT sum(animal_bites_cases)  as header_count,'Total Ambulances Operational' as header_title FROM `nrcp_master_table`  ";
    return $this->db->query($qry)->row_array();  
}

public function get_table_data(){
   
    $subqry="(SELECT State_Name  FROM `m_state` where m_state.State_ID =state_id  limit 1) as state_name";
    $qry="SELECT State_Name, animal_bites_cases as a,human_rabies_total as b,vaccine_total as c FROM nrcp_master_table inner join m_state on m_state.State_ID=
    nrcp_master_table.state_id order by nrcp_master_table.state_id ";
    return $this->db->query($qry)->result_array();   
	
	//echo $this->db->last_query(); die;
}


public function get_array_kpi(){

    return array("animal_bites_cases as 'Total Number of Animal Bite Cases Reported'","human_rabies_total as 'Total Number of Deaths due to Human Rabies'","vaccine_total as 'States/UTs reported shortage of AR Vaccine'");
}

public function get_table_kpi_data($id){
    $data_val=$this->get_total_kpi_val();
    
	if($id=="animal_bites_cases as 'Total Number of Animal Bite Cases Reported'"){
		$qry="SELECT State_Name,".$id." FROM nrcp_master_table inner join m_state on m_state.State_ID=
		nrcp_master_table.state_id where  e_year='".$data_val['e_year']."' and e_quarter ='".$data_val['e_quarter']."' and nrcp_master_table.animal_bites_cases<>'' group by nrcp_master_table.state_id order by m_state.State_Name ";
		return $this->db->query($qry)->result_array(); 
	}
	if($id=="human_rabies_total as 'Total Number of Deaths due to Human Rabies'"){
		$qry="SELECT State_Name,".$id." FROM nrcp_master_table inner join m_state on m_state.State_ID=
		nrcp_master_table.state_id where  e_year='".$data_val['e_year']."' and e_quarter ='".$data_val['e_quarter']."' and nrcp_master_table.human_rabies_total<>'' group by nrcp_master_table.state_id order by m_state.State_Name ";
		return $this->db->query($qry)->result_array(); 
	}
	if($id=="vaccine_total as 'States/UTs reported shortage of AR Vaccine'"){
		$qry="SELECT State_Name,".$id." FROM nrcp_master_table inner join m_state on m_state.State_ID=
		nrcp_master_table.state_id where  e_year='".$data_val['e_year']."' and e_quarter ='".$data_val['e_quarter']."' and nrcp_master_table.vaccine_total='Yes' group by nrcp_master_table.state_id order by m_state.State_Name ";
		return $this->db->query($qry)->result_array(); 
	}
	
	
}

}