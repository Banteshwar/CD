<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Nrcpmap_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
public function get_PMSSYs(){ 
    $this->db->select('nohp_master_table.*');
    $this->db->from('nohp_master_table');
	// $this->db->join('m_state','m_state.State_ID=nohp_master_table.state_id','inner');
    
 
   $this->db->order_by("nohp_master_table.id", "desc");


        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
}
public function get_mdiabetesform(){
		
		$sql     =  "select * from tbl_mdiabetes";
	
		$stmt = $this->db->query($sql); 
        if($stmt->num_rows()>0){
            return $stmt->result_array(); 
        }else{
            return false;
        }
        
	}

public function get_map_data(){

    $qry="SELECT concat('Animal Bite_cases reported : ',Animal_Bite_cases_reported,',Human rabies cases reported : ',Human_rabies_cases_reported,'Vaccine availability status: ',Vaccine_availability_status) AS hover, state_id FROM `nrcp_master_table` order by state_id";
    return $this->db->query($qry)->result_array();

}


public function get_total_kpi(){

    $qry="SELECT concat('Total Animal Bite cases reported : ',sum(Animal_Bite_cases_reported),' ,Total Human rabies cases reported : ', sum(Human_rabies_cases_reported),' ,Total Vaccine availability status : ' , sum(Vaccine_availability_status)) as total_kpi FROM `nrcp_master_table`  ";
    return $this->db->query($qry)->row_array();

}

public function get_total_header(){
    $qry="SELECT sum(Animal_Bite_cases_reported)  as header_count,'Total Animal Bite cases reported' as header_title FROM `nrcp_master_table`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_table_data(){
    $subqry="(SELECT State_Name FROM `m_state` where m_state.State_ID =state_id  limit 1) as state_name";
    $qry="SELECT State_Name,  Animal_Bite_cases_reported,Human_rabies_cases_reported,Vaccine_availability_status FROM nrcp_master_table inner join m_state on m_state.State_ID=
    nrcp_master_table.state_id group by nrcp_master_table.state_id order by nrcp_master_table.state_id ";
    return $this->db->query($qry)->result_array();   
}

public function get_table_data_map(){
    
    $qry="SELECT State_Name,Animal_Bite_cases_reported,Human_rabies_cases_reported,Vaccine_availability_status FROM nrcp_master_table inner join m_state on m_state.State_ID=
    nrcp_master_table.state_id  order by nrcp_master_table.state_id ";
    return $this->db->query($qry)->result_array();   
}

public function get_table_header($table){
    $qry="describe $table  ";
    return $this->db->query($qry)->result_array();   
}
}