<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Ntcp_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
  

/* public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `ntcp_master_table`  order by year desc,Quarterly desc LIMIT 1";
    return $this->db->query($qry)->row_array();
} */

public function get_total_kpi_val(){
    
     $qry="SELECT * FROM `ntcp_master_table` order by e_year desc,e_quarter desc LIMIT 1"; 
    $row  = $this->db->query($qry)->row_array();

    if(empty($row)) {

     $qry="SELECT * FROM `ntcp_master_table` order by e_year desc,e_quarter desc LIMIT 1"; 

       $row = $this->db->query($qry)->row_array();
        //echo "Inner condition"; print_r($row);
    }

    return $row;

}

public function get_total_kpi_val2(){
    
   $qry  = "SELECT * FROM `ntcpcentre_master_table` order by e_year desc,e_quarter desc LIMIT 1";
    $row  = $this->db->query($qry)->row_array();

    if(empty($row)) {

     $qry="SELECT * FROM `ntcpcentre_master_table` order by e_year desc,e_quarter desc LIMIT 1"; 

       $row = $this->db->query($qry)->row_array();
        
    }

    return $row;

}
public function  getCountFieldValue($field, $table, $where =''){
	
	
	 $qry="SELECT count(". $field.") as count_". $field.", 
		  count(IF(". $field."='', 1,0)) as count_". $field.",
	    count(*) as total_count
	  FROM ".$table." " . $where." and ".$field."<>''"; 
	  
	  
	 $val= $this->db->query($qry)->row_array();	 
	 
	 if($val["count_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
		return 'N/E';
	 }
	 else if(empty($val['total_count']))
	 {
		return 'N/E'; 
	 }
	 else {
		return $val["count_".$field]; 
	 }
	 
}
public function  getSumFieldValue($field, $table, $where =''){
	
	
	 $qry="SELECT sum(". $field.") as sum_". $field.", 
		  SUM(IF(". $field."='' , 1,0)) as count_". $field.",
	    count(*) as total_count
	  FROM ".$table." " . $where; 
	  
	  
	 $val= $this->db->query($qry)->row_array();	 
	 
	 if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
		return 'N/E';
	 }
	 else if(empty($val['total_count']))
	 {
		return 'N/E'; 
	 }
	 else {
		return $val["sum_".$field]; 
	 }
	 
}
public function get_total_kpi()
{ 
     $data_val=$this->get_total_kpi_val();
	$data_val2=$this->get_total_kpi_val2();	 

    
	 $table = 'ntcp_master_table';
	  $table2 = 'ntcpcentre_master_table';
	 $where = "where e_year='".$data_val['e_year']."' and e_quarter='".$data_val['e_quarter']."' ";
	 $where1 = "where e_year='".$data_val2['e_year']."' and e_quarter='".$data_val2['e_quarter']."' ";
	 
	  $total_kpi = array();	
	  
	  
	  
	  $value1 = $this->getSumFieldValue('No_of_calls_landing_at_Quitline', $table, $where);
	  $total_kpi[] = 'No. of calls landed at Quitline : '.$value1 ; 
	  
	   $value1 = $this->getSumFieldValue('No_of_registered_Quitters', $table, $where);
	  $total_kpi[] = 'Nunber of registered Quitters : '.$value1 ; 
	  
	  $value1 = $this->getSumFieldValue('No_of_persons_who_have_quit', $table, $where);
	  $total_kpi[] = 'No. of persons who have quit : '.$value1 ; 
	  
	  $value1 = $this->getSumFieldValue('Total_No_of_District_in_State_UT', $table2, $where1);
	  $total_kpi[] = 'Total No. of districts under NTCP : '.$value1 ; 
	  
	  $value1 = $this->getSumFieldValue('No_of_persons_fined_COTPA', $table2, $where1);
	  $total_kpi[] = 'No. of persons fined under COTPA : '.$value1 ; 
	  
	  $value1 = $this->getSumFieldValue('Amount_of_fine_imposed', $table2, $where1);
	  $total_kpi[] = 'Amount of fine imposed (in RS.) : '.$value1 ; 
	
	  $value1 = $this->getSumFieldValue('No_of_TCCS_Under_NTCP', $table2, $where1);
	  $total_kpi[] = 'No. of TCC under NTCP: '.$value1 ;
	  
	   $value1 = $this->getSumFieldValue('No_of_persons_who_availed_TC_services', $table2, $where1);
	  $total_kpi[] = 'No. of persons who availed TC services: '.$value1 ;
	  
    $data['total_kpi'] = implode(',',$total_kpi);
	 $data=str_replace("N/E/N/E","N/E",$data);
    return $data;
}

public function get_total_header(){
   //$qry="SELECT sum(Sanctioned_Post_for_Medical_Officers_Under_NUHM)  as header_count,'Total Ambulances Operational' as header_title FROM `ntcp_master_table`  ";
    return 1; //$this->db->query($qry)->row_array();  
}

public function get_table_data(){
   
    //$subqry="(SELECT State_Name  FROM `m_state` where m_state.State_ID =state_id  limit 1) as state_name";
    //$qry="SELECT State_Name, Sanctioned_Post_for_Medical_Officers_Under_NUHM as a,Vacancies_of_Medical_officers_under_NUHM as b FROM ntcp_master_table inner join m_state on m_state.State_ID=
   // ntcp_master_table.state_id order by ntcp_master_table.state_id ";
    return 1; //$this->db->query($qry)->result_array();   
	
	//echo $this->db->last_query(); die;
}


public function get_array_kpi(){

    return array(
	
	"No_of_calls_landing_at_Quitline as `No. of calls landed at Quitline`",
	"No_of_registered_Quitters as `No. of registered Quitters`",
	"No_of_persons_who_have_quit as `No. of persons who have quit`",
	"Total_No_of_District_in_State_UT as `Total No. of districts in state/UT`",
	"No_of_persons_fined_COTPA as `No. of persons fined COPTA`",
	"Amount_of_fine_imposed as `Amount of fine imposed (in RS.)`",
	"No_of_TCCS_Under_NTCP as `No. of TCC Under NTCP`",
	"No_of_persons_who_availed_TC_services"
	);
}

public function get_table_kpi_data($id){
    $data_val=$this->get_total_kpi_val();
	 $data_val2=$this->get_total_kpi_val2();
    
	if($id=="No_of_registered_Quitters as `No. of registered Quitters`"){
		$qry="SELECT State_Name,".$id." FROM ntcp_master_table inner join m_state on m_state.State_ID=
		ntcp_master_table.state_id where  ntcp_master_table.e_year='".$data_val['e_year']."' and ntcp_master_table.e_quarter ='".$data_val['e_quarter']."' and No_of_registered_Quitters<>'' and No_of_registered_Quitters <>0 group by ntcp_master_table.state_id order by State_Name";
		return $this->db->query($qry)->result_array(); 
	}
	if($id=="No_of_calls_landing_at_Quitline as `No. of calls landed at Quitline`"){
		 $qry="SELECT State_Name,".$id." FROM ntcp_master_table inner join m_state on m_state.State_ID=
		ntcp_master_table.state_id where  ntcp_master_table.e_year='".$data_val['e_year']."' and ntcp_master_table.e_quarter ='".$data_val['e_quarter']."' and No_of_calls_landing_at_Quitline <> ''and No_of_calls_landing_at_Quitline <> 0 group by ntcp_master_table.state_id order by State_Name";
		return $this->db->query($qry)->result_array(); 
	}
	if($id=="No_of_persons_who_have_quit as `No. of persons who have quit`"){
		$qry="SELECT State_Name,".$id." FROM ntcp_master_table inner join m_state on m_state.State_ID=
		ntcp_master_table.state_id where  ntcp_master_table.e_year='".$data_val['e_year']."' and ntcp_master_table.e_quarter ='".$data_val['e_quarter']."' and No_of_persons_who_have_quit <> '' and No_of_persons_who_have_quit <> 0 group by ntcp_master_table.state_id order by State_Name";
		return $this->db->query($qry)->result_array(); 
	}
	if($id=="Total_No_of_District_in_State_UT as `Total No. of districts in state/UT`"){
		$qry="SELECT State_Name,".$id." FROM ntcpcentre_master_table inner join m_state on m_state.State_ID=
		ntcpcentre_master_table.state_id where  ntcpcentre_master_table.e_year='".$data_val2['e_year']."' and ntcpcentre_master_table.e_quarter ='".$data_val2['e_quarter']."' and Total_No_of_District_in_State_UT <> '' and Total_No_of_District_in_State_UT <> 0 group by ntcpcentre_master_table.state_id order by State_Name";
		
		return $this->db->query($qry)->result_array(); 
	}
	if($id=="No_of_persons_fined_COTPA as `No. of persons fined COPTA`"){
		$qry="SELECT State_Name,".$id." FROM ntcpcentre_master_table inner join m_state on m_state.State_ID=
		ntcpcentre_master_table.state_id where  ntcpcentre_master_table.e_year='".$data_val2['e_year']."' and ntcpcentre_master_table.e_quarter ='".$data_val2['e_quarter']."' and No_of_persons_fined_COTPA <> '' and  No_of_persons_fined_COTPA <> 0 group by ntcpcentre_master_table.state_id order by State_Name";
		
		return $this->db->query($qry)->result_array(); 
	}
	if($id=="Amount_of_fine_imposed as `Amount of fine imposed (in RS.)`"){
		$qry="SELECT State_Name,".$id." FROM ntcpcentre_master_table inner join m_state on m_state.State_ID=
		ntcpcentre_master_table.state_id where  ntcpcentre_master_table.e_year='".$data_val2['e_year']."' and ntcpcentre_master_table.e_quarter ='".$data_val2['e_quarter']."' and Amount_of_fine_imposed <> '' and Amount_of_fine_imposed <> 0 group by ntcpcentre_master_table.state_id order by State_Name";
		return $this->db->query($qry)->result_array(); 
	}
	if($id=="No_of_TCCS_Under_NTCP as `No. of TCC Under NTCP`"){
		$qry="SELECT State_Name,".$id." FROM ntcpcentre_master_table inner join m_state on m_state.State_ID=
		ntcpcentre_master_table.state_id where  ntcpcentre_master_table.e_year='".$data_val2['e_year']."' and ntcpcentre_master_table.e_quarter ='".$data_val2['e_quarter']."' and No_of_TCCS_Under_NTCP <> '' and No_of_TCCS_Under_NTCP <> 0 group by ntcpcentre_master_table.state_id order by State_Name";
		return $this->db->query($qry)->result_array(); 
	}
	if($id=="No_of_persons_who_availed_TC_services"){
		$qry="SELECT State_Name,".$id." FROM ntcpcentre_master_table inner join m_state on m_state.State_ID=
		ntcpcentre_master_table.state_id where  ntcpcentre_master_table.e_year='".$data_val2['e_year']."' and ntcpcentre_master_table.e_quarter ='".$data_val2['e_quarter']."' and No_of_persons_who_availed_TC_services <> '' and No_of_persons_who_availed_TC_services <> 0 group by ntcpcentre_master_table.state_id order by State_Name";
		return $this->db->query($qry)->result_array(); 
	}
	
	
}

}