<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Nuhm_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
public function get_map_data(){

    $qry="SELECT concat('Total No of Medical Officers,ANMs,Staff Nurses,Lab Technician,Pharmacists: ',Medical_Officers+ANMs+Staff_Nurses+Lab_Technician+Pharmacists),' ,Number of UHCs operationalized as HWCs : ', sum(Number_of_UHCs_operationalized_as_HWCs,',Number of Mahila Arogya Samiti Constitued : ',Number_of_Mahila_Arogya_Samiti_Constitued) AS hover,'Patient Treatment Successfully : ',Patient_Successfully_Treated,'Percentage of newborns : ',Newborns_Receiv FROM `immunization_master_table`";
    return $this->db->query($qry)->result_array();

}

public function get_totalRecordNVHCPs(){ 
    $this->db->select('SUM(Medical_Officers+ANMs+Staff_Nurses+Lab_Technician+Pharmacists) as mt , SUM(Number_of_UHCs_operationalized_as_HWCs) as ma , SUM(Number_of_Mahila_Arogya_Samiti_Constitued) as nd');
    $this->db->from('nuhm_master_tbl');
    
    $this->db->order_by("nuhm_master_tbl.id", "desc");

    $query = $this->db->get();

    return $query->row_array();  
}

public function get_total_header(){
    $qry="SELECT sum(Number_of_UHCs_operationalized_as_HWCs)  as header_count,'Number of UHCs operationalized as HWCs' as header_title FROM `nuhm_master_tbl`";
    return $this->db->query($qry)->row_array();   
}

/*public function get_total_kpi(){

    $qry="SELECT concat('Total No of Medical Officers: ',sum(Medical_Officers),+,ANMs:,', sum(ANMs),Staff Nurses,Lab Technician,Pharmacists+ANMs+Staff_Nurses+Lab_Technician+Pharmacists),' ,Number of UHCs operationalized as HWCs : ', sum(Number_of_UHCs_operationalized_as_HWCs),' ,Number of Mahila Arogya Samiti Constitued: ,' ,sum(Number_of_Mahila_Arogya_Samiti_Constitued)) as total_kpi FROM `nuhm_master_tbl`  ";
    return $this->db->query($qry)->row_array();

}

*/

public function get_total_kpi(){

    $qry="SELECT concat('Total No of Medical Officers : ',sum(Medical_Officers),',Total No ANMs : ', sum(ANMs),' ,Total Staff Nurses : ',sum(Staff_Nurses) ,', Total Lab Technician : ',sum(Lab_Technician),',Pharmacists: ', sum(Pharmacists),',Number of UHCs operationalized as HWCs : ', sum(Number_of_UHCs_operationalized_as_HWCs),',Number of Mahila Arogya Samiti Constitued : ', sum(Number_of_Mahila_Arogya_Samiti_Constitued)) as total_kpi FROM `nuhm_master_tbl` ";
    return $this->db->query($qry)->row_array();

}
public function get_table_data(){
    $subqry="(SELECT State_Name FROM `m_state` where m_state.State_ID =state_id  limit 1) as state_name";
    $qry="SELECT State_Name,Medical_Officers,ANMs,Staff_Nurses,Lab_Technician,Pharmacists,Number_of_UHCs_operationalized_as_HWCs, Number_of_Mahila_Arogya_Samiti_Constitued,year FROM nuhm_master_tbl inner join m_state on m_state.State_ID=
    nuhm_master_tbl.state_id  order by nuhm_master_tbl.state_id ";
    return $this->db->query($qry)->result_array();   
}

public function get_array_kpi(){
    return array("Medical_Officers","ANMs","Staff_Nurses","Lab_Technician","Pharmacists","Number_of_UHCs_operationalized_as_HWCs","Number_of_Mahila_Arogya_Samiti_Constitued ");
}

public function get_table_kpi_data($id){
    $subqry="(SELECT State_Name FROM `m_state` where m_state.State_ID =state_id  limit 1) as state_name";
    $qry="SELECT State_Name,".$id." FROM nuhm_master_tbl inner join m_state on m_state.State_ID=
    nuhm_master_tbl.state_id  order by nuhm_master_tbl.state_id ";
    return $this->db->query($qry)->result_array();   
}


/*public function get_table_data(){
    $qry="SELECT state_id,Medical_Officers,ANMs,Staff_Nurses,Lab_Technician,Pharmacists,Number_of_UHCs_operationalized_as_HWCs,Number_of_Mahila_Arogya_Samiti_Constitued,year FROM nuhm_master_tbl order by id desc ";
    return $this->db->query($qry)->result_array();   
}
*/
public function get_table_header($table){
    $qry="describe $table  ";
    return $this->db->query($qry)->result_array();   
}

    public function selectSmsmaster(){

     $this->db->select('tbl_sms_master.*');
     $this->db->from('tbl_sms_master');
     $this->db->where("tbl_sms_master.is_active", "1");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
    /*global $db;
    $stmt = $db->query('select n.* , s.* from notto_master_tbl as n inner join m_state as s on  n.state_id = s.state_id order by n.id desc'); 
        return $stmt->fetchAll(); 
*/
   } 




   
}

