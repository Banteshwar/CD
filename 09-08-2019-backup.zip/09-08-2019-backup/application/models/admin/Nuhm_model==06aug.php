<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Nuhm_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
  

/* public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `nuhm_master_tbl`  order by year desc,Quarterly desc LIMIT 1";
    return $this->db->query($qry)->row_array();
} */

public function get_total_kpi_val(){
    
    $qry  = "SELECT * FROM `nuhm_master_tbl` where year <= '".getCurrFinYear()."' and Quarterly <= '".getCurrQuarter()."' order by year desc,Quarterly DESC LIMIT 1";
    $row  = $this->db->query($qry)->row_array();

    if(empty($row)) {

      $qry="SELECT * FROM `nuhm_master_tbl` where year < '".getCurrFinYear()."' order by year desc,Quarterly desc LIMIT 1"; 

       $row = $this->db->query($qry)->row_array();
        //echo "Inner condition"; print_r($row);
    }

    return $row;

}

public function calpercentage1(){
	$data_val=$this->get_total_kpi_val();
	$qry="SELECT sum(nuhm_master_tbl.Sanctioned_Post_for_Medical_Officers_Under_NUHM) as Sanctioned_Post_for_Medical_Officers_Under_NUHM,sum(nuhm_master_tbl.Vacancies_of_Medical_officers_under_NUHM) as Vacancies_of_Medical_officers_under_NUHM  FROM nuhm_master_tbl inner join m_state on m_state.State_ID=
		nuhm_master_tbl.state_id where  nuhm_master_tbl.year='".$data_val['year']."' and nuhm_master_tbl.Quarterly ='".$data_val['Quarterly']."' and Sanctioned_Post_for_Medical_Officers_Under_NUHM<>''";
		
		$x = $this->db->query($qry)->result_array();
		if(!empty($x[0]['Sanctioned_Post_for_Medical_Officers_Under_NUHM']) && !empty($x[0]['Vacancies_of_Medical_officers_under_NUHM'])){
		$val1= $x[0]['Sanctioned_Post_for_Medical_Officers_Under_NUHM'];
		$val2= $x[0]['Vacancies_of_Medical_officers_under_NUHM'];
	
		return round(($val2/$val1)*100);
		}
		return 'N/E';
}
public function calpercentage2(){
	$data_val=$this->get_total_kpi_val();
	$qry="SELECT sum(nuhm_master_tbl.Sanctioned_Post_for_Nurses_Under_NUHM) as Sanctioned_Post_for_Nurses_Under_NUHM,sum(nuhm_master_tbl.Vacancies_of_Nurses_under_NUHM) as Vacancies_of_Nurses_under_NUHM  FROM nuhm_master_tbl inner join m_state on m_state.State_ID=
		nuhm_master_tbl.state_id where  nuhm_master_tbl.year='".$data_val['year']."' and nuhm_master_tbl.Quarterly ='".$data_val['Quarterly']."' and Sanctioned_Post_for_Nurses_Under_NUHM<>'' ";
		
		$x = $this->db->query($qry)->result_array();
		if(!empty($x[0]['Sanctioned_Post_for_Nurses_Under_NUHM']) && !empty($x[0]['Vacancies_of_Nurses_under_NUHM'])){
		$val1= $x[0]['Sanctioned_Post_for_Nurses_Under_NUHM'];
		$val2= $x[0]['Vacancies_of_Nurses_under_NUHM'];
	
		return round(($val2/$val1)*100);
		}
		return 'N/E';
	
}
public function calpercentage3(){
	$data_val=$this->get_total_kpi_val();
	$qry="SELECT sum(nuhm_master_tbl.Sanctioned_Post_for_ANMs_Under_NUHM) as Sanctioned_Post_for_ANMs_Under_NUHM, sum(nuhm_master_tbl.Vacancies_of_ANMs_under_NUHM) as Vacancies_of_ANMs_under_NUHM FROM nuhm_master_tbl inner join m_state on m_state.State_ID=
		nuhm_master_tbl.state_id where  nuhm_master_tbl.year='".$data_val['year']."' and nuhm_master_tbl.Quarterly ='".$data_val['Quarterly']."' and Sanctioned_Post_for_ANMs_Under_NUHM<>'' ";
		
		$x = $this->db->query($qry)->result_array();
		if(!empty($x[0]['Sanctioned_Post_for_ANMs_Under_NUHM']) && !empty($x[0]['Vacancies_of_ANMs_under_NUHM'])){
		$val1= $x[0]['Sanctioned_Post_for_ANMs_Under_NUHM'];
		$val2= $x[0]['Vacancies_of_ANMs_under_NUHM'];
	
		return round(($val2/$val1)*100);
		}
		return 'N/E';
	
}
public function calpercentage4(){
	$data_val=$this->get_total_kpi_val();
	$qry="SELECT sum(nuhm_master_tbl.Sanctioned_Post_for_Lab_Technicians_Under_NUHM) as Sanctioned_Post_for_Lab_Technicians_Under_NUHM, sum(nuhm_master_tbl.Vacancies_of_Lab_Technicians_under_NUHM) as Vacancies_of_Lab_Technicians_under_NUHM FROM nuhm_master_tbl inner join m_state on m_state.State_ID=
		nuhm_master_tbl.state_id where  nuhm_master_tbl.year='".$data_val['year']."' and nuhm_master_tbl.Quarterly ='".$data_val['Quarterly']."' and Sanctioned_Post_for_Lab_Technicians_Under_NUHM<>'' ";
		
		$x = $this->db->query($qry)->result_array();
		if(!empty($x[0]['Sanctioned_Post_for_Lab_Technicians_Under_NUHM']) && !empty($x[0]['Vacancies_of_Lab_Technicians_under_NUHM'])){
		$val1= $x[0]['Sanctioned_Post_for_Lab_Technicians_Under_NUHM'];
		$val2= $x[0]['Vacancies_of_Lab_Technicians_under_NUHM'];
	
		return round(($val2/$val1)*100);
	}
		return 'N/E';
	
}
public function calpercentage5(){
	$data_val=$this->get_total_kpi_val();
	$qry="SELECT sum(nuhm_master_tbl.Sanctioned_Post_for_Pharmacists_Under_NUHM) as Sanctioned_Post_for_Pharmacists_Under_NUHM, sum(nuhm_master_tbl.Vacancies_of_Lab_Pharmacists_under_NUHM) as Vacancies_of_Lab_Pharmacists_under_NUHM FROM nuhm_master_tbl inner join m_state on m_state.State_ID=
		nuhm_master_tbl.state_id where  nuhm_master_tbl.year='".$data_val['year']."' and nuhm_master_tbl.Quarterly ='".$data_val['Quarterly']."' and Sanctioned_Post_for_Pharmacists_Under_NUHM<>'' ";
		
		$x = $this->db->query($qry)->result_array();
		if(!empty($x[0]['Sanctioned_Post_for_Pharmacists_Under_NUHM']) && !empty($x[0]['Vacancies_of_Lab_Pharmacists_under_NUHM'])){
		$val1= $x[0]['Sanctioned_Post_for_Pharmacists_Under_NUHM'];
		$val2= $x[0]['Vacancies_of_Lab_Pharmacists_under_NUHM'];
	
		return round(($val2/$val1)*100);
	}
		return 'N/E';
}
public function calpercentage6(){
	$data_val=$this->get_total_kpi_val();
	$qry="SELECT sum(nuhm_master_tbl.Number_of_MAS_approved) as Number_of_MAS_approved, sum(nuhm_master_tbl.Number_of_MAS_created) as Number_of_MAS_created FROM nuhm_master_tbl inner join m_state on m_state.State_ID=
		nuhm_master_tbl.state_id where  nuhm_master_tbl.year='".$data_val['year']."' and nuhm_master_tbl.Quarterly ='".$data_val['Quarterly']."' and Number_of_MAS_approved<>'' ";
		
		$x = $this->db->query($qry)->result_array();
		if(!empty($x[0]['Number_of_MAS_approved']) && !empty($x[0]['Number_of_MAS_created'])){
		$val1= $x[0]['Number_of_MAS_approved'];
		$val2= $x[0]['Number_of_MAS_created'];
	
		return round(($val2/$val1)*100);
	}
		return 'N/E';
}

public function get_total_kpipre(){
	
$data_val=$this->get_total_kpi_val();
  
	$qry="SELECT concat('Vacancies(".$this->calpercentage1()."% of Medical Officers (including specialists)) against sanctioned posts under nuhm : ',sum(Sanctioned_Post_for_Medical_Officers_Under_NUHM),'/',sum(Vacancies_of_Medical_officers_under_NUHM),
	',Vacancies(".$this->calpercentage2()."% )of Staff Nurse against sanctioned posts under nuhm: ', sum(Sanctioned_Post_for_Nurses_Under_NUHM),'/',sum(Vacancies_of_Nurses_under_NUHM),
	',Vacancies(".$this->calpercentage3()."% )of ANMs against sanctioned posts under nuhm: ', sum(Sanctioned_Post_for_ANMs_Under_NUHM),'/',sum(Vacancies_of_ANMs_under_NUHM),
	',Vacancies(".$this->calpercentage4()."% )of Lab Technicians against sanctioned posts under nuhm: ', sum(Sanctioned_Post_for_Lab_Technicians_Under_NUHM),'/',sum(Vacancies_of_Lab_Technicians_under_NUHM),
	',Vacancies(".$this->calpercentage5()."% )of Pharmacists against sanctioned posts under nuhm: ', sum(Sanctioned_Post_for_Pharmacists_Under_NUHM),'/',sum(Vacancies_of_Lab_Pharmacists_under_NUHM),
	',No. of UPHCs Operationalized HWCs: ', sum(No_of_UPHCs_Operationalized_as_HWCs),
	',".$this->calpercentage6()."% of Mass created against Approved: ', sum(Number_of_MAS_approved),'/',sum(Number_of_MAS_created)
	
	) as total_kpi FROM `nuhm_master_tbl`  where year='".$data_val['year']."' and Quarterly='".$data_val['Quarterly']."'  ";
    return $this->db->query($qry)->row_array();
	
	
	
	
	//echo $this->db->last_query();
	
	
}
public function  getSumFieldValue($field, $table, $where =''){
	
	
	 $qry="SELECT sum(". $field.") as sum_". $field.", 
		  SUM(IF(". $field."='' || ". $field."='0', 1,0)) as count_". $field.",
	    count(*) as total_count
	  FROM ".$table." " . $where; 
	  
	  
	 $val= $this->db->query($qry)->row_array();	 
	 
	 if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
		return 'N/E';
	 }
	 else if($val['total_count']==0)
	 {
		return 'N/E'; 
	 }
	 else {
		return $val["sum_".$field]; 
	 }
	 
}
public function get_total_kpi()
{ 
     $data_val=$this->get_total_kpi_val(); 

    
	 $table = 'nuhm_master_tbl';
	 $where = "where year='".$data_val['year']."' and Quarterly='".$data_val['Quarterly']."' ";
	 
	  $total_kpi = array();	
	  
	  $value1 = $this->getSumFieldValue('Sanctioned_Post_for_Medical_Officers_Under_NUHM', $table, $where);
	  $value2 = $this->getSumFieldValue('Vacancies_of_Medical_officers_under_NUHM', $table, $where);
	 $total_kpi[] = 'Vacancies ('.$this->calpercentage1()."%) of Medical Officers (including specialists) against sanctioned posts under NUHM : ".$value2.'/'.$value1 ; 
	 
	 $value1 = $this->getSumFieldValue('Sanctioned_Post_for_Nurses_Under_NUHM', $table, $where);
	 $value2 = $this->getSumFieldValue('Vacancies_of_Nurses_under_NUHM', $table, $where);
	 $total_kpi[] = 'Vacancies ('.$this->calpercentage2()."%) of Staff Nurse against sanctioned posts under NUHM:".$value2.'/'.$value1 ;
	 
	 $value1 = $this->getSumFieldValue('Sanctioned_Post_for_ANMs_Under_NUHM', $table, $where);
	 $value2 = $this->getSumFieldValue('Vacancies_of_ANMs_under_NUHM', $table, $where);
	 $total_kpi[] = 'Vacancies ('.$this->calpercentage3()."%) of ANMs against sanctioned posts under NUHM:".$value2.'/'.$value1 ;
	
	 $value1 = $this->getSumFieldValue('Sanctioned_Post_for_Lab_Technicians_Under_NUHM', $table, $where);
	 $value2 = $this->getSumFieldValue('Vacancies_of_Lab_Technicians_under_NUHM', $table, $where);
	 $total_kpi[] = 'Vacancies ('.$this->calpercentage4()."%) of Lab Technicians against sanctioned posts under NUHM: ".$value2.'/'.$value1 ;
	 
	  $value1 = $this->getSumFieldValue('Sanctioned_Post_for_Pharmacists_Under_NUHM', $table, $where);
	  $value2 = $this->getSumFieldValue('Vacancies_of_Lab_Pharmacists_under_NUHM', $table, $where);
	 $total_kpi[] = "Vacancies (".$this->calpercentage5()."%) of Pharmacists against sanctioned posts under NUHM: ".$value2.'/'.$value1 ;
	 
	 $value1 = $this->getSumFieldValue('No_of_UPHCs_Operationalized_as_HWCs', $table, $where);
	 $total_kpi[] = 'No. of UPHCs Operationalized HWCs : '.$value1 ;
	 
	 $value1 = $this->getSumFieldValue('Number_of_MAS_approved', $table, $where);
	 $value2 = $this->getSumFieldValue('Number_of_MAS_created', $table, $where);
	 $total_kpi[] = $this->calpercentage6()."% of MAS created against Approved: ".$value2.'/'.$value1 ;
	
    $data['total_kpi'] = implode(',',$total_kpi);
	 $data=str_replace("N/E/N/E","N/E",$data);
    return $data;
}

public function get_total_header(){
   $qry="SELECT sum(Sanctioned_Post_for_Medical_Officers_Under_NUHM)  as header_count,'Total Ambulances Operational' as header_title FROM `nuhm_master_tbl`  ";
    return $this->db->query($qry)->row_array();  
}

public function get_table_data(){
   
    $subqry="(SELECT State_Name  FROM `m_state` where m_state.State_ID =state_id  limit 1) as state_name";
    $qry="SELECT State_Name, Sanctioned_Post_for_Medical_Officers_Under_NUHM as a,Vacancies_of_Medical_officers_under_NUHM as b FROM nuhm_master_tbl inner join m_state on m_state.State_ID=
    nuhm_master_tbl.state_id order by nuhm_master_tbl.state_id ";
    return $this->db->query($qry)->result_array();   
	
	//echo $this->db->last_query(); die;
}


public function get_array_kpi(){

    return array("Sanctioned_Post_for_Medical_Officers_Under_NUHM,Vacancies_of_Medical_officers_under_NUHM",
	"Sanctioned_Post_for_Nurses_Under_NUHM,Vacancies_of_Nurses_under_NUHM",
	"Sanctioned_Post_for_ANMs_Under_NUHM,Vacancies_of_ANMs_under_NUHM",
	"Sanctioned_Post_for_Lab_Technicians_Under_NUHM,Vacancies_of_Lab_Technicians_under_NUHM",
	"Sanctioned_Post_for_Pharmacists_Under_NUHM,Vacancies_of_Lab_Pharmacists_under_NUHM",
	"No_of_UPHCs_Operationalized_as_HWCs",
	"Number_of_MAS_approved,Number_of_MAS_created"
	);
}

public function get_table_kpi_data($id){
    $data_val=$this->get_total_kpi_val();
    
	if($id=="Sanctioned_Post_for_Medical_Officers_Under_NUHM,Vacancies_of_Medical_officers_under_NUHM"){
		$qry="SELECT State_Name,".$id." FROM nuhm_master_tbl inner join m_state on m_state.State_ID=
		nuhm_master_tbl.state_id where  nuhm_master_tbl.year='".$data_val['year']."' and nuhm_master_tbl.Quarterly ='".$data_val['Quarterly']."' and Sanctioned_Post_for_Medical_Officers_Under_NUHM<>'' group by nuhm_master_tbl.state_id order by State_Name";
		return $this->db->query($qry)->result_array(); 
	}
	if($id=="Sanctioned_Post_for_Nurses_Under_NUHM,Vacancies_of_Nurses_under_NUHM"){
		$qry="SELECT State_Name,".$id." FROM nuhm_master_tbl inner join m_state on m_state.State_ID=
		nuhm_master_tbl.state_id where  nuhm_master_tbl.year='".$data_val['year']."' and nuhm_master_tbl.Quarterly ='".$data_val['Quarterly']."' and Sanctioned_Post_for_Nurses_Under_NUHM<>'' group by nuhm_master_tbl.state_id  order by State_Name";
		return $this->db->query($qry)->result_array(); 
	}
	if($id=="Sanctioned_Post_for_ANMs_Under_NUHM,Vacancies_of_ANMs_under_NUHM"){
		$qry="SELECT State_Name,".$id." FROM nuhm_master_tbl inner join m_state on m_state.State_ID=
		nuhm_master_tbl.state_id where  nuhm_master_tbl.year='".$data_val['year']."' and nuhm_master_tbl.Quarterly ='".$data_val['Quarterly']."' and Sanctioned_Post_for_ANMs_Under_NUHM<>'' group by nuhm_master_tbl.state_id order by State_Name ";
		return $this->db->query($qry)->result_array(); 
	}
	if($id=="Sanctioned_Post_for_Lab_Technicians_Under_NUHM,Vacancies_of_Lab_Technicians_under_NUHM"){
		$qry="SELECT State_Name,".$id." FROM nuhm_master_tbl inner join m_state on m_state.State_ID=
		nuhm_master_tbl.state_id where  nuhm_master_tbl.year='".$data_val['year']."' and nuhm_master_tbl.Quarterly ='".$data_val['Quarterly']."' and Sanctioned_Post_for_Lab_Technicians_Under_NUHM<>'' group by nuhm_master_tbl.state_id order by State_Name ";
		return $this->db->query($qry)->result_array(); 
	}
	if($id=="Sanctioned_Post_for_Pharmacists_Under_NUHM,Vacancies_of_Lab_Pharmacists_under_NUHM"){
		$qry="SELECT State_Name,".$id." FROM nuhm_master_tbl inner join m_state on m_state.State_ID=
		nuhm_master_tbl.state_id where  nuhm_master_tbl.year='".$data_val['year']."' and nuhm_master_tbl.Quarterly ='".$data_val['Quarterly']."' and Sanctioned_Post_for_Pharmacists_Under_NUHM<>'' group by nuhm_master_tbl.state_id order by State_Name ";
		return $this->db->query($qry)->result_array(); 
	}
	if($id=="No_of_UPHCs_Operationalized_as_HWCs"){
		$qry="SELECT State_Name,".$id." FROM nuhm_master_tbl inner join m_state on m_state.State_ID=
		nuhm_master_tbl.state_id where  nuhm_master_tbl.year='".$data_val['year']."' and nuhm_master_tbl.Quarterly ='".$data_val['Quarterly']."' and No_of_UPHCs_Operationalized_as_HWCs<>'' group by nuhm_master_tbl.state_id order by State_Name ";
		return $this->db->query($qry)->result_array(); 
	}
	if($id=="Number_of_MAS_approved,Number_of_MAS_created"){
		$qry="SELECT State_Name,".$id." FROM nuhm_master_tbl inner join m_state on m_state.State_ID=
		nuhm_master_tbl.state_id where  nuhm_master_tbl.year='".$data_val['year']."' and nuhm_master_tbl.Quarterly ='".$data_val['Quarterly']."' and Number_of_MAS_approved<>'' group by nuhm_master_tbl.state_id order by State_Name ";
		return $this->db->query($qry)->result_array(); 
	}
	
	
}

}