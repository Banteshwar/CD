<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Nvhcp_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
  

/* public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `nvhcp_master_table`  order by year desc,Quarterly desc LIMIT 1";
    return $this->db->query($qry)->row_array();
} */

public function get_total_kpi_val(){
    
    $qry  = "SELECT * FROM `nvhcp_master_table` where e_year <= '".getCurrFinYear()."' and e_month <= '".getCurrMonth()."' order by e_year desc,e_month DESC LIMIT 1";
    $row  = $this->db->query($qry)->row_array();

    if(empty($row)) {

      $qry="SELECT * FROM `nvhcp_master_table` order by e_year desc,e_month desc LIMIT 1"; 

       $row = $this->db->query($qry)->row_array();
        //echo "Inner condition"; print_r($row);
    }

    return $row;

}

public function  getSumFieldValue($field, $table, $where =''){
	
	
	 $qry="SELECT sum(". $field.") as sum_". $field.", 
		  SUM(IF(". $field."='', 1,0)) as count_". $field.",
	    count(*) as total_count
	  FROM ".$table." " . $where; 
	  
	  
	 $val= $this->db->query($qry)->row_array();	 
	 
	 if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
		return 'N/E';
	 }
	 else if(empty($val['total_count']))
	 {
		return 'N/E'; 
	 }
	 else {
		return $val["sum_".$field]; 
	 }
	 
}
public function get_total_kpi()
{ 
     $data_val=$this->get_total_kpi_val(); 

    
	 $table = 'nvhcp_master_table';
	 $where = "where e_year='".$data_val['e_year']."' and e_month='".$data_val['e_month']."' ";
	 
	  $total_kpi = array();	
	  
	 $value1 = $this->getSumFieldValue('Number_of_Districts', $table, $where);
	 $total_kpi[] = "No. of Districts with at least 1 Treatment centre : ".$value1 ; 
	 
	 $value1 = $this->getSumFieldValue('Model_Treatment_Center_Target', $table, $where);
	 $total_kpi[] = "No. of Model Treatment Centres Target : ".$value1 ; 
	 
	  $value1 = $this->getSumFieldValue('Model_Treatment_Center_Achieved', $table, $where);
	 $total_kpi[] = "No. of Model Treatment Centre Achieved : ".$value1 ;
	 
	 $value1 = $this->getSumFieldValue('Districts_with_TC', $table, $where);
	 $total_kpi[] = "No. of Districts with Treatment Centres : ".$value1 ;
	 
	 $value1 = $this->getSumFieldValue('Total_No_of_TC', $table, $where);
	 $total_kpi[] = "Total No. of Treatment Centres : ".$value1 ;
	 
	 $value1 = $this->getSumFieldValue('Patient_on_treatment', $table, $where);
	 $total_kpi[] = "No. of patients put on treatment for Hepatitis-C : ".$value1 ;
	 
	 $value1 = $this->getSumFieldValue('Patient_Successfully_Treated', $table, $where);
	 $total_kpi[] = "No. of Hepatitis-C patients successfully treated : ".$value1 ;
	 
	 $value1 = $this->getSumFieldValue('Institutional_Deliveries', $table, $where);
	 $total_kpi[] = "No. of Institutional deliveries : ".$value1 ;
	 
	 $value1 = $this->getSumFieldValue('Newborns_Receiving_birth_dose_of_Hepatitis_B_vaccine', $table, $where);
	 $total_kpi[] = "No. of Newborns receiving Birth dose of Hepatitis-B vaccine : ".$value1 ;
	
    $data['total_kpi'] = implode(',',$total_kpi);
	 $data=str_replace("N/E/N/E","N/E",$data);
	 
    return $data;
}

public function get_total_header(){
   //$qry="SELECT sum(Sanctioned_Post_for_Medical_Officers_Under_NUHM)  as header_count,'Total Ambulances Operational' as header_title FROM `nvhcp_master_table`  ";
   // return $this->db->query($qry)->row_array();  
   return 1;
}

public function get_table_data(){
   
    //$subqry="(SELECT State_Name  FROM `m_state` where m_state.State_ID =state_id  limit 1) as state_name";
   // $qry="SELECT State_Name, Sanctioned_Post_for_Medical_Officers_Under_NUHM as a,Vacancies_of_Medical_officers_under_NUHM as b FROM nvhcp_master_table inner join m_state on m_state.State_ID=
   // nvhcp_master_table.state_id order by nvhcp_master_table.state_id ";
    return 1; //$this->db->query($qry)->result_array();   
	
	//echo $this->db->last_query(); die;
}


public function get_array_kpi(){

    return array("Number_of_Districts",
	"Model_Treatment_Center_Target",
	"Model_Treatment_Center_Achieved",
	"Districts_with_TC",
	"Total_No_of_TC",
	"Patient_on_treatment",
	"Patient_Successfully_Treated",
	"Institutional_Deliveries",
	"Newborns_Receiving_birth_dose_of_Hepatitis_B_vaccine"
	);
}

public function get_table_kpi_data($id){
    $data_val=$this->get_total_kpi_val();
    
	if($id=="Number_of_Districts"){
		$qry="SELECT State_Name,".$id." FROM nvhcp_master_table inner join m_state on m_state.State_ID=
		nvhcp_master_table.state_id where  nvhcp_master_table.e_year='".$data_val['e_year']."' and nvhcp_master_table.e_month ='".$data_val['e_month']."' and Number_of_Districts<>''and Number_of_Districts<>0 group by nvhcp_master_table.state_id order by State_Name";
		return $this->db->query($qry)->result_array(); 
	}
	if($id=="Model_Treatment_Center_Target"){
		$qry="SELECT State_Name,".$id." FROM nvhcp_master_table inner join m_state on m_state.State_ID=
		nvhcp_master_table.state_id where  nvhcp_master_table.e_year='".$data_val['e_year']."' and nvhcp_master_table.e_month ='".$data_val['e_month']."' and Model_Treatment_Center_Target<>'' and Model_Treatment_Center_Target<>0 group by nvhcp_master_table.state_id order by State_Name";
		return $this->db->query($qry)->result_array(); 
	}
	if($id=="Model_Treatment_Center_Achieved"){
		$qry="SELECT State_Name,".$id." FROM nvhcp_master_table inner join m_state on m_state.State_ID=
		nvhcp_master_table.state_id where  nvhcp_master_table.e_year='".$data_val['e_year']."' and nvhcp_master_table.e_month ='".$data_val['e_month']."' and Model_Treatment_Center_Achieved<>'' and Model_Treatment_Center_Achieved<>0 group by nvhcp_master_table.state_id order by State_Name";
		return $this->db->query($qry)->result_array();  
	}
	if($id=="Districts_with_TC"){
		$qry="SELECT State_Name,".$id." FROM nvhcp_master_table inner join m_state on m_state.State_ID=
		nvhcp_master_table.state_id where  nvhcp_master_table.e_year='".$data_val['e_year']."' and nvhcp_master_table.e_month ='".$data_val['e_month']."' and Districts_with_TC<>'' and Districts_with_TC<>0 group by nvhcp_master_table.state_id order by State_Name";
		return $this->db->query($qry)->result_array();  
	}
	if($id=="Total_No_of_TC"){
		$qry="SELECT State_Name,".$id." FROM nvhcp_master_table inner join m_state on m_state.State_ID=
		nvhcp_master_table.state_id where  nvhcp_master_table.e_year='".$data_val['e_year']."' and nvhcp_master_table.e_month ='".$data_val['e_month']."' and Total_No_of_TC<>''and Total_No_of_TC<>0 group by nvhcp_master_table.state_id order by State_Name";
		return $this->db->query($qry)->result_array();
	}
	if($id=="Patient_on_treatment"){
		$qry="SELECT State_Name,".$id." FROM nvhcp_master_table inner join m_state on m_state.State_ID=
		nvhcp_master_table.state_id where  nvhcp_master_table.e_year='".$data_val['e_year']."' and nvhcp_master_table.e_month ='".$data_val['e_month']."' and Patient_on_treatment<>''and Patient_on_treatment<>0 group by nvhcp_master_table.state_id order by State_Name";
		return $this->db->query($qry)->result_array();
	}
	if($id=="Patient_Successfully_Treated"){
		$qry="SELECT State_Name,".$id." FROM nvhcp_master_table inner join m_state on m_state.State_ID=
		nvhcp_master_table.state_id where  nvhcp_master_table.e_year='".$data_val['e_year']."' and nvhcp_master_table.e_month ='".$data_val['e_month']."' and Patient_Successfully_Treated<>''and Patient_Successfully_Treated<>0 group by nvhcp_master_table.state_id order by State_Name";
		return $this->db->query($qry)->result_array();
	}
	if($id=="Institutional_Deliveries"){
		$qry="SELECT State_Name,".$id." FROM nvhcp_master_table inner join m_state on m_state.State_ID=
		nvhcp_master_table.state_id where  nvhcp_master_table.e_year='".$data_val['e_year']."' and nvhcp_master_table.e_month ='".$data_val['e_month']."' and Institutional_Deliveries<>''and Institutional_Deliveries<>0 group by nvhcp_master_table.state_id order by State_Name";
		return $this->db->query($qry)->result_array();
	}
	if($id=="Newborns_Receiving_birth_dose_of_Hepatitis_B_vaccine"){
		$qry="SELECT State_Name,".$id." FROM nvhcp_master_table inner join m_state on m_state.State_ID=
		nvhcp_master_table.state_id where  nvhcp_master_table.e_year='".$data_val['e_year']."' and nvhcp_master_table.e_month ='".$data_val['e_month']."' and Newborns_Receiving_birth_dose_of_Hepatitis_B_vaccine<>''and Newborns_Receiving_birth_dose_of_Hepatitis_B_vaccine<>0 group by nvhcp_master_table.state_id order by State_Name";
		return $this->db->query($qry)->result_array();
	}
	/**/
	
	
}

}