<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Pbs_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   


public function get_total_kpi(){
    $data_val=$this->get_total_kpi_val();

    $qry="SELECT concat('Personnel trained in NCD management: ',sum(trained_NCD_mgmt),' ,Personnel trained on NCD application : ', sum(trained_NCD_appl),' ,Persons enrolled in NCD application : ', sum(enrolled_NCD_appl),' ,Persons screened For NCD: ', sum(persons_screened)) as total_kpi FROM `tbl_pbs` where e_year='".$data_val['e_year']."' and e_month='".$data_val['e_month']."'  ";
    return $this->db->query($qry)->row_array();

}

public function get_total_header(){
   $qry="SELECT sum(trained_NCD_mgmt)  as header_count,'trained_NCD_appl' as header_title FROM `tbl_pbs`  ";
    return $this->db->query($qry)->row_array();  
}

public function get_table_data(){
   
    //$subqry="(SELECT State_Name FROM `m_state` where m_state.State_ID =state_id  limit 1) as state_id";
   $qry="SELECT trained_NCD_mgmt,trained_NCD_appl,enrolled_NCD_appl,persons_screened FROM tbl_pbs ";
    return $this->db->query($qry)->result_array();   
	
	//echo $this->db->last_query(); die;
}


public function get_array_kpi(){

    return array("trained_NCD_mgmt as 'Personnel trained in NCD management'","trained_NCD_appl as 'Personnel trained on NCD application'","enrolled_NCD_appl as 'Persons enrolled in NCD application'","persons_screened as 'Persons screened For NCD'");
}

public function get_table_kpi_data($id){
   
   

   
      $data_val=$this->get_total_kpi_val();

    $qry="SELECT State_Name, ".$id." FROM tbl_pbs inner join m_state on m_state.State_ID=
    tbl_pbs.state_id where  e_year='".$data_val['e_year']."' and e_month ='".$data_val['e_month']."' group  by tbl_pbs.state_id ";
    return $this->db->query($qry)->result_array();   
}
public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `tbl_pbs` GROUP by state_id  order by e_year,e_month";
    return $this->db->query($qry)->row_array();
}

}