<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Pclp2_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    

public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `pclp_casesreported_master_table` where 'year' <= ".getCurrYear()." and 'month' <= ".getCurrMonth()." order by e_year desc,financial_month desc LIMIT 1"; 
    return $this->db->query($qry)->row_array();
}



public function  getSumFieldValue($field, $table, $where =''){
	
	
	 $qry="SELECT sum(". $field.") as sum_". $field.", 
		  SUM(IF(". $field."='', 1,0)) as count_". $field.",
	    count(*) as total_count
	  FROM ".$table." " . $where; 
	  
	  
	 $val= $this->db->query($qry)->row_array();	 
	 
	 if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
		return 'N/E';
	 }
	 else if($val['total_count']==0)
	 {
		return 'N/E'; 
	 }
	 else {
		return $val["sum_".$field]; 
	 }
	 
}

public function get_total_kpi()
{ 
     $data_val=$this->get_total_kpi_val(); 

    
	 $table = 'pclp_casesreported_master_table';
	 $where = "where e_year='".$data_val['e_year']."' and financial_month='".$data_val['financial_month']."' ";
	 
	  $total_kpi = array();	
	  
	  $value = $this->getSumFieldValue('Total_Number_of_districts_affected', $table, $where);
	 $total_kpi[] = 'Total Number of Districts Affected: '.$value ; 
	 
	
	 
	 $value = $this->getSumFieldValue('Number_of_Leptospirosis_outbreaks_reported', $table, $where);	 
	 $total_kpi[] = 'Leptospirosis outbreaks reported: '.$value ; 
	 
	 $value = $this->getSumFieldValue('laboratory_leptospirosis_casesreported', $table, $where);
	 $total_kpi[] = 'Total No of Laboratory Confirmed Cases: '.$value ; 
	 
    $data['total_kpi'] = implode(',',$total_kpi);
	
	//echo print_r($data); die;
    return $data;
}

public function get_array_kpi(){

  
	
	return  array("Total_Number_of_districts_affected as 'No. of Districts Affected'","Number_of_Leptospirosis_outbreaks_reported as 'Number of Leptospirosis outbreaks reported'","laboratory_leptospirosis_casesreported as 'No of Laboratory Confirmed Cases'");
	 
}



public function get_table_kpi_data($id){ 

	$data_val=$this->get_total_kpi_val();

     //$data_val1=$this->get_total_kpi_val1();
	 
	$idWithoutAs = substr($id, 0, stripos($id, "as "));
 
    $qry="SELECT State_Name,".$id." FROM pclp_casesreported_master_table inner join m_state on m_state.State_ID=
    pclp_casesreported_master_table.state_id  where e_year='".$data_val['e_year']."' and financial_month='".$data_val['financial_month']."' AND ".$idWithoutAs." !='' AND ".$idWithoutAs." !='0' order by m_state.State_Name "; 
    return $this->db->query($qry)->result_array(); 

    
   
	
}



}