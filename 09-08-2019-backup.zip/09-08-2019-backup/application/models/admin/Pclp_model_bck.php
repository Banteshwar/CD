<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Pclp_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
public function get_PCLP(){ 
    $this->db->select('pclp_master_table.*');
    $this->db->from('pclp_master_table');
	// $this->db->join('m_state','m_state.State_ID=nohp_master_table.state_id','inner');
    
   $this->db->order_by("pclp_master_table.id", "desc");

        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
}

public function get_pclpform(){
		
		$sql     =  "select * from pclp_master_table";
	
		$stmt = $this->db->query($sql); 
        if($stmt->num_rows()>0){
            return $stmt->result_array(); 
        }else{
            return false;
        }
        
	}

public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `pclp_master_table` order by e_year desc,e_quarter desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}

public function get_total_kpi_val1(){
    
    $qry="SELECT * FROM `pclp_casesreported_master_table` order by e_year desc,e_quarter desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}




public function get_total_kpi()
{
    $data_val=$this->get_total_kpi_val();
     $data_val1=$this->get_total_kpi_val1();

    $qry="SELECT concat('Total Laboratory confirmed Leptospirosis cases reported : ',(select sum(laboratory_leptospirosis_casesreported) from pclp_casesreported_master_table where e_year='".$data_val1['e_year']."' and e_quarter='".$data_val1['e_quarter']."' ),',Leptospirosis outbreaks reported : ',count(id)) as total_kpi FROM `pclp_master_table` where e_year='".$data_val['e_year']."' and e_quarter='".$data_val['e_quarter']."' ";
    return $this->db->query($qry)->row_array();
}

public function get_array_kpi(){

    $qry =  array("laboratory_leptospirosis_casesreported as 'Laboratory confirmed Leptospirosis cases reported'","disease_syndrome as 'Disease/Syndrome',no_of_cases as 'Number of Cases',no_of_deaths as 'Number of Deaths',date_of_outbreak as 'Date of Outbreak'");
    return $qry;
}



public function get_table_kpi_data($id){
    $data_val=$this->get_total_kpi_val();

     $data_val1=$this->get_total_kpi_val1();

     if($id == "laboratory_leptospirosis_casesreported as 'Laboratory confirmed Leptospirosis cases reported'"){

         $qry="SELECT State_Name,".$id." FROM pclp_casesreported_master_table inner join m_state on m_state.State_ID=
    pclp_casesreported_master_table.state_id  where e_year='".$data_val1['e_year']."' and e_quarter='".$data_val1['e_quarter']."' order by pclp_casesreported_master_table.state_id ";
    return $this->db->query($qry)->result_array(); 

     }
     if($id == "disease_syndrome as 'Disease/Syndrome',no_of_cases as 'Number of Cases',no_of_deaths as 'Number of Deaths',date_of_outbreak as 'Date of Outbreak'"){

         $qry="SELECT State_Name,".$id." FROM pclp_master_table inner join m_state on m_state.State_ID=
    pclp_master_table.state_id  where e_year='".$data_val['e_year']."' and e_quarter='".$data_val['e_quarter']."' order by pclp_master_table.state_id ";
    return $this->db->query($qry)->result_array(); 

     }

   
	
}



}