<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Pczdmap_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   


public function get_map_data(){

    $qry="SELECT concat('Health and Veterinary professionals trained	 : ',Health_and_Veterinary_professionals_trained) AS hover, state_id FROM `pczd_master_table` order by state_id";
    return $this->db->query($qry)->result_array();

}

/* public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `pczd_master_table` order by e_year desc,e_quarter desc LIMIT 1";
    return $this->db->query($qry)->row_array();
} */


public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `pczd_master_table` where e_year <= '".getCurrFinYear()."' and e_quarter <= '".getCurrQuarter('Quarterly')."' order by e_year desc,e_quarter desc LIMIT 1"; 

    $row = $this->db->query($qry)->row_array();
    
    if(empty($row)) {

      $qry="SELECT * FROM `pczd_master_table` where e_year < '".getCurrFinYear()."' order by e_year desc,e_quarter desc LIMIT 1"; 

       $row = $this->db->query($qry)->row_array();        
    }

    return $row;
}

public function  getSumFieldValue($field, $table, $where =''){
	
	
	 $qry="SELECT sum(". $field.") as sum_". $field.", 
		  SUM(IF(". $field."='' , 1,0)) as count_". $field.",
	    count(*) as total_count
	  FROM ".$table." " . $where; 
	  
	  
	 $val= $this->db->query($qry)->row_array();	 
	 
	 if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
		return 'N/E';
	 }
	 else if(empty($val['total_count']))
	 {
		return 'N/E'; 
	 } 
	 
	 else {
		return $val["sum_".$field]; 
	 }
	 
}

public function get_total_kpi()
{ 
     $data_val=$this->get_total_kpi_val(); 

    
	 $table = 'pczd_master_table';
	 $where = "where e_year='".$data_val['e_year']."' and e_quarter='".$data_val['e_quarter']."' ";
	 
	  $total_kpi = array();	
	  
	  $value = $this->getSumFieldValue('Health_and_Veterinary_professionals_trained', $table, $where);
	 $total_kpi[] = 'Total Health and Veterinary professionals trained: '.$value ; 
	 
	
	 
	
	
	 
    $data['total_kpi'] = implode(',',$total_kpi);
	
	//echo print_r($data); die;
    return $data;
}

public function get_total_header(){
    $qry="SELECT sum(Health_and_Veterinary_professionals_trained)  as header_count,'Total Health and Veterinary professionals trained' as header_title FROM `pczd_master_table`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_table_data(){
    $subqry="(SELECT State_Name FROM `m_state` where m_state.State_ID =state_id  limit 1) as state_name";
    $qry="SELECT State_Name,  Health_and_Veterinary_professionals_trained FROM pczd_master_table inner join m_state on m_state.State_ID=
    pczd_master_table.state_id  order by m_state.State_Name ";
    return $this->db->query($qry)->result_array();   
}

public function get_table_data_map(){
    
    $qry="SELECT State_Name,Health_and_Veterinary_professionals_trained FROM pczd_master_table inner join m_state on m_state.State_ID=
    pczd_master_table.state_id  order by pczd_master_table.state_id ";
    return $this->db->query($qry)->result_array();   
}

public function get_table_header($table){
    $qry="describe $table  ";
    return $this->db->query($qry)->result_array();   
}


public function get_array_kpi(){
    return array("Health_and_Veterinary_professionals_trained as 'No. of Health and Veterinary professionals trained'");
}
/*
public function get_table_kpi_data($id){
  

    $data_val=$this->get_total_kpi_val();
    
    $qry="SELECT State_Name, ".$id." FROM pczd_master_table inner join m_state on m_state.State_ID=
    pczd_master_table.state_id where  e_year='".$data_val['e_year']."' and e_quarter ='".$data_val['e_quarter']."' GROUP by pczd_master_table.state_id  ";
   
    return $this->db->query($qry)->result_array();  
}
*/

public function get_table_kpi_data($id){ 

	$data_val=$this->get_total_kpi_val();

     //$data_val1=$this->get_total_kpi_val1();
	 
	$idWithoutAs = substr($id, 0, stripos($id, "as "));
 
    $qry="SELECT State_Name,".$id." FROM pczd_master_table inner join m_state on m_state.State_ID=
    pczd_master_table.state_id  where e_year='".$data_val['e_year']."' and e_quarter ='".$data_val['e_quarter']."' AND ".$idWithoutAs." !='' AND ".$idWithoutAs." !='0' order by m_state.State_Name "; 
    return $this->db->query($qry)->result_array(); 

}

}