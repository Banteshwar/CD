<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Pmjay_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   



public function get_total_kpi(){
   
   $qry="SELECT concat('No. of E-Cards Generated : ',sum(no_ecards_generated),',No. of Pre-Authorizations Done : ' , sum(no_pre_authorizations),',Hospitals Empanelled Under the scheme : ' , sum(hospitals_empanelled_scheme)) as total_kpi FROM `pmjay_master_table`  ";
   
  return $this->db->query($qry)->row_array();
	
}

public function get_total_header(){
    $qry="SELECT sum(no_ecards_generated)  as header_count,'No. of e-cards generated' as header_title FROM `tbl_pmjay`  ";
    return $this->db->query($qry)->row_array();   
}

/*public function get_table_data(){
    
    $qry="SELECT SUM(No_of_districts_with_functional_dialysis_units),SUM(units_against_the_total_districts),SUM(No_of_patients_receiving_treatment) FROM tbl_pmjay  ";
    return $this->db->query($qry)->result_array();   
}*/




public function get_array_kpi(){

    $qry =  array("no_ecards_generated as 'No. of E-Cards Generated'","no_pre_authorizations as 'No. of Pre-Authorizations Done'","hospitals_empanelled_scheme as 'Hospitals Empanelled Under the scheme'");
   
    return $qry;
}

public function get_table_kpi_data($id){
        
   $qry="SELECT State_Name,".$id." FROM pmjay_master_table inner join m_state on m_state.State_ID=
    pmjay_master_table.state_id order by m_state.State_Name ";
   
    return $this->db->query($qry)->result_array();  
}
 
    
   
}

