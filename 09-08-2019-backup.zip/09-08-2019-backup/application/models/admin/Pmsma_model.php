<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Pmsma_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
public function get_map_data(){

    $qry="SELECT concat('Number of PPIUCD insertions: ',ppiucd_insertion_no,',Total institutional deliveries : ',total_institution_delivery,',PPIUCD acceptance rate : ',acceptance_rate,',Number of Injectable doses given : ',injectable_doses) AS hover,'Patient Treatment Successfully : ',Patient_Successfully_Treated,'Percentage of newborns : ',Newborns_Receiving_birth_dose_of_Hepatitis_B_vaccine, state_id FROM `nvhcp_master_table` order by state_id";
    return $this->db->query($qry)->result_array();

}

public function get_totalRecordNVHCPs(){ 
    $this->db->select('SUM(firsttrimester) as mt , SUM(institutedelivery) as ma , SUM(anccheckup) as nd , SUM(noofanc) as id');
    $this->db->from('maternal_master_table');
    
    $this->db->order_by("maternal_master_table.id", "desc");

    $query = $this->db->get();

    return $query->row_array();  
}

public function get_total_header(){
    $qry="SELECT sum(firsttrimester)  as header_count,'Percentage of First trimester registration during ANC' as header_title FROM `maternal_master_table`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_total_kpi(){

    $qry="SELECT concat('Percentage of First trimester registration during ANC : ',sum(firsttrimester),' ,Percentage of Institutional delivery: ', sum(institutedelivery),' ,Percentage - 4 or more ANC checkup : ' ,sum(anccheckup) ,', PMSMA-No. ANCs conducted under PMSMA : ',sum(noofanc)) as total_kpi FROM `maternal_master_table` ";
    return $this->db->query($qry)->row_array();

}

public function get_table_data(){
    $qry="SELECT firsttrimester,institutedelivery,anccheckup,noofanc FROM maternal_master_table order by id desc ";
    return $this->db->query($qry)->result_array();   
}

public function get_table_header($table){
    $qry="describe $table  ";
    return $this->db->query($qry)->result_array();   
}

  


   
}

