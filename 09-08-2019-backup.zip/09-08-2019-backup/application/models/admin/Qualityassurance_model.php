<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Qualityassurance_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
 

public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `qa_master_table` order by financial_year desc,quarter desc LIMIT 1";
    $row   =  $this->db->query($qry)->row_array();
    return $row;
}

public function  getSumFieldValue($field, $table, $where =''){    
    
     $qry="SELECT sum(". $field.") as sum_". $field.", 
          SUM(IF(". $field."='', 1,0)) as count_". $field.",
        count(*) as total_count
      FROM ".$table." " . $where; 
      
      
     $val= $this->db->query($qry)->row_array();  
     
     if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
        return 'N/E';
     }else if(empty($val['total_count'])){
        return 'N/E'; 
     }
     else {
        return $val["sum_".$field]; 
     }     
}

public function get_total_kpi()
{ 
     $data_val=$this->get_total_kpi_val(); 

    
     $table = 'qa_master_table';
     $where = "where financial_year='".$data_val['financial_year']."' and quarter='".$data_val['quarter']."' ";
     
     $total_kpi = array(); 
      
     $value = $this->getSumFieldValue('nqas_facilities_count', $table, $where);
     $total_kpi[] = 'Number of facilities NQAS Certified : '.$value ; 
     
         
     $value = $this->getSumFieldValue('Number_of_facilities_LaQshya_certified', $table, $where);     
     $total_kpi[] = 'Number of facilities LaQshya Certified: '.$value ; 
     
     $data['total_kpi'] = implode(',',$total_kpi);
    
    //echo print_r($data); die;
    return $data;
}

public function get_array_kpi(){
    
    return  array("nqas_facilities_count as 'Number of facilities NQAS Certified'","Number_of_facilities_LaQshya_certified as 'Number of facilities LaQshya Certified'");
     
}

public function get_table_kpi_data($id){ 

    $data_val=$this->get_total_kpi_val();
     
    $idWithoutAs = substr($id, 0, stripos($id, "as "));
 
    $qry="SELECT State_Name,".$id." FROM qa_master_table inner join m_state on m_state.State_ID=
    qa_master_table.state_id  where financial_year='".$data_val['financial_year']."' and quarter='".$data_val['quarter']."' AND ".$idWithoutAs." !='' AND ".$idWithoutAs." !='0' order by m_state.State_Name "; 
    return $this->db->query($qry)->result_array(); 
}



}