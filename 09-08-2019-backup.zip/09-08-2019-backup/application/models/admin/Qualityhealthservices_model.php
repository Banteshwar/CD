<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Qualityhealthservices_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   


public function get_totalRecordnqas(){ 
    $this->db->select('SUM( nqas_facilities_count ) as nfc , updated_date ');
    $this->db->from('qa_master_table');
    
    $this->db->order_by("qa_master_table.id", "desc");

    $query = $this->db->get();

    return $query->row_array();  
}

  public function get_rtidata(){ 
    $this->db->select('SUM(	RTI_Applications_Received) as rtirecv ,SUM(	RTI_Application_Disposed_Off	) as rtideposed,SUM(First_Appeal_Received) as appelarecv ,SUM(First_Appeal_Disposed_Off) as appealoff');
    $this->db->from('rti_master_tbl');
    
    

    $query = $this->db->get();

    return $query->row_array();  
}

  public function Qualityhealthservices_get(){ 
    $this->db->select('SUM(firsttrimester) as firsttrimester,SUM(institutedelivery) as institutedelivery,SUM(anccheckup) as anccheckup,SUM(noofanc) as noofanc');
    $this->db->from('maternal_master_table');
    
    

    $query = $this->db->get();

    return $query->row_array();  
}
    
    public function nuhm_get(){ 
    $this->db->select('SUM(Medical_Officers+ANMs+Staff_Nurses+Lab_Technician+Pharmacists) as Pharmacists,SUM(Number_of_UHCs_operationalized_as_HWCs) as Number_of_UHCs_operationalized_as_HWCs,SUM(Number_of_Mahila_Arogya_Samiti_Constitued) as Number_of_Mahila_Arogya_Samiti_Constitued');
    $this->db->from('nuhm_master_tbl');
    
    

    $query = $this->db->get();

    return $query->row_array();  
}

public function Childhealth_get(){ 
    $this->db->select('SUM(ndd) as ndd ,SUM(idcf) as idcf ,SUM(no_of_children_screened) as no_of_children_screened,SUM(no_of_children_received) as no_of_children_received,SUM(no_of_newborns_received) as no_of_newborns_received');
    $this->db->from('childhealth_master_table');
    
    

    $query = $this->db->get();

    return $query->row_array();  
}


/* ORS CODE HERE */

public function ORS_get(){ 
    $this->db->select('*');
    $this->db->from('ors_master_table');

    $query = $this->db->get();

    return $query->result_array();  
}

/* ORS CODE ENDED */

}
