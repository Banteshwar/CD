<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Qualityhealthservices_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   


public function get_totalRecordnqas(){ 
    $this->db->select('SUM( nqas_facilities_count ) as nfc , updated_date ');
    $this->db->from('qa_master_table');
    
    $this->db->order_by("qa_master_table.id", "desc");

    $query = $this->db->get();

    return $query->row_array();  
}

  public function get_rtidata(){ 
    $this->db->select('SUM(	RTI_Applications_Received) as rtirecv ,SUM(	RTI_Application_Disposed_Off	) as rtideposed,SUM(First_Appeal_Received) as appelarecv ,SUM(First_Appeal_Disposed_Off) as appealoff');
    $this->db->from('rti_master_tbl');
    
    

    $query = $this->db->get();

    return $query->row_array();  
}

 
    
   
}

