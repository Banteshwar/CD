<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Rch_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   



public function get_total_kpi(){

$qry="SELECT concat('No. of Eligible Couple Registered : ',No_of_Eligible_Couple_Registered,' ,No. of Pregnant Woman Registered: ', No_of_Pregnant_Woman_Registered,' ,No. of Children Registered: ' , No_of_Children_Registered ,', No. of Health Providers : ',No_of_Health_Providers) as total_kpi FROM `rch_master_table` where State_code = '0'   ";
  return $this->db->query($qry)->result_array();

}


public function get_array_kpi(){

   return array("No_of_Eligible_Couple_Registered as 'No. of Eligible Couple Registered'","No_of_Pregnant_Woman_Registered as 'No. of Pregnant Woman Registered'","No_of_Children_Registered as 'No. of Children Registered'","No_of_Health_Providers as 'No. of Health Providers'");

}

public function get_table_kpi_data($id){
   
   $qry="SELECT m_state.State_Name, ".$id."  FROM  rch_master_table inner JOIN  m_state ON m_state.State_ID=rch_master_table.State_code where rch_master_table.State_code!='0'  order by m_state.State_Name ";
    return $this->db->query($qry)->result_array();
    
}

 
    
   
}

