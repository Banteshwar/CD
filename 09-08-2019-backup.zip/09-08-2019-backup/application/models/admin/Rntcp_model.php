<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Rntcp_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `rntcp_master_table` GROUP by state_id  order by e_year desc,e_month desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}
public function paid(){
	
	$data_val=$this->get_total_kpi_val();
	 $qry="SELECT sum(Total_amount_paid) as sum_amount  FROM `rntcp_child_table` where e_year='".$data_val['e_year']."' and e_month='".$data_val['e_month']."' ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount']; 
}

public function paidListing(){
	$data_val=$this->get_total_kpi_val();
	
	$qry="SELECT m.State_Name,s.Total_amount_paid FROM `rntcp_child_table` s left join m_state m on m.State_ID=s.state_id where s.e_year='".$data_val['e_year']."' and s.e_month='".$data_val['e_month']."' ";
	return $this->db->query($qry)->result_array();
}
public function BeneficiariesNumerbs(){
	
	$data_val=$this->get_total_kpi_val();
	 $qry="SELECT sum(Total_number_of_beneficiaries_paid_in_present_year) as sum_amount  FROM `rntcp_child_table` where e_year='".$data_val['e_year']."' and e_month='".$data_val['e_month']."' ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount']; 
}

public function BeneficiariesListing(){
	$data_val=$this->get_total_kpi_val();
	
	$qry="SELECT m.State_Name,s.Total_number_of_beneficiaries_paid_in_present_year as `Total number of beneficiaries paid in present year (Cumulative till reporting month` FROM `rntcp_child_table` s left join m_state m on m.State_ID=s.state_id where s.e_year='".$data_val['e_year']."' and s.e_month='".$data_val['e_month']."' ";
	return $this->db->query($qry)->result_array();
}
  
public function CurMonthNumerbs(){
	
	$data_val=$this->get_total_kpi_val();
	 $qry="SELECT sum(Corrected_Score) as sum_amount  FROM `rntcp_master_table` where e_year='".$data_val['e_year']."' and e_month='".$data_val['e_month']."' ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount']; 
}

public function CurMonthListing(){
	$data_val=$this->get_total_kpi_val();
	
	$qry="SELECT m.State_Name, TB_cases_notified_amongst_the_target_TB_cases,TB_cases_with_known_HIV_status,UDST_done_amongst_eligible_TB_cases,Treatment_success_rate,Nikshay_Poshan_Yojana,MDR_patients_initiated_on_treatment_amongst_diagnosed,Expenditure,eligible_children_given_chemoprophylaxis,eligible_PLHIV_patients_given_IPT,Total_Score,Corrected_Score as `State Score (Reporting month)` FROM `rntcp_master_table` s left join m_state m on m.State_ID=s.state_id where s.e_year='".$data_val['e_year']."' and s.e_month='".$data_val['e_month']."' ";
	return $this->db->query($qry)->result_array();
}

public function PreviousMonthNumbers(){
	$data_val=$this->get_total_kpi_val();
	$mon = ''; $year='';
	if($data_val['e_month']==1){
		$mon=12; $year = $data_val['e_year']-1;
	}else{
		
		$mon=$data_val['e_month']-1; $year = $data_val['e_year'];
	}
	$data_val=$this->get_total_kpi_val();
	
	 $qry="SELECT sum(Corrected_Score) as sum_amount  FROM `rntcp_master_table`  where e_year='".$year."' and e_month='".$mon."' ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount']; 
}

public function PreviousMonthListing(){
	$data_val=$this->get_total_kpi_val();
	$mon = ''; $year='';
	if($data_val['e_month']==1){
		$mon=12; $year = $data_val['e_year']-1;
	}else{
		
		$mon=$data_val['e_month']-1; $year = $data_val['e_year'];
	}
	$data_val=$this->get_total_kpi_val();
	
	$qry="SELECT m.State_Name, TB_cases_notified_amongst_the_target_TB_cases,TB_cases_with_known_HIV_status,UDST_done_amongst_eligible_TB_cases,Treatment_success_rate,Nikshay_Poshan_Yojana,MDR_patients_initiated_on_treatment_amongst_diagnosed,Expenditure,eligible_children_given_chemoprophylaxis,eligible_PLHIV_patients_given_IPT,Total_Score,Corrected_Score as `State Score (Previous month)` FROM `rntcp_master_table` s left join m_state m on m.State_ID=s.state_id where s.e_year='".$year."' and s.e_month='".$mon."' ";
	
	return $this->db->query($qry)->result_array();
}

public function gainLoss(){
	
	//Formula for calculating % Gain/ loss in score = [Score (reporting month) – Score (Previous month)/Score (Previous month)] X 100
	$val =''; $result = '';
	$val = $this->CurMonthNumerbs()-$this->PreviousMonthNumbers();
	$result = (($val/$this->PreviousMonthNumbers())*100);
	return  round($result);
}


public function get_total_kpi(){
	 $row  = array();
     $row['total_kpi'] = 'State Score (Reporting month) : '.$this->CurMonthNumerbs().' , State Score (Previous month) : '.$this->PreviousMonthNumbers().' , Percentage Gain/Loss in Score : '.$this->gainLoss().' , Total number of beneficiaries paid in present year (Cumulative till reporting month) : '.$this->BeneficiariesNumerbs().' , Total amount paid : '.$this->paid();	 

	 
	 return $row;
  
    //$qry="SELECT concat('No. of fully operational FRUs (5 C-section/month for CHC and SDH) against months : ',sum(chc),' , No. of fully operational FRUs (10 C-section/month for DH) against required no. of FRUs : ', sum(phc)) as total_kpi FROM `fru_master_table`  ";
   // return $this->db->query($qry)->row_array();
}

public function get_total_header(){
    $qry="SELECT sum(fru)  as header_count,'Total First Referral Unit' as header_title FROM `fru_master_table`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_table_data(){
	
   $data_val=$this->get_total_kpi_val();
   
    $qry="SELECT m.State_Name, TB_cases_notified_amongst_the_target_TB_cases,TB_cases_with_known_HIV_status,UDST_done_amongst_eligible_TB_cases,Treatment_success_rate,Nikshay_Poshan_Yojana,MDR_patients_initiated_on_treatment_amongst_diagnosed,Expenditure,eligible_children_given_chemoprophylaxis,eligible_PLHIV_patients_given_IPT,Total_Score,Corrected_Score FROM `rntcp_master_table` s left join m_state m on m.State_ID=s.state_id  where s.e_year='".$year."' and s.e_month='".$mon."' ";	
	
    return $this->db->query($qry)->result_array();   
}


public function get_array_kpi(){

     $qry =  array("Corrected_Score as 'State Score (Reporting month)'",
	 "second as 'State Score (Previous month)'",
	 "test", 
	 "third as 'Total number of beneficiaries paid in present year (Cumulative till reporting month)'",
	 "paid as 'Total amount paid'");
   
    return $qry;
}


public function get_table_kpi_data($id){
   
   if($id == "Corrected_Score as 'State Score (Reporting month)'") {
	   return $this->CurMonthListing();
   }
   
   if($id == "second as 'State Score (Previous month)'") {
	   return $this->PreviousMonthListing();
   }
   if($id == "test") {
	   return 1;
   }
    if($id == "third as 'Total number of beneficiaries paid in present year (Cumulative till reporting month)'") {
	   return $this->BeneficiariesListing();
   }
     if($id == "paid as 'Total amount paid'") {
	   return $this->paidListing();
   }
	return array();
	
    //$qry="SELECT year, fru_month, SUM(".$id.") AS ".$id."  FROM fru_master_table group by fru_master_table.year ";   
    //return $this->db->query($qry)->result_array();   
}

 
    
   
}

