<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Rntcp_model_17_07_2019 extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   


public function get_total_kpi(){

    $qry="SELECT concat('State TB Index Score up to the month : ',sum(state_tbindex_score),' ,State Ranking for performance up to the month: ', sum(state_ranking_reportingmonth),' ,State Ranking at the end of previous month : ' , sum(state_ranking_previousmonth) ,', Gain / Loss In Rank : ',sum(staterank_gainloss),' ,Annual Target: ', sum(annual_target),', Target till Reporting month : ',sum(target_reportingmonth),', Achievement till reporting month in previous year : ',sum(achievement_reportingmonth_previousyear),', Percentage Gain/Loss : ',sum(tbnotification_gainloss),', Total number of beneficiaries paid (Public/Private) : ',sum(no_of_benefeciaries),', Total amount paid (Public/Private) : ',sum(total_amount_paid)) as total_kpi FROM `rntcp_master_table` order by id DESC LIMIT 1 ";
    return $this->db->query($qry)->row_array();

}

public function get_total_header(){
    $qry="SELECT sum(state_tbindex_score)  as header_count,'State TB Index Score up to the month' as header_title FROM `rntcp_master_table`  ";
    return $this->db->query($qry)->row_array();   
}






public function get_array_kpi(){

   //return array("state_tbindex_score as 'test'","state_ranking_reportingmonth as 'testw'","state_ranking_previousmonth as 'testwd'","staterank_gainloss as 'testg'","annual_target as 'testf'","target_reportingmonth as 'testbb'","achievement_reportingmonth_previousyear as 'testhh'","tbnotification_gainloss as 'testjj'","no_of_benefeciaries as 'testhh'","total_amount_paid as 'testhh'");

    $qry =  array("state_tbindex_score","state_ranking_reportingmonth","state_ranking_previousmonth","staterank_gainloss","annual_target","target_reportingmonth","achievement_reportingmonth_previousyear","tbnotification_gainloss","no_of_benefeciaries","total_amount_paid");
	
	
   
    return $qry;
}

public function get_table_kpi_data($id){
	
	
	

				  
   
   
	
    $qry="SELECT State_Name,financial_year, ".$id."  FROM rntcp_master_table inner join m_state on m_state.State_ID=
    rntcp_master_table.state_id  group by m_state.State_Name, rntcp_master_table.financial_year";
   
    return $this->db->query($qry)->result_array();   
}

 
    
   
}

