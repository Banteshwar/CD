<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Rticell_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    

public function get_total_kpi_val(){
    
   // echo $qry="SELECT * FROM `rti_master_tbl` where year <= '".getCurrYear('Yearly')."' and month <= '".getCurrMonth('Monthly')."' order by year desc,month desc LIMIT 1"; die;

    $qry="SELECT * FROM `rti_master_tbl` order by year desc,month asc LIMIT 1";

    $row = $this->db->query($qry)->row_array();
   
    return $row;
}

/*public function get_total_kpi_val(){
    
    echo $qry="SELECT * FROM `rti_master_tbl` where year <= '".getCurrYear('Yearly')."' order by year desc,month desc LIMIT 1"; die;

    $row = $this->db->query($qry)->row_array();
    
    if(empty($row)) {

      $qry="SELECT * FROM `rti_master_tbl` where year < '".getCurrYear('Yearly')."' order by year desc,month desc LIMIT 1"; 
       $row = $this->db->query($qry)->row_array();        
    }
    return $row;
}*/


public function  getSumFieldValue($field, $table, $where =''){    
    
     $qry="SELECT sum(". $field.") as sum_". $field.", 
          SUM(IF(". $field."='' , 1,0)) as count_". $field.",
        count(*) as total_count
      FROM ".$table." " . $where; 
      
      
     $val= $this->db->query($qry)->row_array();  
     
     if($val["sum_".$field] == 0 && $val['total_count'] == $val["count_". $field]) {
        return 'N/E';
     }else if(empty($val['total_count'])){
        return 'N/E'; 
     }else {
        return $val["sum_".$field]; 
     }     
}

public function get_total_kpi(){ 

     $data_val=$this->get_total_kpi_val(); 
    
     $table = 'rti_master_tbl';
     $where = "where year='".$data_val['year']."' and month='".$data_val['month']."' ";
     
     $total_kpi = array(); 
      
     $value1 = $this->getSumFieldValue('RTI_Applications_Received', $table, $where);             
     if($value1=='N/E'){        
         $total_kpi[] = 'RTI Applications Received: N/E';
     }else{
        $total_kpi[]  = 'RTI Applications Received: '.$value1;
     }
  
     $value2 = $this->getSumFieldValue('RTI_Application_Disposed_Off', $table, $where);     
          
     if($value2=='N/E'){
        $total_kpi[]= 'RTI Applications Disposed Off: N/E';
     }else{
        $total_kpi[]= 'RTI Applications Disposed Off: '.$value2;
     }

   

     $value3 = $this->getSumFieldValue('First_Appeal_Received', $table, $where);     
          
     if($value3=='N/E'){
        $total_kpi[]= 'First Appeal Received: N/E';
     }else{
        $total_kpi[]= 'First Appeal Received: '.$value3;
     } 

     $value4 = $this->getSumFieldValue('First_Appeal_Disposed_Off', $table, $where);     
          
     if($value4=='N/E'){
        $total_kpi[]= 'First Appeal Disposed Off: N/E';
     }else{
        $total_kpi[]= 'First Appeal Disposed Off: '.$value4;
     }    
     
     $data['total_kpi'] = implode(',',$total_kpi);
        
     return str_replace('N/E/N/E','N/E',$data);
}

public function get_array_kpi(){

    $qry =  array("RTI_Applications_Received as 'RTI Applications Received'","RTI_Application_Disposed_Off as 'RTI Applications Disposed Off'",
      "First_Appeal_Received as 'First Appeal Received'"," 
      First_Appeal_Disposed_Off as 'First Appeal Disposed Off'");
   
    return $qry;
}

public function get_table_kpi_data($id){ 

    $data_val=$this->get_total_kpi_val();
     
    $idWithoutAs = substr($id, 0, stripos($id, "as "));
    
    $qry="SELECT State_Name,".$id." FROM rti_master_tbl inner join m_state on m_state.State_ID=
    rti_master_tbl.state_id  where year='".$data_val['year']."' and month='".$data_val['month']."' AND ".$idWithoutAs." !='' AND ".$idWithoutAs." !='0' order by m_state.State_Name "; 
    return $this->db->query($qry)->result_array();     
}

}