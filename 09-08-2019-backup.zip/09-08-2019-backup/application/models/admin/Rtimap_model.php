<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Rtimap_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
public function get_PMSSYs(){ 
    $this->db->select('nohp_master_table.*');
    $this->db->from('nohp_master_table');
	// $this->db->join('m_state','m_state.State_ID=nohp_master_table.state_id','inner');
    
 
   $this->db->order_by("nohp_master_table.id", "desc");


        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
}
    public function rti_list(){

     $this->db->select('rti_master_tbl.*,Year (rti_master_tbl.date) as year, Month(rti_master_tbl.date) as month');
     $this->db->from('rti_master_tbl');
     
     $this->db->order_by("rti_master_tbl.id", "desc");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
    /*global $db;
    $stmt = $db->query('select n.* , s.* from notto_master_tbl as n inner join m_state as s on  n.state_id = s.state_id order by n.id desc'); 
        return $stmt->fetchAll(); 
*/
   } 

public function get_map_data(){

    $qry="SELECT concat('ALS Operational : ',ALS_ambulances_operational,',ALS Required : ',ALS_ambulances_required,'BLS Operational : ',BLS_ambulances_operational,',BLS Required : ',BLS_ambulances_required) AS hover, state_id FROM `ambulance_master_table` order by state_id";
    return $this->db->query($qry)->result_array();

}


public function get_total_kpi(){

    $qry="SELECT concat('Total ALS Ambulances Operational : ',sum(ALS_ambulances_operational),' ,Total ALS Ambulances Required : ', sum(ALS_ambulances_required),' ,Total BLS Ambulances Operational : ' , sum(BLS_ambulances_operational) ,', Total BLS Ambulances Required : ',sum(BLS_ambulances_required)) as total_kpi FROM `ambulance_master_table`  ";
    return $this->db->query($qry)->row_array();

}

public function get_total_header(){
    $qry="SELECT sum(RTI_Applications_Received)  as header_count,'Total RTI Applications Received' as header_title FROM `rti_master_tbl`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_table_data(){
    $subqry="(SELECT State_Name FROM `m_state` where m_state.State_ID =state_id  limit 1) as state_name";
    $qry="SELECT State_Name,  ALS_ambulances_operational,ALS_ambulances_required,BLS_ambulances_operational,BLS_ambulances_required,ALS_average_response_time,BLS_average_response_time FROM ambulance_master_table inner join m_state on m_state.State_ID=
    ambulance_master_table.state_id  order by ambulance_master_table.state_id ";
    return $this->db->query($qry)->result_array();   
}

public function get_table_data_map(){
    
    $qry="SELECT State_Name,ALS_ambulances_operational,ALS_ambulances_required,BLS_ambulances_operational,BLS_ambulances_required,ALS_average_response_time,BLS_average_response_time FROM ambulance_master_table inner join m_state on m_state.State_ID=
    ambulance_master_table.state_id  order by ambulance_master_table.state_id ";
    return $this->db->query($qry)->result_array();   
}

public function get_table_header($table){
    $qry="describe $table  ";
    return $this->db->query($qry)->result_array();   
}
}