<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Son_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    

public function get_total_kpi(){

    $qry="SELECT concat('No. of Application SON : ',sum(noof_application_son),',No. of Application Exceptional Need Certificate(ENC): ',sum(noof_application_enc)) as total_kpi FROM `son_master_tbl`  ";
    return $this->db->query($qry)->row_array();

}


public function get_table_data(){
   
    $qry="SELECT noof_application_son as 'No. of Application SON', issued_son as 'Issued SON',  pending_son as 'Pending SON',  noof_application_enc  as 'No. of Application Exceptional Need Certificate(ENC)',
     issued_enc as 'Issued Exceptional Need Certificate(ENC)',pending_enc as 'Pending Exceptional Need Certificate(ENC)' FROM son_master_tbl
    order by son_master_tbl.id ";
    return $this->db->query($qry)->result_array();   
}

public function get_table_header($table){
    $qry="describe $table  ";
    return $this->db->query($qry)->result_array();   
}


}

