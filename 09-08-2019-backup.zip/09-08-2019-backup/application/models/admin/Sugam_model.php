<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Sugam_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
public function getFru(){ 
    $this->db->select('*');
    $this->db->from('fru_master_table');
    $query = $this->db->get();

	if ($query->num_rows() > 0) {
		foreach ($query->result() as $row) {
			$data[] = $row;
		}
		return $data;
	}
	return false;
}


public function HrNumerbs(){
	
	 $qry="SELECT concat(sum(sanctioned), '/', sum(filled)) as cnt  FROM `hrcdsco_master_tbl`  ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['cnt'];   
	
	
}
public function Hrlisting(){
	
	 $qry="SELECT post, concat(sanctioned,'/', filled) as `Sanctioned/Filled` FROM `hrcdsco_master_tbl`  ";	
	 return $this->db->query($qry)->result_array();
	
}

public function MinistrialNumbers(){
	 $qry="SELECT concat(sum(sanctioned), '/', sum(filled)) as sum_amount_due  FROM `hrhq_master_tbl`  ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount_due']; 
}

public function MinistrialListing(){
	$qry="SELECT post, concat(sanctioned,'/', filled) as `Sanctioned/Filled` FROM `hrhq_master_tbl`  ";	
	return $this->db->query($qry)->result_array();
}

public function LabNumbers(){
	 $qry="SELECT concat(sum(sanctioned_post), '/', sum(filled)) as sum_amount_due  FROM `hrcl_master_tbl`  ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount_due']; 
}

public function LabListing(){
	$qry="SELECT name_of_lab, concat(sanctioned_post,'/', filled) as `sanctioned_post/Filled` FROM `hrcl_master_tbl`  ";	
	return $this->db->query($qry)->result_array();
}

public function SugamNumbers(){
	 $qry="SELECT sum(no_of_manufacturing) as sum_amount_due  FROM `sugam_master_tbl`  ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount_due']; 
}

public function SugamListing(){
	$qry="SELECT m.State_Name, no_of_manufacturing as 'No. of Manufacturing Sites',number_of_formulation,total_application_received, lmport_Registration_Division, Medical_device,Cosmetic_division, BABE_Division, GCT_Division, Ethics_Division, Biological_Division,New_Drug_Division,Subsequent_New,FDC_Division,Export_NOC_division,Test_License FROM `sugam_master_tbl` s left join m_state m on m.State_ID=s.state_id ";	
	return $this->db->query($qry)->result_array();
}




public function manNumbers(){
	 $qry="SELECT sum(number_of_formulation) as sum_amount_due  FROM `sugam_master_tbl`  ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount_due']; 
}

public function manListing(){
	$qry="SELECT m.State_Name, no_of_manufacturing,number_of_formulation,total_application_received, lmport_Registration_Division, Medical_device,Cosmetic_division, BABE_Division, GCT_Division, Ethics_Division, Biological_Division,New_Drug_Division,Subsequent_New,FDC_Division,Export_NOC_division,Test_License FROM `sugam_master_tbl` s left join m_state m on m.State_ID=s.state_id ";	
	return $this->db->query($qry)->result_array();
}
public function CdscoNumbers(){
	 $qry="SELECT sum(total_application_received) as sum_amount_due  FROM `sugam_master_tbl`  ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount_due']; 
}

public function CdscoListing(){
	$qry="SELECT m.State_Name, no_of_manufacturing,number_of_formulation,total_application_received,  lmport_Registration_Division, Medical_device,Cosmetic_division, BABE_Division, GCT_Division, Ethics_Division, Biological_Division,New_Drug_Division,Subsequent_New,FDC_Division,Export_NOC_division,Test_License FROM `sugam_master_tbl` s left join m_state m on m.State_ID=s.state_id ";	
	return $this->db->query($qry)->result_array();
}


public function CdsNumbers(){
	 $qry="SELECT sum(total_no_of_sample_tested) as sum_amount_due  FROM `cdsco_lab_master_tbl`  ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount_due']; 
}

public function CdsListing(){
	$qry="SELECT name_of_the_lab, total_no_of_sample_tested, sample_for_standard, sample_found, spurious FROM `cdsco_lab_master_tbl`  ";	
	return $this->db->query($qry)->result_array();
}
public function PvpiNumbers(){
	 $qry="SELECT sum(noof_individual) as sum_amount_due  FROM `pvpi_master_tbl`  ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount_due']; 
}

public function PvpiListing(){
	$qry="SELECT month, noof_individual, noof_causality, noof_cases, outcome FROM `pvpi_master_tbl`  ";	
	return $this->db->query($qry)->result_array();
}












public function get_total_kpi(){
	 $row  = array();
     $row['total_kpi'] = 'Regulatory Personnel in CDSCO (Sanctioned/Filled) : '.$this->HrNumerbs().' , Ministerial Staff(HQ) And Zonal office (Sanctioned/Filled) : '.$this->MinistrialNumbers().' , Laboratory Personnel (Sanctioned/Filled) : '.$this->LabNumbers().' , Number of manufacturing sites state wise : '.$this->SugamNumbers().' , Number of formulation data state wise : '.$this->manNumbers().' , Total application received in CDSCO : '.$this->CdscoNumbers().' , No. of CDSCO Laboratories : '.$this->CdsNumbers().' , Number of Adverse Drug Reaction (ADR) Monitoring Centres (AMCs) : '.$this->PvpiNumbers();	 

	 
	 return $row;
  
    //$qry="SELECT concat('No. of fully operational FRUs (5 C-section/month for CHC and SDH) against months : ',sum(chc),' , No. of fully operational FRUs (10 C-section/month for DH) against required no. of FRUs : ', sum(phc)) as total_kpi FROM `fru_master_table`  ";
   // return $this->db->query($qry)->row_array();
}

public function get_total_header(){
    $qry="SELECT sum(fru)  as header_count,'Total First Referral Unit' as header_title FROM `fru_master_table`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_table_data(){
   
    $qry="SELECT year, fru_month, chc as 'No. of fully operational FRUs (5 C-section/month for CHC and SDH) against months', phc as 'No. of fully operational FRUs (10 C-section/month for DH) against required no. of FRUs' FROM fru_master_table order by fru_master_table.id ";
    return $this->db->query($qry)->result_array();   
}


public function get_array_kpi(){

     $qry =  array("Hr","MinistrialListing","LabListing","no_of_manufacturing","number_of_formulation","total_application_received","CdsListing","PvpiListing");
   
    return $qry;
}

public function get_table_kpi_data($id){
   
   if($id == 'Hr') {
	   return $this->Hrlisting();
   }
   
   if($id == 'MinistrialListing') {
	   return $this->MinistrialListing();
   }
    if($id == 'LabListing') {
	   return $this->LabListing();
   }
	if($id == 'no_of_manufacturing') {
	   return $this->SugamListing();
   }
   if($id == 'number_of_formulation') {
	   return $this->manListing();
   }
   
    if($id == 'total_application_received') {
	   return $this->CdscoListing();
   }
   if($id == 'CdsListing') {
	   return $this->CdsListing();
   }
   if($id == 'PvpiListing') {
	   return $this->PvpiListing();
   }
	return array();
	
    //$qry="SELECT year, fru_month, SUM(".$id.") AS ".$id."  FROM fru_master_table group by fru_master_table.year ";   
    //return $this->db->query($qry)->result_array();   
}

}