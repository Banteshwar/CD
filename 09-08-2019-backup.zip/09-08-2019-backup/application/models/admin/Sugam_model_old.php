<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Sugam_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
public function getFru(){ 
    $this->db->select('*');
    $this->db->from('fru_master_table');
    $query = $this->db->get();

	if ($query->num_rows() > 0) {
		foreach ($query->result() as $row) {
			$data[] = $row;
		}
		return $data;
	}
	return false;
}


public function HrNumerbs(){
	
	 $qry="SELECT sum(sanctioned) as cnt  FROM `hrcdsco_master_tbl`  ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['cnt'];   
	
	
}
public function Hrlisting(){
	
	 $qry="SELECT post, sanctioned, filled FROM `hrcdsco_master_tbl`  ";	
	 return $this->db->query($qry)->result_array();
	
}

public function MinistrialNumbers(){
	 $qry="SELECT sum(sanctioned) as sum_amount_due  FROM `hrhq_master_tbl`  ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount_due']; 
}

public function MinistrialListing(){
	$qry="SELECT post, sanctioned, filled FROM `hrhq_master_tbl`  ";	
	return $this->db->query($qry)->result_array();
}

public function LabNumbers(){
	 $qry="SELECT sum(sanctioned_post) as sum_amount_due  FROM `hrcl_master_tbl`  ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount_due']; 
}

public function LabListing(){
	$qry="SELECT name_of_lab, sanctioned_post, filled FROM `hrcl_master_tbl`  ";	
	return $this->db->query($qry)->result_array();
}

public function SugamNumbers(){
	 $qry="SELECT sum(no_of_manufacturing) as sum_amount_due  FROM `sugam_master_tbl`  ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount_due']; 
}

public function SugamListing(){
	$qry="SELECT m.State_Name, Division,no_of_manufacturing, number_of_formulation, total_application,New, Approved, Rejected, Inprocess, Query_Raised FROM `sugam_master_tbl` s left join m_state m on m.State_ID=s.state_id ";	
	return $this->db->query($qry)->result_array();
}

public function CdsNumbers(){
	 $qry="SELECT sum(total_no_of_sample_tested) as sum_amount_due  FROM `cdsco_lab_master_tbl`  ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount_due']; 
}

public function CdsListing(){
	$qry="SELECT name_of_the_lab, total_no_of_sample_tested, sample_for_standard, sample_found, spurious FROM `cdsco_lab_master_tbl`  ";	
	return $this->db->query($qry)->result_array();
}
public function PvpiNumbers(){
	 $qry="SELECT sum(noof_individual) as sum_amount_due  FROM `pvpi_master_tbl`  ";	
	 $row = $this->db->query($qry)->row_array();
     return $row['sum_amount_due']; 
}

public function PvpiListing(){
	$qry="SELECT month, noof_individual, noof_causality, noof_cases, outcome FROM `pvpi_master_tbl`  ";	
	return $this->db->query($qry)->result_array();
}












public function get_total_kpi(){
	 $row  = array();
     $row['total_kpi'] = 'Regulatory Personal  : '.$this->HrNumerbs().' , Ministerial Staff(HQ) And Zonal office : '.$this->MinistrialNumbers().' , CDSCO Laboratories : '.$this->LabNumbers().' , SUGAM : '.$this->SugamNumbers().' , CDSCO Laboratories : '.$this->CdsNumbers().' , Pharmaco-Vigilance Programme Of India(PvPI) : '.$this->PvpiNumbers();	 
	 return $row;
  
    //$qry="SELECT concat('No. of fully operational FRUs (5 C-section/month for CHC and SDH) against months : ',sum(chc),' , No. of fully operational FRUs (10 C-section/month for DH) against required no. of FRUs : ', sum(phc)) as total_kpi FROM `fru_master_table`  ";
   // return $this->db->query($qry)->row_array();
}

public function get_total_header(){
    $qry="SELECT sum(fru)  as header_count,'Total First Referral Unit' as header_title FROM `fru_master_table`  ";
    return $this->db->query($qry)->row_array();   
}

public function get_table_data(){
   
    $qry="SELECT year, fru_month, chc as 'No. of fully operational FRUs (5 C-section/month for CHC and SDH) against months', phc as 'No. of fully operational FRUs (10 C-section/month for DH) against required no. of FRUs' FROM fru_master_table order by fru_master_table.id ";
    return $this->db->query($qry)->result_array();   
}


public function get_array_kpi(){

    $qry =  array("Hr","MinistrialListing","LabListing","SugamListing","CdsListing","PvpiListing");
   
    return $qry;
}

public function get_table_kpi_data($id){
   
   if($id == 'Hr') {
	   return $this->Hrlisting();
   }
   
   if($id == 'MinistrialListing') {
	   return $this->MinistrialListing();
   }
    if($id == 'LabListing') {
	   return $this->LabListing();
   }
	if($id == 'SugamListing') {
	   return $this->SugamListing();
   }
   if($id == 'CdsListing') {
	   return $this->CdsListing();
   }
   if($id == 'PvpiListing') {
	   return $this->PvpiListing();
   }
	return array();
	
    //$qry="SELECT year, fru_month, SUM(".$id.") AS ".$id."  FROM fru_master_table group by fru_master_table.year ";   
    //return $this->db->query($qry)->result_array();   
}

}