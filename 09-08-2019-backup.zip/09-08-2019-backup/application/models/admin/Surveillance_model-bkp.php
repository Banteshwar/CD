<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Surveillance_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   


public function get_Healthdata(){ 
    $this->db->select('nohp_master_table.*');
    $this->db->from('nohp_master_table');
	// $this->db->join('m_state','m_state.State_ID=nohp_master_table.state_id','inner');
    
 
   $this->db->order_by("nohp_master_table.id", "desc");


        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
}

  public function get_totalRecordfdsi(){ 
    $this->db->select('SUM( Number_of_States ) as st ,  updated_by   ');
    $this->db->from('free_diagnosticssi_master_tbl');
    
    $this->db->order_by("free_diagnosticssi_master_tbl.id", "desc");

    $query = $this->db->get();

    return $query->row_array();  
}



  public function get_totalMdiabities(){ 
    $this->db->select('SUM(persons_registered_application) as total ,updated_date');
    $this->db->from('tbl_mdiabetes');
    
    

    $query = $this->db->get();

    return $query->row_array();  
}


  public function get_totalNrcpdata(){ 
    $this->db->select('SUM(	Animal_Bite_cases_reported) as bitecasetotal ,SUM(	Human_rabies_cases_reported	) as rabiescasetotal,SUM(Vaccine_availability_status) as avlabilitytotal');
    $this->db->from('nrcp_master_table');
    
    

    $query = $this->db->get();

    return $query->row_array();  
}


  public function get_totalPclpdata(){ 
    $this->db->select('SUM(	Laboratory_confirmed_Leptospirosis_cases_reported) as labconfirmtotal ,SUM(	Number_of_Leptospirosis_outbreaks_reported	) as outbreaktotal');
    $this->db->from('pclp_master_table');
    
    

    $query = $this->db->get();

    return $query->row_array();  
}


  public function get_totalPczddata(){ 
    $this->db->select('SUM(Health_and_Veterinary_professionals_trained) as trainedtotal');
    $this->db->from('pczd_master_table');
    
    

    $query = $this->db->get();

    return $query->row_array();  
}


  public function get_totalVhpdata(){ 
    $this->db->select('SUM(Regional_Laboratory) as vhplabtotal');
    $this->db->from('vhp_regional_lab_master_table');
    
    

    $query = $this->db->get();

    return $query->row_array();  
}

    
   
}

