<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Surveillance_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
public function get_Healthdata(){ 
    $this->db->select('nohp_master_table.*');
    $this->db->from('nohp_master_table');
	// $this->db->join('m_state','m_state.State_ID=nohp_master_table.state_id','inner');
    
 
   $this->db->order_by("nohp_master_table.id", "desc");


        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
}

  public function get_totalRecordfdsi(){ 
    $this->db->select('SUM( Number_of_States ) as st ,  updated_by   ');
    $this->db->from('free_diagnosticssi_master_tbl');
    
    $this->db->order_by("free_diagnosticssi_master_tbl.id", "desc");

    $query = $this->db->get();

    return $query->row_array();  
}



  public function get_totalMdiabities(){ 
    $this->db->select('SUM(persons_registered_application) as total ,updated_date');
    $this->db->from('tbl_mdiabetes');
    
    

    $query = $this->db->get();

    return $query->row_array();  
}


  public function get_totalNrcpdata(){ 
    $this->db->select('SUM(animal_bites_cases) as bitecasetotal ,SUM(human_rabies_total) as rabiescasetotal,SUM(vaccine_total) as avlabilitytotal');
    $this->db->from('nrcp_master_table');
    
    

    $query = $this->db->get();

    return $query->row_array();  
}


  public function get_totalPclpdata(){ 
    $this->db->select('SUM(	Laboratory_confirmed_Leptospirosis_cases_reported) as labconfirmtotal ,SUM(	Number_of_Leptospirosis_outbreaks_reported	) as outbreaktotal');
    $this->db->from('pclp_master_table');
    
    

    $query = $this->db->get();

    return $query->row_array();  
}


  public function get_totalPczddata(){ 
    $this->db->select('SUM(Health_and_Veterinary_professionals_trained) as trainedtotal');
    $this->db->from('pczd_master_table');
    
    

    $query = $this->db->get();

    return $query->row_array();  
}


  public function get_totalVhpdata(){ 
    $this->db->select('SUM(Regional_Laboratory) as vhplabtotal');
    $this->db->from('vhp_regional_lab_master_table');
    
    

    $query = $this->db->get();

    return $query->row_array();  
}


public function total_get_nppcd(){ 
    $this->db->select('SUM( Total_Number_of_districts ) as total_dist ,  SUM( Total_Number_of_district_made_operational ) as total_dist_opr   ');
    $this->db->from('nppcd_master_tbl');
    
    $this->db->order_by("nppcd_master_tbl.id", "desc");

    $query = $this->db->get();

    return $query->row_array();  
}


public function total_get_hmis(){ 
    $this->db->select('SUM( anc_registration ) as anc_registration ,  SUM( estimated_preg ) as estimated_preg,SUM( institution_delevery ) as institution_delevery,SUM( estimated_delevery ) as estimated_delevery,SUM( female_birth ) as female_birth,SUM( male_birth ) as male_birth,SUM( imr ) as imr,SUM( mmr ) as mmr ');
    $this->db->from('hmis_master_table');
    
    $this->db->order_by("hmis_master_table.id", "desc");

    $query = $this->db->get();

    return $query->row_array();  
}


public function total_get_hmispatient(){ 
    $this->db->select('SUM( total_ipd ) as total_ipd,SUM( total_opd ) as total_opd,SUM( labtest ) as labtest');
    $this->db->from('hmis_patient_service');
    
    $this->db->order_by("hmis_patient_service.id", "desc");

    $query = $this->db->get();

    return $query->row_array();  
}


public function total_get_hmisImmuni(){ 
    $this->db->select('SUM( newborns ) as newborns,SUM( reported_live_birth ) as reported_live_birth,SUM( infants ) as infants,SUM( total_estimated_infants ) as total_estimated_infants');
    $this->db->from('hmis_immunization');
    
    $this->db->order_by("hmis_immunization.id", "desc");

    $query = $this->db->get();

    return $query->row_array();  
}


public function total_get_nppcf(){ 
    $this->db->select('SUM( Tertiary_Care_Component ) as Tertiary_Care_Component ,  SUM( Budget_Allocation ) as Budget_Allocation,SUM( Number_of_Districts ) as Number_of_Districts');
    $this->db->from('nppcf_master_table');
    
    $this->db->order_by("nppcf_master_table.id", "desc");

    $query = $this->db->get();

    return $query->row_array();  
}



public function total_get_tobbaco(){ 
    $this->db->select('SUM( no_users_registered ) as no_users_registered ,  SUM( no_users_quit_tobacco ) as no_users_quit_tobacco');
    $this->db->from('tbl_tobacco');
    
    $this->db->order_by("tbl_tobacco.id", "desc");

    $query = $this->db->get();

    return $query->row_array();  
}

    
   
}

