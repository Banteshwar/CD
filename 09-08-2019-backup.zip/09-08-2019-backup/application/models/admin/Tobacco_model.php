<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Tobacco_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }   


    public function get_total_kpi(){
        $qry="SELECT concat('Total mCessation User Registered   : ',tabacco,' ,Total mDiabetes User Registered   : ',diabeties) as total_kpi FROM `tbl_mhealth`  ";
        return $this->db->query($qry)->row_array();
    }

    public function get_total_header(){
        $qry="SELECT sum(tabacco)  as header_count,'M Diabetes' as header_title FROM `tbl_mhealth`  ";
        return $this->db->query($qry)->row_array();   
    }


    public function get_array_kpi(){

        $qry =  array("Tabacco");
       
        return $qry;
    }

    public function get_table_kpi_data($id){
       
        
        $qry="SELECT tabacco ".$id." FROM tbl_mhealth order by tbl_mhealth.id ";
       
        return $this->db->query($qry)->result_array();   
    }

 
    
   
}

