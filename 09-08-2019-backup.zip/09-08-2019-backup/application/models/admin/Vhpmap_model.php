<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Vhpmap_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   
public function get_PMSSYs(){ 
    $this->db->select('nohp_master_table.*');
    $this->db->from('nohp_master_table');
	// $this->db->join('m_state','m_state.State_ID=nohp_master_table.state_id','inner');
    
 
   $this->db->order_by("nohp_master_table.id", "desc");


        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
}
public function get_mdiabetesform(){
		
		$sql     =  "select * from tbl_mdiabetes";
	
		$stmt = $this->db->query($sql); 
        if($stmt->num_rows()>0){
            return $stmt->result_array(); 
        }else{
            return false;
        }
        
	}




public function get_total_kpi(){
    $data_val=$this->get_total_kpi_val();
    $data_val1=$this->get_total_kpi_val1();
    
    $qry="SELECT concat('Regional labs doing enhanced case reporting : ',(SELECT sum(Regional_Laboratory) FROM vhp_regional_lab_master_table where year='".$data_val['year']."' and month='".$data_val['month']."'),',Districts reporting on acute hepatitis surveillance : ',(SELECT count(district_id) FROM vhp_district_lab_master_table where year='".$data_val['year']."' and month='".$data_val['month']."')) as total_kpi   ";
//    $this->db->query($qry);
  return $this->db->query($qry)->row_array();

}
public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `vhp_regional_lab_master_table` order by year desc,month desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}

public function get_total_kpi_val1(){
    
    $qry="SELECT * FROM `vhp_district_lab_master_table` order by year desc,month desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}

public function get_array_kpi(){

    $qry =  array("Regional_Laboratory as 'Regional labs doing enhanced case reporting'","district_id as 'Districts reporting on acute hepatitis surveillance'");
   
    return $qry;
}

public function get_table_kpi_data($id){
    $data_val=$this->get_total_kpi_val();
    $data_val1=$this->get_total_kpi_val1();
   if($id == "Regional_Laboratory as 'Regional labs doing enhanced case reporting'"){
    
        $qry="SELECT State_Name,".$id." FROM vhp_regional_lab_master_table inner join m_state on m_state.State_ID=vhp_regional_lab_master_table.state_id  where  year='".$data_val['year']."' and month ='".$data_val['month']."' GROUP by vhp_regional_lab_master_table.state_id   ";
        return $this->db->query($qry)->result_array(); 
   }
   if($id == "district_id as 'Districts reporting on acute hepatitis surveillance'"){
    $qry="SELECT State_Name, ".$id." FROM  vhp_district_lab_master_table inner join m_state on m_state.State_ID=
     vhp_district_lab_master_table.state_id where  year='".$data_val1['year']."' and month ='".$data_val1['month']."' GROUP by vhp_district_lab_master_table.state_id  ";
         return $this->db->query($qry)->result_array(); 
	}

    /*if($id == "district_id"){

    $qry="SELECT State_Name, ".$id." as 'Districts reporting on acute hepatitis surveillance' FROM  vhp_district_lab_master_table inner join m_state on m_state.State_ID=
     vhp_district_lab_master_table.state_id inner join m_district_lg on m_district_lg.District_Code_LG = vhp_district_lab_master_table.".$id." where  vhp_district_lab_master_table.year='".$data_val1['year']."' and vhp_district_lab_master_table.month ='".$data_val1['month']."' GROUP by vhp_district_lab_master_table.state_id  ";
     echo $qry; die;
         return $this->db->query($qry)->result_array(); 
    }*/
}



}