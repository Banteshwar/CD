<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Freediagnostic_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
public function get_total_kpi_val(){
    
    $qry="SELECT * FROM `free_diagnosticssi_master_tbl` GROUP by state_id  order by year desc,Quarterly desc LIMIT 1";
    return $this->db->query($qry)->row_array();
}

public function get_total_kpi(){
    $data_val=$this->get_total_kpi_val();

    $qry="SELECT concat('Number of States/UTs implemented Free Diagnostic Services : ',sum(Number_of_States),' ,Number of States/UTs implemented Free Laboratory Services : ', sum(Free_Laboratory_services),' ,Number of States/UTs implemented Free Tele Radiology Services : ' , sum(Radiology_services),',Number of States/UTs implemented Free CT Scan services in DHs :',sum(services_in_DHs)) as total_kpi FROM `free_diagnosticssi_master_tbl`  where year='".$data_val['year']."' and Quarterly='".$data_val['Quarterly']."' ";
    return $this->db->query($qry)->row_array();

}




public function get_array_kpi(){

    $qry =  array("Number_of_States as 'Number of States/UTs implemented Free Diagnostic Services'","Free_Laboratory_services as 'Number of States/UTs implemented Free Laboratory Services'","Radiology_services as 'Number of States/UTs implemented Free Tele Radiology Services'","services_in_DHs as 'Number of States/UTs implemented Free CT Scan services in DHs'");
   
    return $qry;
}

public function get_table_kpi_data($id){
   
    
    /*$qry="SELECT year, SUM(".$id.") AS ".$id." FROM free_diagnosticssi_master_tbl group by free_diagnosticssi_master_tbl.year ";*/

    $data_val=$this->get_total_kpi_val();
    
    $qry="SELECT State_Name, ".$id." FROM free_diagnosticssi_master_tbl inner join m_state on m_state.State_ID=
    free_diagnosticssi_master_tbl.state_id where  year='".$data_val['year']."' and Quarterly ='".$data_val['Quarterly']."' GROUP by free_diagnosticssi_master_tbl.state_id  ";
   
    return $this->db->query($qry)->result_array();   
}

 
    
   
}

