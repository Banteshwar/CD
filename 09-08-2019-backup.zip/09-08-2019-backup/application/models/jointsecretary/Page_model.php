<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Page_model extends MY_Model {

    public function __construct() {
       global $db;
    
        parent::__construct();
    }  
	
	public function get_List($role){ 
    $this->db->select('program_list.*');
    $this->db->from('program_list');
	$this->db->where('P_status',1);
	$this->db->where('JS_role',$role);
  //  $this->db->join('m_state','m_state.State_ID=ambulance_master_table.state_id','inner');
    
 
   $this->db->order_by("program_list.id", "desc");


        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
}




}
