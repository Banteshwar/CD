  
<?php
public function fetch_all_service_total($FinancialYear=NULL,$state_code=NULL)
	{
            $sql = "SELECT dft_service_id,sum(dft_achieved) as 'total' , progress.pr_id ,progress.pr_month,progress.pr_financial_year,progress.pr_state_id ,dpr.dft_progress_report_id ,dpr.dft_service_id ";
            $result =  $this->db->query($sql);
            $query  =  $result->fetch();
	}
      ?>  