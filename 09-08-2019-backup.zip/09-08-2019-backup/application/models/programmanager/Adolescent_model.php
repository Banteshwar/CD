<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Adolescent_model extends CI_Model 
{
    public function __construct() 
    {
        parent::__construct();
    }
 
   public function saveAmbulances($post_val)
    {
		
		//echo "<pre>"; print_r($post_val); die;
		if(count($post_val['check'])>0)

				 {
					foreach($post_val['check'] as $check_value)
					{
		///////// check value allready exist ///////
		
		 $this->db->where('state_id',$post_val['state_id'][$check_value]);
		$this->db->where('financial_year',$post_val['year_id']);
		 $this->db->where('quarter',$post_val['q_id']);
		
        $this->db->from("adolescenthealth_master_table");
        $count_val = $this->db->count_all_results(); 
		
		          if($count_val>0)
                    {
						
						$data = array
				        (	 				
					
					
					'client_load'=>$post_val['client_load'][$check_value],
					'coverage_of_wifs'=>$post_val['coverage_of_wifs'][$check_value],
					
					'updated_by'=>  (isset($_SESSION['memberID']))
													
			  	     );
					 
					
                        $this->db->where('state_id',$post_val['state_id'][$check_value]);
		               $this->db->where('financial_year',$post_val['year_id']);
		                $this->db->where('quarter',$post_val['q_id']);
                      $this->db->update('adolescenthealth_master_table', $data);
					  
					  ///////////// blank value should delete on update ////////
					  
					  if($post_val['client_load'][$check_value]=='' && $post_val['coverage_of_wifs'][$check_value]=='')
					  {
						  
					  $this->db->where('state_id',$post_val['state_id'][$check_value]);
		              $this->db->where('financial_year',$post_val['year_id']);
		              $this->db->where('quarter',$post_val['q_id']);
                      $this->db->delete('adolescenthealth_master_table');
						  
					  }
					  
					  
					  ///////////// end blank value should delete on update ////////
				
				
						
					}
					else
					{
						
						
						 if($post_val['client_load'][$check_value]!='' || $post_val['coverage_of_wifs'][$check_value]!='' )
					  {
						
						$data = array
				        (	 				
					
					      
					'state_id'=> $post_val['state_id'][$check_value],
					
					'financial_year'=> $post_val['year_id'],
					'quarter'=> $post_val['q_id'],
					'client_load'=>$post_val['client_load'][$check_value],
					'coverage_of_wifs'=>$post_val['coverage_of_wifs'][$check_value],
					
					'updated_by'=>  (isset($_SESSION['memberID']))
													
			  	     );
					 
					
					  
					 $this->db->insert('adolescenthealth_master_table', $data);
					 
					
						
					}
					}
		
					}
					
				 }
		
		
		
    }
	
	
	 public function form_save_agregate($post_val)
    {
		
		if($post_val['client_load']!='' || $post_val['coverage_of_wifs']!='' )
		{
			
			$data = array
			(
				'financial_year'=> $post_val['year_id'],
				'quarter'=> $post_val['q_id'],
				'client_load'=>$post_val['client_load'],
				'coverage_of_wifs'=>$post_val['coverage_of_wifs'],
				
				'updated_by'=>  (isset($_SESSION['memberID']))
			);	
			
			 
		///////// check value allready exist ///////

			$this->db->where('financial_year',$post_val['year_id']);
			$this->db->where('quarter',$post_val['q_id']);
			
			$this->db->from("adolescenthealth_aggregate_table");
			$row_val = $this->db->count_all_results(); 
			
			if($row_val>0)
			{
				$this->db->where('financial_year',$post_val['year_id']);
				$this->db->where('quarter',$post_val['q_id']);
				$this->db->update('adolescenthealth_aggregate_table', $data);
			}else{
				$this->db->insert('adolescenthealth_aggregate_table', $data);
			}
		}
		
    }
	
	
	public function get_Ambulances_State($f_year,$f_quarter)
    {
		
		 global $db;
		 
		
            $query = "Select m_state.*,adolescenthealth_master_table.* from m_state LEFT JOIN adolescenthealth_master_table on (m_state.State_ID=adolescenthealth_master_table.state_id and adolescenthealth_master_table.financial_year='".$f_year."' and adolescenthealth_master_table.quarter='".$f_quarter."') order by m_state.State_Name" ;
			
		
		

             $stmt = $db->query($query);
			 		
  
  
            return $stmt->fetchAll(); 
			
			
		
	}
	
	public function get_Ambulances_State_ajax($f_year,$f_quarter)
    {
		
		 global $db;
            $query = "Select m_state.*,adolescenthealth_master_table.* from m_state LEFT JOIN adolescenthealth_master_table on (m_state.State_ID=adolescenthealth_master_table.state_id and adolescenthealth_master_table.financial_year='".$f_year."' and adolescenthealth_master_table.quarter='".$f_quarter."')  order by m_state.State_Name" ;
			
			
			
			
			$statement = $db->prepare($query);
		
		                 if($statement->execute())
{
 while($row = $statement->fetch(PDO::FETCH_ASSOC))
 {
  $data[] = $row;
 }
}
			 
return $data; 		
			 		

  
            //return $stmt->fetchAll(); 
		
	}
	
	
/*	public function get_agregate_ajax($f_year,$f_quarter)
    {
		global $db;
		echo $query = "Select * from adolescenthealth_aggregate_table where financial_year='".$f_year."' and quarter='".$f_quarter."'" ; die; 
		
		$statement = $db->prepare($query);
	
		if($statement->execute())
		{
			while($row = $statement->fetch(PDO::FETCH_ASSOC))
			{
				$data[] = $row;
			}
		}
		 
		return $data;
	}
	*/
	
	public function get_agregate($f_year,$f_quarter)
    {
		
            $query = "Select * from adolescenthealth_aggregate_table where financial_year='".$f_year."' and quarter='".$f_quarter."'" ;
			
		
		

            $stmt = $this->db->query($query);
			// echo $this->db->last_query(); die;		
  
  
            return $stmt->row_array();
			
			
		
	}
	
}