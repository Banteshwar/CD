<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Alert_model extends MY_Model {

    public function __construct() {
       global $db;
    
        parent::__construct();
            }  
             public function getAlertddata(){
                 
			    return $this->db->get('alert_table')->result_array();

				}
            public function update_alert($id, $data) {
		$this->db->where('Id', $id);
		return $this->db->update('alert_table', $data);
	}
		public function insertalert($data){
		return $this->db->insert('alert_table', $data);
	}
}?>	
