<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Ambulance2_model extends MY_Model {

    public function __construct() {
       global $db;
    
        parent::__construct();
    }  
	
	public function get_Ambulances(){ 
    $this->db->select('ambulance_master_table.*,m_state.State_Name');
    $this->db->from('ambulance_master_table');
    $this->db->join('m_state','m_state.State_ID=ambulance_master_table.state_id','inner');
    
 
   $this->db->order_by("ambulance_master_table.id", "desc");


        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
}

 public function chkAmbulances($stateID,$e_year,$e_quarter)
    {
        
       
        $this->db->where('state_id',$stateID);
		$this->db->where('e_year',$e_year);
		 $this->db->where('e_quarter',$e_quarter);
		
        $this->db->from("ambulance_master_table");
        return $this->db->count_all_results();


    }
	
	public function getAmbulance_byId($id)
    {
        return $result = $this->db->select('ambulance_master_table.*')->where("ambulance_master_table.id",$id)->get("ambulance_master_table",1)->result();
    }
	
  public function updateAmbulance_byId($id,$data)
  {
    $where = array('id ' => $id);
    $this->db->where($where);
    return $this->db->update('ambulance_master_table', $data);
  }
	
public function insertAmbulances($data)
    {
        return $this->db->insert('ambulance_master_table', $data);
    }
	
	public function saveAmbulances($post_val)
    {
		
		
		if(count($post_val['check'])>0)

				 {
					foreach($post_val['check'] as $check_value)
					{
		///////// check value allready exist ///////
		
		 $this->db->where('state_id',$post_val['state_id'][$check_value]);
		$this->db->where('e_year',$post_val['year_id']);
		 $this->db->where('e_quarter',$post_val['q_id']);
		
        $this->db->from("ambulance_master_table");
        $count_val = $this->db->count_all_results(); 
		
		          if($count_val>0)
                    {
						
						$data = array
				        (	 				
					
					
					'ALS_ambulances_operational'=>$post_val['ALS_ambulances_operational'][$check_value],
					'ALS_ambulances_required'=>$post_val['ALS_ambulances_required'][$check_value],
					'BLS_ambulances_operational'=>$post_val['BLS_ambulances_operational'][$check_value],
					'BLS_ambulances_required'=>$post_val['BLS_ambulances_required'][$check_value],
					'ALS_average_response_time'=>$post_val['ALS_average_response_time'][$check_value],
					'BLS_average_response_time'=>$post_val['BLS_average_response_time'][$check_value],
					
					'updated_by'=>  (isset($_SESSION['memberID']))
													
			  	     );
					 
					
                        $this->db->where('state_id',$post_val['state_id'][$check_value]);
		               $this->db->where('e_year',$post_val['year_id']);
		                $this->db->where('e_quarter',$post_val['q_id']);
                      $this->db->update('ambulance_master_table', $data);
				
				
						
					}
					else
					{
						
						$data = array
				        (	 				
					
					'state_id'=> $post_val['state_id'][$check_value],
					
					'e_year'=> $post_val['year_id'],
					'e_quarter'=> $post_val['q_id'],
					'ALS_ambulances_operational'=>$post_val['ALS_ambulances_operational'][$check_value],
					'ALS_ambulances_required'=>$post_val['ALS_ambulances_required'][$check_value],
					'BLS_ambulances_operational'=>$post_val['BLS_ambulances_operational'][$check_value],
					'BLS_ambulances_required'=>$post_val['BLS_ambulances_required'][$check_value],
					'ALS_average_response_time'=>$post_val['ALS_average_response_time'][$check_value],
					'BLS_average_response_time'=>$post_val['BLS_average_response_time'][$check_value],
					
					'updated_by'=>  (isset($_SESSION['memberID']))
													
			  	     );
					 
					 $this->db->insert('ambulance_master_table', $data);
						
					}
		
					}
					
				 }
		
		
		
    }
	
	public function get_Ambulances_State($f_year,$f_quarter)
    {
		
		 global $db;
            $query = "Select m_state.*,ambulance_master_table.* from m_state LEFT JOIN ambulance_master_table on (m_state.State_ID=ambulance_master_table.state_id and ambulance_master_table.e_year='".$f_year."' and ambulance_master_table.e_quarter='".$f_quarter."') order by m_state.State_Name" ;
			
		
		

             $stmt = $db->query($query);
			 		
  
  
            return $stmt->fetchAll(); 
			
			
		
	}
	
	public function get_Ambulances_State_ajax($f_year,$f_quarter)
    {
		
		 global $db;
            $query = "Select m_state.*,ambulance_master_table.* from m_state LEFT JOIN ambulance_master_table on (m_state.State_ID=ambulance_master_table.state_id and ambulance_master_table.e_year='".$f_year."' and ambulance_master_table.e_quarter='".$f_quarter."')  order by m_state.State_Name" ;
			
			
			
			
			$statement = $db->prepare($query);
		
		                 if($statement->execute())
{
 while($row = $statement->fetch(PDO::FETCH_ASSOC))
 {
  $data[] = $row;
 }
}
			 
return $data; 		
			 		

  
            //return $stmt->fetchAll(); 
		
	}
	
	
	
	
	
	


}
