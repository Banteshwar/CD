<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Amr_new_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   


public function saveAmbulances($post_val){
	
	//echo "<pre>"; print_r($post_val); die;
    	
        
        if(count($post_val['check'])>0){

         foreach($post_val['check'] as $check_value){
 		//var_dump($check_value);
        /*echo $post_val['rowid'.$check_value][0]."<br>";
        echo $post_val['year_id']."<br>";
        echo $post_val['q_id']."<br>";die;*/
        ///////// 	check value allready exist ///////
        
        $this->db->where('rowid',$post_val['rowid'.$check_value][0]);
        $this->db->where('e_year',$post_val['year_id']);
        $this->db->where('e_quarter',$post_val['q_id']);
        
        $this->db->from("amrcp_master_table");
        

        $count_val = $this->db->count_all_results(); 
        //echo $this->db->last_query();die;   
        if($count_val>0){
                           
          $data = array(
                    
              'state_id'             =>  $post_val['state_id'.$check_value][0],
              'Labs_enrolled_under_the_AMR_Programme' =>  $post_val['Labs_enrolled_under_the_AMR_Programme'][$check_value],
              //'Labs_reporting_AMR_surveillance_data'      =>  $post_val['Labs_reporting_AMR_surveillance_data'][$check_value],
			  'Labs_reporting_AMR_surveillance_data'             =>  $post_val['Labs_reporting_AMR_surveillance_data'.$check_value][0],
              'updated_by'           =>  (isset($_SESSION['memberID']))
                                              
            );

//          var_dump($data);die;                   
                    $this->db->where('rowid',$post_val['rowid'.$check_value][0]);
                    $this->db->where('e_year',$post_val['year_id']);
                    $this->db->where('e_quarter',$post_val['q_id']);
                    $this->db->update('amrcp_master_table', $data);

            ///////////// blank value should delete on update ////////
            
            if(($post_val['Labs_enrolled_under_the_AMR_Programme'][$check_value]=='' && $post_val['Labs_reporting_AMR_surveillance_data'.$check_value][0]=='0' || $post_val['state_id'.$check_value][0]=='0'))
            {
            	              
             $this->db->where('rowid',$post_val['rowid'.$check_value][0]);
             $this->db->where('e_year',$post_val['year_id']);
             $this->db->where('e_quarter',$post_val['q_id']);
             $this->db->delete('amrcp_master_table');
              
            }
            
            
            ///////////// end blank value should delete on update ////////
                  
          }else{
          	//echo "<pre>";print_r($post_val['state_id'.$check_value][0]);
          	//	die('Insert');
       if(!empty($post_val['state_id'.$check_value][0]) && $post_val['state_id'.$check_value][0]!='0' ){

        	if($post_val['Labs_enrolled_under_the_AMR_Programme'][$check_value]!='' || $post_val['Labs_reporting_AMR_surveillance_data'][0]!='') {             

                    $data = array(                                         
                        'state_id'=> $post_val['state_id'.$check_value][0],
                        'e_year'=> $post_val['year_id'],
                        'e_quarter'=> $post_val['q_id'],
                        'rowid' =>$post_val['rowid'.$check_value][0],                    
                        'Labs_enrolled_under_the_AMR_Programme'=>$post_val['Labs_enrolled_under_the_AMR_Programme'][$check_value],
                        //'Labs_reporting_AMR_surveillance_data'=>$post_val['Labs_reporting_AMR_surveillance_data'][0],
						'Labs_reporting_AMR_surveillance_data'=> $post_val['Labs_reporting_AMR_surveillance_data'.$check_value][0],
                        'updated_by'=>  (isset($_SESSION['memberID']))
                    );
                    // echo "<pre>";print_r($data); die;
                     $this->db->insert('amrcp_master_table', $data);
                        
       			 }
       			}
           	  }
            }
                    
          }
        
        
        
    }
    
    public function get_Ambulances_State($f_year,$f_quarter){
        
         global $db;
            $query = "Select m_state.*,amrcp_master_table.* from m_state LEFT JOIN amrcp_master_table on (m_state.State_ID=amrcp_master_table.state_id and amrcp_master_table.e_year='".$f_year."' and amrcp_master_table.e_quarter='".$f_quarter."' ) order by m_state.State_Name" ;
            
        
    $statement = $db->prepare($query);

    if($statement->execute()){
      while($row = $statement->fetch(PDO::FETCH_ASSOC)){

        $data[$row['rowid']] = $row;
      }
    }
   /* echo "<pre>";print_r($data);die;*/
    return $data;
    }
    
  public function get_Ambulances_State_ajax($f_year,$f_quarter){

    $data=array();

    global $db;
    $query = "Select * from amrcp_master_table where e_year='".$f_year."' and e_quarter='".$f_quarter."' " ;     

    $statement = $db->prepare($query);

    if($statement->execute()){
      while($row = $statement->fetch(PDO::FETCH_ASSOC)){
         $data[] = $row;
      }
    }
    else
    {
      $data[]='';
    }
    return $data; 
            //return $stmt->fetchAll(); 
  }


    public function getstate()
    {  
      global $db;
      $query = "Select * from m_state" ;
      $stmt = $db->query($query);
      return $stmt->fetchAll(); 
    }
    
  


   
}

