<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Amrcp_model extends MY_Model {

    public function __construct() {
       global $db;
    
        parent::__construct();
    }  
	
	public function get_AMRCPs(){ 
    $this->db->select('amrcp_master_table.*,m_state.State_Name');
    $this->db->from('amrcp_master_table');
	 $this->db->join('m_state','m_state.State_ID=amrcp_master_table.state_id','inner');
    
 
   $this->db->order_by("amrcp_master_table.id", "desc");


        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
}

 public function chkAMRCP($state_name,$e_year,$e_quarter)
    {
        
       
        $this->db->where('state_id',$state_name);
		$this->db->where('e_year',$e_year);
		 $this->db->where('e_quarter',$e_quarter);
		
        $this->db->from("amrcp_master_table");
        return $this->db->count_all_results();


    }
	
	public function getAMRCP_byId($id)
    {
        return $result = $this->db->select('amrcp_master_table.*')->where("amrcp_master_table.id",$id)->get("amrcp_master_table",1)->result();
    }
	
  public function updateAMRCP_byId($id,$data)
  {
    $where = array('id ' => $id);
    $this->db->where($where);
    return $this->db->update('amrcp_master_table', $data);
  }
	
public function insertAMRCP($data)
    {
        return $this->db->insert('amrcp_master_table', $data);
    }
    


}
