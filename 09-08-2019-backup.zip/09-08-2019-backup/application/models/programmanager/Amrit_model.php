<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Amrit_model extends CI_Model {

    public function __construct() {
      
    
        parent::__construct();
    }  
    public function amrit_list(){

     $this->db->select('amrit_master_tbl.*');
     $this->db->from('amrit_master_tbl');
     $this->db->order_by("amrit_master_tbl.id", "desc");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
    /*global $db;
    $stmt = $db->query('select n.* , s.* from notto_master_tbl as n inner join m_state as s on  n.state_id = s.state_id order by n.id desc'); 
        return $stmt->fetchAll(); 
*/
   } 
    public function chkamrit($year,$month)
    {
        
       $this->db->where('year',$year);

        $this->db->where('month',$month);
        
        $this->db->from("amrit_master_tbl");
        return $this->db->count_all_results();

        // echo $this->db->last_query(); die;echo $this->db->last_query(); die;

 
    }
    public function insertamrit($data)
    {
        return $this->db->insert('amrit_master_tbl',$data);
    }
    public function amrit_edit_show($id){

    return $result = $this->db->select('amrit_master_tbl.*')->where("amrit_master_tbl.id",$id)->get("amrit_master_tbl",1)->result();
}
public function amrit_update_data($id,$data)
  {
    $where = array('id ' => $id);
    $this->db->where($where);
    return $this->db->update('amrit_master_tbl',$data);
  }
   
  

}

    
   