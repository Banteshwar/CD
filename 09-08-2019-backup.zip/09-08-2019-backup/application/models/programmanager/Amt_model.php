<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Amt_model extends MY_Model {

    public function __construct() {
       global $db;
    
        parent::__construct();
    }  
		
	public function saveAmt($post_val)
    {
		
		
		if(count($post_val['check'])>0)

				 {
					foreach($post_val['check'] as $check_value)
					{
		
		
		 $this->db->where('state_id',$post_val['state_id'][$check_value]);
		$this->db->where('year',$post_val['year_id']);
		 $this->db->where('month',$post_val['month']);
		
        $this->db->from("amrit_master_tbl");
        $count_val = $this->db->count_all_results(); 
		
		          if($count_val>0)
                    {
						
						$data = array
				        (	 				
					
					
					'Total_number_of_pharmacies'=>$post_val['Total_number_of_pharmacies'][$check_value],
					'Number_of_patients_served'=>$post_val['Number_of_patients_served'][$check_value],
					'Value_of_drugs_dispensed'=>$post_val['Value_of_drugs_dispensed'][$check_value],
					'Savings_to_the_patients'=>$post_val['Savings_to_the_patients'][$check_value],			
					'updated_by'=>  (isset($_SESSION['memberID']))
													
			  	     );
					   $this->db->where('state_id',$post_val['state_id'][$check_value]);
		               $this->db->where('year',$post_val['year_id']);
		               $this->db->where('month',$post_val['month']);
                       $this->db->update('amrit_master_tbl', $data);
					   
					   ///////////// blank value should delete on update ////////
					  
					  if($post_val['Total_number_of_pharmacies'][$check_value]=='' && $post_val['Number_of_patients_served'][$check_value]=='' && $post_val['Value_of_drugs_dispensed'][$check_value]=='' && $post_val['Savings_to_the_patients'][$check_value]=='')
					  {
						  
					   $this->db->where('state_id',$post_val['state_id'][$check_value]);
		               $this->db->where('year',$post_val['year_id']);
		               $this->db->where('month',$post_val['month']); 
                          $this->db->delete('amrit_master_tbl');
						  
					  }
					  
					  
					  ///////////// end blank value should delete on update ////////
					  
					}
					else
					{
						
						 if($post_val['Total_number_of_pharmacies'][$check_value]!='' || $post_val['Number_of_patients_served'][$check_value]!='' || $post_val['Value_of_drugs_dispensed'][$check_value]!='' || $post_val['Savings_to_the_patients'][$check_value]!='')
						{	
						
						$data = array
				        (	 				
					
					'state_id'=> $post_val['state_id'][$check_value],
					
					'year'=> $post_val['year_id'],
					'month'=> $post_val['month'],
					'Total_number_of_pharmacies'=>$post_val['Total_number_of_pharmacies'][$check_value],
					'Number_of_patients_served'=>$post_val['Number_of_patients_served'][$check_value],
					'Value_of_drugs_dispensed'=>$post_val['Value_of_drugs_dispensed'][$check_value],
					'Savings_to_the_patients'=>$post_val['Savings_to_the_patients'][$check_value],
					'updated_by'=>  (isset($_SESSION['memberID']))
													
			  	     );
					 
					 $this->db->insert('amrit_master_tbl', $data);
						
					}
					}
		
					}
					
				 }
		
		
		
    }
	
	public function get_Amt_State($f_year,$month)
    {
		
		 global $db;
		 
		
            $query = "Select m_state.*,amrit_master_tbl.* from m_state left join amrit_master_tbl on (m_state.State_ID=amrit_master_tbl.State_ID and amrit_master_tbl.year='".$f_year."' and amrit_master_tbl.month='".$month."') order by m_state.State_Name" ;
             
             $stmt = $db->query($query); 
  
            return $stmt->fetchAll(); 
			
			
		
	}
	
	public function get_Amt_State_ajax($f_year,$month){
		
		 global $db;
            $query = "Select m_state.*,amrit_master_tbl.* from m_state LEFT JOIN amrit_master_tbl on (m_state.State_ID=amrit_master_tbl.state_id and amrit_master_tbl.year='".$f_year."' and amrit_master_tbl.month='".$month."')  order by m_state.State_Name" ;			
				
				$statement = $db->prepare($query);
		        if($statement->execute()){
 					while($row = $statement->fetch(PDO::FETCH_ASSOC)){
  						$data[] = $row;
					 }
					}
			 
				return $data; 		
		}


	public function getmonth(){
		global $db;
		$query   =  "select * from tbl_month";
		$stmt = $db->query($query);   
        return $stmt->fetchAll(); 
    }
	

}
