<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Api_model extends MY_Model implements DatatableModel{

    public function __construct() {
        global $db;
    
        parent::__construct();
    }  
  	
  	public function appendToSelectStr() {
  		return NULL;
  	}
  	
  	public function fromTableStr() {
  		return 'api_call_log a';
  	}
  
  	public function joinArray(){
  		return NULL;
  	}
  	
  	public function whereClauseArray(){
  		return NULL;
  	}
	
	 public function insertdata_ors($request){ 

       
        if($this->db->insert('ors_master_table', $request)){
            return true;
        }else{
            return false;
        }
    }
	
	   public function truncate_ors(){ 

       
       $this->db->truncate('ors_master_table');
    }
	
	   public function truncate_rch(){ 

       
       $this->db->truncate('rch_master_table');
    }
	
	 public function insertdata_ehospital($request){ 

       
        if($this->db->insert('ehospital_master_table', $request)){
            return true;
        }else{
            return false;
        }
    }
	
	   public function truncate_ehospital(){ 

       
       $this->db->truncate('ehospital_master_table');
    }
	
	public function insertdata($tbl_name,$value){
        if($this->db->insert($tbl_name, $value)){
            return true;
        }else{
            return false;
        }
    }
	
	
	//FetchData
	public function fetchdata($table,$value){
       $sql = $this->db->query("select * from  $table where pid=$value");
         if ($sql->num_rows() > 0) {
            return true;
        }else{
            return false;
        }
    }
	
    //Update
    public function updatedata($tbl_name,$values,$condition=""){
        if($condition!=''){
            foreach($condition as $key=>$value){
                $this->db->where($key, $value);
            }
        }
        return $this->db->update($tbl_name ,$values);
        //return true;
    }
	
   public function api_list()
    {
        $this->db->select('*');
        $this->db->from('api_list');
		   $this->db->where('active','1');
		 // $this->db->group_by('API_Name'); 
      
        $this->db->order_by("sorting_order", "asc");

        $query = $this->db->get();

        if ($query->num_rows() > 0) 
        {
            foreach ($query->result() as $row) 
            {
                $data[] = $row;
            }
            return $data;
        }
        return false;
    } 
	
	
	 public function smshistory_list()
    {
        $this->db->select('*');
        $this->db->from('sms_history_detail');
		 //$this->db->where('call_status','');
		 //$this->db->group_by('API_Name'); 
      
        $this->db->order_by("date_time", "desc");

        $query = $this->db->get();

        if ($query->num_rows() > 0) 
        {
            foreach ($query->result() as $row) 
            {
                $data[] = $row;
            }
            return $data;
        }
        return false;
    } 
    


    public function insertapidata($value){
       
        if($this->db->query("insert into tbl_mHealth (`record`) values ('".$value."')")){
            return true;
        }else{
            return false;
        }
    }

    public function getElederlyData(){
       $query  =  $this->db->query("select * from elderly_master_table_new");
        if($query->num_rows()>0){
            return $query->row_array();
        }else{
            return false;
        } 
    }

    public function getElederlyData_v1(){
       $query  =  $this->db->query("select * from elderly_master_table_160719");
        if($query->num_rows()>0){
            return $query->row_array();
        }else{
            return false;
        } 
    }

 public function truncateMdiabetes(){
      $query  =  $this->db->query("TRUNCATE TABLE tbl_mhealth");
        if($query){
            return true;
        }else{
            return false;
        } 
    }
    public function getMhelathData(){
      $query  =  $this->db->query("select * from tbl_mhealth");
        if($query->num_rows()>0){
            return $query->row_array();
        }else{
            return false;
        } 
    }

    public function emptyDatamHealth(){
      $query  =  $this->db->query("TRUNCATE TABLE tbl_mhealth");
        if($query){
            return true;
        }else{
            return false;
        } 
    }

    public function truncatePMJAY(){
      $query  =  $this->db->query("TRUNCATE TABLE pmjay_master_table");
        if($query){
            return true;
        }else{
            return false;
        } 
    }


    public function truncatedvdms(){
      $query  =  $this->db->query("TRUNCATE TABLE dvdms_master_table");
        if($query){
            return true;
        }else{
            return false;
        } 
    }
    
	


}
