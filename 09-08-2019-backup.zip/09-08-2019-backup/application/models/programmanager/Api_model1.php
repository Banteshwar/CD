<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Api_model extends MY_Model {

    public function __construct() {
        global $db;
    
        parent::__construct();
    }  
	
	public function insertdata($tbl_name,$value){
        if($this->db->insert($tbl_name, $value)){
            return true;
        }else{
            return false;
        }
    }
    //Update
    public function updatedata($tbl_name,$values,$condition=""){
        if($condition!=''){
            foreach($condition as $key=>$value){
                $this->db->where($key, $value);
            }
        }
        $this->db->update($tbl_name ,$values);
        return true;
    }
   
    


    public function insertapidata($value){
       
        if($this->db->query("insert into tbl_mHealth (`record`) values ('".$value."')")){
            return true;
        }else{
            return false;
        }
    }

    
	


}
