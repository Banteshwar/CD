<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Art_model extends CI_Model {

    public function __construct() {
          
        parent::__construct();
    }  
    public function art_list(){

     $this->db->select('art_master_tbl.*');
     $this->db->from('art_master_tbl');
     
     $this->db->order_by("art_master_tbl.id", "desc");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
    /*global $db;
    $stmt = $db->query('select n.* , s.* from notto_master_tbl as n inner join m_state as s on  n.state_id = s.state_id order by n.id desc'); 
        return $stmt->fetchAll(); 
*/
   } 
    
    public function insertart($data)
    {
        return $this->db->insert('art_master_tbl',$data);
    }
    public function art_edit_show($id){

    return $result = $this->db->select('art_master_tbl.*')->where("art_master_tbl.id",$id)->get("art_master_tbl",1)->result();
}
public function art_update_data($id,$data)
  {
    $where = array('id ' => $id);
    $this->db->where($where);
    return $this->db->update('art_master_tbl',$data);
  }
   
  /* start second */
public function art2_list(){

     $this->db->select('atr2_master_tbl.*');
     $this->db->from('atr2_master_tbl');
     
     $this->db->order_by("atr2_master_tbl.id", "desc");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
    /*global $db;
    $stmt = $db->query('select n.* , s.* from notto_master_tbl as n inner join m_state as s on  n.state_id = s.state_id order by n.id desc'); 
        return $stmt->fetchAll(); 
*/
   } 
    
    public function insertart2($data)
    {
        return $this->db->insert('atr2_master_tbl',$data);
    }
    public function art_edit_show2($id){

    return $result = $this->db->select('atr2_master_tbl.*')->where("atr2_master_tbl.id",$id)->get("atr2_master_tbl",1)->result();
}
public function art_update_data2($id,$data)
  {
    $where = array('id ' => $id);
    $this->db->where($where);
    return $this->db->update('atr2_master_tbl',$data);
  }
   
   /*end second*/
/*start third*/
public function art_list3(){

     $this->db->select('atr3_master_tbl.*');
     $this->db->from('atr3_master_tbl');
     
     $this->db->order_by("atr3_master_tbl.id", "desc");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
    /*global $db;
    $stmt = $db->query('select n.* , s.* from notto_master_tbl as n inner join m_state as s on  n.state_id = s.state_id order by n.id desc'); 
        return $stmt->fetchAll(); 
*/
   } 
    
    public function insertart3($data)
    {
        return $this->db->insert('atr3_master_tbl',$data);
    }
    public function art_edit_show3($id){

    return $result = $this->db->select('atr3_master_tbl.*')->where("atr3_master_tbl.id",$id)->get("atr3_master_tbl",1)->result();
}
public function art_update_data3($id,$data)
  {
    $where = array('id ' => $id);
    $this->db->where($where);
    return $this->db->update('atr3_master_tbl',$data);
  }
   
  


/*end third*/

/*start fourth*/
public function art_list4(){

     $this->db->select('atr4_master_tbl.*');
     $this->db->from('atr4_master_tbl');
     
     $this->db->order_by("atr4_master_tbl.id", "desc");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
    
   } 
    
    public function insertart4($data)
    {
        return $this->db->insert('atr4_master_tbl',$data);
    }
    public function art_edit_show4($id){

    return $result = $this->db->select('atr4_master_tbl.*')->where("atr4_master_tbl.id",$id)->get("atr4_master_tbl",1)->result();
}
public function art_update_data4($id,$data)
  {
    $where = array('id ' => $id);
    $this->db->where($where);
    return $this->db->update('atr4_master_tbl',$data);
  }
  public function program_list($cid=null){ 
            global $db;
            $query = "Select * from atr4_master_tbl order by program_name" ;
            $stmt = $db->query($query); 
            return $stmt->fetchAll(); 
    }
   
  
/*end fourth*/

   /*query = $this->db->get($sql);

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
  
   */
    
  

}

    
   