<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Cdsco_model extends CI_Model {

    public function __construct() {
      
    
        parent::__construct();
    }  
    public function cdsco_list(){

     $this->db->select('hrcdsco_master_tbl.*');
     $this->db->from('hrcdsco_master_tbl');
     
     $this->db->order_by("hrcdsco_master_tbl.id", "desc");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
    /*global $db;
    $stmt = $db->query('select n.* , s.* from notto_master_tbl as n inner join m_state as s on  n.state_id = s.state_id order by n.id desc'); 
        return $stmt->fetchAll(); 
*/
   } 
    
    public function inserthrreg($data)
    {
        return $this->db->insert('hrcdsco_master_tbl',$data);
    }
    public function hrreg_edit_show($id){

    return $result = $this->db->select('hrcdsco_master_tbl.*')->where("hrcdsco_master_tbl.id",$id)->get("hrcdsco_master_tbl",1)->result();
}
public function hrreg_update_data($id,$data)
  {
    $where = array('id ' => $id);
    $this->db->where($where);
    return $this->db->update('hrcdsco_master_tbl',$data);
  }
   
  
public function hrhq_list(){

     $this->db->select('hrhq_master_tbl.*');
     $this->db->from('hrhq_master_tbl');
     
     $this->db->order_by("hrhq_master_tbl.id", "desc");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
    /*global $db;
    $stmt = $db->query('select n.* , s.* from notto_master_tbl as n inner join m_state as s on  n.state_id = s.state_id order by n.id desc'); 
        return $stmt->fetchAll(); 
*/
   } 
    
    public function inserthrhq($data)
    {
        return $this->db->insert('hrhq_master_tbl',$data);
    }
    public function hrrhq_edit_show($id){

    return $result = $this->db->select('hrhq_master_tbl.*')->where("hrhq_master_tbl.id",$id)->get("hrhq_master_tbl",1)->result();
}
public function hrrhq_update_data($id,$data)
  {
    $where = array('id ' => $id);
    $this->db->where($where);
    return $this->db->update('hrhq_master_tbl',$data);
  }

  public function hrcl_list(){

     $this->db->select('hrcl_master_tbl.*');
     $this->db->from('hrcl_master_tbl');
     
     $this->db->order_by("hrcl_master_tbl.id", "desc");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
    /*global $db;
    $stmt = $db->query('select n.* , s.* from notto_master_tbl as n inner join m_state as s on  n.state_id = s.state_id order by n.id desc'); 
        return $stmt->fetchAll(); 
*/
   } 
    
    public function inserthrcl($data)
    {
        return $this->db->insert('hrcl_master_tbl',$data);
    }
    public function hrrcl_edit_show($id){

    return $result = $this->db->select('hrcl_master_tbl.*')->where("hrcl_master_tbl.id",$id)->get("hrcl_master_tbl",1)->result();
}
public function hrrcl_update_data($id,$data)
  {
    $where = array('id ' => $id);
    $this->db->where($where);
    return $this->db->update('hrcl_master_tbl',$data);
  }




   public function sugam_list(){

     $this->db->select('sugam_master_tbl.*,m_state.state_name');
          $this->db->join('m_state','m_state.state_id=sugam_master_tbl.state_id','inner');

     $this->db->from('sugam_master_tbl');
     
     $this->db->order_by("sugam_master_tbl.id", "desc");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
    /*global $db;
    $stmt = $db->query('select n.* , s.* from notto_master_tbl as n inner join m_state as s on  n.state_id = s.state_id order by n.id desc'); 
        return $stmt->fetchAll(); 
*/
   } 
    
    public function insertsugam($data)
    {
        return $this->db->insert('sugam_master_tbl',$data);
    }
    public function sugam_edit_show($id){

    return $result = $this->db->select('sugam_master_tbl.*')->where("sugam_master_tbl.id",$id)->get("sugam_master_tbl",1)->result();
}
public function sugam_update_data($id,$data)
  {
    $where = array('id ' => $id);
    $this->db->where($where);
    return $this->db->update('sugam_master_tbl',$data);
  }



  public function  cdscolab_list(){

     $this->db->select('cdsco_lab_master_tbl.*');
         

     $this->db->from('cdsco_lab_master_tbl');
     
     $this->db->order_by("cdsco_lab_master_tbl.id", "desc");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
    /*global $db;
    $stmt = $db->query('select n.* , s.* from notto_master_tbl as n inner join m_state as s on  n.state_id = s.state_id order by n.id desc'); 
        return $stmt->fetchAll(); 
*/
   } 
    
    public function insertcdscolab($data)
    {
        return $this->db->insert('cdsco_lab_master_tbl',$data);
    }
    public function cdscolab_edit_show($id){

    return $result = $this->db->select('cdsco_lab_master_tbl.*')->where("cdsco_lab_master_tbl.id",$id)->get("cdsco_lab_master_tbl",1)->result();
}
public function cdscolab_update_data($id,$data)
  {
    $where = array('id ' => $id);
    $this->db->where($where);
    return $this->db->update('cdsco_lab_master_tbl',$data);
  }



  public function pvpi_list(){

     $this->db->select('pvpi_master_tbl.*');
         

     $this->db->from('pvpi_master_tbl');
     
     $this->db->order_by("pvpi_master_tbl.id", "desc");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
    /*global $db;
    $stmt = $db->query('select n.* , s.* from notto_master_tbl as n inner join m_state as s on  n.state_id = s.state_id order by n.id desc'); 
        return $stmt->fetchAll(); 
*/
   } 
    
    public function insertpvpi($data)
    {
        return $this->db->insert('pvpi_master_tbl',$data);
    }
    public function pvpi_edit_show($id){

    return $result = $this->db->select('pvpi_master_tbl.*')->where("pvpi_master_tbl.id",$id)->get("pvpi_master_tbl",1)->result();
}
public function pvpi_update_data($id,$data)
  {
    $where = array('id ' => $id);
    $this->db->where($where);
    return $this->db->update('pvpi_master_tbl',$data);
  }
   
}

    
   