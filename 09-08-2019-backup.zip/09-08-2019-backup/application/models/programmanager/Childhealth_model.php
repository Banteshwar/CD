<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Childhealth_model extends CI_Model 
{
    public function __construct() 
    {
        parent::__construct();
    }
 
    //---------START Child Health CRUD FUNCTIONS-------->
    public function insert_childhealth($data,$table)
    {
        return $this->db->insert($table, $data);
    }

    public function update_childhealth($id,$data)
    {
        $where = array('id ' => $id);
        $this->db->where($where);
        return $this->db->update('childhealth_master_table', $data);
    }

    public function childhealth_list()
    {
        $this->db->select('childhealth_master_table.*');
        $this->db->from('childhealth_master_table');
        $this->db->order_by("childhealth_master_table.id", "desc");

        $query = $this->db->get();

        if ($query->num_rows() > 0) 
        {
            foreach ($query->result() as $row) 
            {
				$data[] = $row;
            }
            return $data;
        }
        return false;
    } 
	 
    public function getCH_byId($id)
    {
        return $result = $this->db->select('childhealth_master_table.*')->where("childhealth_master_table.id",$id)->get("childhealth_master_table",1)->result();
    }
public function chkchild($year,$Quarter)
    {
        

        $this->db->where('year',$year);
        $this->db->where('Quarter',$Quarter);
        
        $this->db->from("childhealth_master_table");
        return $this->db->count_all_results();
   //---------END Adolescent CRUD FUNCTIONS---------->
}
}