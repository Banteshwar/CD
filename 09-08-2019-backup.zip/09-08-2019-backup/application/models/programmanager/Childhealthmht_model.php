<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Childhealthmht_model extends CI_Model 
{
    public function __construct() 
    {
        parent::__construct();
}
    
public function saveChMHT($post_val)
{
	
	if(count($post_val['check'])>0)
	{
	 	foreach($post_val['check'] as $check_value)
		{
		///////// check value allready exist ///////
			$this->db->where('state_id',$post_val['state_id'][$check_value]);
			$this->db->where('year',$post_val['year_id']);
			$this->db->where('Quarter',$post_val['q_id']);
	        $this->db->from("childhealthmht_master_table");
	        $count_val = $this->db->count_all_results(); 
		
		    if($count_val>0)
            {	
				$data = array
				(	 							
					'no_of_children_screened'=>$post_val['no_of_children_screened'][$check_value],
					'no_of_children_received'=>$post_val['no_of_children_received'][$check_value],
					'no_of_newborns_received'=>$post_val['no_of_newborns_received'][$check_value],
					'Quarter'=>$post_val['q_id'],
					'updated_by'=>  (isset($_SESSION['memberID'])),
                    'updated_date'=> $this->input->post(date('updated_date'))											
			  	);
					 			
             	$this->db->where('state_id',$post_val['state_id'][$check_value]);
		        $this->db->where('year',$post_val['year_id']);   
				$this->db->where('Quarter',$post_val['q_id']);
                $this->db->update('childhealthmht_master_table', $data);  

                        ///////////// blank value should delete on update ////////
					  
					  if($post_val['no_of_children_screened'][$check_value]=='' && $post_val['no_of_children_received'][$check_value]=='' && $post_val['no_of_newborns_received'][$check_value]=='')
					  {
						  
					$this->db->where('state_id',$post_val['state_id'][$check_value]);
		        $this->db->where('year',$post_val['year_id']);   
				$this->db->where('Quarter',$post_val['q_id']);
                     $this->db->delete('childhealthmht_master_table');
						  
					  }
					  
					  
					  ///////////// end blank value should delete on update ////////				
			}
			else
			{	
		
		           if($post_val['no_of_children_screened'][$check_value]!='' || $post_val['no_of_children_received'][$check_value]!='' || $post_val['no_of_newborns_received'][$check_value]!='' )
					     {
				$data = array
				(	 								
					'state_id'=> $post_val['state_id'][$check_value],					
					'year'=> $post_val['year_id'],				
					'no_of_children_screened'=>$post_val['no_of_children_screened'][$check_value],
					'no_of_children_received'=>$post_val['no_of_children_received'][$check_value],
					'no_of_newborns_received'=>$post_val['no_of_newborns_received'][$check_value],
					'Quarter'=>$post_val['q_id'],
					'updated_by'=>  (isset($_SESSION['memberID']))											
			  	);				 
					 $this->db->insert('childhealthmht_master_table', $data);						
			}	

			}			
		}					
	}	
}
	
	public function get_ChMHT_State($f_year,$f_quarter)
    {
		global $db;
        $query = "Select m_state.*,childhealthmht_master_table.* from m_state LEFT JOIN childhealthmht_master_table on (m_state.State_ID=childhealthmht_master_table.state_id and childhealthmht_master_table.year='".$f_year."'  and childhealthmht_master_table.Quarter='".$f_quarter."') order by m_state.State_Name" ;
			
        $stmt = $db->query($query);
        return $stmt->fetchAll(); 
	}
	
	public function get_ChMHT_State_ajax($f_year,$f_quarter)
    {	
		global $db;
        $query = "Select m_state.*,childhealthmht_master_table.* from m_state LEFT JOIN childhealthmht_master_table on (m_state.State_ID=childhealthmht_master_table.state_id and childhealthmht_master_table.year='".$f_year."' and childhealthmht_master_table.Quarter='".$f_quarter."')  order by m_state.State_Name" ;
				
	    $statement = $db->prepare($query);
		if($statement->execute())
	    {
		 	while($row = $statement->fetch(PDO::FETCH_ASSOC))
		 	{
			  $data[] = $row;
	    	}
		}
			 
		return $data; 		
        //return $stmt->fetchAll(); 	
	}
}

