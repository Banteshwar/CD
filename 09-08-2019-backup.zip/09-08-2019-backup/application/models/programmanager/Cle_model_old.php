<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Cle_model extends MY_Model {

    public function __construct() {
       global $db;
    
        parent::__construct();
    }  
	
	public function insertdata($tbl_name,$value){
        if($this->db->insert($tbl_name, $value)){
            return true;
        }else{
            return false;
        }
    }
    //Update
    public function updatedata($tbl_name,$values,$condition=""){
        if($condition!=''){
            foreach($condition as $key=>$value){
                $this->db->where($key, $value);
            }
        }
        $this->db->update($tbl_name ,$values);
        return true;
    }
    //Delete
    public function deletedata($tbl_name,$condition=""){
        if($condition!=''){
            foreach($condition as $key=>$value){
                $this->db->where($key, $value);
            }
        }
        $this->db->delete($tbl_name);
        return true;
    }
    //Fetch Where
    public function fetchwhere($tbl_name,$andwherecondition="",$orwherecondition="",$type=""){
        $this->db->select('*');
        $this->db->from($tbl_name);
		$this->db->order_by('id','desc');
        if($andwherecondition!=''){
            foreach($andwherecondition as $key=>$value){
                $this->db->where($key, $value);
            }
        }
        if($orwherecondition!=''){
            foreach($orwherecondition as $key=>$value){
                $this->db->or_where($key, $value);
            }
        }
        $query = $this->db->get();
        if($query->num_rows()>0){
            if($type!=''){
                return $query->row_array();
            }else{
                return $query->result_array();
            }
        }else{
            return false;
        }
    }
	
	public function get_state(){ 
            global $db;
            $query = "Select * from m_state order by State_Name" ;
            $stmt = $db->query($query); 
            return $stmt->fetchAll(); 
	}
	
	public function get_cle_establish(){
		global $db;
		$sql     =  "Select * from cle_clinical_establishment order by statename";
		$stmt = $db->query($sql); 
        return $stmt->fetchAll(); 
	}
	public function get_cle_registered(){
		global $db;
		$sql     =  "Select * from cle_registered order by statename";
		$stmt = $db->query($sql); 
        return $stmt->fetchAll(); 
	}
	
	public function get_cle_notadopted(){
		global $db;
		$sql     =  "Select * from cle_state_notadopted order by statename";
		$stmt = $db->query($sql); 
        return $stmt->fetchAll(); 
	}
	
	public function get_treatment_guidelines(){
		global $db;
		$sql     =  "Select * from cle_treatment_guidelines";
		$stmt = $db->query($sql); 
        return $stmt->fetchAll(); 
	}
	
	
	
	
}
