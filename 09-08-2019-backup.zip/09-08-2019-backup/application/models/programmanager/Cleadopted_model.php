<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Cleadopted_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
   
public function saveAmbulances($post_val)
    {
                
        if(count($post_val['check'])>0){
            foreach($post_val['check'] as $check_value){

        ///////// check value allready exist ///////
        
        $this->db->where('rowid',$post_val['rowid'.$check_value][0]);
        $this->db->where('year',$post_val['year_id']);
        
        $this->db->from("cle_clinical_establishment");
        $count_val = $this->db->count_all_results(); 
        
        if($count_val>0){                        
          $data = array(
                    
              'state_id'             =>  $post_val['state_id'.$check_value][0],
              'updated_by'           =>  (isset($_SESSION['memberID']))
                                              
            );                   
                    $this->db->where('rowid',$post_val['rowid'.$check_value][0]);
                    $this->db->where('year',$post_val['year_id']);
                    $this->db->update('cle_clinical_establishment', $data);

            ///////////// blank value should delete on update ////////
            
            if($post_val['state_id'.$check_value][0]=='0')
            {
              
              $this->db->where('rowid',$post_val['rowid'.$check_value][0]);
              $this->db->where('year',$post_val['year_id']);
              $this->db->delete('cle_clinical_establishment');
              
            }
                              
          }else{

          if(!empty($post_val['state_id'.$check_value][0]) && $post_val['state_id'.$check_value][0]!='0' ){
        
                    $data = array(                                         
                        'state_id'=> $post_val['state_id'.$check_value][0],
                        'year'=> $post_val['year_id'],
                        'rowid' =>$post_val['rowid'.$check_value][0],                    
                        'updated_by'=>  (isset($_SESSION['memberID']))
                    );
                    // echo "<pre>";print_r($data); die;
                     $this->db->insert('cle_clinical_establishment', $data);
      
              }
            }
          }
                 
       }
        
    }
    
    public function get_Ambulances_State($f_year){
        
      global $db;
      $query = "Select m_state.*,cle_clinical_establishment.* from m_state LEFT JOIN cle_clinical_establishment on (m_state.State_ID=cle_clinical_establishment.state_id and cle_clinical_establishment.year='".$f_year."' ) order by m_state.State_Name" ;
        
    $statement = $db->prepare($query);

    if($statement->execute()){
      while($row = $statement->fetch(PDO::FETCH_ASSOC)){

        $data[$row['rowid']] = $row;
      }
    }   
    return $data;
    }
    
  public function get_Ambulances_State_ajax($f_year){

    $data=array();

    global $db;
    $query = "Select * from cle_clinical_establishment where year='".$f_year."' " ;     

    $statement = $db->prepare($query);

    if($statement->execute()){
      while($row = $statement->fetch(PDO::FETCH_ASSOC)){
         $data[] = $row;
      }
    }
    else
    {
      $data[]='';
    }
    return $data; 
            //return $stmt->fetchAll(); 
  }

    public function getstate(){  
      global $db;
      $query = "Select * from m_state" ;
      $stmt = $db->query($query);
      return $stmt->fetchAll(); 
    }
       
}

