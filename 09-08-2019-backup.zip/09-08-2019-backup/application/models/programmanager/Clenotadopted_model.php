<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Clenotadopted_model extends CI_Model 
{
    public function __construct(){
        parent::__construct();
    } 

    //---------START Immunization CRUD FUNCTIONS-------->
  public function saveCle($post_val){		
		
	if(count($post_val['check'])>0){				
					 
		foreach($post_val['check'] as $check_value){
				
		$this->db->where('state_id',$post_val['state_id'][$check_value]);
		$this->db->where('year',$post_val['year_id']);		
        $this->db->from("cle_state_notadopted");
        $count_val = $this->db->count_all_results(); 
		
          if($count_val>0){
				
			$data = array(			
			'type'				=>		$post_val['type'.$check_value][0],
			'updated_by'		=>  	(isset($_SESSION['memberID']))										
	  	     );
	  	     			
              $this->db->where('state_id',$post_val['state_id'][$check_value]);
              $this->db->where('year',$post_val['year_id']);              
              $this->db->update('cle_state_notadopted', $data);		
				
			}else{

				$data = array(	 									
					'state_id'			=> $post_val['state_id'][$check_value],					
					'year'				=> $post_val['year_id'],					
					'type'				=> $post_val['type'.$check_value][0],
					'updated_by'		=> (isset($_SESSION['memberID']))								
			  	     );
					 $this->db->insert('cle_state_notadopted', $data);
						
					 }		
					}					
				  }			
    		    }
	
	public function get_Cle_State($f_year){

		global $db; 
		$query = "Select m_state.*,cle_state_notadopted.* from m_state LEFT JOIN cle_state_notadopted on (m_state.State_ID=cle_state_notadopted.state_id and cle_state_notadopted.year='".$f_year."' ) order by m_state.State_Name" ;

		$stmt = $db->query($query);
		return $stmt->fetchAll(); 
	}

	public function get_Cle_State_ajax($f_year){		
		global $db;
	    $query = "Select m_state.*,cle_state_notadopted.* from m_state LEFT JOIN cle_state_notadopted on (m_state.State_ID=cle_state_notadopted.state_id and cle_state_notadopted.year='".$f_year."')  order by m_state.State_Name" ; 
				$statement = $db->prepare($query);
			
			if($statement->execute()){
				 while($row = $statement->fetch(PDO::FETCH_ASSOC)){
				  $data[] = $row;
				 }
			}
				 
		return $data;
	}
   
}