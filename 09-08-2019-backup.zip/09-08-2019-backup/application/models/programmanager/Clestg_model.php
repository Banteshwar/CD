<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Clestg_model extends CI_Model 
{
    public function __construct(){
        parent::__construct();
    } 

    //---------START Immunization CRUD FUNCTIONS-------->
  public function saveCle($post_val){		
		
	if(count($post_val['check'])>0){				
					 
		foreach($post_val['check'] as $check_value){
				
		$this->db->where('state_id',$post_val['state_id'][$check_value]);
		$this->db->where('year',$post_val['year_id']);		
        $this->db->from("cle_treatment_guidelines");
        $count_val = $this->db->count_all_results(); 
		
          if($count_val>0){
			  
				
			$data = array(			
			'allopathic'		=>		$post_val['allopathic'][$check_value],
			'ayush'				=>		$post_val['ayush'][$check_value],			
			'updated_by'		=>  	(isset($_SESSION['memberID']))
											
	  	     );			 
			
              $this->db->where('state_id',$post_val['state_id'][$check_value]);
              $this->db->where('year',$post_val['year_id']);              
              $this->db->update('cle_treatment_guidelines', $data);	

             ///////////// blank value should delete on update ////////
					  
					  if($post_val['allopathic'][$check_value]=='' && $post_val['ayush'][$check_value]=='')
					  {
						  
					   $this->db->where('state_id',$post_val['state_id'][$check_value]);
                        $this->db->where('year',$post_val['year_id']);    
                          $this->db->delete('cle_treatment_guidelines');
						  
					  }
					  
					  
					  ///////////// end blank value should delete on update ////////			  
				
			}else{
				
				 if($post_val['allopathic'][$check_value]!='' || $post_val['ayush'][$check_value]!='')
						{	

				$data = array(	 									
					'state_id'			=> 		$post_val['state_id'][$check_value],					
					'year'				=> 		$post_val['year_id'],
					'allopathic'		=>		$post_val['allopathic'][$check_value],
					'ayush'				=>		$post_val['ayush'][$check_value],
					'updated_by'		=>  	(isset($_SESSION['memberID']))						
			  	     );					 
					 $this->db->insert('cle_treatment_guidelines', $data);
						
					 }
			}					 
					}					
				  }			
    		    }
	
	public function get_Cle_State($f_year){

		global $db; 
		$query = "Select m_state.*,cle_treatment_guidelines.* from m_state LEFT JOIN cle_treatment_guidelines on (m_state.State_ID=cle_treatment_guidelines.state_id and cle_treatment_guidelines.year='".$f_year."' ) order by m_state.State_Name" ;

		$stmt = $db->query($query);
		return $stmt->fetchAll(); 
	}

	public function get_Cle_State_ajax($f_year){		
		global $db;
	    $query = "Select m_state.*,cle_treatment_guidelines.* from m_state LEFT JOIN cle_treatment_guidelines on (m_state.State_ID=cle_treatment_guidelines.state_id and cle_treatment_guidelines.year='".$f_year."')  order by m_state.State_Name" ; 
				$statement = $db->prepare($query);
			
			if($statement->execute()){
				 while($row = $statement->fetch(PDO::FETCH_ASSOC)){
				  $data[] = $row;
				 }
			}
				 
		return $data;
	}
   
}