<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Community_process2_model extends MY_Model {

    public function __construct() {
       global $db;
    
        parent::__construct();
    }  
		
	public function saveCommunity($post_val)
    {
		
		
		if(count($post_val['check'])>0)

				 {
					foreach($post_val['check'] as $check_value)
					{
		///////// check value allready exist ///////
		
		 $this->db->where('state_id',$post_val['state_id'][$check_value]);
		$this->db->where('year',$post_val['year_id']);
		 $this->db->where('Quarter',$post_val['q_id']);
		
        $this->db->from("community_process");
        $count_val = $this->db->count_all_results(); 
		
		          if($count_val>0)
                    {
						
						$data = array
				        (	 				
					
					
					'Number_of_VHNSCs_formed'=>$post_val['Number_of_VHNSCs_formed'][$check_value],
					'number_of_villages'=>$post_val['number_of_villages'][$check_value],
					'Number_of_RKSs'=>$post_val['Number_of_RKSs'][$check_value],
					'total_number_of_PHC_CHC_SDH_DH'=>$post_val['total_number_of_PHC_CHC_SDH_DH'][$check_value],
					'No_of_ASHAs_in_position'=>$post_val['No_of_ASHAs_in_position'][$check_value],  
					'approved'=>$post_val['approved'][$check_value],
					'ASha_As_whose_honorarium'=>$post_val['ASha_As_whose_honorarium'][$check_value],
					'number_of_MAS_created'=>$post_val['number_of_MAS_created'][$check_value],
					'number_of_MAS_approved'=>$post_val['number_of_MAS_approved'][$check_value],
					'updated_by'=>  (isset($_SESSION['memberID']))
													
			  	     );
					 
					
                    $this->db->where('state_id',$post_val['state_id'][$check_value]);
		            $this->db->where('year',$post_val['year_id']);
		            $this->db->where('Quarter',$post_val['q_id']);
                    $this->db->update('community_process', $data);
					
					 ///////////// blank value should delete on update ////////
					  
					  if($post_val['Number_of_VHNSCs_formed'][$check_value]=='' && $post_val['number_of_villages'][$check_value]=='' && $post_val['Number_of_RKSs'][$check_value]=='' && $post_val['total_number_of_PHC_CHC_SDH_DH'][$check_value]=='' && $post_val['No_of_ASHAs_in_position'][$check_value]=='' && $post_val['approved'][$check_value]=='' && $post_val['ASha_As_whose_honorarium'][$check_value]=='' && $post_val['number_of_MAS_created'][$check_value]==''&& $post_val['number_of_MAS_approved'][$check_value]=='')
					  {
						  
					$this->db->where('state_id',$post_val['state_id'][$check_value]);
		            $this->db->where('year',$post_val['year_id']);
		            $this->db->where('Quarter',$post_val['q_id']);
                          $this->db->delete('community_process');
						  
					  }
					  
					  
					  ///////////// end blank value should delete on update ////////
				
				
						
					}
					else
					{
						
						if($post_val['Number_of_VHNSCs_formed'][$check_value]!='' || $post_val['number_of_villages'][$check_value]!='' || $post_val['Number_of_RKSs'][$check_value]!='' || $post_val['total_number_of_PHC_CHC_SDH_DH'][$check_value]!='' || $post_val['No_of_ASHAs_in_position'][$check_value]!='' || $post_val['approved'][$check_value]!='' || $post_val['ASha_As_whose_honorarium'][$check_value]!=''|| $post_val['number_of_MAS_created'][$check_value]!=''|| $post_val['number_of_MAS_approved'][$check_value]!='')
						{	
						
						$data = array
				        (	 				
					
					'state_id'=> $post_val['state_id'][$check_value],
					
					'year'=> $post_val['year_id'],
					'Quarter'=> $post_val['q_id'],
					'Number_of_VHNSCs_formed'=>$post_val['Number_of_VHNSCs_formed'][$check_value],
					'number_of_villages'=>$post_val['number_of_villages'][$check_value],
					'Number_of_RKSs'=>$post_val['Number_of_RKSs'][$check_value],
					'total_number_of_PHC_CHC_SDH_DH'=>$post_val['total_number_of_PHC_CHC_SDH_DH'][$check_value],
					'No_of_ASHAs_in_position'=>$post_val['No_of_ASHAs_in_position'][$check_value],
					'approved'=>$post_val['approved'][$check_value],
					'ASha_As_whose_honorarium'=>$post_val['ASha_As_whose_honorarium'][$check_value],
					'number_of_MAS_created'=>$post_val['number_of_MAS_created'][$check_value],
					'number_of_MAS_approved'=>$post_val['number_of_MAS_approved'][$check_value],
					'updated_by'=>  (isset($_SESSION['memberID']))
													
			  	     );
					 
					 $this->db->insert('community_process', $data);
						
					}
					}
		
					}
					
				 }
		
		
		
    }
	
	public function get_Community_State($f_year,$f_quarter)
    {
		
		 global $db;
		 
		
            $query = "Select m_state.*,community_process.* from m_state LEFT JOIN community_process on (m_state.State_ID=community_process.state_id and community_process.year='".$f_year."' and community_process.Quarter='".$f_quarter."') order by m_state.State_Name" ;
			
		
		

             $stmt = $db->query($query);
			 		
  
  
            return $stmt->fetchAll(); 
			
			
		
	}
	
	public function get_Community_State_ajax($f_year,$f_quarter)
    {
		
		 global $db;
            $query = "Select m_state.*,community_process.* from m_state LEFT JOIN community_process on (m_state.State_ID=community_process.state_id and community_process.year='".$f_year."' and community_process.Quarter='".$f_quarter."')  order by m_state.State_Name" ;
			
			
			
			
			$statement = $db->prepare($query);
		
		                 if($statement->execute())
{
 while($row = $statement->fetch(PDO::FETCH_ASSOC))
 {
  $data[] = $row;
 }
}
			 
return $data; 		
			 		

  
            //return $stmt->fetchAll(); 
		
	}
	
	
	
	
	
	


}
