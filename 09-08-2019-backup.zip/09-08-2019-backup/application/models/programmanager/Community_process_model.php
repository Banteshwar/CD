<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Community_process_model extends CI_Model {

    public function __construct() {
      
    
        parent::__construct();
    }  
    public function cp_list(){

     $this->db->select('community_process.*,m_state.state_name');
          $this->db->from('community_process');

     $this->db->join('m_state','m_state.state_ID=community_process.state_id');
     
     $this->db->order_by("community_process.id", "desc");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   
    /*global $db;
    $stmt = $db->query('select n.* , s.* from notto_master_tbl as n inner join m_state as s on  n.state_id = s.state_id order by n.id desc'); 
        return $stmt->fetchAll(); 
*/
   } 
    public function chkcp($state,$year,$Quarter)
    {
        
       

        $this->db->where('state_id',$state);
        $this->db->where('year',$year);

        $this->db->where('Quarter',$Quarter);
        $this->db->from("community_process");
        return $this->db->count_all_results();

        // echo $this->db->last_query(); die;echo $this->db->last_query(); die;

 
    }
    public function insertcp($data)
    {
        return $this->db->insert('community_process',$data);
    }
    public function cp_edit_show($id){

    return $result = $this->db->select('community_process.*')->where("community_process.id",$id)->get("community_process",1)->result();
}

public function cp_update_data($id,$data)
  {
    $where = array('id ' => $id);
    $this->db->where($where);
    return $this->db->update('community_process',$data);
  }
  
  
   
  

}

    
   