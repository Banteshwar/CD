<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Ddapnew_model extends MY_Model {

    public function __construct() {
       global $db;
    
        parent::__construct();
    }  
     public function saveAmbulances($post_val){
	

	
	//echo count($post_val['check']); die;
    	
        
        if(count($post_val['check'])>0){

			foreach($post_val['check'] as $check_value){
				//var_dump($check_value);
				/*echo $post_val['rowid'.$check_value][0]."<br>";
				echo $post_val['year_id']."<br>";
				echo $post_val['q_id']."<br>";die;*/
				///////// 	check value allready exist ///////
				
			   // $this->db->where('rowid',$post_val['rowid'.$check_value][0]);
				$this->db->where('e_year',$post_val['year_id']);
				$this->db->where('e_quarter',$post_val['q_id']);
				$this->db->where('state_id',$post_val['state_id'][$check_value]); 
				$this->db->from("tbl_center");
				

				$count_val = $this->db->count_all_results(); 
				//echo $this->db->last_query();die;   
				if($count_val>0){
							   
				  $data = array(
				  
					   'state_id'=> $post_val['state_id'][$check_value],
							
					  'name_hospital'=>$post_val['name_hospital'.$check_value],
                        'new_reg'=>$post_val['new_reg'][$check_value],
                        'Follow_up'=>$post_val['Follow_up'][$check_value],
                        'Total'=>$post_val['Total'][$check_value],
                        'No_of_persons_IPD'=>$post_val['No_of_persons_IPD'][$check_value],
					  //'Labs_reporting_AMR_surveillance_data'             =>  $post_val['Labs_reporting_AMR_surveillance_data'.$check_value][0],
					  'updated_by'           =>  (isset($_SESSION['memberID']))
													  
					);
					//print_r($data);
		//          var_dump($data);die;                   
							$this->db->where('state_id',$post_val['state_id'][$check_value]);
							$this->db->where('e_year',$post_val['year_id']);
							$this->db->where('e_quarter',$post_val['q_id']);
							$this->db->update('tbl_center', $data);

					///////////// blank value should delete on update ////////
					
					//echo $post_val['vaccine_total'.$check_value][0]; die;
					
					if((
					$post_val['state_id'][$check_value]== '' &&
					$post_val['new_reg'][$check_value]== '' &&
					$post_val['Follow_up'][$check_value]== '' &&
					$post_val['Total'][$check_value]== '' &&
					$post_val['name_hospital'.$check_value]=='Not Reported'))
					{
									  
					 //$this->db->where('rowid',$post_val['rowid'.$check_value][0]);
					 $this->db->where('state_id',$post_val['state_id'][$check_value]);
					 $this->db->where('e_year',$post_val['year_id']);
					 $this->db->where('e_quarter',$post_val['q_id']);
					 $this->db->delete('tbl_center');
					  
					}
				
				
			 
					  
				}else{    ///////////// end blank value should delete on update ////////
				//echo "<pre>"; echo $post_val['name_hospital'.$check_value];
					//die('Insert');
				   if($post_val['state_id'][$check_value]!='' ){
					 
						if($post_val['new_reg'][$check_value]!='' ||
						$post_val['Follow_up'][$check_value]!='' || 
						$post_val['name_hospital'.$check_value]!='Not Reported' ||
						$post_val['Total'][$check_value]!='' || 
						$post_val['No_of_persons_IPD'][$check_value]!='' ) {             

							$data = array(
							
								'name_hospital'=>$post_val['name_hospital'.$check_value],
								'new_reg'=>$post_val['new_reg'][$check_value],
								'Follow_up'=>$post_val['Follow_up'][$check_value],
								'Total'=>$post_val['Total'][$check_value],
								'No_of_persons_IPD'=>$post_val['No_of_persons_IPD'][$check_value],
								
								'state_id'=> $post_val['state_id'][$check_value],
								'e_year'=> $post_val['year_id'],
								'e_quarter'=> $post_val['q_id'],                 
						  
								'updated_by'=>  (isset($_SESSION['memberID']))
							);
							 //echo "<pre>";print_r($data); die;
							 $this->db->insert('tbl_center', $data);
								
						 }
					}
				}
			}
                    
        }
        
        
        
    }
    
   
    public function saveAmbulancespre($post_val){  

        if(count($post_val['check'])>0)
            {
               foreach($post_val['check'] as $check_value){
        ///////// check value allready exist ///////        
                        $this->db->where('state_id',$post_val['state_id'][$check_value]);
                        $this->db->where('e_year',$post_val['year_id']);
                        $this->db->where('e_quarter',$post_val['q_id']);
                
                        $this->db->from("tbl_center");
                        $count_val = $this->db->count_all_results(); 
        
                      if($count_val>0)
                        {
							echo "in============================================"; 
                            print_r($post_val);
                            $data = array
                            (                   
                        
                        
                        'name_hospital'=>$post_val['name_hospital'.$check_value],
                        'new_reg'=>$post_val['new_reg'][$check_value],
                        'Follow_up'=>$post_val['Follow_up'][$check_value],
                        'Total'=>$post_val['Total'][$check_value],
                        'No_of_persons_IPD'=>$post_val['No_of_persons_IPD'][$check_value],
                        
                        'updated_by'=>  (isset($_SESSION['memberID']))
                                                        
                         );
                         
                        
                            $this->db->where('state_id',$post_val['state_id'][$check_value]);
                           $this->db->where('e_year',$post_val['year_id']);
                            $this->db->where('e_quarter',$post_val['q_id']);
                          $this->db->update('tbl_center', $data);
                          
                           ///////////// blank value should delete on update ////////
                         
                          if($post_val['name_hospital'.$check_value]=='0' && $post_val['new_reg'][$check_value]=='' && $post_val['Follow_up'][$check_value]=='' && $post_val['Total'][$check_value]=='' && $post_val['No_of_persons_IPD'][$check_value]=='')
                          {
                          
                       $this->db->where('state_id',$post_val['state_id'][$check_value]);
                       $this->db->where('e_year',$post_val['year_id']);
                        $this->db->where('e_quarter',$post_val['q_id']);
                          $this->db->delete('tbl_center');
                          
                      }
                      
                      
                      ///////////// end blank value should delete on update ////////
                    }
                    else
                    {
						echo "in iffffffffffffffffffffffffffffffffffffffffff<pre>";
print_r($post_val);die;                       
                          if($post_val['name_hospital'.$check_value]!='0' || $post_val['new_reg'][$check_value]!='' || $post_val['Follow_up'][$check_value]!='' || $post_val['Total'][$check_value]!='' || $post_val['No_of_persons_IPD'][$check_value]!='')
                            {   
                          
                            
                            $data = array
                            (                   
                        
                        'state_id'=> $post_val['state_id'][$check_value],
                        
                        'e_year'=> $post_val['year_id'],
                        'e_quarter'=> $post_val['q_id'],
                         
                            'name_hospital'=>$post_val['name_hospital'.$check_value],
                            'new_reg'=>$post_val['new_reg'][$check_value],
                            'Follow_up'=>$post_val['Follow_up'][$check_value],
                            'Total'=>$post_val['Total'][$check_value],
                            'No_of_persons_IPD'=>$post_val['No_of_persons_IPD'][$check_value],
                            'updated_by'=>  (isset($_SESSION['memberID']))
                                                        
                         );
                         
                         $this->db->insert('tbl_center', $data);
                            
                        }
                    }
        
                    }
                    
                 }
        
            }
    
    public function get_Ambulances_State($f_year,$f_quarter)
    {
        
         global $db;
         
        
            $query = "Select m_state.*,tbl_center.* from m_state LEFT JOIN tbl_center on (m_state.State_ID=tbl_center.state_id and tbl_center.e_year='".$f_year."' and tbl_center.e_quarter='".$f_quarter."') order by m_state.State_Name" ;
             $stmt = $db->query($query);  
  
            return $stmt->fetchAll(); 
        
    }
    
    public function get_Ambulances_State_ajax($f_year,$f_quarter)
    {
        
         global $db;
            $query = "Select m_state.*,tbl_center.* from m_state LEFT JOIN tbl_center on (m_state.State_ID=tbl_center.state_id and tbl_center.e_year='".$f_year."' and tbl_center.e_quarter='".$f_quarter."')  order by m_state.State_Name" ;
            
            
            
            
            $statement = $db->prepare($query);
        
                         if($statement->execute())
{
 while($row = $statement->fetch(PDO::FETCH_ASSOC))
 {
  $data[] = $row;
 }
}
             
return $data;       
                    

  
            //return $stmt->fetchAll(); 
        
    }
    
    
    
    
    
    


}
