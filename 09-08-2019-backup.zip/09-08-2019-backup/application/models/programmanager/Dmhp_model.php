<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Dmhp_model extends MY_Model {

    public function __construct() {
       global $db;
    
        parent::__construct();
    }  
        
    public function saveNcdc($post_val)
    {
        
        
        if(count($post_val['check'])>0)

                 {
                    foreach($post_val['check'] as $check_value)
                    {
        ///////// check value allready exist ///////
        
         $this->db->where('statename',$post_val['state_id'][$check_value]);
        $this->db->where('e_year',$post_val['year_id']);
         $this->db->where('e_quarter',$post_val['q_id']);
        
        $this->db->from("tbl_dmhp");
        $count_val = $this->db->count_all_results(); 
        
                  if($count_val>0)
                    {
                        
                        $data = array
                        (                   
                    
                         
                           'num_district'=>$post_val['num_district'][$check_value],
                            'num_district_cover'=>$post_val['num_district_cover'][$check_value],
                            'fund'=>$post_val['fund'][$check_value],
                            'expenditure'=>$post_val['expenditure'][$check_value],
                    
                    
                    
                                                    
                     );
                     
                    
                        $this->db->where('statename',$post_val['state_id'][$check_value]);
                        $this->db->where('e_year',$post_val['year_id']);
                        $this->db->where('e_quarter',$post_val['q_id']);
                        $this->db->update('tbl_dmhp', $data);
						
		        ///////////// blank value should delete on update ////////
					  
					  if($post_val['num_district'][$check_value]=='' && $post_val['num_district_cover'][$check_value]=='' && $post_val['fund'][$check_value]=='' && $post_val['expenditure'][$check_value]=='')
					  {
						  
					 $this->db->where('statename',$post_val['state_id'][$check_value]);
                        $this->db->where('e_year',$post_val['year_id']);
                        $this->db->where('e_quarter',$post_val['q_id']);
                          $this->db->delete('tbl_dmhp');
						  
					  }
					  
					  
					  ///////////// end blank value should delete on update ////////
                
                
                        
                    }
                    else
                    {
						
						/// blank value should not insert in table //////	
						
                        if($post_val['num_district'][$check_value]!='' || $post_val['num_district_cover'][$check_value]!='' || $post_val['fund'][$check_value]!='' || $post_val['expenditure'][$check_value]!='')
						{	
                        
                        $data = array
                        (                   
                    
                            'statename'=> $post_val['state_id'][$check_value],
                            
                            'e_year'=> $post_val['year_id'],
                            'e_quarter'=> $post_val['q_id'],

                            'num_district'=>$post_val['num_district'][$check_value],
                            'num_district_cover'=>$post_val['num_district_cover'][$check_value],
                            'fund'=>$post_val['fund'][$check_value],
                            'expenditure'=>$post_val['expenditure'][$check_value],
                            
                    
                    
                                                    
                        );
                     
                     $this->db->insert('tbl_dmhp', $data);
                        
                    }
					}
        
                    }
                    
                 }
        
        
        
    }
    
    public function get_ncdc_State($f_year,$f_quarter)
    { 
        
         global $db;
         
        
            $query = "Select m_state.*,tbl_dmhp.* from m_state LEFT JOIN tbl_dmhp on (m_state.State_ID=tbl_dmhp.statename and tbl_dmhp.e_year='".$f_year."' and tbl_dmhp.e_quarter='".$f_quarter."') order by m_state.State_Name" ;
            
        
        

             $stmt = $db->query($query);
                    
  
  
            return $stmt->fetchAll(); 
            
            
        
    }
	
	
	public function get_DMHP(){
		global $db;
		$query = "Select * from tbl_dmhp" ;
		$stmt = $db->query($query); 
		return $stmt->fetchAll(); 
	}
    
    public function get_Ambulances_State_ajax($f_year,$f_quarter)
    {
        
         global $db;
            $query = "Select m_state.*,tbl_dmhp.* from m_state LEFT JOIN tbl_dmhp on (m_state.State_ID=tbl_dmhp.statename and tbl_dmhp.e_year='".$f_year."' and tbl_dmhp.e_quarter='".$f_quarter."')  order by m_state.State_Name" ;
            
            
            
            
            $statement = $db->prepare($query);
        
                         if($statement->execute())
{
 while($row = $statement->fetch(PDO::FETCH_ASSOC))
 {
  $data[] = $row;
 }
}
             
return $data;       
                    

  
            //return $stmt->fetchAll(); 
        
    }
    
    
    
    
    
    


}
