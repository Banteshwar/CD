<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Emrdhmcbrn_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
   


public function saveAmbulances($post_val)
    {
        
        
        if(count($post_val['check'])>0)

                 {
                    foreach($post_val['check'] as $check_value)
                    {
        ///////// check value allready exist ///////
        
        // $this->db->where('state_id',$post_val['state_id'][$check_value]);
                       $this->db->where('rowid',$post_val['rowid'.$check_value][0]);
        $this->db->where('year',$post_val['year_id']);
        
        
        $this->db->from("emr_dhm_cbrn_master_table");
        $count_val = $this->db->count_all_results(); 
        
                  if($count_val>0)
                    {
                        
                        $data = array
                        (                   
                    
                    'state_id'             =>  $post_val['state_id'.$check_value][0],
                    'centre_name'=>$post_val['centre_name'][$check_value],
                    'status'=>$post_val['status'.$check_value][0],
                    
                    'updated_by'=>  (isset($_SESSION['memberID']))
                                                    
                     );
                     
                    $this->db->where('rowid',$post_val['rowid'.$check_value][0]);
                      //  $this->db->where('state_id',$post_val['state_id'][$check_value]);
                       $this->db->where('year',$post_val['year_id']);
                        
                      $this->db->update('emr_dhm_cbrn_master_table', $data);
                
                 ///////////// blank value should delete on update ////////
            
            if(($post_val['centre_name'][$check_value]=='' && $post_val['status'][$check_value]=='') || $post_val['state_id'.$check_value][0]=='0')
            {
              
             $this->db->where('rowid',$post_val['rowid'.$check_value][0]);
                    $this->db->where('year',$post_val['year_id']);
                          $this->db->delete('emr_dhm_cbrn_master_table');
              
            }
            
            
            ///////////// end blank value should delete on update ////////
                        
                    }
                    else
                    {
                     
                  if(!empty($post_val['state_id'.$check_value][0]) && $post_val['state_id'.$check_value][0]!='0' ){
                     if($post_val['centre_name'][$check_value]!='' || $post_val['status'.$check_value][0]!='0')
                  {       
                        $data = array
                        ( 

                        'state_id'=> $post_val['state_id'.$check_value][0],
                        'year'=> $post_val['year_id'],
                        'rowid' =>$post_val['rowid'.$check_value][0], 
                    
                        'centre_name'=>$post_val['centre_name'][$check_value],
                        'status'=>$post_val['status'.$check_value][0],
                        'updated_by'=>  (isset($_SESSION['memberID']))
                                                    
                     );
                     
                     $this->db->insert('emr_dhm_cbrn_master_table', $data);
                      }        
                    }
                  }
              }
                    
            }
                
        
    }
    
    public function get_Ambulances_State($f_year)
    {
        
         global $db;
         
        
            $query = "Select m_state.*,emr_dhm_cbrn_master_table.* from m_state LEFT JOIN emr_dhm_cbrn_master_table on (m_state.State_ID=emr_dhm_cbrn_master_table.state_id and emr_dhm_cbrn_master_table.year='".$f_year."' ) order by m_state.State_Name" ;
            
        
         $statement = $db->prepare($query);

    if($statement->execute()){
      while($row = $statement->fetch(PDO::FETCH_ASSOC)){

        $data[$row['rowid']] = $row;
      }
    }
            
      return $data;         
        
    }
    
   /* public function get_Ambulances_State_ajax($f_year)
    {
        
         global $db;
            $query = "Select m_state.*,emr_dhm_cbrn_master_table.* from m_state LEFT JOIN emr_dhm_cbrn_master_table on (m_state.State_ID=emr_dhm_cbrn_master_table.state_id and emr_dhm_cbrn_master_table.year='".$f_year."')  order by m_state.State_Name" ;
            
            
            
            
            $statement = $db->prepare($query);
        
                         if($statement->execute())
{
 while($row = $statement->fetch(PDO::FETCH_ASSOC))
 {
  $data[] = $row;
 }
}
             
return $data;       
                    

        
    }*/
    

     public function get_Ambulances_State_ajax($f_year){

    $data=array();

    global $db;
    $query = "Select * from emr_dhm_cbrn_master_table where year='".$f_year."' " ;     

    $statement = $db->prepare($query);

    if($statement->execute()){
      while($row = $statement->fetch(PDO::FETCH_ASSOC)){
         $data[] = $row;
      }
    }
    else
    {
      $data[]='';
    }
    return $data; 
            //return $stmt->fetchAll(); 
  }
  

    public function getstate()
    {  
      global $db;
      $query = "Select * from m_state" ;
      $stmt = $db->query($query);
      return $stmt->fetchAll(); 
    }
    

   
}

