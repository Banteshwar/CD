<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Emrdhmtrained_model extends CI_Model 
{
    public function __construct() 
    {
        parent::__construct();
    }
 
    //---------START EMR Skill Centre CRUD FUNCTIONS-------->
    public function insert_emrdhmtrained($data,$table)
    {
        return $this->db->insert($table, $data);
    }

    public function update_emrdhmtrained($id,$data)
    {
        $where = array('id ' => $id);
        $this->db->where($where);
        return $this->db->update('emr_dhm_personneltrained_master_table', $data);
    }

    public function emrdhmtrained_list()
    {
        $this->db->select('emr_dhm_personneltrained_master_table.*,m_state.State_Name');
        $this->db->from('emr_dhm_personneltrained_master_table');
        $this->db->join('m_state','m_state.State_ID=emr_dhm_personneltrained_master_table.state_id','inner');
        $this->db->order_by("emr_dhm_personneltrained_master_table.id", "desc");

        $query = $this->db->get();

        if ($query->num_rows() > 0) 
        {
            foreach ($query->result() as $row) 
            {
                $data[] = $row;
            }
            return $data;
        }
        return false;
    } 
     
    public function getNLES_byId($id)
    {
        return $result = $this->db->select('emr_dhm_personneltrained_master_table.*')->where("emr_dhm_personneltrained_master_table.id",$id)->get("emr_dhm_personneltrained_master_table",1)->result();
    }

   //---------END EMR Skill Centre CRUD FUNCTIONS---------->
}